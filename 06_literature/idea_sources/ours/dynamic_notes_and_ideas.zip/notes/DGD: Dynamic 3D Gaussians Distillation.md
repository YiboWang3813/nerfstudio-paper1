# DGD: Dynamic 3D Gaussians Distillation

## 0. Metadata

- Title: DGD: Dynamic 3D Gaussians Distillation
- Authors: Isaac Labe; Noam Issachar; Itai Lang; Sagie Benaim
- Venue/Year: ECCV 2024, LNCS / Springer version published 2025
- DOI: `10.1007/978-3-031-73113-6_21`
- URL: https://link.springer.com/10.1007/978-3-031-73113-6_21
- Project page: https://isaaclabe.github.io/DGD-Website/
- Zotero item key: `ZGY8WGAI`
- Zotero PDF attachment key: `ZTBUN5HI`
- Duplicate PDF attachment key: `RTFHNIAM`
- PDF path: `/Users/wangyibo/Zotero/storage/ZTBUN5HI/Labe 等 - 2025 - DGD Dynamic 3D Gaussians Distillation.pdf`
- Local note path: `notes/DGD: Dynamic 3D Gaussians Distillation.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

DGD 在 Deformable 3D Gaussians 的动态外观/几何表示上为每个 Gaussian 增加 learnable semantic feature，并用 2D foundation-model feature maps 与 RGB 图像联合监督，使单目动态视频能够形成可实时渲染、可文本/点击查询、可跨时间跟踪的 3D semantic Gaussian field。

## 2. Problem Formulation

输入是一段单目视频 $\{I_t\}_{t=1}^{N}$，带有由 SfM 估计的相机内外参和初始稀疏点云。目标不只是动态 NVS，而是学习一个同时包含 geometry、appearance、deformation 和 semantics 的 dynamic 3D representation。用户可以通过 text prompt 或 3D click 指定语义实体，系统需要在 3D 空间和时间上分割并跟踪这些实体。

传统 semantic NeRF / feature distillation 方法主要处理静态场景，渲染慢；动态 3DGS 方法能快速重建和跟踪点，但不支持开放词汇或点击式语义实体跟踪。DGD 的核心问题是：如何把 2D foundation model 的 feature maps lift 到动态 3DGS 上，并让语义监督反过来改善几何/变形优化。

## 3. Method Overview

DGD 以 Deformable 3D Gaussians 风格的 canonical Gaussian set 加 deformation MLP 为基础。每个 Gaussian 有 spatial parameters $(x_i,r_i,s_i)$、appearance parameters $(c_i,\sigma_i)$ 和 semantic feature $f_i$。deformation network $D$ 输入 canonical position 和 time，输出 position、rotation 和 scale offsets，把 canonical Gaussians 变形到目标帧。

训练时，先用 2D feature extractor $F$ 从每帧图像 $I_t$ 得到 feature map $F_t$，例如 CLIP、DINOv2 或 SAM features。渲染时同一组 Gaussians 同时 rasterize RGB image 和 feature map；优化目标同时匹配 ground-truth RGB 与 2D reference features。由于 Gaussian spatial parameters 和 deformation network 同时参与 RGB 与 semantic feature loss，它们会被语义监督共同影响。

## 4. Method Details

### 4.1 Dynamic 3D Gaussian Base

SfM 先提供 camera intrinsics/extrinsics $K_t,E_t$ 和初始稀疏点云 $P$。每个点初始化一个 Gaussian $G(x_i,r_i,s_i,\sigma_i)$，其中 $x_i$ 是中心，$r_i$ 是 quaternion rotation，$s_i$ 是 scale，$\sigma_i$ 是 density/opacity。

deformation MLP $D$ 输入 Gaussian 的位置和当前时间，输出 offsets：

$$
\delta x_i,\delta r_i,\delta s_i=D(\gamma(x_i),\gamma(t)).
$$

目标时间 $t$ 的 Gaussian 变为 $G(x_i+\delta x_i,r_i+\delta r_i,s_i+\delta s_i,\sigma_i)$。$\gamma$ 是 Fourier / frequency encoding。这个动态基础与 Deformable 3DGS 类似。

### 4.2 Feature-Augmented Gaussians

DGD 为每个 Gaussian 额外学习 semantic feature vector $f_i$，同时仍学习颜色 $c_i$。给定 2D feature extractor $F$，每帧有 reference feature map $F_t=F(I_t)$。若 feature map 分辨率低于 RGB，会被上采样到图像分辨率。

对像素 $p$，RGB 与 feature rendering 使用相同 alpha compositing weights：

$$
C(p)=\sum_{i=1}^{N}T_i\alpha_ic_i,\quad F(p)=\sum_{i=1}^{N}T_i\alpha_if_i.
$$

这里 $T_i$ 是 transmittance，$\alpha_i$ 是 Gaussian 在像素处的 opacity contribution。因为颜色和语义 feature 共用同一投影、深度排序和 opacity 权重，所以 feature supervision 会影响哪些 Gaussians 应该占据哪些 3D 空间位置。

### 4.3 Joint RGB-Semantic Optimization

DGD 的关键不是先训练几何再附加语义，而是 joint optimization。Gaussian parameters、colors、features 和 deformation network 都同时被 RGB loss 与 semantic feature loss 更新。这样 spatial parameters、density、covariance 和 deformation 不只拟合像素颜色，也拟合 2D foundation model features。

这种 joint optimization 有两个效果。第一，语义一致的区域在 3D 中更容易聚合到相同实体的 Gaussians。第二，动态变形不仅要让 RGB 对齐，还要让 feature rendering 在每一帧对齐 reference feature map，从而支持跨时间语义跟踪。

### 4.4 3D Semantic Tracking Interface

训练后，用户可以用多种方式选择 Gaussians。若使用 CLIP features，给定 text prompt `txt`，将 CLIP text encoding $E(txt)$ 与每个 Gaussian feature $f_i$ 做 cosine similarity，选择高于阈值的 Gaussians。若使用 DINOv2 features，用户可以点击一个 3D Gaussian，取其 feature，与所有 Gaussians 的 feature 做相似度，选择相似区域。

选中 canonical-space Gaussians 后，在任意时间 $t$ 上通过 deformation network $D$ 变形到该时刻，就得到该语义实体的动态 3D segmentation / tracking。论文还提到可以通过用户选定训练视频中的 pixels，反查对这些 pixels 贡献权重 $T_i\alpha_i$ 高的 Gaussians，但本工作主要实验使用 text 和 3D click 两种。

### 4.5 Semantic Editing

一旦选中某个 semantic entity 对应的 Gaussians，就可以只修改这些 Gaussians 的局部属性。论文把属性分为 spatial parameters、appearance parameters、semantic features 和 deformation network。实验中只做 texture editing：固定选中区域，通过 Stable Diffusion v2.1 的 SDS-like loss 优化选中 Gaussians 的 colors $c_i$，实现例如把 cookie 改成 strawberry 风格。

## 5. Mathematical Objectives and Losses

DGD 的 rendering equations 是双通道的：RGB channel 渲染 $C(p)$，semantic feature channel 渲染 $F(p)$。训练目标可概括为：

$$
L=L_{\mathrm{rgb}}(C_t,I_t)+\lambda_{\mathrm{feat}}L_{\mathrm{feat}}(\hat F_t,F_t),
$$

其中 $\hat F_t$ 是由 Gaussians rasterize 出来的 feature map，$F_t$ 是 2D foundation model reference feature map。论文正文没有给出更细的 loss 展开，但强调 geometry / deformation / appearance / feature parameters 是联合优化的。

对于 semantic selection，核心是 feature-space cosine similarity，而不是额外训练 classifier。对于 editing，使用 diffusion SDS-like reconstruction signal，只优化被选中 Gaussians 的 texture attributes。

## 6. Training and Inference Procedure

训练 40K iterations。前 3K 是 warmup，只训练 static 3D Gaussians，并把 deformation $D$ 固定为 identity。3K 之后联合训练 Gaussian parameters、colors、features 和 deformation field。优化器为 Adam，deformation network 的学习率从 $8e^{-4}$ 指数衰减到 $1.6e^{-6}$，$\beta=(0.9,0.999)$。训练 deformation field 时使用 Deformable 3DGS 中的 annealing smooth training (AST)。每个 scene 使用单张 NVIDIA A100。

推理时，给定 camera 和 time，先用 $D$ 变形 canonical Gaussians，再 rasterize RGB 和 semantic features。对于已选择的 semantic Gaussians，只需同样随 $D$ 变形即可得到该对象在新视角和新时间的 mask / tracking。

## 7. Experimental Setup and Results Summary

实验任务是 3D dense semantic segmentation and tracking，输入为单目视频，目标对象由 click 或 text prompt 指定。数据集包括 D-NeRF synthetic scenes 和 HyperNeRF real scenes。由于没有 ground-truth segmentation，作者对 training views 先用 SAM 生成 masks 再手工 refine，作为评测 GT。

Table 1 的 mIoU 显示 DGD 明显优于 2D LSeg baseline。HyperNeRF 上，Split-cookie(cookie) 为 78.65 vs LSeg 76.09；Americano(hands) 为 75.98 vs 13.90；Torchocolate(hands) 为 75.98 vs 13.90；Chickchicken(hands) 为 77.92 vs 22.92。D-NeRF 上，Standup(helmet) 为 93.80 vs 1.08，Jumpingjack(hands) 为 68.35 vs 0.89，Trex(skull) 为 70.39 vs 2.48。

用户研究比较 DGD 与静态 3D feature Gaussian baseline。50 名用户对两个问题打 1-5 分：Q1 object segmentation quality，Q2 two-view consistency。Baseline 分别为 2.71 和 3.40，DGD 都为 4.63。

backbone ablation 在 Split-cookie 上比较不同 semantic backbones：DINOv2 78.65，CLIP(text) 65.28，CLIP 75.01，CLIP+DINOv2 75.58，SAM 81.90。作者最终不把 SAM 作为主 backbone，因为 SAM features 更偏 segmentation features，而不是通用 semantic features。

速度和存储方面，DGD 继承 3DGS 渲染速度，约至少 30 FPS，示例为 200K Gaussians。但训练因额外 feature map supervision 约 5 小时，高于只用 RGB 的 Deformable 3DGS。存储也更高，因为每个 Gaussian 需存 384-D DINO 或 512-D CLIP feature。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 unified dynamic semantic 3D Gaussian representation，以及 text/click interface 下的 semantic 3D tracking and editing。实际技术增量是把 static feature-field distillation 搬到 dynamic 3DGS 中，并让 semantic feature loss 与 RGB loss 共同优化 geometry 和 deformation。

与 Deformable 3DGS 相比，DGD 的变形表达本身并不新，新增的是 per-Gaussian semantic feature 和 feature-map rasterization loss。与 LERF / Feature 3DGS 相比，DGD 处理动态单目视频，并把选中的 semantic Gaussians 通过 deformation network 跨时间传播。

## 9. Limitations / Assumptions

训练时间和显存/存储成本更高。每个 Gaussian 附加高维 feature，DINOv2 为 384 维，CLIP 为 512 维，因此比非语义 dynamic 3DGS 更重。

低帧率视频会失败，因为连续帧变化过大，deformation 和 feature consistency 难以稳定学习。论文在 NVIDIA Dynamic Scene 示例中展示了这一失败模式。

透明物体难以分割，例如 HyperNeRF Americano 场景中的 glass。原因包括 2D features 对透明物体不稳定，以及 Gaussian/feature rendering 对透明边界的表达有限。

2D feature maps 通常低于 RGB 分辨率，需要上采样到图像尺寸，导致 3D features 分辨率受限，细粒度 segmentation 难以捕捉。单目输入也仍会带来 novel-view reconstruction artifacts。editing 目前只展示 texture-level 修改，高分辨率和几何/变形 editing 仍未解决。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Single monocular video with SfM cameras; 2D foundation model features |
| Output | Dynamic 3D Gaussians with RGB and semantic features |
| Base dynamics | Canonical 3DGS + deformation MLP |
| Semantic field | Per-Gaussian learnable feature vector |
| Supervision | RGB reconstruction + rendered feature map matching |
| Interaction | Text prompt via CLIP; 3D click via feature similarity |
| Applications | Dynamic 3D semantic segmentation, tracking, texture editing |
| Weakness | High feature storage, slow training, low-FPS / transparent object failure |

## 11. Reusable Components

- feature-map rasterization parallel to RGB rasterization。
- per-Gaussian semantic feature optimized jointly with geometry and deformation。
- click-based 3D entity selection via cosine similarity in DINOv2 feature space。
- text-based Gaussian selection via CLIP text-feature similarity。
- selected-Gaussian editing where only local color attributes are optimized by SDS-like loss。

## 12. Gap / Idea Seeds

- Per-Gaussian high-dimensional features are expensive; compression, PCA, product quantization, or anchor-level feature sharing could reduce memory.
- Video foundation features could replace per-frame features to improve temporal consistency and low-frame-rate robustness.
- Transparent and reflective objects need feature uncertainty or alpha-aware semantic supervision.
- Pixel-selection interface mentioned but not explored; combining 2D clicks/masks with 3D Gaussian contribution weights could make annotation easier.
- Editing could extend from texture to geometry/deformation by constraining only selected semantic Gaussians.

## 13. Human Check List

- NEED_HUMAN_CHECK: Zotero metadata authors include ECCV editors; this note uses the paper authors from the first page.
- NEED_HUMAN_CHECK: Two PDF attachments exist; this note uses `ZTBUN5HI` as the primary Springer/ECCV PDF and records `RTFHNIAM` as duplicate.
- NEED_HUMAN_CHECK: Project URL in extracted text has a space after `https://`; this note normalizes it to `https://isaaclabe.github.io/DGD-Website/`.

## 14. Evidence Anchors

- Section 3.1: dynamic 3D Gaussian representation and deformation MLP。
- Section 3.2: dynamic feature distillation, RGB and feature rasterization equations。
- Section 3.3: text / 3D click semantic tracking interfaces。
- Section 3.4: training iterations, warmup, AST, optimizer details。
- Section 4 and Tables 1-3: segmentation mIoU, user study, semantic backbone ablation。
- Sections 4.3-4.4: speed / memory costs and limitations。
