---
title: "D$^2$GS: Depth-and-Density Guided Gaussian Splatting for Stable and Accurate Sparse-View Reconstruction"
authors: "Meixi Song, Xin Lin, Dizhe Zhang, Haodong Li, Bo Du, Xiangtai Li, Lu Qi"
year: 2025
venue: "arXiv"
zotero_item_key: "DE8MKYK3"
pdf_attachment_key: "BFKV57ZI"
pdf_path: "/Users/wangyibo/Zotero/storage/BFKV57ZI/Song 等 - 2025 - D$^2$GS Depth-and-Density Guided Gaussian Splatting for Stable and Accurate Sparse-View Reconstruct.pdf"
note_path: "notes/D$^2$GS: Depth-and-Density Guided Gaussian Splatting for Stable and Accurate Sparse-View Reconstruction.md"
tags: ["3D Gaussian Splatting", "sparse-view reconstruction", "dropout", "depth prior", "robustness metric"]
---

## 0. 一句话总结

D$^2$GS 针对 sparse-view 3DGS 中“近场高密度 Gaussian 过拟合、远场 Gaussian 覆盖不足欠拟合”的空间失衡问题，提出深度和密度引导的自适应 dropout 抑制近场冗余，同时用单目深度生成远场 mask 加强远场监督，并用 IMR 指标衡量多次训练得到的 Gaussian 分布稳定性。

## 1. 问题与动机

稀疏视角下 3DGS 容易出现两类相反但同时存在的问题：靠近相机、纹理丰富、可见性高的区域会生成过多 Gaussian，导致训练视角过拟合和新视角伪影；远离相机、可见性弱或被近场遮挡的区域 Gaussian 数量不足，导致结构模糊、细节丢失和远景欠拟合。

已有 DropGaussian 类方法用统一随机 dropout 缓解过拟合，但这种无条件 dropout 会同时削弱已经欠拟合的远场和本来拟合良好的区域。本文的核心动机是：dropout 不应均匀施加，而应根据每个 Gaussian 的深度和局部密度来决定；远场也不应只靠普通光度损失，而需要专门增强监督。

## 2. 适用场景

该方法适合相机位姿可由 SfM/COLMAP 得到、输入视角很少的静态场景重建与新视角合成，尤其是 LLFF 3-view/6-view、Mip-NeRF360 sparse setting、DTU sparse setting 这类存在明显近远场差异的场景。

它更偏向 per-scene optimization 的 3DGS 改进，不是前馈式泛化模型。若场景尺度很小、深度分布不明显，或者单目深度估计极不可靠，D$^2$GS 的远场 mask 和深度分层收益会下降。

## 3. 方法定位

D$^2$GS 建立在 3DGS 和 DropGaussian 思路之上，但从“随机丢弃 Gaussian”改为“按空间风险自适应丢弃 Gaussian”。它不是改变渲染器或 Gaussian 参数化，而是在训练阶段加入两个调控模块：Depth-and-Density Guided Dropout（DD-Drop）和 Distance-Aware Fidelity Enhancement（DAFE）。

DD-Drop 用来处理过拟合区域，重点约束近场高密度 Gaussian；DAFE 用来处理欠拟合区域，重点增强远场像素监督。两者分别对应稀疏视角 3DGS 的两个失败模式。

## 4. 核心创新

第一，作者系统分析了 sparse-view 3DGS 的空间失衡：dense-view 与 sparse-view 训练结果对比显示，近场区域 Gaussian 数量明显过多，而远场区域 Gaussian 数量不足。

第二，提出 DD-Drop，根据 Gaussian 的相机距离和局部 kNN 密度计算 dropout score，并结合近/中/远三层深度分区进行全局衰减，让近场高密度区域更容易被 dropout，而远场区域被更少干扰。

第三，提出 DAFE，用单目深度估计得到远场二值 mask，只在远场区域额外计算重建损失，促使优化器给远距离欠拟合区域分配更多 Gaussian 和监督信号。

第四，提出 Inter-Model Robustness（IMR）评价指标，把不同随机种子训练出的 3DGS 模型视为 Gaussian mixture distribution，通过 Wasserstein/OT 距离衡量 learned Gaussian 分布的一致性，补充 PSNR/SSIM/LPIPS 这类 2D 图像指标。

## 5. 方法细节

对第 $i$ 个 Gaussian，作者计算其深度 $d_i$ 和局部密度 $\rho_i$。深度是到相机的欧氏距离，密度由 k-nearest neighbors 估计。归一化后得到 $\tilde{d}_i$ 和 $\tilde{\rho}_i$，局部 dropout score 为：

$$
S_i = \omega_{depth}\tilde{d}_i + \omega_{density}\tilde{\rho}_i
$$

其中 $\omega_{depth}+\omega_{density}=1$。为了结合全局深度层次，点云按深度三等分为 near、middle、far，dropout probability 为：

$$
P_i =
\begin{cases}
S_i, & d_i \le D_{near} \\
\lambda_{middle}S_i, & D_{near}<d_i\le D_{middle} \\
\lambda_{far}S_i, & d_i>D_{middle}
\end{cases}
$$

其中实践中 $\lambda_{middle}=0.7$、$\lambda_{far}=0.3$，即越远的 Gaussian 越少被 dropout。训练过程中还使用递增的全局 dropout rate $r(t)$，从 $r_{min}$ 逐渐增加到 $r_{max}$，让后期正则更强。

DAFE 先用单目深度估计器生成每张训练图的深度图，再用阈值构造远场 mask $M_{dis}$：当 $D(x,y)>\tau D_{max}$ 时 $M_{dis}(x,y)=1$，否则为 0。远场增强损失为 mask 区域中渲染图 $\hat{I}$ 与真值图 $I$ 的差异：

$$
L_{DAFE} =
\frac{1}{\sum_{x,y} M_{dis}(x,y)}
\sum_{x,y} M_{dis}(x,y)\cdot |\hat{I}(x,y)-I(x,y)|
$$

总训练目标为：

$$
L_{total}=L_1(\hat{I},I)+\lambda_{SSIM}L_{D\text{-}SSIM}(\hat{I},I)+\lambda_{DAFE}L_{DAFE}(\hat{I},I)
$$

IMR 指标中，每个 3DGS 模型 $G_i$ 被表示为由 Gaussian primitive 组成的 mixture distribution，opacity $\alpha$ 用作 mixture weight。两个 Gaussian 的距离用近似 2-Wasserstein distance 衡量，两个模型之间的 mixture distance 通过 entropic regularized OT/Sinkhorn 求解。最终 IMR 对多次独立训练模型的 pairwise distance 做聚合，数值越低表示模型间 3D Gaussian 分布越稳定。

## 6. 实验设置

论文主要在 LLFF 和 Mip-NeRF360 上评估，附录还报告 DTU。实现基于 DropGaussian，每个数据集训练 10k iterations，使用单张 H20 GPU。输入图像先由 COLMAP 估计相机和初始点云，初始 SH degree 为 0，训练中每 1000 iterations 提升一次，最高到 degree 3。

DD-Drop 中密度信息每 500 iterations 重新计算一次，kNN 的 $k=6$。深度信息每个 iteration 根据随机选中的训练相机计算。默认单目深度模型为 DepthAnything V2。

## 7. 主要结果

在 LLFF 3-view 1/4 分辨率上，D$^2$GS 达到 21.35 PSNR、0.746 SSIM、0.179 LPIPS、0.087 AVGE，优于 3DGS、DNGaussian、FSGS、CoR-GS、LoopSparseGS 和 DropGaussian。相比 DropGaussian，PSNR 从 20.76 提升到 21.35，LPIPS 从 0.200 降到 0.179。

在 LLFF 3-view 1/8 分辨率上，D$^2$GS 达到 20.56 PSNR、0.695 SSIM、0.254 LPIPS、0.107 AVGE，也优于 DropGaussian 的 20.01 PSNR 和 0.258 LPIPS。

在 Mip-NeRF360 sparse setting 上，D$^2$GS 达到 20.09 PSNR、0.587 SSIM、0.356 LPIPS、0.130 AVGE，优于 CoR-GS 的 19.52 PSNR 和 DropGaussian 的 19.74 PSNR。附录中 LLFF 6-view 和 Mip-NeRF360 24-view 也显示 D$^2$GS 取得最好或竞争性最强的结果。

IMR 方面，LLFF 3-view 中 3DGS、CoR-GS、DropGaussian、D$^2$GS 分别为 3.162、3.136、3.205、3.039；LLFF 6-view 中分别为 3.234、3.270、3.143、3.109。D$^2$GS 的 IMR 最低，说明不同训练轮次得到的 Gaussian 分布更一致。

## 8. 消融与分析

组件消融显示，从 baseline 的 19.22 PSNR、0.649 SSIM、0.229 LPIPS、3.162 IMR 出发，加入 density score 后提升到 21.02 PSNR；加入 depth score 和 depth-based layering 后继续提升；完整加入 DAFE 后达到 21.35 PSNR、0.746 SSIM、0.179 LPIPS、3.039 IMR。

DD-Drop 参数消融显示，$\omega_{depth}=0.5$、$\omega_{density}=0.5$ 最优，说明深度和密度都重要，单独偏重任何一项都会损失性能。全局 dropout rate 取 $r_{min}=0.05$、$r_{max}=0.3$ 效果较好，早期温和 dropout 有助于保留必要几何，后期适度增强正则。

DAFE 消融显示，选择最远约 5% 的深度区域作为增强监督区域效果最好，$\lambda_{DAFE}=1.0$ 取得较好平衡。不同单目深度模型 MiDaS、DPT、DepthAnything V2 都能带来提升，其中 DepthAnything V2 最优。

## 9. 与相关工作的关系

相对 DropGaussian，D$^2$GS 的关键区别是 dropout 不是随机或无条件的，而是根据深度、密度和全局深度层动态决定。它避免了随机丢弃远场欠拟合 Gaussian 的副作用。

相对 DNGaussian、FSGS、CoR-GS、LoopSparseGS 等 sparse-view 3DGS 方法，D$^2$GS 不强调新的几何初始化、伪视角生成或循环一致性，而是从 Gaussian 分布的空间密度控制入手，解决稀疏训练带来的 near/far imbalance。

相对 NeRF-based sparse-view 方法，D$^2$GS 保留 3DGS 的显式 primitive 和高效渲染优势，同时用训练期正则改善稀疏视角鲁棒性。

## 10. 优点

方法优点是问题诊断清晰，两个模块分别对应两类失败模式：DD-Drop 抑制近场过重建，DAFE 补强远场欠重建。它不需要改动 3DGS 渲染核心，实现上可以作为 DropGaussian/3DGS 的训练插件。

另一个优点是引入了 3D representation 稳定性指标 IMR。传统 PSNR/SSIM/LPIPS 只能评价渲染图像，IMR 试图直接衡量 learned Gaussian distribution 在不同训练轮次之间是否一致，这对 sparse-view 3DGS 很有意义。

## 11. 局限

DD-Drop 依赖手工设定的深度分层、权重和 dropout schedule，论文附录也指出这些固定阈值不一定能适配所有复杂场景。DAFE 依赖单目深度估计，若深度估计在反光、透明、低纹理或室外大尺度场景中出错，远场 mask 可能会把监督加到错误区域。

IMR 虽然能衡量 Gaussian 分布一致性，但计算涉及大量 Gaussian 的 OT 近似，需要采样和 Sinkhorn，仍比普通图像指标复杂。它也主要衡量不同训练模型之间的分布差异，并不直接衡量动态视角连续性或主观感知稳定性。

## 12. 可复现要点

复现时先用 COLMAP 生成相机和点云，再按 3DGS 初始化 Gaussian。训练时维护每个 Gaussian 的相机深度和 kNN 局部密度，计算 $S_i$ 与 $P_i$ 后按概率 dropout。密度每 500 iterations 更新一次，深度每轮根据采样训练相机更新。

DAFE 需要预先或在线生成训练图的单目深度，按 $D(x,y)>\tau D_{max}$ 得到远场 mask，并把 mask 区域的额外 $L_1$ 监督加入总 loss。默认使用 DepthAnything V2，$r_{min}=0.05$、$r_{max}=0.3$、$\omega_{depth}=\omega_{density}=0.5$、$\lambda_{DAFE}=1.0$ 是论文中较优配置。

## 13. 可能扩展

一个自然扩展是把深度分层和 dropout 权重做成可学习策略，例如根据训练过程中的残差、可见性和 opacity 变化自适应调整，而不是使用固定 tertile 和固定 $\lambda$。

第二个扩展是把 DAFE 从二值远场 mask 改为连续权重 map，让远场、遮挡边界、低监督区域获得不同强度的监督，避免 hard threshold 带来的不连续。

第三个扩展是把 IMR 用作训练正则或模型选择指标。比如同一场景训练多个轻量候选模型，用 IMR 低且图像指标好的模型作为最终结果，或在训练中约束 Gaussian 分布对随机扰动保持稳定。

## 14. 个人理解

D$^2$GS 的价值在于它把 sparse-view 3DGS 的问题从“整体过拟合”细化成了“空间分布不均衡”。这个视角很实用，因为很多稀疏视角伪影确实不是全场均匀发生，而是近处局部 Gaussian 太密、远处结构太少造成的。

这篇文章也说明 dropout 在 3DGS 中不能简单照搬神经网络中的随机正则。Gaussian 是空间 primitive，丢掉哪个 primitive 有明确几何含义。因此更合理的 dropout 应该看深度、密度、可见性、残差和不确定性，而 D$^2$GS 是朝这个方向迈出的一步。
