# MoDec-GS: Global-to-Local Motion Decomposition and Temporal Interval Adjustment for Compact Dynamic 3D Gaussian Splatting

## 0. Metadata

- Title: MoDec-GS: Global-to-Local Motion Decomposition and Temporal Interval Adjustment for Compact Dynamic 3D Gaussian Splatting
- Authors: Sangwoon Kwak; Joonsoo Kim; Jun Young Jeong; Won-Sik Cheong; Jihyong Oh; Munchurl Kim
- Venue/Year: CVPR 2025
- Project page: https://kaist-viclab.github.io/MoDecGS-site/
- Zotero item key: `XAWLMXY8`
- Zotero PDF attachment key: `DDHGWKEF`
- PDF path: `/Users/wangyibo/Zotero/storage/DDHGWKEF/Kwak 等 - MoDec-GS Global-to-Local Motion Decomposition and Temporal Interval Adjustment for Compact Dynamic.pdf`
- Local note path: `notes/MoDec-GS: Global-to-Local Motion Decomposition and Temporal Interval Adjustment for Compact Dynamic 3D Gaussian Splatting.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

MoDec-GS 用 anchor-based Scaffold-GS 做 compact canonical representation，并通过 Global-to-Local Motion Decomposition 将大范围全局运动交给 Global Anchor Deformation、局部细节运动交给 Local Gaussian Deformation，再用 Temporal Interval Adjustment 在训练中自适应划分时间段，以低存储量处理长视频复杂动态。

## 2. Problem Formulation

动态 3DGS 方法通常在 canonical 3DGS 或 4D Gaussians 上加入时间相关属性，导致存储量随 Gaussian 数量和动态属性快速增长。长视频或大运动场景还会出现另一个问题：用一个统一模型覆盖所有帧时容量不足，容易模糊；手工切分 temporal segments 又依赖外部 motion information 或经验规则。

MoDec-GS 的目标是在 monocular dynamic videos 上同时降低模型存储、保持实时渲染，并提升复杂运动场景的画质。论文把真实运动看成 global movement 和 local movement 的组合：全局运动应在稀疏 anchors 层面处理，局部残余 motion 再在 reconstructed Gaussians 层面细化。

## 3. Method Overview

方法基于 Scaffold-GS 的 anchor representation，而不是直接存储大量 canonical Gaussians。每个 anchor 有 learnable feature、offsets 和 context attributes，通过 decoder 生成多个 neural Gaussians。MoDec-GS 将这个静态 compact 表示扩展为动态视频表示。

核心模块是 GLMD。第一阶段 GAD 用 tiny global hexplane 查询 anchor position 和 canonical time，直接 deform anchor position、offset 和 local context feature，把 Global Canonical Scaffold-GS 转成面向某个 temporal segment 的 Local Canonical Scaffold-GS。第二阶段 LGD 先从 Local CS 派生 3D Gaussians，再用 shared local hexplane 对每个 target timestamp 做显式 Gaussian deformation。TIA 则在训练中根据 positional gradients 自适应调整每个 Local CS 的 temporal interval。

## 4. Method Details

### 4.1 Scaffold-GS Base Representation

Scaffold-GS 由 sparse anchor points、与每个 anchor 相关的 $k$ 个 neural Gaussians，以及预测 Gaussian attributes 的 MLP decoders 组成。对 anchor $v$，第 $i$ 个 neural Gaussian 的中心为 $m_i=x_v+o_i$，其中 $x_v$ 是 anchor position，$o_i$ 是 learnable offset。opacity、color、quaternion 和 scale 等属性由 anchor feature、相机相对距离和 viewing direction 解码得到。

这个表示比直接存储所有 Gaussians 更 compact，因为大量 Gaussian attributes 被 anchor feature 和 small decoders 隐式生成。MoDec-GS 选择它作为 canonical 3DGS 的基础，目的是让动态扩展本身也保持低存储。

### 4.2 Global Anchor Deformation (GAD)

GAD 负责跨 temporal interval 的大范围全局运动。给定 anchor position $(x_v,y_v,z_v)$ 和 canonical time $t_c$，方法查询 tiny global hexplane $H_G$，再通过 light MLP $F_G$ 和 multi-head anchor decoder 输出 anchor position 与 attributes 的 deformation，例如 local context feature deformation：

$$
\Delta f_v=\phi_f(F_G(H_G(x_v,y_v,z_v,t_c))).
$$

输出包括 $(\Delta x,\Delta y,\Delta z)$、$\Delta f_v$、$\Delta o_v$ 和 $\Delta s_v$，分别作用于 anchor position、local context feature、offset 和 scale。论文认为，对大物体整体运动，直接 deform anchors 比先生成大量 Gaussians 再逐 Gaussian deform 更高效。

### 4.3 Learnable Anchor Dynamics

为了区分静态区域与动态区域，MoDec-GS 给 anchor 添加两个 learnable dynamics：global dynamics $d_G$ 和 local dynamics $d_L$。$d_G$ 学习整个 anchor 是否需要 global movement，并通过 straight-through 风格的 binary mask $M(d_G)$ 控制 position deformation；$d_L$ 控制 anchor 内局部属性变化。

deformed anchor attributes 写作：

$$
(x'_v,y'_v,z'_v)=(x_v,y_v,z_v)+M(d_G)(\Delta x,\Delta y,\Delta z),\quad f'_v=f_v+\Delta f_v\sigma(d_L).
$$

offset 和 scale 也类似地加上 $\Delta o_v\sigma(d_L)$ 与 $\Delta s_v\sigma(d_L)$。这个设计避免显式使用外部 dynamic mask，同时让静态 anchor 不必承担不必要的动态参数变化。

### 4.4 Local Gaussian Deformation (LGD)

GAD 后得到的 Local CS 只覆盖一个 temporal segment，剩余运动被认为更局部、更小。此时先在 view frustum 内从 deformed anchors 派生 $k$ 个 neural Gaussians，例如 opacity 由 $F_\alpha(\hat f'_v,\delta_{v',cam},\vec d_{v',cam})$ 预测。

随后对派生出的 Gaussian 做显式 local deformation。对第 $k$ 个 neural Gaussian 的位置 deformation，方法查询 shared local multi-resolution hexplane $H_L$：

$$
(\Delta x_k,\Delta y_k,\Delta z_k)=\phi_p(F_L(H_L(x_k,y_k,z_k,t_L))).
$$

这里 $t_L$ 是 target timestamp。local hexplane 和 decoder 在各个 Local CS 之间共享，以保持 compactness。

### 4.5 Temporal Interval Adjustment (TIA)

总帧数 $N$ 被分成 $l$ 个 segments，初始为 uniform intervals。不同时间段的 motion complexity 不同，固定均匀区间会让有些 Local CS 覆盖过复杂的 motion，有些则浪费容量。TIA 在训练中维护 canonical time list $T_c=[t_1,\ldots,t_{l-1}]$ 作为 segment boundaries，并在指定训练阶段开始调整。

每个 adjustment period 中，TIA 将 positional gradient Frobenius norm $g_t^{pos}$ 按训练 view 的 timestamp 累积到对应 interval：$g_c^{acc}=g_c^{acc}+g_t^{pos}$，$\nu_c^{acc}=\nu_c^{acc}+1$。之后计算各 interval 的平均梯度、全局均值 $\mu$ 和标准差 $\sigma$。若某个 interval 的 motion/gradient 复杂度高于 $\mu+\tau_{\mathrm{TIA}}\sigma$，则该 interval 两侧边界按 step $s_{\mathrm{TIA}}$ 收缩，使更多 temporal capacity 分配到高运动区域附近。

## 5. Mathematical Objectives and Losses

MoDec-GS 的主创新不在 photometric loss，而在表示与训练调度。渲染和基本优化继承 4DGS / Scaffold-GS 的 pipeline，训练通过图像重建指标驱动。GAD、LGD 与 TIA 的梯度都来自 rendering loss 对 anchor / Gaussian position 的影响。

TIA 可视为一个 training-time resource allocation 机制。它使用 positional gradients 作为 motion complexity proxy，不依赖预计算 optical flow 或 tracker。高梯度 interval 被缩短，Local CS 的 temporal support 更集中，从而让有限 hexplane capacity 处理更简单的局部运动。

## 6. Training and Inference Procedure

训练先构建 Global CS，覆盖整个视频。然后按当前 canonical time intervals 生成多个 Local CS：每个 Local CS 通过 GAD 从 Global CS 变形而来，再通过 neural Gaussian derivation 生成 local Gaussians，并用 LGD 对 target timestamp 做显式形变。训练过程中 TIA 定期更新 temporal boundaries，逐渐从均匀区间变成非均匀区间。

推理时，给定 timestamp，先定位其所属 Local CS，再执行对应的 GAD / neural Gaussian derivation / LGD，最后用标准 3DGS rasterization 渲染。因为 anchor representation compact，且 local hexplane shared，模型存储显著低于逐 Gaussian 动态属性方法。

## 7. Experimental Setup and Results Summary

实验使用 DyCheck-iPhone、HyperNeRF 和 Nvidia monocular datasets。初始点云由 COLMAP 根据 4DGS 脚本手动生成。iPhone 使用官方 co-visible mask 做 masked metrics，指标为 PSNR、SSIM、LPIPS 和 Storage(MB)。对比方法包括 Deformable-3DGS、SC-GS 和 4DGS。

iPhone 平均结果中，SC-GS 为 13.90 / 0.464 / 0.479，存储 232.4 MB；Deformable 3DGS 为 13.72 / 0.461 / 0.430，存储 109.4 MB；4DGS 为 13.72 / 0.460 / 0.509，存储 78.54 MB；MoDec-GS 为 14.60 / 0.480 / 0.443，存储 18.37 MB。论文强调相对画质第二好的 SC-GS，iPhone 上 PSNR 提升约 +0.7 dB，存储减少约 94%。

HyperNeRF 平均结果中，Ours 为 27.78 / 0.827 / 0.219，存储 40.82 MB；SC-GS 为 26.95 / 0.815 / 0.213，存储 226.0 MB；4DGS 为 27.44 / 0.797 / 0.302，存储 72.65 MB。Nvidia 上，Ours 为 26.65 / 0.876 / 0.171，存储 39.64 MB，高于 4DGS 的 25.82 / 0.844 / 0.219，且存储低于 67.44 MB。

消融表显示，单阶段 Gaussian deform baseline 为 13.73 / 0.460 / 0.509，存储 78.54 MB；单阶段 anchor deform 降存储到 36.92 MB 但画质略低；2-stage GAD + LGD 提升到 14.48 / 0.475 / 0.455，存储 49.70 MB；减小 hexplane 后存储 22.67 MB 且质量几乎不降；加入 $d_G,d_L$ 后为 14.51 / 0.478 / 0.447；最终加入 TIA 后为 14.60 / 0.480 / 0.443，存储 18.37 MB。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称的贡献是 GLMD、TIA 和显著存储压缩。实际技术增量在于把动态 3DGS 的 deformation 从单一层级拆成 anchor-level global deformation 与 Gaussian-level local deformation，并把 temporal segmentation 变成可训练过程的一部分。

与 4DGS 类方法相比，MoDec-GS 不把所有动态信息塞到统一 spatiotemporal feature 中，而是先用 Local CS 切分时间，再在每段中只处理较简单 local motion。与 SWinGS 类手工/外部运动切分相比，TIA 不需要 optical flow 或 tracker 作为训练输入，而是用训练中的 positional gradients 自适应调整边界。

## 9. Limitations / Assumptions

方法依赖 COLMAP 初始化点云；对 monocular 视频中 SfM 失败、遮挡严重或纹理不足的场景，anchor 初始化和后续 deformation 都可能受影响。

TIA 用 positional gradients 作为 motion complexity proxy。该指标可能同时反映几何错误、遮挡、曝光变化或优化不稳定，并不总是纯 motion 信号。

Local CS 数量 $l$ 仍需预设。TIA 调整的是边界位置，不会自动增删 temporal segments；如果预设段数过少，复杂长视频仍可能容量不足。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Monocular dynamic videos with COLMAP point cloud |
| Output | Compact dynamic Scaffold-GS / 3DGS representation |
| Base representation | Scaffold-GS anchors and neural Gaussian derivation |
| Global motion | Global Anchor Deformation with tiny global hexplane |
| Local motion | Local Gaussian Deformation with shared local hexplane |
| Temporal allocation | TIA adjusts Local CS intervals using positional gradients |
| Strength | Strong storage reduction while preserving or improving quality |
| Weakness | Requires preset segment count and reliable initialization |

## 11. Reusable Components

- anchor-level deformation for large global motion before Gaussian derivation。
- two learnable anchor dynamics $d_G$ and $d_L$ for global/local motion gating。
- shared local hexplane across Local CS to reduce storage。
- training-time temporal boundary adjustment based on accumulated position gradients。
- compact dynamic representation strategy combining Scaffold-GS and 4DGS-style deformation。

## 12. Gap / Idea Seeds

- TIA 可以进一步扩展为可增删 segments 的 adaptive temporal model，而不仅是移动边界。
- positional gradient 可与 photometric residual、mask motion 或 optical flow uncertainty 融合，得到更稳健的 complexity estimator。
- GLMD 的 global/local 分解仍是两级结构，可探索 object-level anchors 或 hierarchy 以处理多物体独立运动。
- anchor dynamics 的 binary masking 可加入 entropy 或 sparsity regularization，使静态区域更稳定、更可解释。

## 13. Human Check List

- NEED_HUMAN_CHECK: PDF 中 TIA Algorithm 1 的排版抽取不完整，本笔记根据主文段落和可读算法行概括其逻辑。
- NEED_HUMAN_CHECK: iPhone Table 1 的每个单元包含四个指标，笔记重点记录平均值和代表性结论。
- NEED_HUMAN_CHECK: 论文声称不依赖 optical flow 做 TIA 输入，但 Fig. 5 用预计算 optical flow 进行事后验证，二者不要混淆。

## 14. Evidence Anchors

- Section 3.2: Scaffold-GS anchor representation and neural Gaussian attributes。
- Section 4.1: GLMD overview and Global CS / Local CS structure。
- Section 4.2: GAD, anchor dynamics $d_G,d_L$, anchor attribute deformation。
- Section 4.3: LGD and shared local hexplane deformation。
- Section 4.4: TIA canonical time list, accumulated positional gradients, interval shrinking。
- Tables 1-3: iPhone, HyperNeRF/Nvidia, and ablation results。
