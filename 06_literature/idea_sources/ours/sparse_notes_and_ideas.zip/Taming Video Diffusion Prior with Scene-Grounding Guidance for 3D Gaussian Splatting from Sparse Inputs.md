# Taming Video Diffusion Prior with Scene-Grounding Guidance for 3D Gaussian Splatting from Sparse Inputs

## 0. Metadata

* Title: Taming Video Diffusion Prior with Scene-Grounding Guidance for 3D Gaussian Splatting from Sparse Inputs
* Authors: Yingji Zhong, Zhihao Li, Dave Zhenyu Chen, Lanqing Hong, Dan Xu
* Year: 2025
* Venue: CVPR 2025
* PDF source: Zotero local PDF
* Zotero item key: TW2E5N9Z
* Zotero PDF attachment key: 8RPVNUZ6
* PDF path: `/Users/wangyibo/Zotero/storage/8RPVNUZ6/Zhong 等 - Taming Video Diffusion Prior with Scene-Grounding Guidance for 3D Gaussian Splatting from Sparse Inp.pdf`
* Note path: `notes/Taming Video Diffusion Prior with Scene-Grounding Guidance for 3D Gaussian Splatting from Sparse Inputs.md`
* Code: Not specified
* Project page: Not specified
* Dataset link: Not specified
* Main task: sparse-input / sparse-view 3D Gaussian Splatting novel view synthesis
* Domain: indoor scene reconstruction, sparse-view 3DGS, video diffusion prior
* Input: 少量带相机位姿的图像，baseline 3DGS，camera-controlled image-to-video diffusion model
* Output: 更完整、更少空洞和幻觉的 3DGS 场景表示及 novel view renderings

## 1. One-Sentence Technical Summary

本文把一个 camera-controlled video diffusion model 作为 sparse-view 3DGS 的辅助视图生成器，但在扩散采样过程中用 baseline 3DGS 渲染结果做 scene-grounding guidance，并用 hole-aware camera trajectory selection 主动覆盖外推和遮挡区域，最后用真实输入视图与生成视图共同优化 3DGS。

## 2. Problem Formulation

Sparse-input 3DGS 在真实室内场景中不仅缺少训练视图，还会遇到两个具体退化：其一是 novel camera 超出 sparse input 视锥时的 extrapolation 区域，其二是移动到新视角后暴露出来的 occlusion / disocclusion 区域。普通 3DGS 或 FSGS 类方法在这些区域容易出现 black holes、漂浮伪影和几何不完整。

作者希望利用 video diffusion 的多帧生成能力补充训练视图，但直接使用视频扩散会带来两个新问题：跨帧 appearance inconsistency，以及在场景中不存在的 hallucinated objects。本文的问题因此可以表述为：给定 sparse posed images 和一个不完整但可渲染的 baseline 3DGS，如何让视频扩散模型在未知区域生成补充监督，同时不破坏已观测区域的一致性。

## 3. Method Overview

整体流程分为三步。第一步，用 DUSt3R point cloud 初始化 baseline 3DGS，并结合 FSGS 的 Gaussian unpooling 获得一个较强但仍不完整的初始场景。第二步，以 baseline 3DGS 的可见区域渲染作为扩散采样时的条件约束，让 video diffusion 生成与已有场景一致的多视角序列。第三步，用输入真值视图和生成视图联合优化最终 3DGS。

关键设计有两个：scene-grounding guidance 解决生成序列与已有场景不一致的问题；trajectory initialization 则通过选择 hole mask 最大的候选相机轨迹，让生成序列优先覆盖 extrapolation 和 occlusion 区域。

## 4. Method Details

### 4.1 Baseline 3DGS 初始化

论文使用 DUSt3R 从 sparse input images 估计点云，然后训练 baseline 3DGS，并使用 FSGS 的 Gaussian unpooling 增强稀疏视角下的点分布。这个 baseline 不作为最终结果，而是给扩散模型提供场景锚点：在已有几何能够覆盖的区域，扩散生成结果应与 3DGS 渲染保持一致；在空洞区域，则允许 diffusion prior 发挥补全能力。

### 4.2 Scene-grounding guidance

本文采用 training-free guidance，不微调视频扩散模型，而是在每一步 denoising 中加入由 3DGS 渲染图像产生的梯度。标准扩散采样写作：

$$
x_{t-1}=(1+\beta_t/2)x_t+\beta_t\nabla_{x_t}\log p(x_t)+\sqrt{\beta_t}z
$$

在给定 scene-grounding target $Q$ 后，条件 score 被拆成：

$$
\nabla_{x_t}\log p(x_t|Q)=\nabla_{x_t}\log p(x_t)+\nabla_{x_t}\log p(Q|x_t)
$$

作者把第二项实现为关于 guidance loss 的负梯度。对轨迹 $\{\phi_j\}_{j=1}^L$，baseline 3DGS 渲染得到序列 $S_j$ 和 hole mask $M_j$。mask 由 alpha / transmittance 累积得到：

$$
O(x_p)=\sum_{i\in K}\sigma_i\prod_{j=1}^{i-1}(1-\sigma_j)
$$

其中 $M=(O<\eta_{mask})$ 表示 baseline 渲染不可靠或缺失的区域。扩散当前 latent $x_t$ 被估计为 clean image：

$$
x_{0|t}=\frac{x_t-\sqrt{1-\bar{\alpha}_t}\epsilon_\theta(x_t,t)}{\sqrt{\bar{\alpha}_t}}
$$

再经 VAE decoder 得到图像 $X_{0|t}$。guidance loss 只约束 baseline 可靠的已观测区域：

$$
L(S,M,X_{0|t})=\|\bar{M}\odot(S-X_{0|t})\|_1+\lambda_{perc}L_{perc}(\bar{M}\odot S,\bar{M}\odot X_{0|t})
$$

其中 $\bar{M}$ 是 hole mask 的反向区域。denoising update 中加入 $g_t=\nabla_{x_t}L(S,M,X_{0|t})$，形成 $x_{t-1}=\hat{x}_{t-1}-\gamma_tg_t$。这一设计的含义是：已知区域由 3DGS 锚定，未知区域仍由视频扩散模型自由生成。

### 4.3 Hole-aware trajectory initialization

为了让扩散生成真正覆盖稀疏输入没有观测到的区域，作者不随机给视频扩散模型相机轨迹，而是在每个输入相机周围采样候选姿态，渲染 baseline 3DGS 并计算 hole mask 面积。每个输入视角选 top-$k$ 个 hole 最大的候选姿态作为终点，再从输入姿态 $\phi_i$ 插值到候选姿态 $\hat{\phi}_c^{(i)}$，得到长度为 $L=25$ 的相机轨迹：

$$
\{\phi_j^{(i,c)}\}_{j=1}^L=\mathrm{interp}(\phi_i,\hat{\phi}_c^{(i)})
$$

这些轨迹组成 trajectory pool $\Phi=\{\{\phi_j^{(i,c)}\}_{j=1}^L|i,c\}$。该策略把生成预算集中到可见性缺口最大的方向，而不是平均地在已有视角附近生成重复监督。

## 5. Mathematical Objectives and Losses

真实输入视图使用标准 3DGS photometric loss：

$$
L^{input}=(1-\lambda)L_1(C_i,C_i^{gt})+\lambda L_{D-SSIM}(C_i,C_i^{gt})
$$

生成视图使用重建项和 perceptual 项：

$$
L^{gen}=\lambda_{gen1}L_1(C_j,S_j)+\lambda_{gen2}L_{perc}(C_j,S_j)
$$

作者强调生成图像并非完美真值，因此 $L_1$ 权重不能过大；perceptual loss 作用于整幅生成图像，能更有效地把 diffusion prior 中的语义和结构补全信息传给 3DGS。文中报告的主要超参数包括 $\lambda=0.2$、$\lambda_{perc}=10^{-4}$、$\lambda_{gen1}=0.1$、$\lambda_{gen2}=0.01$、$\eta_{mask}=0.9$、global sampling ratio $\eta=0.5$。

## 6. Training and Inference Procedure

训练先得到 baseline 3DGS，然后每隔 $N_{gen}=260$ iterations 从 trajectory pool 中选择一条轨迹生成视频序列。最终 3DGS 总共优化 $N_{iter}=10000$ iterations。

生成视图采样有 local 和 global 两种来源。local sampling 从当前生成序列中采样视图，强化当前缺口区域；global list $G$ 保存历史生成视图，并按 $\eta=0.5$ 的比例混入训练，避免模型在优化新生成区域时遗忘早期补全的区域。推理阶段只需要渲染优化后的 3DGS，不再调用视频扩散模型。

## 7. Experimental Setup and Results Summary

实验覆盖 Replica 和 ScanNet++ 两个室内数据集，每个场景选择 6 个输入视图，评估 PSNR、SSIM、LPIPS。对比方法包括 Mip-NeRF、InfoNeRF、DietNeRF、FreeNeRF、3DGS、DNGaussian、FSGS 及其 DUSt3R 初始化版本。作者特别设置强 baseline：3DGS 使用 DUSt3R point cloud 初始化，FSGS 也有 DUSt3R 初始化版本。

主结果显示，本文在 Replica 上达到 26.35 PSNR / 0.872 SSIM / 0.122 LPIPS，在 ScanNet++ 上达到 23.89 PSNR / 0.850 SSIM / 0.182 LPIPS，均优于 FSGS 与 DNGaussian 的强初始化版本。消融表明，vanilla video generation 能改善 full-image 指标，但会降低 observable 区域 PSNR，说明生成不一致会伤害已知区域；加入 scene-grounding guidance 后 observable 和 full-image 指标同时提升；再加入 trajectory initialization 后对 full-image 有进一步帮助。

与 LaMa inpainting 和 SDS with SDInpaint 的对比显示，直接在空洞区域做 2D inpainting 或 SDS 监督不如本文的视频扩散加场景锚定策略。作者认为原因是视频扩散提供了更强的跨视角结构先验，而 scene grounding 抑制了纯生成模型的幻觉。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称的贡献是把 video diffusion prior 引入 sparse-input 3DGS，并提出 scene-grounding guidance 与 trajectory initialization。实际技术增量可以拆成三个可复用模块：用 baseline 3DGS 的可靠渲染区域约束 diffusion denoising；用 alpha/hole mask 选择最需要补全的相机轨迹；用 local/global generated-view sampling 防止补全区域遗忘。

相对 FSGS / DNGaussian，本文不是设计新的 Gaussian 正则项，而是把外部生成模型作为视图扩增器。相对 SDS / inpainting，它的关键区别是多帧 camera-controlled video diffusion 与已知区域的显式一致性约束。

## 9. Limitations and Hidden Assumptions

方法依赖一个可用的 baseline 3DGS。如果 DUSt3R 初始化或 FSGS unpooling 在输入视图中已经失败，scene-grounding target 也会误导 diffusion guidance。方法还假设输入相机位姿已知；对于完全 unposed sparse images，需要额外 pose estimation 或和 pose-free 方法组合。

生成视图仍然不是可靠真值，因此训练权重需要谨慎调节。论文主要在室内 Replica / ScanNet++ 验证，户外大尺度、强反射、动态物体、非 Lambertian 材质下的稳定性没有充分说明。计算成本也比纯 3DGS 正则化方法高，因为训练过程中需要多次调用视频扩散模型。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| 核心任务 | Sparse-input 3DGS novel view synthesis |
| 输入条件 | 少量 posed images，baseline 3DGS，camera-controlled video diffusion |
| 主要先验 | DUSt3R 点云、FSGS unpooling、视频扩散先验、3DGS 可见区域渲染 |
| 关键模块 | scene-grounding diffusion guidance；hole-aware trajectory initialization；generated-view local/global sampling |
| 主要损失 | 输入视图 photometric loss；生成视图 $L_1$ + perceptual loss；扩散采样中的 masked guidance loss |
| 解决的稀疏视角问题 | extrapolation holes、occlusion holes、generated-view inconsistency、hallucination |
| 最强证据 | Replica / ScanNet++ 主表和 guidance / trajectory / perceptual loss 消融 |
| 主要风险 | baseline 错误会传递给扩散；生成视图可能仍含噪声；扩散计算成本较高 |

## 11. Reusable Components for My Research

1. 可以把 scene-grounding guidance 改成通用的 “renderer-guided diffusion sampling”：任意已有 3D 表示只要能输出可信 mask，就可以约束生成模型不要改写已知区域。
2. Hole-aware trajectory selection 可直接用于主动视角生成或 synthetic supervision scheduling，把补全预算分配给最大不确定区域。
3. Local/global generated-view replay 的思想适合与增量式 3DGS、动态 3DGS 或 lifelong scene updating 结合，避免生成监督只改善最近区域。
4. Masked perceptual guidance 可以与 uncertainty-aware mask 结合：已知区域用强约束，高不确定区域降低 renderer guidance，交给 diffusion prior。

## 12. Gap and Idea Seeds

1. 将本文的 hole mask 替换为 uncertainty-aware mask：用渲染方差、depth variance 或 ensemble disagreement 判断哪些区域应由 3DGS 锚定，哪些区域交给 diffusion。
2. 与 pose-free sparse 3DGS 结合：先用 NoPoSplat / FreeSplatter 估计粗场景和相机，再进行 scene-grounded video diffusion 补全。
3. 把 trajectory initialization 从最大 hole 面积扩展成 information gain 目标，同时考虑视角新颖性、生成模型可信度和 Gaussian density。
4. 对生成视图引入 cross-view consistency filter，只保留在多条生成轨迹中互相一致的像素或 patch 作为监督。
5. 用轻量 image-to-video model 蒸馏本文流程，减少训练中多次调用 diffusion 的成本。

## 13. Human Check List

* NEED_HUMAN_CHECK: 论文是否在补充材料中给出更完整的 candidate pose sampling 范围、top-$k$ 设置和 $\gamma_t$ schedule。
* NEED_HUMAN_CHECK: project page / code release 是否在正式 CVPR 页面或作者主页中给出，PDF 文本中未稳定抽取。
* NEED_HUMAN_CHECK: 生成视频模型的具体 backbone 名称、预训练数据和 camera-control 参数需要从方法实现或附录进一步确认。
* 已确认：公式使用仓库要求的 inline dollar 与 display dollar 约定。

## 14. Evidence Anchors

* Abstract / Introduction: 提出 sparse-input 3DGS 中 extrapolation 和 occlusion 区域会产生 artifacts，并指出 vanilla video diffusion 的 inconsistency 和 hallucination 问题。
* Method, scene-grounding guidance: 给出 diffusion sampling、conditional score、clean image estimate、masked guidance loss 和 denoising update。
* Method, trajectory initialization: 描述候选相机采样、hole mask 面积排序、top-$k$ 终点选择和长度 $L=25$ 的插值轨迹。
* Method, 3DGS optimization: 给出 input-view loss、generated-view loss、$N_{gen}=260$、$N_{iter}=10000$、local/global sampling 和 global list $G$。
* Experiments, Table 1: Replica 和 ScanNet++ 上与 Mip-NeRF、InfoNeRF、DietNeRF、FreeNeRF、3DGS、DNGaussian、FSGS 的主结果。
* Ablation, Table 2: vanilla generation、guided generation、trajectory initialization、perceptual loss、local sampling、global list 的消融。
* Comparison, Table 3: 与 LaMa inpainting 和 SDS with SDInpaint 的对比。
