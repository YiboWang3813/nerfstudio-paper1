# Event-boosted Deformable 3D Gaussians for Dynamic Scene Reconstruction

## 0. Metadata

- Title: Event-boosted Deformable 3D Gaussians for Dynamic Scene Reconstruction
- Authors: Wenhao Xu; Wenming Weng; Yueyi Zhang; Ruikang Xu; Zhiwei Xiong
- Venue/Year: ICCV 2025
- Code: https://github.com/wh-xu1/E-D3DGS
- Zotero item key: `U2HMRW9F`
- Zotero PDF attachment key: `I2EJ48FM`
- PDF path: `/Users/wangyibo/Zotero/storage/I2EJ48FM/Xu 等 - Event-boosted Deformable 3D Gaussians for Dynamic Scene Reconstruction.pdf`
- Local note path: `notes/Event-boosted Deformable 3D Gaussians for Dynamic Scene Reconstruction.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

E-D3DGS 将 event camera 的高时间分辨率运动信息接入 Deformable 3DGS，并通过 GS-threshold joint modeling 校准事件阈值、通过 dynamic-static decomposition 只对动态 Gaussians 做 deformation，从而同时提升动态重建质量和渲染速度。

## 2. Problem Formulation

动态 3DGS 受普通 RGB 相机帧率和 motion blur 限制，训练帧之间的中间运动信息缺失。Event cameras 以微秒级分辨率记录亮度变化，能提供连续运动线索和近似无限 temporal viewpoints，因此适合补足动态重建监督。

但 event supervision 依赖事件生成模型中的 threshold $C$。真实 event camera 的 threshold 会随 polarity、space 和 time 变化，不能简单设为常数。若 threshold 建模错误，事件积分会产生 artifact，反过来污染 3DGS supervision。

此外，动态场景中大量区域是静态的。若所有 Gaussians 都通过 deformation field，静态区域浪费 MLP capacity，也降低渲染速度并影响动态区域 fidelity。论文的目标是同时解决 event threshold modeling 和 dynamic/static resource allocation。

## 3. Method Overview

方法有两条主线。第一条是 GS-threshold joint modeling (GTJM)。先用稀疏 RGB frames 的真实亮度变化估计 event threshold，再用训练得到的 3DGS 渲染中间帧作为 pseudo-supervision 细化 threshold。最终联合优化 threshold、event loss 和 RGB rendering loss，让更准确的 threshold 提供更可靠 event supervision，而更好的 3DGS 又通过几何一致性改进 threshold。

第二条是 dynamic-static decomposition (DSD)。先只用 static Gaussians 重建场景 3k iterations，因为 static Gaussians 不能表示运动，动态区域会重建差。用 VGG feature similarity between rendered and GT images 生成 2D dynamic mask，再结合 depth unprojection 转成 3D dynamic Gaussian candidates。最后用 buffer-based soft decomposition 处理边界不确定区：内半径为 dynamic，外半径为 static，中间 buffer pruning 后交给 adaptive density control 搜索边界。

最终 static Gaussians 直接进入 rasterizer；dynamic Gaussians 通过 Deformable-3DGS 风格 deformation field 预测 $\delta\mu,\delta r,\delta s$ 后再混合渲染。

## 4. Method Details

### 4.1 Event Rendering Model

每个 event 记为 $e_{x,y}(\tau)=p\delta(\tau)$，其中 polarity $p\in\{+1,-1\}$，threshold 为 $C$。在时间区间 $[t,t+\Delta t]$ 上，事件积分对应的亮度变化为：

$$
E(t,t+\Delta t)=\int_t^{t+\Delta t} C\cdot e(\tau)d\tau.
$$

从 rendered / ground-truth brightness 也可估计亮度变化：

$$
\hat E(t,t+\Delta t)=\log(\hat I(t+\Delta t))-\log(I(t)).
$$

Event rendering loss 为：

$$
L_{\mathrm{event}}=\|E(t,t+\Delta t)-\hat E(t,t+\Delta t)\|_2^2.
$$

RGB rendering loss 沿用 3DGS 的 $L_1$ 和 D-SSIM：

$$
L_{\mathrm{rgb}}=(1-\lambda_s)\|\hat I(t)-I(t)\|_1+\lambda_s L_{\mathrm{D-SSIM}}(\hat I(t),I(t)).
$$

### 4.2 RGB-Assisted Threshold Estimation

给定两个 RGB frames $I(t)$ 和 $I(f)$，真实亮度变化为 $E_{\mathrm{thres}}(t,f)=\log(I(f))-\log(I(t))$。阈值模型预测事件积分：

$$
\hat E_{\mathrm{thres}}(t,f)=\int_t^f \hat C\cdot e(\tau)d\tau.
$$

阈值 loss 为：

$$
L_{\mathrm{thres}}=\|E_{\mathrm{thres}}(t,f)-\hat E_{\mathrm{thres}}(t,f)\|_2^2.
$$

实践中先把 events 累积为 event count maps $\mathrm{ECM}_{t,f}\in\mathbb{R}^{B\times P\times H\times W}$，其中 $B$ 是 temporal bins，$P=2$ 是 polarity。学习阈值 $\hat C_{t,f}\in\mathbb{R}^{B\times P\times H\times W}$，预测为：

$$
\hat E_{\mathrm{thres}}(t,f)=\sum_{b=1}^{B}\sum_{p=1}^{P}\mathrm{ECM}_{t,f}\odot \hat C_{t,f}^{b,p,:,:}.
$$

### 4.3 GS-Boosted Threshold Refinement and Joint Optimization

RGB frames 稀疏时，长时间积分会降低 threshold estimation 质量。E-D3DGS 先训练一个 3DGS，再冻结它，用它渲染 intermediate frames 作为额外 pseudo-supervision，优化：

$$
\hat C^*=\arg\min_{\hat C}(L_{\mathrm{thres}}+L_{\mathrm{event}}).
$$

最终联合优化 threshold 和 3DGS：

$$
\hat C^*,GS^*=\arg\min_{\hat C,GS}(L_{\mathrm{thres}}+L_{\mathrm{event}}+L_{\mathrm{rgb}}).
$$

Table 1 显示 threshold modeling 可以把 3D reconstruction PSNR 从 24.46 提高到 26.63；用 3DGS 反哺 threshold modeling 可将 threshold MSE 从 $8.317\times10^{-4}$ 降到 $7.077\times10^{-4}$；joint optimization 达到 PSNR 28.01 和 MSE $6.322\times10^{-4}$。

### 4.4 Dynamic-Static Decomposition in 2D

DSD 先用 static Gaussians 训练 3k iterations。静态区域能重建好，动态区域因无法表示 motion 而重建差。用 pretrained VGG19 $F_\phi$ 提取 rendered image $\hat I(t)$ 和 ground truth $I(t)$ 的 multi-scale features，计算 cosine similarity 并上采样融合：

$$
\mathrm{Sim}=\sum_l \mathrm{Up}\left(
\frac{F_\phi^l(\hat I(t))\cdot F_\phi^l(I(t))}
{\|F_\phi^l(\hat I(t))\|\|F_\phi^l(I(t))\|}
\right).
$$

Similarity map 具有 bimodal distribution，用 Otsu threshold 生成 dynamic mask：

$$
\mathrm{Mask}=\mathbf{1}_{\mathrm{Sim}<\mathrm{Otsu}(\mathrm{Sim})}.
$$

### 4.5 Decomposition from 2D to 3D and Soft Buffer

把 masked dynamic pixels 用 depth unprojection 从多个视角合并成 3D dynamic point cloud。每个 point 用半径 $r$ 扩张成 sphere，空间邻近的 Gaussians 被初步标为 dynamic。

为降低 radius sensitivity，E-D3DGS 使用两个半径 $r_1,r_2$。$r_1$ 内的 Gaussians 标为 dynamic，$r_2$ 外标为 static，中间区域 prune 掉形成 buffer zone。后续 adaptive density control 会在训练中重新填充/优化边界，使分解更软。DSD 只执行一次，约 1 分钟。

### 4.6 Dynamic Gaussian Deformation

Dynamic Gaussians 使用 Deformable-3DGS 风格 deformation field。输入 dynamic Gaussian center $\mu$ 和时间 $t$，输出 position、rotation、scale residuals：

$$
(\delta\mu,\delta r,\delta s)=F_\theta(\gamma(\mathrm{sg}(\mu)),\gamma(t)).
$$

更新为：

$$
(\mu',r',s')=(\mu+\delta\mu,r+\delta r,s+\delta s).
$$

Static Gaussians 绕过 deformation field，直接与 deformed dynamic Gaussians 合并进入 rasterizer。

## 5. Mathematical Objectives and Losses

E-D3DGS 的最终目标由三项组成：

$$
L=L_{\mathrm{thres}}+L_{\mathrm{event}}+L_{\mathrm{rgb}}.
$$

其中 $L_{\mathrm{thres}}$ 直接监督 threshold，$L_{\mathrm{event}}$ 用 event brightness change 监督 3DGS 和 threshold，$L_{\mathrm{rgb}}$ 保持 RGB photometric fidelity。核心训练策略是 staged-to-joint：先估 threshold，再用 GS refinement，最后 jointly fine-tune。

渲染仍使用 3DGS alpha compositing：

$$
c=\sum_{i\in N}c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j).
$$

## 6. Training and Inference Procedure

合成 benchmark 用 Blender 生成 8 个 dynamic scenes，每个 scene 一秒、360-degree monocular camera rotation，连续高时间分辨率 frames 经 ESIM 生成 events。训练只均匀采样 30 frames，相当于 30 FPS；测试选取远离训练帧的 intermediate frames。

真实 benchmark 用 beam splitter、Prophesee Gen4 event camera、Basler ace frame camera 和 STM32 同步信号搭建 hybrid camera system。相机系统固定，物体放在 motorized rotating turntable 上，等价于相机运动。

训练时先进行 threshold estimation / GTJM，再执行或结合 DSD。推理时，static Gaussians 直接渲染，dynamic Gaussians 通过 deformation field 后渲染，因此相比全动态 deformation 有更高 FPS。

## 7. Experimental Setup and Results Summary

合成数据包含 Lego、Hotdog、Materials、Music box、Celestial globe、Fan、Water wheel、Man。真实数据包含 Excavator、Jeep、Flowers、Eagle。指标为 PSNR、SSIM、LPIPS 和 RTX 3090 上 FPS。

Synthetic table 中，Ours 在 8 个场景均为最佳。例子：Lego PSNR 31.85 / FPS 189，Event-4DGS 为 28.00 / 54；Materials 38.02 / 240，Event-4DGS 为 35.60 / 74；Fan 30.18 / 168，Event-4DGS 为 27.66 / 71。论文总结 Ours 相比 Event-4DGS 平均 PSNR 提升 2.73 dB，且平均比 4D-GS 快 1.71x。

Real-world table 中，Ours 也在四场景最好：Excavator 31.28 / 0.925 / 0.070 / 179 FPS，Jeep 30.41 / 0.905 / 0.068 / 89 FPS，Flowers 28.57 / 0.913 / 0.069 / 149 FPS，Eagle 31.29 / 0.918 / 0.074 / 192 FPS。

Ablation on synthetic dataset：w/o GTJM 为 PSNR 29.39、FPS 153；w/o Joint Optimization in GTJM 为 30.87；w/o DSD 为 PSNR 30.78、FPS 57；w/o Buffer-based Soft Decomposition 为 31.02、FPS 138；Full 为 PSNR 31.56、SSIM 0.966、LPIPS 0.022、FPS 156。DSD 使 PSNR 提升 0.78 dB，并把 FPS 提升到 2.74x。

Dynamic blurry scenes 中，结合 events 的 deblurring 优势，Ours 相比 Deformable-3DGS 提升 4.79 dB PSNR。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是首个 event cameras + deformable 3DGS 动态重建方法、GTJM、DSD 和 event-inclusive 4D benchmark。实际技术增量有两个核心：一是把 event threshold 从常数改成由 RGB/GS 双重监督学习的 spatio-temporal-polartiy threshold；二是用 static-only reconstruction failure 作为 signal 来自动找 dynamic regions。

相对 Event-4DGS 这种“给 Deformable-3DGS 加 event loss”的 baseline，E-D3DGS 解决了 threshold variation artifact 和 static/dynamic capacity waste。相对 RGB-only 4D-GS / Deformable-3DGS，它获得了 RGB 帧间的高时间分辨率 motion supervision。

## 9. Limitations / Assumptions

方法需要 event + RGB hybrid capture，数据采集硬件复杂度高。真实 benchmark 用 beam splitter 和同步系统搭建，不是普通 RGB 视频可直接使用。

Threshold modeling 虽比常数强，但仍依赖 RGB frames 和 GS rendered pseudo-frames 的质量；若初始 3DGS 很差，GS-boosted threshold refinement 可能受影响。

DSD 依赖 static-only reconstruction failure 来识别 dynamic regions。低纹理动态区域、遮挡或 photometric ambiguity 可能导致 mask 不准确。

Benchmark 是论文自建，虽然有 synthetic 和 real-world，但与普通 RGB-only dynamic benchmarks 的可比性有限。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | RGB frames plus event stream |
| Output | Dynamic/static decomposed deformable 3DGS |
| Event model | Learnable threshold over time bins, polarity and pixels |
| Main loss | $L_{\mathrm{thres}}+L_{\mathrm{event}}+L_{\mathrm{rgb}}$ |
| GTJM | RGB-assisted threshold estimation plus GS-boosted refinement |
| DSD signal | Static Gaussians fail in dynamic regions |
| DSD mapping | VGG similarity mask, depth unprojection, buffer-based soft decomposition |
| Dynamic model | Deformable-3DGS field only for dynamic Gaussians |
| Strength | High temporal motion supervision and faster selective rendering |
| Weakness | Requires event hardware; threshold/model bootstrapping can be brittle |

## 11. Reusable Components

- Event threshold modeled as learnable $B\times P\times H\times W$ tensor.
- RGB-assisted threshold supervision using log brightness differences.
- Frozen-GS pseudo intermediate frames for threshold refinement.
- Joint threshold and Gaussian optimization.
- Static-only warmup to reveal dynamic regions by reconstruction failure.
- VGG feature similarity + Otsu threshold for dynamic masks.
- Buffer-based soft 2D-to-3D dynamic/static decomposition.

## 12. Gap / Idea Seeds

- Replace dense threshold tensor with lower-rank or neural threshold field for better generalization.
- Use event confidence/uncertainty to weight $L_{\mathrm{event}}$ under noisy thresholds.
- Combine DSD with Swift4D's learnable per-Gaussian dynamic parameter $d$.
- Adapt GTJM to RGB-only high-frame interpolation pseudo-events.
- Explore online DSD updates instead of one-time decomposition.

## 13. Human Check List

- NEED_HUMAN_CHECK: Real-world supplementary ablations are referenced but not in extracted text; note records main synthetic ablation table.
- NEED_HUMAN_CHECK: Exact implementation details for threshold parameterization size/binning may require code or supplementary.
- NEED_HUMAN_CHECK: Venue/year inferred from ICCV open-access watermark and Zotero date 2025.

## 14. Evidence Anchors

- Abstract and Figure 1: method overview, GTJM artifacts and DSD dynamic/static rendering.
- Section 3.1: event rendering loss and RGB loss.
- Section 3.2 / Table 1: GS-threshold joint modeling and mutual boosting.
- Section 3.3 / Figure 5: DSD from 2D mask to 3D Gaussians and buffer zone.
- Tables 2-3: synthetic and real-world benchmark results.
- Table 4 / Figures 10-12: ablation of GTJM, joint optimization, DSD and buffer size.
- Figure 6: real-world hybrid event/RGB acquisition setup.
