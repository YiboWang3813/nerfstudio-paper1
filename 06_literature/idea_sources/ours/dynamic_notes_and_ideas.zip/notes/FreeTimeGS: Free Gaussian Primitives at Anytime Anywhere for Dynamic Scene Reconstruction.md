# FreeTimeGS: Free Gaussian Primitives at Anytime Anywhere for Dynamic Scene Reconstruction

## 0. Metadata

- Title: FreeTimeGS: Free Gaussian Primitives at Anytime Anywhere for Dynamic Scene Reconstruction
- Authors: Yifan Wang; Peishan Yang; Zhen Xu; Jiaming Sun; Zhanhua Zhang; Yong Chen; Hujun Bao; Sida Peng; Xiaowei Zhou
- Venue/Year: CVPR 2025
- Zotero item key: `84ZVPYNH`
- Zotero PDF attachment key: `7PVMB3F4`
- PDF path: `/Users/wangyibo/Zotero/storage/7PVMB3F4/Wang 等 - FreeTimeGS Free Gaussian Primitives at Anytime Anywhere for Dynamic Scene Reconstruction.pdf`
- Local note path: `notes/FreeTimeGS: Free Gaussian Primitives at Anytime Anywhere for Dynamic Scene Reconstruction.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

FreeTimeGS 放弃 canonical-space Gaussians + long-range deformation field，把每个 Gaussian 直接定义在 4D 时空中，并赋予 appearance time、duration、linear velocity 和 temporal opacity，使 primitives 可以在任意时间任意位置出现并短程移动，从而更容易重建快速复杂运动。

## 2. Problem Formulation

Canonical deformation methods 在动态 3DGS 中很常见：先在 canonical space 建 Gaussians，再用 deformation field 映射到每个 observation time。它们在小运动场景中效果好，但面对快速、大幅、复杂运动时，需要从 canonical state 到 observation state 建立 long-range correspondence。这个对应关系仅从 RGB supervision 中优化，容易陷入局部最优或产生模糊。

FreeTimeGS 的目标是用更自由的 4D primitive 表达动态场景。与其要求所有 Gaussians 永久存在于 canonical space 并跨时间大幅 deformation，不如允许 Gaussian 在某个时间附近出现，在空间上只做邻域短程移动。这样运动函数可以简化为线性 velocity，表示复杂动态时依赖 primitive 的时空分布，而不是依赖一个强 deformation MLP。

输入是 multi-view dynamic videos，输出是可在任意时间和新视角渲染的动态 3D Gaussian representation。论文主要面向 multi-view dynamic novel view synthesis，而非单目重建。

## 3. Method Overview

FreeTimeGS 的核心表示是 Gaussian primitives at anytime anywhere。每个 primitive 学习八类参数：position、time、duration、velocity、scale、orientation、opacity 和 spherical harmonics coefficients。给定查询时间 $t$，Gaussian 先根据自己的 velocity 从原始时空位置 $\mu_x,\mu_t$ 移动到 $\mu_x(t)$，再通过 spatial Gaussian density 和 temporal opacity $\sigma(t)$ 共同决定它在当前帧的贡献。

训练仍通过 differentiable Gaussian rasterization 和图像监督优化，但论文发现仅用 rendering loss 时，快速运动区域容易陷入局部最优。原因是很多 Gaussians 的 opacity 接近 1，会遮挡梯度传播。因此 FreeTimeGS 在早期加入 4D regularization，惩罚高 opacity，且用 temporal opacity 加权，避免惩罚当前时间影响很小的 Gaussians。

此外，方法加入 periodic relocation：定期把低 opacity primitives 移到高梯度/高 opacity 区域，以减少 4D regularization 带来的 primitive 数量膨胀。初始化阶段用 ROMA 匹配 multi-view 2D points，再 triangulate 成 3D points，同时通过相邻帧 KNN displacement 初始化 velocity。

## 4. Method Details

### 4.1 Free Gaussian Primitive

每个 Gaussian primitive 包含空间位置 $\mu_x$、中心时间 $\mu_t$、duration $s$、velocity $v$、scale、orientation、opacity $\sigma$ 和 SH color coefficients。不同于 canonical Gaussian，FreeTimeGS 中的 Gaussian 不需要在全时间范围内存在，而是在 $\mu_t$ 附近通过 temporal opacity 激活。

Gaussian 在时间 $t$ 的实际空间位置由线性 motion function 给出：

$$
\mu_x(t)=\mu_x+v\cdot(t-\mu_t).
$$

这里 $v\in\mathbb{R}^3$。由于 primitive 自身可以出现在任意时间和任意空间位置，$v$ 只需要解释邻域短程运动，而不是 canonical-to-observation 的长程形变。

### 4.2 Color and Opacity

颜色仍使用 view-dependent spherical harmonics：

$$
c=\sum_{l=0}^{L}\sum_{m=-l}^{l}c_{lm}Y_{lm}(d(\mu_x(t))).
$$

其中 $d(\mu_x(t))$ 是移动后 Gaussian 位置对应的 view direction。空间 covariance 由 scale 和 orientation 定义，$\Sigma=RSS^\top R^\top$。

Gaussian 在空间位置 $x$ 和时间 $t$ 的 opacity density 为：

$$
\sigma(x,t)=\sigma(t)\cdot\sigma\cdot\exp\left(-\frac{1}{2}(x-\mu_x(t))^\top\Sigma^{-1}(x-\mu_x(t))\right).
$$

Temporal opacity $\sigma(t)$ 控制 primitive 在时间维的影响范围。论文将其建模为 Gaussian distribution：

$$
\sigma(t)=\exp\left(-\frac{1}{2}\left(\frac{t-\mu_t}{s}\right)^2\right).
$$

$\mu_t$ 和 $s$ 可由 rendering gradients 自动调整，因此 primitive 的出现时间和持续时间是可学习的。

### 4.3 Rendering Loss

训练使用 image loss、SSIM loss 和 perceptual loss：

$$
L_{\mathrm{render}}=\lambda_{\mathrm{img}}L_{\mathrm{img}}+\lambda_{\mathrm{ssim}}L_{\mathrm{ssim}}+\lambda_{\mathrm{perc}}L_{\mathrm{perc}}.
$$

默认权重为 $\lambda_{\mathrm{img}}=0.8$，$\lambda_{\mathrm{ssim}}=0.2$，$\lambda_{\mathrm{perc}}=0.01$。

### 4.4 4D Opacity Regularization

仅用 rendering loss 时，许多 primitives 的 opacity 变得很高，阻碍其他 Gaussians 获得梯度。FreeTimeGS 用 4D regularization 惩罚高 opacity：

$$
L_{\mathrm{reg}}(t)=\frac{1}{N}\sum_{i=1}^{N}\left(\sigma_i\cdot\mathrm{sg}[\sigma_i(t)]\right).
$$

其中 $\mathrm{sg}[\cdot]$ 是 stop-gradient。Temporal opacity 作为权重，表示 primitive 在当前训练帧的影响；stop-gradient 防止模型通过压低 temporal opacity 来逃避 regularization。默认 $\lambda_{\mathrm{reg}}=10^{-2}$。

### 4.5 Periodic Relocation

Opacity regularization 会降低无效高 opacity，但也可能需要更多 primitives 表达同一场景。FreeTimeGS 因此定期 relocation：把 opacity 低于阈值的 primitives 移到更需要 primitives 的区域。采样 score 为：

$$
s=\lambda_g\nabla g+\lambda_o\sigma.
$$

这里 $\nabla g$ 是 Gaussian primitive 的 spatial gradient，$\sigma$ 是 opacity，$\lambda_g=\lambda_o=0.5$。Relocation 每 $N=100$ iterations 执行一次。

### 4.6 4D Initialization and Motion Scheduler

初始化时，对每个视频帧，用 ROMA 在 multi-view images 中获取 2D matches，再 triangulate 得到 3D points；这些 points 和对应 time step 初始化 primitive position 和 time。相邻两帧的 3D points 通过 KNN 匹配，point-pair translation 初始化 velocity。

训练中对 velocity learning rate 做 annealing motion scheduler。可见文本中的形式为 $\lambda_t=\lambda_0^{1-t}+\lambda_1^t$，其中 $t$ 从 0 到 1。其目的在于早期快速建模 fast motion，后期更细致地优化 complex motion。

## 5. Mathematical Objectives and Losses

FreeTimeGS 的优化目标由 rendering loss 和 4D opacity regularization 组成：

$$
L=L_{\mathrm{render}}+\lambda_{\mathrm{reg}}L_{\mathrm{reg}}.
$$

其中 $L_{\mathrm{render}}$ 负责图像重建，$L_{\mathrm{reg}}$ 在训练早期降低高 opacity 导致的梯度遮挡。方法没有使用 deformation MLP，也没有 explicit physical loss；运动先验主要来自每个 primitive 的 linear velocity 和 temporal Gaussian opacity。

从表示角度看，FreeTimeGS 用时空局部 primitives 代替 canonical global deformation。一个 dynamic point 可以由在相邻时间出现的多个 primitives 表示，也可以由一个 primitive 通过 velocity 在短时间内复用。Temporal duration $s$ 控制这种复用范围。

## 6. Training and Inference Procedure

实现使用 PyTorch 和 Adam，参数设置沿用 3DGS。对 300 帧序列训练 30k iterations，在 RTX 4090 上约 1 小时。4D regularization 权重为 $10^{-2}$，periodic relocation 每 100 iterations 执行一次。

训练流程：先用 multi-view matching 和 triangulation 初始化 primitive position/time/velocity；然后用 rendering loss、perceptual loss 和 4D opacity regularization 优化全部 primitive parameters；训练过程中执行 relocation 和 velocity learning-rate annealing。

推理时，给定时间 $t$ 和新视角，先对每个 primitive 计算 temporal opacity $\sigma(t)$ 和移动后位置 $\mu_x(t)$，再用标准 Gaussian splatting 的投影与 alpha compositing 渲染。论文报告在 1080p 下 RTX 4090 单卡可达约 450 FPS，SelfCap 表中为 467 FPS。

## 7. Experimental Setup and Results Summary

实验使用 Neural3DV、ENeRF-Outdoor 和自采 SelfCap。Neural3DV 包含 6 个场景、19-21 个 cameras、2704x2028、30 FPS，使用前 300 帧并 resize 0.5。ENeRF-Outdoor 包含 3 个 outdoor scenes、18 cameras、1920x1080、60 FPS。SelfCap 包含 8 个 fast/complex motion scenes、22-24 cameras、60 帧、3840x2160 或 bike scene 1080x1080。

Neural3DV 上，FreeTimeGS 得到 PSNR 33.19、DSSIM1 0.026、DSSIM2 0.013、LPIPS 0.036，优于 STGS 的 32.05 / 0.026 / 0.014 / 0.044、4DGS 的 32.01 / 0.014 / 0.055、Ex4DGS 的 32.11 / 0.030 / 0.015 / 0.048。

ENeRF-Outdoor 上，FreeTimeGS 得到 PSNR 25.36、DSSIM2 0.077、LPIPS 0.244、FPS 454，优于 ENeRF、4K4D、4DGS 和 STGS。相比 4K4D 的 220 FPS 和 STGS 的 226 FPS，FreeTimeGS 速度也更高。

SelfCap 上，表 3 同时报告 whole image / dynamic regions。FreeTimeGS 为 PSNR 27.41 / 29.38，DSSIM2 0.024 / 0.013，LPIPS 0.204 / 0.080，FPS 467。4DGS 为 25.98 / 26.75，STGS 为 24.97 / 25.32。动态区域 PSNR 提升尤其明显。

消融在 SelfCap dance1 上进行。完整模型在 entire / fastest subsequence 上为 PSNR 29.74 / 30.75，LPIPS 0.152 / 0.133。去掉 proposed motion 降到 28.10 / 26.92；去掉 4D regularization 为 28.68 / 29.09；去掉 periodic relocation 为 29.07 / 29.15；去掉 4D initialization 为 28.33 / 27.06。$\lambda_{\mathrm{reg}}$ 消融显示 $10^{-2}$ 最优，$10^{-1}$ 过强会严重降低质量。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 FreeTimeGS 4D representation、每个 Gaussian 的 explicit motion function、4D opacity regularization、periodic relocation 和 4D initialization。实际技术增量集中在表示侧：把 canonical-space persistent primitive 改成 spacetime-local primitive。

与 4DGS / STGS 相比，FreeTimeGS 不把 velocity 与 spatial scale 或 angular velocity 强耦合，而是用简单 Euclidean linear velocity 和 temporal Gaussian opacity。与 deformation-field methods 相比，它不需要学习从 canonical 到 observation 的长程 deformation，因此在快速复杂运动中优化更容易。

这种设计的代价是 primitive 数量和时空管理更重要，因此需要 4D regularization、relocation 和初始化策略配合，不能只看作“给 Gaussian 加个时间维”。

## 9. Limitations / Assumptions

FreeTimeGS 仍然需要每个动态场景单独较长训练过程。论文明确提到未来可以用 generative priors 做 optimization-free reconstruction。

当前表示只关注 novel view synthesis，不支持 relighting。若要扩展到 relighting，需要加入 surface normal、material properties 或更物理的 appearance model。

Linear velocity 适合短程运动复用，但对于长时间强加速度或复杂非线性轨迹，需要多个 temporal primitives 协同表达；这可能增加存储和优化负担。

方法依赖 multi-view matching / triangulation 初始化来提升 fast motion 建模，弱纹理、遮挡或视角不足可能影响初始化质量。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Multi-view dynamic videos |
| Output | 4D Gaussian primitives for dynamic NVS |
| Core representation | Free primitives with position, time, duration, velocity, scale, orientation, opacity, SH |
| Motion model | Per-primitive linear velocity $\mu_x(t)=\mu_x+v(t-\mu_t)$ |
| Temporal support | Gaussian temporal opacity $\sigma(t)$ with learnable center and duration |
| Optimization | Rendering + SSIM + perceptual loss plus 4D opacity regularization |
| Extra strategies | Periodic relocation; ROMA + triangulation 4D initialization; velocity scheduler |
| Strength | High quality and high FPS on fast multi-view dynamic scenes |
| Weakness | Per-scene optimization; no relighting; linear motion needs many primitives for nonlinear dynamics |

## 11. Reusable Components

- Spacetime-local Gaussian primitive with learnable appearance time and duration.
- Per-Gaussian linear velocity as short-range motion function.
- Temporal opacity weighting for 4D Gaussian activation.
- Stop-gradient temporal-opacity-weighted opacity regularizer.
- Periodic relocation from low-opacity primitives to high-gradient/high-opacity regions.
- Multi-view matching + triangulation initialization for dynamic Gaussian position/time/velocity.
- Velocity learning-rate annealing for early fast motion and late detailed refinement.

## 12. Gap / Idea Seeds

- Replace linear velocity with low-order spline only when duration is long, keeping short-duration primitives linear.
- Use temporal opacity and relocation scores to build automatic pruning/compression.
- Combine FreeTimeGS with learned priors to reduce per-scene 30k-iteration training.
- Add surface/material attributes for relighting while preserving spacetime-local flexibility.
- Study whether primitive appearance time/duration can support streaming updates for online dynamic capture.

## 13. Human Check List

- NEED_HUMAN_CHECK: Venue/year inferred from CVPR open-access watermark and Zotero date 2025; confirm final citation if needed.
- NEED_HUMAN_CHECK: Velocity scheduler formula is garbled in extracted text; verify exact interpolation form from PDF before implementation.
- NEED_HUMAN_CHECK: Table 1 has footnotes for Neural Volume and HexPlane exclusions; note records aggregate numbers but not per-scene details.

## 14. Evidence Anchors

- Figure 1: SelfCap quality/speed comparison and motivation for complex motion.
- Section 3.1: Gaussian primitives at anytime anywhere; motion, SH color, spatial-temporal opacity.
- Section 3.2: rendering loss, 4D regularization, periodic relocation and initialization.
- Section 3.3: training iterations, weights and relocation interval.
- Tables 1-3: Neural3DV, ENeRF-Outdoor and SelfCap comparisons.
- Tables 4-5 and Figure 6: component and $\lambda_{\mathrm{reg}}$ ablations.
- Conclusion: limitations on per-scene reconstruction and relighting.
