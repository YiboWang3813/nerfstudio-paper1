# MEGA: Memory-Efficient 4D Gaussian Splatting for Dynamic Scenes

## 0. Metadata

- Title: MEGA: Memory-Efficient 4D Gaussian Splatting for Dynamic Scenes
- Authors: Xinjie Zhang; Zhening Liu; Yifan Zhang; Xingtong Ge; Dailan He; Tongda Xu; Yan Wang; Zehong Lin; Shuicheng Yan; Jun Zhang
- Venue/Year: ICCV 2025
- Code: https://github.com/Xinjie-Q/MEGA
- Zotero item key: `LE94WA4X`
- Zotero PDF attachment key: `M9MH8GSY`
- PDF path: `/Users/wangyibo/Zotero/storage/M9MH8GSY/Zhang 等 - MEGA Memory-Efficient 4D Gaussian Splatting for Dynamic Scenes.pdf`
- Local note path: `notes/MEGA: Memory-Efficient 4D Gaussian Splatting for Dynamic Scenes.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

MEGA 通过 DC-AC color representation 去掉 4DGS 中高开销的 4D spherical harmonics，并用 temporal-viewpoint aware deformation predictor 扩大单个 4D Gaussian 的作用范围，再用 opacity entropy loss 限制 Gaussian 数量，实现百倍级存储压缩且保持相近动态渲染质量。

## 2. Problem Formulation

4DGS 用 4D Gaussians 表示动态场景，质量高但内存开销巨大。每个 4D Gaussian 在原始 4DGS 中约 161 个参数，其中 4D spherical harmonics color coefficients 可占 144 个参数，成为主要存储来源。另一方面，4DGS 的 temporal slicing 只给每个 Gaussian 线性时间运动和固定 covariance，复杂运动需要大量 Gaussians 组合表达。

此外，temporal decay opacity 使每个 Gaussian 只在靠近其 temporal center $\mu_t$ 的时间段可见。论文观察到 Birthday scene 任意时间参与渲染的 Gaussians 只有约 6%，导致模型为覆盖全时间段不断 densify。

MEGA 的目标是同时减少 per-Gaussian attributes 和 Gaussian count。它不是单纯 post-compression，而是在表示、训练和存储三个层面修改 4DGS。

## 3. Method Overview

MEGA 的框架有三部分。第一，memory-efficient 4D Gaussian color：把原 4D SH coefficients 替换为每个 Gaussian 的 3 参数 DC color $c_{\mathrm{dc}}$，再用共享的 temporal-viewpoint aware AC color predictor MLP 补偿时间和视角相关颜色变化。

第二，entropy-constrained Gaussian deformation：对每个 Gaussian，根据时间、视角和 4D position 预测 4D center、scale、left/right quaternion 的 deformation，使 Gaussian 的 motion、shape 和 transience 更灵活，能覆盖更大 action range。

第三，opacity-based entropy loss：把 spatial opacity 推向二值状态，帮助识别并删除低贡献 Gaussians，迫使模型用更少 Gaussians 表达动态场景。最终用 FP16 和 zip delta compression 存储。

## 4. Method Details

### 4.1 4DGS Temporal Slicing

4DGS 中每个 Gaussian 有 4D center $\mu_{4D}$、4D rotation $R_{4D}$、4D scale $s_{4D}$、4D SH color $h$ 和 spatial opacity $o$。4D covariance 为：

$$
\Sigma_{4D}=R_{4D}S_{4D}S_{4D}^{T}R_{4D}^{T}
=
\begin{bmatrix}
U & V\\
V^T & W
\end{bmatrix}.
$$

在时间 $t$ slicing 后，3D density 为：

$$
G_{3D}(x,t)=\sigma(t)\exp\left(-\frac{1}{2}[x-\mu_{3D}(t)]^T\Sigma_{3D}^{-1}[x-\mu_{3D}(t)]\right).
$$

其中：

$$
\Sigma_{3D}=U-\frac{VV^T}{W}.
$$

Temporal opacity 和 center linear motion 为：

$$
\sigma(t)=\exp\left(-\frac{(t-\mu_t)^2}{2W}\right),\quad
\mu_{3D}(t)=\mu_{3D}+(t-\mu_t)\frac{V}{W}.
$$

这个原始设计高效但 rigid：motion 是线性的，covariance 不随时间/视角改变。

### 4.2 DC-AC Color Representation

原 4DGS 用 4D spherical harmonics $h$ 表达 temporal-view-dependent color，参数多且冗余。MEGA 将 color 分为 per-Gaussian direct current component $c_{\mathrm{dc}}\in\mathbb{R}^3$ 和共享 AC predictor $F_\phi$。

对 viewpoint $v$，camera center 为 $p_v$，view direction 为：

$$
d_v=\frac{\mu_{3D}-p_v}{\|\mu_{3D}-p_v\|_2}.
$$

最终 color 为：

$$
c_{t,v}=\mathrm{sigmoid}\left(c_{\mathrm{dc}}+F_\phi(\mathrm{sg}(\mu_{3D}),\mathrm{sg}(d_v),t,c_{\mathrm{dc}})\right).
$$

$\mathrm{sg}(\cdot)$ 是 stop-gradient。DC component 保留每个 Gaussian 的稳定颜色信息，AC predictor 提供时间和视角变化。相同 Gaussian 数量下，该表示相对原 4DGS 约 8x 减少参数。

### 4.3 Temporal-Viewpoint Aware Deformation Predictor

为扩大每个 Gaussian 的作用范围，MEGA 用 deformation predictor $F_\theta$ 根据 4D center、view direction 和 time 预测 center/scale/rotation 变化：

$$
(m_{\mu_{4D}}^{t,v},m_{s_{4D}}^{t,v},m_{q_l}^{t,v},m_{q_r}^{t,v})
=F_\theta(\gamma(\mathrm{sg}(\mu_{4D})),\gamma(\mathrm{sg}(d_v)),\gamma(t)).
$$

其中 $\gamma$ 是 sinusoidal frequency positional encoding。预测后更新原始 4D Gaussian：

$$
\mu_{4D}^{t,v}=\mu_{4D}\times m_{\mu_{4D}}^{t,v},\quad
s_{4D}^{t,v}=s_{4D}\times m_{s_{4D}}^{t,v}.
$$

$$
q_l^{t,v}=q_l\times m_{q_l}^{t,v},\quad
q_r^{t,v}=q_r\times m_{q_r}^{t,v}.
$$

抽取文本显示为乘法形式；实现中需核对是否为逐元素缩放/offset 参数化。核心作用是让每个 4D Gaussian 的 motion、shape 和 temporal behavior 更灵活，减少必须 densify 的数量。

### 4.4 Opacity-Based Entropy Loss

仅加入 deformation predictor 会使 Gaussians 继续 split/clone，数量可能增加。因此 MEGA 加入 opacity-based entropy loss $L_{\mathrm{opa}}$，推动 spatial opacity 接近 0 或 1。低 opacity Gaussians 更容易被识别为无用并删除，高 opacity Gaussians 保留有效贡献。

总 loss 为：

$$
L=L_{\mathrm{photo}}+\kappa L_{\mathrm{opa}}
=(1-\lambda)L_1+\lambda L_{\mathrm{ssim}}+\kappa L_{\mathrm{opa}}.
$$

论文设 $\lambda=0.2$、$\kappa=0.0005$。

### 4.5 Compression Pipeline

训练阶段使用 half-precision training。优化完成后，MEGA 将 learnable parameters 以 FP16 格式存储，并应用 zip delta compression。论文称该 lossless compression 通常额外降低约 10% storage。

## 5. Mathematical Objectives and Losses

MEGA 的核心优化不是单独压缩码率，而是通过 representation 和 loss 改变训练动力学。DC-AC color 降低每个 Gaussian 的 color 参数；deformation predictor 提升每个 Gaussian 的表达范围；$L_{\mathrm{opa}}$ 通过二值化 opacity 抑制冗余 Gaussian proliferation。

Ablation 表显示这三者需要组合使用。只用 DAC 能降参数但 Gaussian 数量仍大；只加 deformation 可能反而增加 Gaussian 数量；DAC + deformation + $L_{\mathrm{opa}}$ 才能把 Birthday scene 从 13M Gaussians 降到 0.91M，同时 PSNR 从 31.00 提到 32.02。

## 6. Training and Inference Procedure

MEGA 训练 30k iterations，并在中点停止 densification。Optimizer 为 Adam，batch size 1，沿用原 4DGS 的多数 loss weight、learning rate 和 threshold 参数。渲染时过滤 $\sigma(t)\le0.05$ 的 Gaussians。

Deformation predictor 使用 weight regularization $10^{-6}$，learning rate 从 $8\times10^{-4}$ 指数衰减到 $1.6\times10^{-6}$。AC color predictor 初始 learning rate 为 0.01，100-step warm-up，并在 5k、15k、25k steps 各下降 3 倍。

推理时，先对每个 Gaussian 做 per-Gaussian transformation，包括 AC color prediction 和 geometry deformation；之后按原 4DGS 做 temporal slicing、projection 和 differentiable rasterization。

## 7. Experimental Setup and Results Summary

Technicolor Light Field Dataset：4x4 camera rig，排除第二行第二列 camera，评估 Birthday、Fabien、Painter、Theater、Trains，分辨率 2048x1088。MEGA 得到 PSNR 33.57、DSSIM1 0.0442、DSSIM2 0.0204、LPIPS 0.1014、FPS 83.14、storage 32.45MB。相比 4DGS 的 32.07、0.0535、0.0263、0.1189、55.26 FPS、6107.07MB，MEGA 质量更高、速度更快，storage 约 190x 更小。

Neural 3D Video：300-frame scenes，half resolution。MEGA 得到 PSNR 31.49、DSSIM1 0.0290、DSSIM2 0.0165、LPIPS 0.0568、FPS 77.42、storage 25.05MB。4DGS 为 31.57、0.0290、0.0164、0.0573、96.69 FPS、3128MB。质量和速度接近，storage 约 125x 更小。

Ablation：Technicolor Birthday 上，4DGS 为 31.00 PSNR、13.00M Gaussians、2093.56M params；w/ DAC 为 31.60、15.43M、308.65M；w/ DAC+Lopa 为 31.46、9.15M、183.23M；w/ DAC+Deformation+Lopa 为 32.02、0.91M、18.48M。Fabien 从 5.43M 降到 0.31M Gaussians。Neu3DV Flame Steak / Sear Steak 也显示 DAC 大幅降参数，$L_{\mathrm{opa}}$ 降数量，组合后最紧凑。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 memory-efficient 4DGS framework、DC-AC color、entropy-constrained Gaussian deformation 和 FP16/zip 后处理。实际技术增量在于把 4DGS 的两个主要存储来源分开处理：color coefficients 用共享网络替换，Gaussian 数量用 deformation + entropy regularization 压低。

相对 4DGS-1K，MEGA 更偏训练中改变 representation 和 densification behavior，而不是主要在后期剪枝与 runtime mask。相对传统 3DGS compression，它考虑了 4DGS 中 temporal/view-dependent color 和 temporal opacity 导致的低 utilization。相对 deformation-field methods，MEGA 仍保留 explicit 4D Gaussian slicing，只是在 slicing 前做 per-Gaussian transformation。

## 9. Limitations / Assumptions

AC color predictor 是共享 MLP，虽然省存储，但推理时增加每个 Gaussian 的网络计算。论文结果显示 FPS 仍实时，但在更低算力设备上需权衡。

Deformation predictor 是 temporal-viewpoint aware，可能引入 view-dependent geometry transformation 的风险；如果约束不足，可能产生多视角不一致。论文用 stop-gradient 和 weight regularization 稳定训练。

MEGA 主要压缩 4DGS，并不根本解决 4DGS 对复杂拓扑变化或极端 motion 的表达上限。

抽取文本中 $L_{\mathrm{opa}}$ 的具体 entropy formula 被截断，复现需回看 PDF/代码。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Target | 4D Gaussian Splatting compression |
| Main storage issue | 4D SH color coefficients and too many Gaussians |
| Color solution | Per-Gaussian DC color + shared AC color predictor |
| Geometry solution | Temporal-viewpoint aware 4D Gaussian deformation predictor |
| Count control | Opacity-based entropy loss $L_{\mathrm{opa}}$ |
| Storage backend | FP16 plus zip delta compression |
| Technicolor result | 33.57 PSNR, 32.45MB, 83.14 FPS |
| Neu3DV result | 31.49 PSNR, 25.05MB, 77.42 FPS |
| Strength | 125x-190x compression with comparable quality |
| Weakness | Extra predictor inference; exact entropy details need code/PDF |

## 11. Reusable Components

- DC-AC decomposition for Gaussian color compression.
- Shared temporal-viewpoint MLP to replace per-Gaussian high-dimensional SH.
- Stop-gradient on position/view direction in color and deformation predictors.
- Per-Gaussian transformation before 4DGS temporal slicing.
- Opacity entropy regularization to control Gaussian proliferation.
- FP16 + zip delta compression for final 4DGS storage.
- Participation-ratio analysis to diagnose Gaussian utilization.

## 12. Gap / Idea Seeds

- Combine MEGA's DC-AC color with 4DGS-1K temporal filtering for both storage and runtime gains.
- Distill AC predictor outputs into small codebooks for edge devices.
- Add multi-view consistency loss if view-dependent deformation causes geometry inconsistency.
- Make opacity entropy schedule adaptive to scene complexity.
- Explore low-rank or hash-conditioned AC predictor to reduce per-Gaussian inference cost.

## 13. Human Check List

- NEED_HUMAN_CHECK: The exact mathematical definition of $L_{\mathrm{opa}}$ is truncated in extracted text; consult PDF/code before implementation.
- NEED_HUMAN_CHECK: Eq. 5 transformation uses multiplication in extracted text; verify exact parameterization of center deformation.
- NEED_HUMAN_CHECK: Venue/year inferred from ICCV open-access watermark and Zotero date 2025.

## 14. Evidence Anchors

- Abstract and Figure 1: compression ratios and Birthday scene example.
- Figure 2 / Section 3.1: temporal slicing in 4DGS.
- Figure 3 / Section 3.2: DC-AC color, deformation predictor and rendering process.
- Figure 4: participation ratio and Gaussian count during training.
- Section 3.3 / Section 4.1: training and compression pipeline details.
- Tables 1-2: Technicolor and Neu3DV comparisons.
- Table 3: ablation of DAC, deformation and opacity loss.
