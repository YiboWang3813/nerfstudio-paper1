# CoMapGS: Covisibility Map-based Gaussian Splatting for Sparse Novel View Synthesis

## 0. 元数据

* Title: CoMapGS: Covisibility Map-based Gaussian Splatting for Sparse Novel View Synthesis
* Authors: Youngkyoon Jang; Eduardo Perez-Pellitero
* Year: 2025
* Venue: CVPR
* PDF source: `/Users/wangyibo/Zotero/storage/LY8TJ7K6/Jang和Perez-Pellitero - CoMapGS Covisibility Map-based Gaussian Splatting for Sparse Novel View Synthesis.pdf`
* Zotero item key: `8XPSCVMB`
* Zotero PDF attachment key: `LY8TJ7K6`
* Code: Not specified
* Project page: `youngkyoonjang.github.io/projects/comapgs`
* Dataset link: Not specified
* Main task: sparse novel view synthesis with 3D Gaussian Splatting
* Domain: sparse-view 3DGS, covisibility-aware supervision, point cloud initialization
* Input: sparse posed training images, COLMAP camera poses/point cloud, MASt3R dense correspondences, monocular depth
* Output: enhanced initial point cloud and trained 3DGS model for sparse NVS

## 1. 一句话技术摘要

CoMapGS 为每张训练图构建 pixel-wise covisibility map，用 MASt3R dense correspondences 和单目深度分别补强多视图/单视图区域的初始点云，再训练 proximity MLP classifier 并按 covisibility count 对 Gaussians 加权施加 proximity loss，从而把 sparse-view 3DGS 的监督从高共视区域重新平衡到欠表示区域。

## 2. 问题形式化

作者认为 sparse-view NVS 的关键不只是训练视图总数少，而是 region-wise covisibility 不均衡：有些区域被多个训练视角反复看到，得到强多视图约束；有些区域只在单个视角出现，几乎没有多视图几何监督。常规 3DGS/FSGS/CoR-GS 在优化时更容易拟合高共视区域，导致 mono-view 或低共视区域纹理缺失、几何不稳定。

CoMapGS 因此对每个 training image $I_i$ 构建 covisibility map $M_i$，其中 $M_i(x,y)$ 表示像素 $(x,y)$ 在其他训练视图中能找到 dense correspondence 的数量。该 map 同时用于点云初始化和训练监督加权。

## 3. 方法概览

CoMapGS 建立在 CoR-GS/FSGS 等 3DGS sparse-view 方法上，主要增加两个模块。

第一，enhanced point cloud initialization。对低不确定的多视图区域，使用 MASt3R dense correspondences 三角化更多 3D points，补充 COLMAP sparse points；对高不确定的 mono-view 区域，使用单目深度反投影生成 points，并通过从多视图区域学习到的 anisotropic scaling 把它们对齐到 COLMAP 坐标系。

第二，covisibility map-based weighted supervision。先用增强点云训练 proximity MLP classifier，判断任意 3D point 是否接近真实场景几何。训练 3DGS 时，对每个 Gaussian 计算 proximity loss，并根据它投影到 covisibility map 的 count 分配权重：低 covisibility/mono-view 区域权重大，高 covisibility 区域权重小；对视锥外 Gaussians 还根据场景平均 covisibility score 施加 scene-level weight。

## 4. 方法细节

**Covisibility map generation。** 给定训练图像集合 $T=\{I_1,\ldots,I_n\}$，对每个图像 $I_i$，用 MASt3R 对 $(I_i,I_j)$ 预测 dense correspondences。若 $I_i$ 中像素 $(x,y)$ 在 $I_j$ 中有 correspondence，则计数加一。最终 $M_i$ 的值域为 $0$ 到 $n-1$，$0$ 表示 mono-view/high-uncertainty，较大值表示 low-uncertainty/multiview。

**多视图区域补点。** 对 MASt3R dense correspondences 做三角化得到点集 $P_T$，并与 COLMAP 点云 $P_C$ 合并。为避免冗余，只加入与已有 COLMAP 点距离超过阈值 $\epsilon$ 的 triangulated points。

**单视图区域补点。** 对每张图像用 monocular depth 反投影得到点集 $P_d$，并根据 covisibility map 分成 $P_d^{low}$ 和 $P_d^{high}$。作者使用多视图区域中已可靠的点学习一个 anisotropic scaling transformation $f_{\text{scale}}$，将随机尺度的单目深度点对齐到 COLMAP/triangulated geometry 的尺度，然后把 mono-view 区域补入最终点云。

**Proximity classifier。** 使用增强点云 $P_{\text{final}}$ 中的 points 作为 positive samples，随机分布且远离 $P_{\text{final}}$ 的 points 作为 negatives，训练 3-layer MLP $f_p:\mathbb{R}^3\rightarrow[0,1]$。该 classifier 输出 point 接近原始场景几何的 proximity score $s$。

**Weighted proximity supervision。** 对完整 Gaussian set $\mathcal{G}$，如果 Gaussian 投影在当前视图 frustum 内，则使用 $w_{\text{in}}=1/(M_i(\pi(g,H_i))+1)$。因此 mono-view 区域 $M_i=0$ 权重最大，多视图区域权重随 covisibility count 增大而降低。如果 Gaussian 在视锥外，则用场景平均 covisibility score $S$ 计算 $w_{\text{out}}$，只在高共视场景中较强地约束视锥外 Gaussians。

## 5. 数学目标与损失

Covisibility map 定义为：

$$
M_i(x,y)=\sum_{j=1,j\neq i}^{n}\delta_{(x,y)\in P(C_i^j)},\quad \forall(x,y)\in I_i
$$

其中 $C_i^j=f_{\text{cor}}(I_i,I_j)$ 是 dense correspondence，$P(C_i^j)$ 是在 $I_i$ 中具有 correspondences 的像素坐标集合。

多视图点云合并为：

$$
P_u=P_C\cup\{p_T\in P_T\mid D(p_T,P_C)>\epsilon\}
$$

单目深度尺度对齐学习为：

$$
f_{\text{scale}}(P_d^{low})\approx P_u^{low}
$$

mono-view 区域点经尺度对齐后为：

$$
P_s^{high}=f_{\text{scale}}(P_d^{high})
$$

最终增强点云为：

$$
P_{\text{final}}=P_u^{low}\cup P_s^{high}
$$

Proximity classifier 输出：

$$
s=f_p(p)\in[0,1]
$$

Proximity loss 为：

$$
L_p=\frac{1}{|\mathcal{G}|}\sum_{g\in\mathcal{G}}(\chi(g)w_{\text{in}}+(1-\chi(g))w_{\text{out}})\cdot(1-s)
$$

其中 frustum indicator 为：

$$
\chi(g)=
\begin{cases}
1,& \pi(g,H_i)\in[0,W)\times[0,H)\\
0,& \text{otherwise}
\end{cases}
$$

视锥内权重为：

$$
w_{\text{in}}=\frac{1}{M_i(\pi(g,H_i))+1}
$$

视锥外权重为：

$$
w_{\text{out}}=\max(0,\frac{S-0.7}{0.3})
$$

最终 3DGS 目标为：

$$
L=(1-\lambda)L_1(I,I^*)+\lambda L_{\text{D-SSIM}}(I,I^*)+L_p
$$

## 6. 训练与推理流程

1. 输入 sparse posed training images，运行 COLMAP 得到 camera poses 和 sparse point cloud $P_C$。
2. 对每对训练图像用 MASt3R 预测 dense correspondences，并经 erosion/dilation 等 morphological operations refined。
3. 构建每张图像的 covisibility map $M_i$。
4. 对多视图区域三角化 dense correspondences，得到 $P_T$，并与 $P_C$ 合并。
5. 对训练图像估计 monocular depth，反投影 mono-view 区域 points。
6. 用多视图区域学习 $f_{\text{scale}}$，把 mono-view depth points 对齐到 COLMAP 坐标系，形成 $P_{\text{final}}$。
7. 用 $P_{\text{final}}$ 初始化 Gaussians。
8. 用 $P_{\text{final}}$ 正样本和随机负样本训练 proximity MLP classifier。
9. 在 CoR-GS 或 FSGS 的原有目标上加入 covisibility weighted $L_p$，训练 3DGS。
10. 推理时按普通 3DGS 渲染 novel views；covisibility map/proximity classifier 主要用于训练期监督。

## 7. 实验设置与结果摘要

数据集包括 LLFF 和 Mip-NeRF360。LLFF 使用 3、6、9 training views，分辨率 downsample 到 $8\times$；Mip-NeRF360 使用 12、24 training views，分辨率 downsample 到 $4\times$。训练 LLFF 为 10k iterations，Mip-NeRF360 为 30k iterations；初始化使用 COLMAP point clouds 和 poses。指标为 PSNR、SSIM、LPIPS。

LLFF 表 1 中，CoMapGS 加到 FSGS 和 CoR-GS 上均有提升。CoR-GS+CoMapGS 在 3/6/9 views 下 PSNR 为 21.105/25.204/26.731，SSIM 为 0.747/0.854/0.886，LPIPS 为 0.182/0.108/0.082，优于 reproduced CoR-GS 的 20.473/24.777/26.475 和 LPIPS 0.199/0.116/0.086。

Mip-NeRF360 表 2 中，CoR-GS+CoMapGS 在 12/24 views 下 PSNR 为 19.680/23.462，SSIM 为 0.591/0.734，LPIPS 为 0.394/0.264，均优于 reproduced CoR-GS 的 19.162/23.321、0.574/0.729、0.414/0.271。作者强调 Mip-NeRF360 的中心物体和外侧区域 covisibility 差异明显，适合验证 region-wise imbalance。

Ablation 表 3 说明初始化和 weighted supervision 需要配合。只加 proximity loss 但不增强点云，提升有限；只增强 low-uncertainty 或 full point cloud 均有提升；full point cloud enhancement 加 weighted supervision 取得最佳 25.204 PSNR、0.854 SSIM、0.108 LPIPS。

## 8. 声称贡献与实际技术增量

* 声称贡献 1: Covisibility map-based learning。实际增量是用 dense correspondence count 构建 pixel-wise covisibility map，并把 sparse-view 难点定义为 region-wise covisibility imbalance。
* 声称贡献 2: Enhanced point cloud initialization。实际增量是多视图区域用 MASt3R triangulation，mono-view 区域用 monocular depth + learned scale alignment。
* 声称贡献 3: Weighted supervision。实际增量是 proximity MLP classifier + inverse covisibility weighting，使 mono-view 区域获得更强几何约束。
* 可插拔性: 论文展示该方法可叠加到 FSGS 和 CoR-GS，而不替换其原有 pseudo-view/co-regularization 策略。

## 9. 局限与隐含假设

* 需要可靠 COLMAP poses；方法不处理 unposed sparse views。
* 依赖 MASt3R dense correspondences 和 monocular depth，错误 correspondence/depth 会影响 point cloud enhancement。
* Mono-view 点云来自 learned scale alignment，而不是真实多视图验证；可能把单目深度 hallucination 固化进几何。
* Proximity classifier 只学习“接近增强点云”的几何先验，如果增强点云有系统性错误，会加权监督错误位置。
* MLP classifier 细节在 supplementary，主文未给出负样本采样距离、网络宽度和训练配置。
* 对动态物体、反光、透明区域等 correspondence/depth 失败场景未展开。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法类别 | Covisibility-aware sparse-view 3DGS |
| 核心模块 | Covisibility maps; enhanced point clouds; proximity MLP; weighted proximity loss |
| 输入条件 | Sparse posed images; COLMAP; MASt3R; monocular depth |
| 解决对象 | Region-wise underrepresented / mono-view regions |
| 可叠加 baseline | CoR-GS; FSGS; most 3DGS sparse-view methods |
| 主要收益 | 改善低共视区域结构和纹理，提升 LLFF/Mip-NeRF360 PSNR/SSIM/LPIPS |
| 主要风险 | 依赖外部 correspondence/depth 和增强点云质量 |

## 11. 对我研究可复用的组件

* **Covisibility map as sparse-view diagnostic**: 比单纯 view count 更细，可用于定量判断每个区域是否欠监督。
* **Region-wise loss weighting**: 用 $1/(M+1)$ 给低共视区域更强几何监督，可与 depth loss、normal loss、dropout loss 结合。
* **Mono-view depth scale alignment**: 用多视图可靠区域学习单目深度尺度，再应用到单视图区域。
* **Proximity classifier**: 将增强点云转化为连续空间几何 prior，监督视锥内外 Gaussians。
* **Plug-in design**: 可加到 FSGS、CoR-GS、DNGaussian 等已有 sparse-view GS pipeline。

## 12. 缺口与想法种子

* **Uncertainty-calibrated covisibility**: 不只计 correspondence 数，还纳入 MASt3R matching confidence、depth uncertainty 和 reprojection error。
* **Covisibility-aware densification**: 在低 covisibility 区域主动 densify，在高 covisibility 区域 pruning 或降低学习率。
* **Pose-free CoMapGS**: 将 CoMapGS 与 SPFSplat/RegGS 结合，使 covisibility map 从 estimated poses 和 learned correspondences 中逐步更新。
* **Dynamic covisibility maps**: 对动态场景按时间和视角建立 covisibility tensor，区分空间欠监督和时间欠监督。
* **Classifier-free proximity**: 用 signed distance / Gaussian kernel density around enhanced point cloud 替代 MLP，降低额外训练和错误泛化风险。

## 13. 人工检查清单

* `NEED_HUMAN_CHECK`: supplementary 中 proximity MLP classifier 的结构、负样本生成和训练细节。
* `NEED_HUMAN_CHECK`: morphological operations 对 covisibility map 的具体参数。
* `NEED_HUMAN_CHECK`: $f_{\text{scale}}$ 的 anisotropic scaling 是否逐图像、逐区域或全局学习。
* `NEED_HUMAN_CHECK`: project page 是否提供代码和 MASt3R/depth 预处理脚本。

## 14. 证据锚点

* Abstract: CoMapGS 使用 covisibility maps、enhanced initial point clouds 和 uncertainty-aware weighted supervision。
* Fig. 1: 常规 sparse 3DGS 偏向高共视区域，CoMapGS 聚焦 underrepresented regions。
* Sec. 1: 三个挑战为 region-wise imbalanced supervision、sparse point cloud initialization、high-uncertainty regions。
* Fig. 2: CoMapGS pipeline，包括 SfM、monocular depth、dense correspondence、covisibility maps、proximity classifier。
* Sec. 3.1 / Eq. (1): covisibility map generation。
* Sec. 3.2 / Eq. (2)-(6): dense triangulated points、monocular depth points 和 scale alignment。
* Fig. 3: LLFF Fern 中 enhanced initial point clouds 示例。
* Sec. 3.3 / Eq. (7)-(11): proximity classifier、weighted proximity loss、frustum weights。
* Sec. 3.4 / Eq. (12): 最终 objective。
* Table 1: LLFF 3/6/9-view 定量结果。
* Table 2: Mip-NeRF360 12/24-view 定量结果。
* Table 3: point cloud enhancement 与 weighted supervision ablation。
* Sec. 4.4: sparse-view 的 region-wise covisibility 重新定义。
