---
title: "SU-RGS: Relightable 3D Gaussian Splatting from Sparse Views under Unconstrained Illuminations"
authors: "Qi Zhang, Chi Huang, Qian Zhang, Nan Li, Wei Feng"
year: 2025
venue: "ICCV 2025"
zotero_item_key: "GFH9XQ6X"
pdf_attachment_key: "9JPVPG97"
pdf_path: "/Users/wangyibo/Zotero/storage/9JPVPG97/Zhang 等 - SU-RGS Relightable 3D Gaussian Splatting from Sparse Views under Unconstrained Illuminations.pdf"
note_path: "notes/SU-RGS: Relightable 3D Gaussian Splatting from Sparse Views under Unconstrained Illuminations.md"
tags: ["3D Gaussian Splatting", "sparse-view reconstruction", "inverse rendering", "relighting", "unconstrained illumination"]
---

## 0. 一句话总结

SU-RGS 面向 sparse views 且每张图光照未知、不同的 relightable 3DGS inverse rendering：先用 varying appearance rendering 让每个 Gaussian 在不同视图/光照下有不同颜色以稳定几何，再用跨视图层级语义 pseudo-label 补充稀疏监督，最后用几何与语义联合的 transient object perception 抑制游客、遮挡等短暂物体带来的错误梯度。

## 1. 问题与动机

现有 relightable 3DGS/inverse rendering 方法通常假设输入视图密集且光照静态。真实采集中，尤其户外场景，输入往往很少，并且每张图可能处于不同未知光照下。直接用标准 3DGS 或 PBR inverse rendering 优化会把光照变化错误吸收到几何、材质或 SH 颜色中。

稀疏视图下还缺少足够 GT 监督。传统 inter-view photometric pseudo-label 依赖颜色一致性，但 unconstrained illumination 下，同一物理点在不同视图中颜色可能不同，直接光度匹配会失效。SU-RGS 因此改用对光照更鲁棒的语义特征 pseudo-label。

## 2. 适用场景

SU-RGS 适用于少量有位姿 RGB 图像、但每张图光照未知且可能变化的静态场景 relighting/inverse rendering。输出包括 novel view RGB、albedo、normal、material 和环境光，可用于重新打光。

它特别面向 NeRF-OSR、TensoIR Synthetic 这类带多光照设置的数据，以及 NeRF On-the-go 这类有 transient objects 的真实场景。当前方法仍需要相机位姿，且主要处理静态场景。

## 3. 方法定位

SU-RGS 是 sparse-view relightable 3DGS 方法，不是普通 NVS。它要同时优化 3DGS geometry、surface materials 和 environment illuminations，因此比只渲染 RGB 的 sparse-view 3DGS 更难。

相对 GSIR、R3DG、LumiGauss 等 relightable 3DGS，SU-RGS 的特殊点是同时处理 sparse views 和 unconstrained illuminations；相对 GS-W/WildGaussians，它显式建模材质、albedo 和 relighting，而不只是 in-the-wild appearance rendering。

## 4. 核心创新

第一，提出 varying appearance rendering。每个 Gaussian 不再只有一个固定 SH color，而是通过 MLP 根据观察方向、base color、Gaussian position 和 image appearance embedding 输出 view/illumination-dependent color。

第二，提出 sparse inverse rendering 的 hierarchical semantic pseudo-label。跨视图重投影后，不比较 RGB 颜色，而比较 2D foundation model 提取的层级语义特征，从而在不同光照下仍能提供额外监督。

第三，提出 transient object perception。利用重投影深度和当前渲染深度的差异，并结合语义相似度，估计 transient uncertainty coefficient，降低短暂物体或遮挡区域 pseudo-label 的梯度贡献。

第四，采用两阶段训练：先用标准 volume rendering 加 varying appearance 学到较稳几何，再切换到 PBR inverse rendering 学材质与环境光。

## 5. 方法细节

SU-RGS 的 PBR 渲染遵循 inverse rendering 公式：

$$
L_o(z,\omega_o)=\int_{\Omega}L_i(z,\omega_i)f_r(\omega_o,\omega_i)(\omega_i\cdot n)d\omega_i
$$

其中 BRDF $f_r$ 包含 albedo $a$、metallic $m$、roughness $\rho$、normal $n$ 等属性。

varying appearance rendering 中，MLP $f_\Theta$ 输入观察方向 $r$、Gaussian base color $c'$、Gaussian position $x$ 和 image appearance code $l$，输出每个 Gaussian 的变化外观颜色：

$$
\dot{c}=f_\Theta(\gamma(r),c',\gamma(x),l)
$$

其中 $\gamma(\cdot)$ 是 positional encoding，$l$ 由 GLO 为每张图分配一个可学习 appearance vector。base color $c'$ 来自 0 阶 SH coefficient，相对更少受不同光照干扰。

sparse inverse rendering 中，给定 source view $S$ 和 target view $T$，先把 source 像素 $p_S$ 根据 rendered depth 和相机参数重投影到 target 像素 $\dot{p}_T$。然后用 2D foundation model 提取层级语义特征，对重投影像素对构造 feature loss：

$$
L_f=\sum_{k\in A}\sum_{(i,j)\in M}\|\hat{F}_k^i(p_S)-F_k^j(\dot{p}_T)\|_2^2
$$

其中 $A$ 是层级语义特征索引集合，$M$ 是有效重投影像素对。2D foundation model 在训练中冻结。

transient object perception 中，设重投影深度为 $\dot{d}_T$，target 像素当前 rendered depth 为 $\hat{d}_T$，相对深度误差为 $E=|\dot{d}_T-\hat{d}_T|/\max(\dot{d}_T,\hat{d}_T)$。再结合语义相似度 $\xi$ 得到 adaptive transience coefficient $\beta$：

$$
\beta=
\begin{cases}
\xi, & 0\le E<F \\
\exp(-E)\xi, & F\le E\le 1
\end{cases}
$$

语义相似度 $\xi$ 是多层语义特征 cosine similarity 的平均。最终训练 loss 为：

$$
L=\beta\left(\lambda_1\sum_{p\in R}\|\hat{C}(p)-C(p)\|_2^2+\lambda_2L_{D\text{-}SSIM}+\lambda_3L_f\right)
$$

训练分两阶段。第一阶段 30k iterations，用标准 3DGS volume rendering、varying appearance 和 TOP 学几何。第二阶段 5k iterations，使用 PBR formulation 与 TOP 学材质、环境光并细化几何。

## 6. 实验设置

实验使用 NeRF-OSR、TensoIR Synthetic 和 NeRF On-the-go。NeRF-OSR 和 TensoIR Synthetic 提供多光照场景，用于 relighting novel view 和 inverse rendering；NeRF On-the-go 用于验证 transient object perception。

对比方法包括 TensoIR、R3DG、GSIR、NeRF-OSR，以及 transient 场景中的 WildGaussians。为适配不同输入光照，作者按 NeRF-OSR 设置修改 TensoIR/R3DG/GSIR，使每个 view 对应一个 lighting parameter。训练在单张 RTX 3090 上约 1.5 小时，24 views 设置总 35k iterations。

## 7. 主要结果

NeRF-OSR 上，24-view 时 SU-RGS 达到 19.95 PSNR、0.876 SSIM、0.244 LPIPS，明显优于 GSIR 的 18.59 PSNR、0.726 SSIM、0.352 LPIPS。12-view 时 SU-RGS 为 18.35 PSNR、0.719 SSIM、0.312 LPIPS；6-view 时仍达到 16.04 PSNR、0.664 SSIM、0.438 LPIPS，均为最佳。

TensoIR Synthetic 上，24-view 时 SU-RGS 达到 33.05 PSNR、0.976 SSIM、0.033 LPIPS、5.17 MAE；12-view 时为 29.19 PSNR、0.946 SSIM、0.067 LPIPS、7.22 MAE；6-view 时为 28.05 PSNR、0.930 SSIM、0.079 LPIPS、12.32 MAE。相比 GSIR 在 24-view 上提升 3.76 PSNR，并降低 normal MAE 约 2.98。

NeRF On-the-go 和 NeRF-OSR 的 transient 可视化显示，SU-RGS 能比 WildGaussians 更好消除 transient uncertainty，同时保留 inverse rendering 的 relighting/decomposition 能力。

## 8. 消融与分析

varying appearance rendering 消融中，逐步加入 appearance embedding、base color、position embedding 和 ray direction，NeRF-OSR 上 PSNR 从 17.01 提升到 19.95，SSIM 从 0.521 提升到 0.876，LPIPS 从 0.550 降到 0.244。说明每个 Gaussian 的 view/illumination-dependent color 对 sparse unconstrained lighting 下的几何初始化很重要。

sparse inverse rendering 消融中，单向语义 pseudo-label、双向重投影和层级语义特征逐步提升效果。最终完整 SIR 达到 19.95 PSNR、0.876 SSIM、0.244 LPIPS，优于不使用该设计的 18.19 PSNR。

TOP 消融显示，用 constant boundary、cosine、truncation 等替代 adaptive transience coefficient 都不如完整 SU-RGS。完整方法为 19.95 PSNR、0.876 SSIM、0.244 LPIPS，而 w/ Cosine 为 19.62 PSNR、0.793 SSIM、0.312 LPIPS。

## 9. 与相关工作的关系

相对 GSIR/R3DG，SU-RGS 不假设静态光照和密集视图，而是在每张图未知光照下学习 relightable 3DGS。相对 LumiGauss，它更关注 sparse-view 设置。

相对 WildGaussians/GS-W，SU-RGS 不只是处理 in-the-wild appearance 和 transient objects，还显式估计 geometry、BRDF/material 和 environment illumination，目标是 scene relighting。

相对普通 sparse-view 3DGS，SU-RGS 处理的是更难的 inverse rendering：RGB 重建只是中间结果，最终还要能分解 albedo、normal、material 并在新光照下渲染。

## 10. 优点

SU-RGS 的优点是把 sparse views、unconstrained illumination 和 transient objects 放在同一个 relightable 3DGS 框架内处理，而不是分别做预处理。

另一个优点是监督设计绕开了光照变化下的 RGB 不一致问题。跨视图 pseudo-label 使用层级语义特征，而不是直接光度匹配，因此更适合不同 illumination 的输入图。

## 11. 局限

方法仍需要已知相机位姿，并且训练流程和模块复杂度较高。varying appearance、PBR inverse rendering、2D foundation semantic features、TOP 都增加实现成本。

此外，语义 pseudo-label 对 2D foundation model 的特征质量有依赖。如果语义特征无法区分细粒度材质或被强光照/反射干扰，可能仍会带来错误监督。动态场景本身也没有被建模，TOP 只是抑制 transient object 的梯度。

## 12. 可复现要点

复现时先实现第一阶段 varying appearance rendering，不能直接从 sparse unconstrained lighting 输入进入 PBR decomposition，否则几何会被不同光照的矛盾颜色梯度拉坏。

第二阶段切换到 PBR formulation 时，仍要保留 TOP。SIR 中需要做双向重投影 $S\to T$ 和 $T\to S$，并提取多层 2D foundation features 构造 hierarchical semantic pseudo-label。foundation model 参数保持冻结。

## 13. 可能扩展

一个扩展是将 SU-RGS 与 pose-free sparse-view 方法结合，处理未标定位姿且光照变化的真实图像。论文也提到 relighting with unposed views 是未来方向。

第二个扩展是把语义 pseudo-label 与物理一致性结合，例如对 albedo/normal/material 的跨视图一致性加 uncertainty-aware loss，减少纯语义特征对材质细节不敏感的问题。

第三个扩展是把 TOP 扩展成显式 dynamic/transient layer decomposition，让短暂物体不只是被降权，而是被建模成可分离前景层。

## 14. 个人理解

SU-RGS 的关键不是单纯把 relightable 3DGS 做到 sparse-view，而是识别出 unconstrained illumination 下普通多视图光度监督会失效。它用 varying appearance 先稳几何，用 semantic pseudo-label 替代跨视图 RGB 一致性，再用 TOP 过滤不可靠重投影区域。

这篇文章对 sparse-view 3DGS 的启发是：当输入存在光照变化时，几何和颜色的耦合会比普通 sparse-view 更严重。此时直接加强 photometric loss 反而可能更糟，需要把 appearance variation 和 geometry/material learning 分阶段解耦。
