# RegGS: Unposed Sparse Views Gaussian Splatting with 3DGS Registration

## 0. Metadata

* Title: RegGS: Unposed Sparse Views Gaussian Splatting with 3DGS Registration
* Authors: Chong Cheng; Yu Hu; Sicheng Yu; Beizhen Zhao; Zijian Wang; Hao Wang
* Year: 2025
* Venue: ICCV
* PDF source: `/Users/wangyibo/Zotero/storage/P3F5SS8R/Cheng 等 - RegGS Unposed Sparse Views Gaussian Splatting with 3DGS Registration.pdf`
* Zotero item key: `WRIQ9369`
* Zotero PDF attachment key: `P3F5SS8R`
* Code: Not specified
* Project page: `https://3dagentworld.github.io/reggs/`
* Dataset link: RE10K, ACID
* Main task: unposed sparse-view 3D Gaussian reconstruction and novel view synthesis
* Domain: pose-free 3DGS, feed-forward Gaussian registration, optimal transport
* Input: multiple unposed sparse images
* Output: globally aligned 3D Gaussians, estimated camera poses, novel views
* Main representation: local feed-forward Gaussian submaps registered into a global Gaussian map in Sim(3)
* Supervision type: differentiable GMM alignment, photometric consistency, rendered depth consistency
* Core contribution in one sentence: 用 feed-forward 3DGS 模型为每个输入生成局部 Gaussian submap，再用 entropy-regularized MW2/Sinkhorn 距离和 photometric/depth losses 在 Sim(3) 中逐步注册到全局 Gaussian map。
* Note status: `complete`

## 1. 一句话技术摘要

This paper addresses unposed sparse-view Gaussian Splatting by using optimal-transport-based 3DGS registration to transform feed-forward local Gaussian submaps into a globally consistent Gaussian scene, with the key technical novelty being differentiable Sim(3) registration using entropy-regularized MW2 distance plus photometric and depth consistency.

## 2. 问题形式化

unposed sparse views 同时缺少足够视角和相机位姿。optimization-based 3DGS 在这种情况下容易陷入拓扑不连续、尺度歧义和姿态错误；feed-forward Gaussian methods 有学习到的 3D prior，但通常只能处理固定/有限输入格式，难以吸收更多视角。

RegGS 的思路是：让 feed-forward model 对每个输入或少量输入生成局部 Gaussian submap，然后把这些 Gaussian mixtures 当作 GMM，在 Sim(3) 空间中注册到一个 main Gaussian map。这样既利用 feed-forward prior，又能增量整合任意数量 sparse views。

## 3. 方法概览

Pipeline 见 Fig. 2：

1. 用预训练 feed-forward Gaussian model 从两张初始图构建 main Gaussians。
2. 对后续每张输入生成 sub Gaussians。
3. 用 Mixture 2-Wasserstein (MW2) 距离衡量 main Gaussians 与经过 Sim(3) 变换的 sub Gaussians 的 GMM 结构差异。
4. 通过 differentiable joint registration 同时优化 MW2、photometric、depth losses，估计 submap 到 main map 的 Sim(3)。
5. 将注册后的 sub Gaussians 合并到 main map。
6. 所有帧注册后做 global refinement 和 adaptive pruning。

## 4. 方法细节

### 4.1 MW2 distance for Gaussian mixtures

对两个 Gaussian components $N(\mu_i^A,\Sigma_i^A)$ 和 $N(\mu_k^{B'},\Sigma_k^{B'})$，平方 $W_2$ 距离包含均值距离和 covariance 差异：

$$
W_2^2 = \|\mu_i^A-\mu_k^{B'}\|^2+\mathrm{Tr}(\Sigma_i^A+\Sigma_k^{B'}-2(\Sigma_i^A\Sigma_k^{B'})^{1/2})
$$

直接计算 GMM 间 $W_2$ 是无限维优化。RegGS 使用 GMM transport，把问题转成离散 transport plan：

$$
MW_2^2(P,Q)=\inf_{\pi\in\Pi(w^A,w^B)}\sum_{i=1}^{M}\sum_{k=1}^{N}\pi_{ik}C_{ik}
$$

其中 $C_{ik}$ 是 Gaussian pair 的 transport cost。$MW_2$ 是 $W_2$ 的 upper bound。

### 4.2 Entropy-regularized Sinkhorn

为避免 local minima、加速收敛并支持 fuzzy matching，引入 entropy regularization：

$$
W_{2,\epsilon}^2=\min_{\pi\in\Pi(w^A,w^B)}\left[\sum_{i,k}\pi_{ik}C_{ik}+\epsilon\sum_{i,k}\pi_{ik}\log\pi_{ik}\right]
$$

kernel 为 $K_{ik}=\exp(-C_{ik}/\epsilon)$，交替更新：

$$
u^{(t)}=\frac{w^A}{Kv^{(t-1)}},\quad v^{(t)}=\frac{w^B}{K^\mathsf{T}u^{(t)}}
$$

最终 transport plan：

$$
\pi^*=\mathrm{diag}(u^{(T)})K\mathrm{diag}(v^{(T)})
$$

并计算 $W_{2,\epsilon}^2=\sum_{i,k}\pi_{ik}^*C_{ik}$。实现用 log-Sinkhorn、Cholesky decomposition、GPU tensorization 和 covariance regularization $\Sigma\leftarrow \Sigma+10^{-6}I$ 保持数值稳定。

### 4.3 Sim(3) pose parameterization

Sim(3) 变换由 quaternion rotation $q$、translation $t$ 和 log-scale $\log s$ 表示，参数为 $\theta=[q;t;\log s]\in\mathbb{R}^8$。scale 通过 $s=\exp(\log s)$ 保证正值，quaternion 用 projected gradient 保持单位长度。

作用到 Gaussian 上：

$$
\mu_k^{B'}=sR(q)\mu_k^B+t,\quad \Sigma_k^{B'}=s^2R(q)\Sigma_k^BR(q)^\mathsf{T}
$$

作者称 quaternion 比 Lie algebra 收敛更快且精度相当。

### 4.4 Joint 3DGS registration loss

联合 loss 为：

$$
\mathcal{L}_{total}=\lambda_1\mathcal{L}_{MW2}+\lambda_2\mathcal{L}_{Photo}+\lambda_3\mathcal{L}_{Depth}
$$

$\mathcal{L}_{MW2}=W_{2,\epsilon}^2(G^A,T(G^B))$ 负责全局结构分布对齐。photometric loss 用 3DGS rendering 的 RGB L1：

$$
\mathcal{L}_{Photo}=\frac{1}{|P|}\sum_{p\in P}|I^A(p)-I^{T(B)}(p)|_1
$$

depth loss 在 valid mask $M_v$ 上比较 rendered depth：

$$
\mathcal{L}_{Depth}=\frac{1}{|M_v|}\sum_{p\in M_v}|D_A^v(p)-D_{T(B)}^v(p)|_1
$$

三者互补：MW2 做 coarse alignment，photometric refine local alignment，depth 抑制 scale drift 和 topology distortion。

## 5. 数学目标和损失

RegGS 的核心目标是估计每个 submap 到 main map 的 Sim(3) 变换。优化变量是 $q,t,\log s$，loss 通过 Sinkhorn transport plan、3DGS RGB rendering 和 depth rendering 反向传播。由于 feed-forward Gaussian submaps scale 差异大，注册前做 scale normalization；初始化 scale 由 main/sub rendered depth 平均值估计。

## 6. 训练和推理流程

流程：

1. 用 NoPoSplat 作为 feed-forward Gaussian backbone。
2. 两张初始图生成 main Gaussians。
3. 每个新输入生成 sub Gaussians。
4. 对 sub Gaussians 做 scale normalization 和 Sim(3) 初始化。
5. 优化 $\mathcal{L}_{MW2}$、$\mathcal{L}_{Photo}$、$\mathcal{L}_{Depth}$ 注册 submap。
6. 将注册后的 submap 融合到 main map。
7. 所有 frame 处理完后做 global refinement 和 adaptive pruning。

实现使用 PyTorch，硬件为 NVIDIA A6000。

## 7. 实验设置与结果摘要

数据集：RE10K 和 ACID。任务为 unposed sparse views reconstruction，输入视角数为 2、8、16、32。RE10K/ACID 都提供 GT camera poses 用于评估。NVS 指标为 PSNR/SSIM/LPIPS，pose 用 ATE RMSE，registration 用 MW2。

结果：

* RE10K Table 1: 2-view 下 RegGS 24.272 PSNR，优于 NoPoSplat 23.247；16-view 下 28.663 PSNR，优于 MASt3R* 27.024 和 CF-3DGS 23.034。
* ACID Table 2: 2-view 下 RegGS 24.291 PSNR，优于 NoPoSplat 23.589；16-view 下 27.745 PSNR，明显优于 baselines。
* Pose Table 3: 8/16/32-view 上 ATE 显著低于 VideoLifter、NoPeNeRF、CF3DGS，例如 RE10K 8x ATE 0.023。
* Ablation Table 4: 去掉 Photo、Depth 或 MW2 都会降低结果；只用某一项不够。
* Table 5: 去掉 joint registration module 后 PSNR 从 23.09 降到 11.41，ATE 从 0.098 变为 1.164，说明 joint registration 是核心。

## 8. 声称贡献 vs 实际技术增量

论文声称提出 unposed sparse views 3DGS registration framework。实际技术增量在于把多个 feed-forward Gaussian local maps 当作 GMM，用 optimal transport 的 MW2/Sinkhorn 作为可微结构对齐项，并与 3DGS photometric/depth rendering loss 联合优化 Sim(3)。

相比纯 optimization-based pose-free 3DGS，RegGS 借助 feed-forward prior；相比纯 feed-forward 2-view 方法，它通过注册模块支持更多输入视角。

## 9. 局限性和隐藏假设

* 依赖 feed-forward Gaussian backbone 的质量；local submap 生成差会导致注册/融合失败。
* 输入视角多时，MW2 计算使训练时间显著增加。
* 大 inter-frame motion 可能导致注册不收敛。
* MW2 是 GMM transport upper bound，不是精确 GMM Wasserstein。
* 全局 refinement 可能引入噪声，部分 LPIPS 情况不总是最优。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 任务 | unposed sparse-view 3DGS |
| 输入 | unposed sparse images |
| 输出 | global Gaussians, camera poses, NVS |
| 表示 | feed-forward local Gaussian submaps + Sim(3) registration |
| 关键模块 | MW2 Sinkhorn, quaternion Sim(3), joint RGB/depth registration |
| 关键损失 | MW2, photometric, depth |
| 主要优点 | 支持无位姿多视角融合，pose accuracy 强 |
| 主要风险 | 依赖 feed-forward submap 质量，MW2 开销较大 |

## 11. 可复用组件

* MW2/Sinkhorn 可作为 Gaussian map alignment metric。
* Sim(3) registration 可用于 3DGS SLAM/submap fusion。
* feed-forward prior + optimization registration 是 pose-free sparse-view 的通用范式。

## 12. Gap 和 idea seeds

* 用 sparse correspondence 或 feature matching 初始化 MW2 transport，降低大 motion 下失败率。
* 将 MW2 registration 与 uncertainty score 结合，对低质量 submap 降权。
* 设计局部/分层 MW2，减少多视角输入时的 quadratic Gaussian pair cost。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: Appendix 中 Sinkhorn gradient consistency proof 和复杂度推导需复核。
* `NEED_HUMAN_CHECK`: NoPoSplat backbone 配置、global refinement 与 adaptive pruning 细节需查代码。

## 14. Evidence Anchors

* Fig. 1: RegGS overview and qualitative comparison。
* Fig. 2: full registration pipeline。
* Sec. 3.2: MW2 distance and Sinkhorn, Eq. (5)-(10)。
* Sec. 3.3: Sim(3), joint loss, Eq. (11)-(18)。
* Sec. 3.4: joint training and computational efficiency。
* Table 1-2: RE10K and ACID NVS results。
* Table 3: pose estimation。
* Table 4-5: loss and module ablations。
