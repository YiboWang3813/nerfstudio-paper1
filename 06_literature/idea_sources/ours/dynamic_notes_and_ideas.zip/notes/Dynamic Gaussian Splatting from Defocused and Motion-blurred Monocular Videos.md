# Dynamic Gaussian Splatting from Defocused and Motion-blurred Monocular Videos

## 0. Metadata

- Paper title: Dynamic Gaussian Splatting from Defocused and Motion-blurred Monocular Videos
- Authors: Xuankai Zhang; Junjin Xiao; Qing Zhang
- Venue / year: NeurIPS 2025
- Project / code: `https://dydeblur.github.io/`; `https://github.com/hhhddddddd/dydeblur`
- Zotero item key: `F3MC53UD`
- Zotero PDF attachment key: `QW8XZELP`
- Zotero PDF path: `/Users/wangyibo/Zotero/storage/QW8XZELP/Zhang 等 - Dynamic Gaussian Splatting from Defocused and Motion-blurred Monocular Videos.pdf`
- Local note path: `notes/Dynamic Gaussian Splatting from Defocused and Motion-blurred Monocular Videos.md`

## 1. One-Sentence Technical Summary

本文把散焦模糊和运动模糊统一建模为逐像素 blur kernel convolution，在 Shape-of-Motion 式动态 Gaussian 表示上加入 BP-Net、blur-aware sparsity、动态 Gaussian densification 和 unseen-view 监督，从模糊单目视频中直接优化出可实时渲染的清晰动态 3DGS。

## 2. Problem Formulation

输入是一段带散焦或运动模糊的单目动态视频 $B_t$，以及由预处理得到的相机、深度、运动 mask、跟踪点等辅助信息。目标不是先做 2D 去模糊再重建，而是在训练时显式合成模糊图像 $\hat{B}_t$ 去匹配输入，同时让底层 Gaussian renderer 输出清晰图像 $\tilde{I}_t$。

核心难点有三点。第一，散焦 blur 和 motion blur 的物理来源不同，已有方法通常只覆盖其中一种。第二，用一个自由 CNN 从渲染图像预测 blur kernel 容易与 3DGS 共同退化，最终得到能拟合模糊图但几何和清晰纹理不可靠的解。第三，单目动态视频每个时刻只有一个视角，动态区域初始化不完整，容易过拟合训练视角。

## 3. Method Overview

方法由两条主线组成。第一条是动态场景表示：沿用 Shape-of-Motion，将静态背景和动态 Gaussians 分开，动态 Gaussians 用 $N_b$ 个 SE(3) motion bases 的线性组合从 canonical frame 变换到 observation frame；训练到相对稳定后，再从所有观测帧的动态区域回投影并 remap 回 canonical space，补充 canonical frame 中不可见的动态点。第二条是 blur synthesis：渲染清晰图、深度和 mask 后，BP-Net 基于相机 embedding、scene feature 和像素位置预测逐像素 blur kernel $k_x$ 与 blur intensity $m_x$，再把清晰图和卷积模糊图混合成 $\hat{B}$。

训练上，输入模糊帧监督 $\hat{B}$；深度和 mask 约束几何；motion bases 和动态 Gaussian 均值做平滑；blur-aware sparsity 用 $m_x$ 约束 kernel 中心权重。此外，作者通过训练视图的深度 reprojection 生成邻近 unseen views，用较弱的 mask/appearance 约束缓解单目过拟合。

## 4. Method Details

### 4.1 Dynamic Gaussians with Motion Bases

动态 Gaussians 初始化自 canonical frame $t_0$ 中可见的 2D tracking points：TAPIR 给出跟踪点，Depth-Anything 给出深度，静态背景则由各帧背景深度回投影初始化。每个动态 Gaussian 额外带 motion coefficient $w \in \mathbb{R}^{N_b}$，用于混合 SE(3) motion bases：

$$
T_{t_0 \to t} = \sum_{b=0}^{N_b} w^{(b)} T^{(b)}_{t_0 \to t}.
$$

若 $T_{t_0 \to t}$ 分解为 rotation $R_{t_0 \to t}$ 和 translation $t_{t_0 \to t}$，动态 Gaussian 的中心和朝向更新为：

$$
\mu_t = R_{t_0 \to t}\mu_{t_0} + t_{t_0 \to t}, \qquad R_t = R_{t_0 \to t}R_{t_0}.
$$

该设计继承 SoM 的优点：运动由少量 motion bases 表达，参数规模比逐点独立轨迹更可控。

### 4.2 Dynamic Gaussian Densification

只用 canonical frame 可见 tracking points 会遗漏 canonical frame 中被遮挡或不可见的动态区域。作者在前 $N_d$ 次迭代后执行一次 densification：从所有 observation frames 的 SAM 动态 mask 中随机采样动态像素 $g$，用深度 $D(g)$ 和相机投影/外参回投影到 observation space：

$$
\mu^g_t = P_t^{-1}\left(\pi_t^{-1}(g, D(g))\right).
$$

随后找到变换后距离 $\mu^g_t$ 最近的已有动态 Gaussian $G'$，取其 motion transform $T^{G'}_{t_0 \to t}=[R^{G'}_{t_0 \to t}, t^{G'}_{t_0 \to t}]$，把新点 remap 回 canonical space：

$$
\mu^g_{t_0} = \left(R^{G'}_{t_0 \to t}\right)^{-1}\left(\mu^g_t - t^{G'}_{t_0 \to t}\right).
$$

这个步骤的技术含义是：用已学稳定 motion bases 为新增动态点提供 canonical 对齐，而不是直接把各帧动态点放进各自空间。

### 4.3 Unified Blur Synthesis

作者将散焦和运动模糊都近似成邻域像素的加权组合。对像素 $x$，清晰渲染图 $\tilde{I}$ 的模糊版本为：

$$
\tilde{B}(x) = \sum_{x_i \in \mathcal{N}(x)} \tilde{I}(x_i) k_x(x_i), \qquad \sum_{x_i \in \mathcal{N}(x)} k_x(x_i)=1.
$$

BP-Net 同时预测 $k_x$ 和 $m_x$。最终训练图像不是完全使用卷积结果，而是用 blur intensity 在清晰像素和模糊像素之间插值：

$$
\hat{B}(x) = (1 - m_x)\tilde{I}(x) + m_x\tilde{B}(x).
$$

这很关键：对于输入中接近清晰的区域，$m_x$ 可以低，重建损失会更直接约束 $\tilde{I}$；对于强 blur 区域，BP-Net 负责解释模糊，从而减少对清晰 3DGS 的错误牵引。

### 4.4 BP-Net Inputs and Sparsity

BP-Net 是四层 CNN，输入包括 camera embedding $e(i)$、scene feature $f_{\mathrm{scene}}(x)$ 和像素位置编码 $p(x)$：

$$
k_x, m_x = F_\Theta(e(i), f_{\mathrm{scene}}(x), p(x)).
$$

其中 $f_{\mathrm{scene}}$ 由三层 Scene Feature Extractor 从渲染图 $\tilde{I}$、渲染深度 $\tilde{D}$ 和渲染 mask $\tilde{M}$ 提取。实现细节中，kernel 使用 Softmax 输出，blur intensity 使用 Sigmoid 输出，默认 kernel size 为 $K=9$。

blur-aware sparsity 用 $m_x$ 控制 kernel 的中心权重。模糊越轻，kernel 应越集中于中心；模糊越重，kernel 分布越分散。作者定义 blur-aware center weight：

$$
c_x = \operatorname{sigmoid}(\operatorname{scale}\cdot(1-\operatorname{sg}(m_x))),
$$

并用 $L_1$ 约束它接近 $k_x(c)$：

$$
L_{\mathrm{spa}} = L_1(c_x, k_x(c)).
$$

其中 $\operatorname{sg}$ 是 stop-gradient，scale 设为 5。该损失在 $m_x$ 训练稳定若干 $N_{\mathrm{spa}}$ 迭代后启用。

### 4.5 Unseen-View Combined Optimization

单目动态重建易过拟合训练视角。作者从训练视角 $V_s$ 生成附近 unseen view $V_t$，将训练像素 $p_s$ 通过深度 reprojection 到 unseen view：

$$
p_t = K P_t^{-1} P_s D_s(p_s) K^{-1} p_s.
$$

颜色 $B_s(p_s)$ 通过 reversed bilinear sampling 分配到 $B_t(p_t)$，mask 同理。unseen views 分为两类：沿相机轨迹插值的 parallel-unseen views，以及沿局部垂直方向扰动相机中心的 perpendicular-unseen views。它们的 timestamp 与生成它们的训练视图一致。由于 unseen-view 深度不可靠，这些迭代只使用 mask 而不用 depth 监督。

## 5. Mathematical Objectives and Losses

图像重建损失监督合成模糊图 $\hat{B}$ 对齐输入模糊图 $B$：

$$
L_{\mathrm{rec}} = (1-\beta)L_1(\hat{B}, B) + \beta L_{\mathrm{ssim}}(\hat{B}, B),
$$

其中 $\beta=0.2$。几何损失约束渲染深度和 mask：

$$
L_{\mathrm{geo}} = \lambda_{\mathrm{depth}}L_1(\tilde{D}, D) + \lambda_{\mathrm{mask}}L_1(\tilde{M}, M).
$$

论文写明 $\lambda_{\mathrm{depth}}$ 和 $\lambda_{\mathrm{mask}}$ 均设为 0.075。平滑损失 $L_{\mathrm{smo}}$ 包含相邻帧 SE(3) motion bases 的平滑，以及动态 Gaussian 均值的平滑。总目标为：

$$
L = L_{\mathrm{rec}} + L_{\mathrm{geo}} + L_{\mathrm{smo}} + L_{\mathrm{spa}}.
$$

## 6. Training and Inference Procedure

训练流程可以概括为：先用 Depth-Anything、TAPIR 和 SAM 预处理深度、跟踪点和动态 mask；用 canonical 可见 tracking points 初始化动态 Gaussians，用背景深度初始化静态 Gaussians；在正常重建损失下先训练 motion bases 和 Gaussians；到 $N_d$ 迭代后执行一次动态 densification；随后继续联合优化 Gaussians、motion bases、BP-Net 和 scene feature extractor，并周期性加入 unseen-view 约束。

推理时，目标是渲染清晰 novel views，因此主要使用学习到的清晰 dynamic 3DGS 表示和 motion bases 进行 rasterization；BP-Net 是训练期解释输入模糊形成过程的模块。论文报告在 512 x 288 分辨率、RTX 3090 上可达 65.143 FPS。

## 7. Experimental Setup and Results Summary

主实验覆盖两个基准：D2RF defocus blur dataset 和 DyBluRF motion blur dataset。训练使用左视角模糊序列，评估使用对应右视角清晰序列，指标为 PSNR、SSIM、LPIPS。比较对象包括 D3DGS、SoM、D2RF、DyBluRF、De4DGS，以及先用视频去模糊方法处理再训练动态 GS 的组合。

主表结果显示：在 D2RF 散焦数据上，本文方法达到 29.39 PSNR、0.859 SSIM、0.078 LPIPS；在 DyBluRF 运动模糊数据上达到 27.01 PSNR、0.876 SSIM、0.056 LPIPS。相较 De4DGS，散焦 LPIPS 从 0.154 降到 0.078，运动模糊 PSNR 从 26.62 提升到 27.01，同时训练时间约 1 小时，明显短于 D2RF/DyBluRF 的 48 小时和 De4DGS 的 20 小时。

补充实验还包括同时存在散焦和运动模糊的 D2RF-v2/DyBluRF-v2、Deblur-NeRF 静态去模糊数据、training-view deblurring 对比、BP-Net 替换消融、kernel size 消融、kernel ground-truth 对比，以及对深度、tracking、mask 预处理误差的鲁棒性分析。消融中，BP-Net 优于直接替换为 De3DGS、De4DGS 或 D2RF 的 blur modeling；kernel size 从 5 增到 9 明显提升，超过 9 后收益很小。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称的主要贡献是第一个同时处理散焦和运动模糊单目动态视频的 dynamic GS 框架。实际技术增量主要不在新的动态场景参数化，而在训练期 blur formation modeling：它把 SoM 式 motion-basis dynamic GS 作为底座，外接一个受相机、场景和像素位置条件化的逐像素 kernel/intensity predictor，并用 $m_x$ 的 sparsity prior 避免 BP-Net 滥用 blur kernel。

第二个真实增量是 densification 和 unseen-view supervision 对单目动态场景的补丁。前者补 canonical frame 中不可见动态区域，后者把有限训练视角的颜色和 mask 投到邻近虚拟视角。两者都不是新的渲染核心，但对模糊单目动态视频这种欠约束设置很实用。

与 De4DGS 这类通过曝光时间多次渲染模拟运动模糊的方法相比，本文的 blur kernel abstraction 更通用，也更容易覆盖散焦 blur；代价是物理可解释性较弱，kernel 预测网络可能学习数据集特定的 blur 先验。

## 9. Limitations / Assumptions

方法依赖 Depth-Anything、TAPIR、SAM、相机位姿等外部预处理；虽然补充实验显示一定鲁棒性，但严重深度/跟踪/mask 错误仍可能破坏 densification 和 motion bases。

散焦和运动模糊被统一为 2D neighborhood convolution，这在工程上有效，但并不严格等价于真实 aperture integration 或 exposure-time scene motion integration。强遮挡、非局部运动轨迹、空间变化极大的 PSF 可能超过固定 $K=9$ kernel 的表达能力。

BP-Net 是训练期解释器，论文的关键假设是 blur-aware sparsity 和清晰区域混合足以避免 3DGS 与 blur network 共同退化。该假设在报告数据上成立，但对更复杂真实镜头、rolling shutter、非线性相机响应等情况还需要验证。

## 10. Matrix-Ready Summary

| Dimension | Entry |
|---|---|
| Input | Defocused or motion-blurred monocular dynamic video; camera/depth/mask/tracking preprocessing |
| Output | Sharp dynamic Gaussian representation and sharp novel-view renderings |
| Representation | Static 3D Gaussians plus dynamic Gaussians controlled by SE(3) motion bases |
| Motion model | Shape-of-Motion style weighted combination of motion bases |
| Blur model | Per-pixel blur kernel $k_x$ plus blur intensity $m_x$ predicted by BP-Net |
| Key modules | Dynamic Gaussian densification; BP-Net; blur-aware sparsity; unseen-view supervision |
| Supervision | Blurry image reconstruction, depth, mask, motion smoothness, blur sparsity |
| Datasets | D2RF, DyBluRF, D2RF-v2, DyBluRF-v2, Deblur-NeRF |
| Main advantage | Handles defocus and motion blur in one dynamic GS framework |
| Main risk | Reliance on preprocessing and learned 2D blur approximation |

## 11. Reusable Components

- BP-Net design: predict both blur kernel and blur intensity, then blend clear and blurred renderings; this can be reused in other 3DGS/NeRF training pipelines for blurred inputs.
- Blur-aware sparsity: use intensity to regularize kernel center weight, preventing mild-blur regions from being over-smoothed.
- One-time dynamic densification: after motion stabilizes, remap dynamic pixels from all observation frames to canonical space to fill incomplete regions.
- Unseen-view construction: project training-view appearance to nearby virtual views for weak extra supervision in monocular settings.
- Evaluation pattern: report both NVS and deblurring quality, because blurred-input reconstruction can otherwise hide whether the learned representation is actually sharp.

## 12. Gap / Idea Seeds

- Replace fixed square kernel with physically parameterized blur families: aperture-aware defocus kernels, exposure-time trajectory kernels, or mixtures selected by learned confidence.
- Make densification uncertainty-aware: if depth/tracking/mask confidence is low, initialize new Gaussians with larger covariance or lower opacity rather than treating all remapped points equally.
- Couple BP-Net with event data or high-FPS priors for motion blur, reducing ambiguity between learned kernel and true exposure trajectory.
- Add camera response and rolling-shutter modeling to handle real phone videos where blur is not just local linear convolution.
- Investigate whether BP-Net can be discarded after training without leaving artifacts, or whether a distillation step should explicitly sharpen the Gaussian representation.

## 13. Human Check List

- NEED_HUMAN_CHECK: Verify exact venue metadata once proceedings entry is finalized; extracted PDF states NeurIPS 2025.
- NEED_HUMAN_CHECK: Confirm the exact definitions of $N_d$, $N_u$, and $N_{\mathrm{spa}}$ from implementation/config, since extraction does not expose their numeric values.
- NEED_HUMAN_CHECK: Check whether inference ever uses BP-Net for any reported deblurring visualization, or only the clear renderer.

## 14. Evidence Anchors

- Abstract: unified framework for defocused and motion-blurred monocular videos; BP-Net; blur-aware sparsity; dynamic Gaussian densification; unseen-view information.
- Section 3.1: SoM initialization, motion bases, Eq. 1-4 dynamic transform and foreground remapping.
- Section 3.2: unified blur synthesis, Eq. 5-9, BP-Net inputs, blur intensity blending and sparsity constraint.
- Section 3.3: unseen-view generation by depth reprojection, parallel/perpendicular unseen views.
- Section 3.4: reconstruction, geometry, smoothing, sparsity losses and total objective.
- Tables 1, 4-11: main comparison, static deblurring comparison, joint blur datasets, BP-Net/kernel-size/robustness ablations.
