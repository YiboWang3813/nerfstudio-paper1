| dataset | transition | delta_psnr | delta_ssim | delta_lpips |
|---|---|---|---|---|
| Liver | Plane -> Fixed | 4.069040 | 0.043129 | -0.258034 |
| Liver | Fixed -> Adaptive | 0.177949 | 0.010262 | 0.026129 |
| Liver | Fixed -> Fixed+Simple | -0.103442 | -0.007138 | -0.012693 |
| Liver | Fixed+Simple -> Fixed+Full | -0.032116 | -0.000168 | 0.000200 |
| Arm | Plane -> Fixed | 12.236155 | 0.207963 | -0.218196 |
| Arm | Fixed -> Adaptive | -0.262558 | -0.004739 | 0.010796 |
| Arm | Fixed -> Fixed+Simple | 0.349972 | 0.002800 | -0.012574 |
| Arm | Fixed+Simple -> Fixed+Full | 0.101267 | 0.000571 | -0.000513 |

