# HAIF-GS: Hierarchical and Induced Flow-Guided Gaussian Splatting for Dynamic Scene

## Methods 总结

### 目标与整体流程

给定单目视频帧序列 \(\{I_t\}\) 及相机位姿 \(\{P_t\}\)，目标是在观测时间区间内，从任意视角、任意时间渲染动态场景。HAIF-GS 在 3DGS 基础上，用**稀疏运动锚点 (motion anchors)** 建模变形：  
- 不再对每个高斯单独做时间变换，而是学习一组 3D 锚点及其随时间的刚体变换；  
- 每个高斯的运动由附近锚点通过**空间插值 + LBS** 驱动；  
- 通过 **Anchor Filter** 做动静分解、**Induced Flow-Guided Deformation (IFGD)** 提供自监督流引导、**Hierarchical Anchor Densification (HAD)** 在高运动复杂度处增加更细锚点层级；  
从而同时提升效率、时间一致性与对非刚性细节的刻画能力。

---

### 3.1 3D Gaussian Splatting 预备

静态 3DGS：场景由各向异性高斯集合表示，每个高斯具有中心 \(\mu \in \mathbb{R}^3\)、协方差 \(\Sigma \in \mathbb{R}^{3\times 3}\)、不透明度 \(\sigma\)，以及 SH 系数 \(h\)。协方差分解为旋转 + 缩放：
\[
\Sigma = R S S^\top R^\top
\]
其中 \(R\) 由单位四元数给出，\(S\) 为对角缩放矩阵。通过投影矩阵 \(W\) 与 Jacobian \(J\) 得到投影后的协方差与中心：
\[
\Sigma' = J W \Sigma W^\top J^\top, \qquad \mu' = J W \mu
\]
渲染时，高斯按深度排序，像素 \(u\) 处颜色为：
\[
C(u) = \sum_{i\in N(u)} T_i \alpha_i\, SH(h_i, v)
\]
其中 \(T_i = \prod_{j<i}(1-\alpha_j)\) 为透射率，\(\alpha_i\) 由 2D 高斯密度与 \(\sigma_i\) 计算，\(v\) 为视角方向。所有参数通过光度损失 (L1 + D-SSIM) 及密度控制（分裂/剪枝）优化。

---

### 3.2 基于 3DGS 的动态重建

常见动态 3DGS 将静态高斯经**变形场**随时间变换：  
设变形网络 \(D\) 输入静态属性 \((\mu,r,s)\) 与时间 \(t\)，输出时刻 \(t\) 的补偿：
\[
(\mu_t, r_t, s_t) = D(\mu, r, s, t)
\]
即每个高斯在时间 \(t\) 的位置、旋转、尺度由网络给出。可再结合运动先验、位姿精化、特征匹配等，但存在：局部复杂运动建模能力有限、时间一致性差、对异质运动模式泛化不足等问题，激发本文的锚点式表示。

---

### 4.1 总体思路

为兼顾效率与表达力，HAIF-GS 采用**层级稀疏运动锚点表示**：  
- 使用少量可学习 3D 锚点表示运动单元，通过空间插值将锚点变换传播到高斯；  
- 通过 IFGD 模块聚合多帧特征，自监督诱导场景流，引导锚点变换、提升时间一致性；  
- 对运动复杂区域，引入层级锚点结构 (HAD)，在更高分辨率上增密锚点并分层传播变换。

整体由三块组成：  
1. 稀疏运动锚点与动静分解（Sec. 4.2）；  
2. Induced Flow-Guided Deformation（Sec. 4.3）；  
3. Hierarchical Anchor Densification（Sec. 4.4）。

---

### 4.2 稀疏运动锚点与动静分解

#### 运动锚点表示

用稀疏可学习 3D 点集表示场景运动，称为**运动锚点**。不直接给每个高斯参数化时间变换，而是对锚点预测局部刚体变换，再通过空间插值传播到高斯。  

- 锚点初始化：在 canonical 空间用 **Farthest Point Sampling (FPS)** 抽样，保证空间均匀覆盖。  
- 每个锚点 \(a_i\) 参数为位置 \(x_i\in\mathbb{R}^3\) 与可学习影响尺度 \(\rho_i>0\)，整体记为  
  \(A = \{(x_i,\rho_i)\}_{i=1}^M\)。  
- 对每个高斯 \(g_j\)（中心 \(\mu_j\)），在 canonical 空间按欧氏距离选取 K 个最近锚点组成 \(A_j\)。  
- 锚点对高斯的影响权重基于归一化高斯核：
\[
\omega_{ij} = \frac{\exp\left(-\|\mu_j - x_i\|^2/\rho_i^2\right)}{\sum\limits_{x_k\in A_j} \exp\left(-\|\mu_j - x_k\|^2/\rho_k^2\right)}
\]
这些权重后续用于插值锚点变换生成高斯的最终运动。

#### 动静分解与 Anchor Filter

为区分静态与动态区域，在锚点集合上做**动静分解**。  
对每个锚点 \(a_i\) 预测一个置信度 \(\alpha_i\in[0,1]\)，表示其参与动态运动的概率：  
- 高 \(\alpha_i\) → **动态锚点**，参与变形建模；  
- 低 \(\alpha_i\) → 视为静态，不参与变形。  

\(\alpha_i\) 由 **Anchor Filter**（轻量 MLP）预测，输入是锚点空间与时间坐标的 positional encoding：\(\gamma(x_i), \gamma(t)\)。Anchor Filter 与 IFGD 模块联合优化。训练分两阶段：  
1. **软分解阶段**：所有锚点都参与变形，其变换由 \(\alpha_i\) 软调制，使梯度能回传到 Anchor Filter；  
2. **硬分解阶段**：对 \(\alpha_i\) 做阈值，真正只保留动态锚点做运动建模。  

为正则化动静分解，引入两项损失（见 4.5）：**稀疏性 loss** 与 **熵正则**，分别鼓励动态锚点比例小、决策更二值化。

---

### 4.3 Induced Flow-Guided Deformation (IFGD)

IFGD 利用**诱导场景流 + 多帧特征聚合**，在无外部光流监督下自监督地指导锚点变换。

#### 诱导流与时间查询

给定锚点位置 \(x\) 与时间 \(t\)，先做 positional encoding，然后用 **Induced Flow MLP** 预测前向和后向场景流：
\[
(F^{t-1}, F^{t+1}) = \mathrm{MLP}_{\text{flow}}(x,t)
\]
其中 \(F^{t-1}\) 与 \(F^{t+1}\) 为从时刻 \(t\) 流向 \(t-1\)、\(t+1\) 的位移。使用这两个流构造三组时间偏移查询：
\[
q_{t-1} = (x + F^{t-1}, t-1),\quad q_t = (x,t),\quad q_{t+1} = (x + F^{t+1}, t+1)
\]

每个查询通过共享的 **Deformable MLP** 映射为时间感知特征：
\[
f^{t+i} = \mathrm{MLP}_{\text{deform}}(q_{t+i}), \quad i\in\{-1,0,+1\}
\]

再做简单线性聚合，得到时间一致的锚点特征：
\[
\tilde{f}^t = \lambda f^{t-1} + (1-2\lambda) f^t + \lambda f^{t+1}, \quad \lambda\in(0,0.5)
\]
文中取 \(\lambda=0.25\)。该聚合在训练中把场景流预测与重建绑定在一起，使流在重建驱动下收敛到一致的运动模式。

#### 锚点变换预测与高斯插值

对锚点 \(a_i\) 在时间 \(t\) 的一致特征 \(\tilde{f}_i^t\)，用多个独立的变换 head 预测其平移 \(\Delta T_i^t\in\mathbb{R}^3\) 与旋转 \(\Delta R_i^t\in\mathbb{R}^3\)（四元数形式）。  

对高斯 \(g_j\)，在 canonical 空间用 KNN 找邻近锚点集合 \(A_j\)，按式 (3) 计算 \(\omega_{ij}\)。然后采用 **线性 blend skinning (LBS)** 将锚点变换插值到高斯：  
位置更新：
\[
\Delta\mu_j^t = \sum_{i\in A_j} \omega_{ij}\Big(\Delta R_i^t(\mu_j - x_i) + x_i + \Delta T_i^t\Big)
\]
旋转更新：
\[
\Delta r_j^t = \left( \sum_{i\in A_j} \omega_{ij} \cdot \Delta R_i^t \right) \otimes r_j
\]
其中 \(r_j\) 为高斯原始四元数，\(\otimes\) 为四元数乘。这样每个高斯的变形由稀疏锚点局部驱动，构成紧凑的稠密变形场。

#### 时间自监督：循环一致性

为加强运动学习的时间一致性，对预测场景流加 **cycle consistency loss**（见 4.5），鼓励前/后向流组合后回到原位置，从而在无显式流标注下获得物理上合理的流场。

---

### 4.4 Hierarchical Anchor Densification (HAD)

稀疏锚点足以建模大尺度运动，但对**细粒度非刚性变形**可能不够。HAD 在**运动复杂区域自适应增密锚点**，构建多层锚点层级以细化表示。

**复杂运动区域判定**：对每个基础层锚点 \(a_i\)，计算其在 \(N_t=16\) 个随机时间上的平移方差：
\[
\text{var}(a_i) = \frac{1}{N_t}\sum_{t=1}^{N_t} \big\|\Delta T_i^t - \overline{\Delta T_i}\big\|_2^2,\quad
\overline{\Delta T_i} = \frac{1}{N_t}\sum_{t=1}^{N_t} \Delta T_i^t
\]
当 \(\text{var}(a_i) > \tau\) 时，认为该锚点所在区域运动复杂，需层级细化。

**层级增密与传播**：  
- 对每个被标记锚点，复制并施加小空间偏移，生成高分辨率子锚点，构成多层层级（见 Fig. 2）；  
- 每个子锚点编码自身位置、时间及父锚点平移，实现跨层运动传播；  
- 所有层共享 Deformable MLP，仅用轻量层级特征提取器区分，保证效率。  

对高斯最终变换：  
- 在每一层独立检索邻近锚点、计算插值变换；  
- 各层结果按层级学习到的置信权重做融合；  
从而以较小开销在运动复杂区域获得多尺度运动分解和更细致的非刚性建模。

---

### 4.5 优化与损失

在 3DGS 的光度损失基础上，引入三类额外正则：**循环一致性 loss、稀疏性 loss、熵 loss**。

**循环一致性 (cycle consistency)**：  
鼓励前向 + 反向流组合后回到原锚点位置：
\[
L_{\text{cycle}} = \mathbb{E}_i\Big[\big\|F_i^{t-1} + \mathrm{Flow}(x_i + F_i^{t-1}, t-1)\big\|_2^2 + \big\|F_i^{t+1} + \mathrm{Flow}(x_i + F_i^{t+1}, t+1)\big\|_2^2\Big]
\]
其中 \(\mathrm{Flow}\) 为 4.3 中的 flow MLP。

**动静分解正则**：对 Anchor Filter 输出 \(\alpha_i\) 加两项：  
\[
L_{\text{sparsity}} = \mathbb{E}_i[\alpha_i],\qquad L_{\text{entropy}} = \mathbb{E}_i[\alpha_i(1-\alpha_i)]
\]
\(L_{\text{sparsity}}\) 控制动态锚点比例，鼓励用尽可能少的动态锚点解释场景（奥卡姆剃刀）；\(L_{\text{entropy}}\) 惩罚接近 0.5 的不确定分数，促使决策更接近 0/1。

**总损失**：在 L1 与 D-SSIM 基础上加权三项正则：
\[
L = \lambda L_1 + (1-\lambda)L_{D\text{-SSIM}} + \lambda_1 L_{\text{cycle}} + \lambda_2 L_{\text{entropy}} + \lambda_3 L_{\text{sparsity}}
\]
文中经验设置 \(\lambda=0.8, \lambda_1=0.01, \lambda_2=0.2, \lambda_3=0.5\)，以重建质量为主，同时兼顾时间一致性与锚点稀疏性。

---

### 小结

| 模块 | 作用 |
|------|------|
| 3DGS 预备 | 静态 3D 高斯表示与可微 splatting (位置/协方差/SH、不透明度、分裂/剪枝) |
| 稀疏运动锚点 (4.2) | FPS 初始化 \(A=\{(x_i,\rho_i)\}\)，KNN + 高斯核权重 \(\omega_{ij}\)，Anchor Filter 动静分解，\(L_{\text{sparsity}}, L_{\text{entropy}}\) 正则化 |
| IFGD (4.3) | Flow MLP 预测 \(F^{t-1},F^{t+1}\)，构造时间偏移查询并由 Deformable MLP 得到 \(f^{t-1},f^t,f^{t+1}\)，公式 (4) 聚合为 \(\tilde{f}^t\)，多 head 输出 \(\Delta T_i^t,\Delta R_i^t\)，LBS 插值到高斯，\(L_{\text{cycle}}\) 做流循环一致性 |
| HAD (4.4) | 以 \(\text{var}(a_i)\) 判定复杂区域（式 (6)），对高 var 锚点增密子锚点，多层结构共享变形网络；对高斯跨层检索、分层插值并按层权重融合，实现多尺度运动建模 |
| 总损失 (4.5) | L1 + D-SSIM + 三正则 (cycle/sparsity/entropy)，权重选型平衡质量、时间一致性与 sparsity |

整体上，HAIF-GS 用**锚点驱动的、层级化的变形表示 + 自监督流引导**取代 per-Gaussian 变形场，在保证 3DGS 实时渲染能力的同时，更好地刻画复杂非刚性动态并提升时间一致性与效率。

