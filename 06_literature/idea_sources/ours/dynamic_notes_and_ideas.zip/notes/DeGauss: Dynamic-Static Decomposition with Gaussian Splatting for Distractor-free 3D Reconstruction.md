# DeGauss: Dynamic-Static Decomposition with Gaussian Splatting for Distractor-free 3D Reconstruction

## 0. Metadata

* Title: DeGauss: Dynamic-Static Decomposition with Gaussian Splatting for Distractor-free 3D Reconstruction
* Authors: Rui Wang; Quentin Lohmeyer; Mirko Meboldt; Siyu Tang
* Year: 2025
* Venue: ICCV 2025
* PDF source: `/Users/wangyibo/Zotero/storage/GWCVPTCJ/Wang 等 - DeGauss Dynamic-Static Decomposition with Gaussian Splatting for Distractor-free 3D Reconstruction.pdf`
* Local note path: `notes/DeGauss: Dynamic-Static Decomposition with Gaussian Splatting for Distractor-free 3D Reconstruction.md`
* Zotero item key: `LMGK69C3`
* Zotero PDF attachment key: `GWCVPTCJ`
* Existing Zotero Markdown attachment key: `MDDEGS01`
* Project page: https://batfacewayne.github.io/DeGauss.io/
* Code: project page exists; repository URL is Not specified in extracted PDF text
* Dataset link: Not specified
* Main task: distractor-free 3D reconstruction and dynamic-static Gaussian decomposition
* Domain: Gaussian Splatting; egocentric video; casual image collections; dynamic/static scene decomposition
* Input: noisy / occluded image collections or long egocentric videos with dynamic distractors; camera poses and point clouds from COLMAP or sensor perception
* Output: clean static background reconstruction, dynamic foreground render, composed render, probabilistic foreground/background masks
* Main representation: decoupled foreground deformable Gaussians and background static Gaussians, coordinated by probabilistic composition masks
* Supervision type: self-supervised reconstruction from images/videos, no external dynamic masks
* Core contribution in one sentence: 用前景可形变高斯和背景静态高斯做自监督动态/静态解耦，并通过前景光栅化出的概率 mask、brightness control、loss-gradient-separated densification 和 partial opacity reset 抑制 static floaters 与 dynamic over-segmentation。
* Note status: `complete`

## 1. 一句话技术摘要

这篇论文处理 real-world / egocentric 输入中的 distractor-free 3D reconstruction，通过把动态元素建模为 foreground deformable Gaussians、静态场景建模为 background Gaussians，并用 foreground rasterized probabilistic masks 在渲染后组合两支路；关键技术差异是把动态/静态分解从外部语义 mask 或 loss residual heuristic 改成一个可微的双分支 Gaussian composition 过程。

## 2. 问题形式化

### 2.1 任务

给定包含移动人、手、物体、光照变化、blur、lens flare 等干扰的真实图像集合或 egocentric video，学习一个 3D 表示，使其既能重建干净静态背景，也能在动态场景设置中渲染 foreground / background / composed dynamic scene。

### 2.2 核心矛盾

静态 3DGS 对跨视角静态结构稳定，但会把动态物体建成 view-dependent artifacts 或 floaters。动态 Gaussian 方法能拟合运动，但在训练视角上容易 overfit，novel view 泛化弱。DeGauss 的设计目标是把两者结合：

* foreground branch: 高表达力，可形变，吸收动态物体；
* background branch: 稳定，专注静态环境；
* probabilistic masks: 协调两支路贡献，而不是用外部 mask 硬切。

### 2.3 输入输出

* 输入: image collections 或 long egocentric videos；相机位姿；scene boundary；background initialization point cloud。
* 输出: foreground render $C_f$、background render $C_b$、controlled background $\hat{C}_b$、composition mask $P_f,P_b$、final composed render $\hat{C}$。
* 训练: self-supervised photometric reconstruction；没有人工动态 mask。
* 应用: distractor-free static scene modeling 和 efficient dynamic scene modeling。

## 3. 方法概览

DeGauss 的主 pipeline 可以分为六块：

1. 初始化 background Gaussians 和 foreground Gaussians。背景来自 COLMAP 或 Aria sensor perception 点云，前景是 scene boundary 内随机点。
2. foreground branch 使用 HexPlane encoder + multi-head MLP decoder，预测前景 Gaussian 属性的时空变形。
3. foreground Gaussians 同时 rasterize 动态颜色、foreground/background probabilistic mask 和 brightness control mask。
4. background branch 独立 rasterize 静态背景，再由 brightness control 调整，以减少光照变化导致的动静态歧义。
5. 最终图像不是沿 ray 混合动态/静态 density，而是在两支路独立渲染后，用 $P_f$ 和 $P_b$ 做 image-space composition。
6. 训练中通过 loss 分组、partial opacity reset 和 pruning 抑制 foreground utility Gaussians 与 background floaters。

方法的关键不是提出更复杂的 dynamic deformation 网络，而是把动态/静态分解变成 foreground branch 自己预测 mask、background branch 独立负责静态细节的协同优化问题。

## 4. 方法细节

### 4.1 3DGS 基础

每个 3D Gaussian primitive 由 mean $x\in R^3$ 和 covariance $\Sigma\in R^{3\times3}$ 定义。Eq. 1 写作 $G(x)=\exp(-\frac{1}{2}(x-x)^T\Sigma^{-1}(x-x))$，原文符号把 query point 和 mean 都写成 $x$，应理解为标准 3DGS 的 $G(y)=\exp(-\frac{1}{2}(y-\mu)^T\Sigma^{-1}(y-\mu))$。

协方差分解为 $\Sigma=Rdiag(s)diag(s)^T R^T$，其中 $R$ 可由 quaternion $r$ 表示，$s$ 是 scale vector。

渲染采用 differentiable splatting。Eq. 2 中像素颜色为 $C=\sum_{i=1}^{N}c_i\sigma_iP_i(G_i)\prod_{j=1}^{i-1}(1-\sigma_jP_j(G_j))$。这里 $c_i$ 是 SH coefficients，$\sigma_i$ 是 opacity，$P_i(G_i)$ 是投影权重。

### 4.2 Foreground deformable Gaussians

DeGauss 将 foreground Gaussian feature 扩展为 $G_f=\{x,s,r,\sigma,c,m_f,m_b,b\}$。

其中：

* $x,s,r,\sigma,c$: 标准 3DGS 属性；
* $m_f$: foreground probabilistic attribute；
* $m_b$: background probabilistic attribute；
* $b$: brightness control attribute。

变形后的前景 Gaussian 写为 $G'_f=\Delta G_f+G_f$。时空模块由 HexPlane encoder $H$ 和 multi-head decoder $D$ 组成。encoder 按参考时间 $t$ 提取特征 $f_d=H(G_f,t)$；decoder 预测各属性增量 $\Delta G_f=D(f_d)$。

decoder 由多个 MLP head 组成：$D=\{\phi_x,\phi_r,\phi_s,\phi_\sigma,\phi_c,\phi_{m_f},\phi_{m_b},\phi_b\}$。Eq. 3 中每个属性都按 residual 形式更新，如 $x'=x+\phi_x(f_d)$、$r'=r+\phi_r(f_d)$、$m'_f=m_f+\phi_{m_f}(f_d)$、$b'=b+\phi_b(f_d)$。

这个 foreground branch 的表达能力很强，因此论文后续必须用 probabilistic mask、brightness control、loss 分组和 partial opacity reset 防止它吞掉静态场景。

### 4.3 Probabilistic composition mask rasterization

给定变形后的 mask attributes $m'_f,m'_b$ 和 geometry attributes $x',r',s',\sigma'$，直接用 Eq. 2 同构的 alpha blending rasterize 出 raw foreground/background probability maps。

Eq. 4: $M_f=\sum_{i=1}^{N}m'_{f_i}\sigma'_iP_i(G'_{f_i})\prod_{j=1}^{i-1}(1-\sigma'_jP_j(G'_{f_j}))$。

Eq. 5: $M_b=\sum_{i=1}^{N}m'_{b_i}\sigma'_iP_i(G'_{f_i})\prod_{j=1}^{i-1}(1-\sigma'_jP_j(G'_{f_j}))$。

然后设 $P=M_f+M_b+\epsilon$，归一化得到 Eq. 6: $P_f=(1/P)M_f$，$P_b=(1/P)M_b$。

论文声称这种概率形式会自然抑制接近 0.5 的中间值，使 mask 倾向于 0/1，从而得到更干净的 dynamic-static decomposition。这个说法是经验/设计直觉，没有单独理论证明。

### 4.4 Background brightness control

真实 casual captures 中光照变化会导致分解歧义：foreground branch 可能把大范围 illumination variations 误判为动态元素。DeGauss 因此让 foreground branch 额外 rasterize brightness control mask $B$。

Eq. 7: $B=\sum_{i=1}^{N}b'_i\sigma'_iP_i(G'_{f_i})\prod_{j=1}^{i-1}(1-\sigma'_jP_j(G'_{f_j}))$。

为了避免 dark dynamic objects 被 brightness mask 解释，同时允许 over-brightness，论文使用 piece-wise linear activation。Eq. 8: 当 $0\le B\le0.75$ 时，$\hat{B}=B+0.5$；当 $0.75<B\le1$ 时，$\hat{B}=k(B-0.75)+1.25$。实践中 $k=35$。

background branch 渲染 raw background $C_b$，controlled background 为 $\hat{C}_b=\hat{B}*C_b$。

### 4.5 Dynamic foreground representation

Foreground color render 也由变形后的 foreground Gaussians rasterize。Eq. 9: $C_f(u,v)=\sum_{i=1}^{N}c'_{f_i}\sigma'_iP_i(G'_{f_i})\prod_{j=1}^{i-1}(1-\sigma'_jP_j(G'_{f_j}))$。

最终 foreground render 应理解为 $\hat{C}_f=P_f*C_f$。论文文本里有一次把 $C_f=P_f C_f$ 写成同名变量复用；note 中用 $\hat{C}_f$ 区分。

这个设计允许一些 utility Gaussians 主要服务于 $P_f,P_b,\hat{B}$，而不直接贡献 foreground color。作者认为这可以减少 unregulated Gaussian movement 导致的 artifacts。

### 4.6 Unsupervised scene decomposition

最终 composed render 在 Eq. 10 中定义为 $\hat{C}=P_f*C_f+P_b*\hat{B}*C_b$。

关键实现选择：foreground 和 background 不是在 ray integration 时共同排序混合，而是先独立 rasterize，再在 image space 按 probabilistic mask composition。论文认为 NeRF-style compose during rendering 会造成 early ray termination 和局部最小值，使静态细节不足；DeGauss 的 compose after rendering 保留两支路完整 gradient flow，使 mask 可在训练过程中逐渐形成。

错误建模的元素随后通过 Gaussian density control、partial opacity reset 和 pruning 逐步移除。

### 4.7 Loss function

Eq. 11 把总损失分成两组：$L=L_1+L_{diversity}+L_{reg}+L_{depth}+L_f+L_b+L_{SSIM}+L_{entropy}+L_{brightness}+L_{scale}$。

论文将前半组记为 $L_{main}$，包括 $L_1,L_{diversity},L_{reg},L_{depth},L_f,L_b$；后半组记为 $L_{uti}$，包括 $L_{SSIM},L_{entropy},L_{brightness},L_{scale}$。

重要细节：$L_{main}$ 和 $L_{uti}$ 都用于参数更新，但只有 $L_{main}$ 的 gradient magnitude 用于 foreground/background Gaussian densification。这个设计是为了抑制 floaters spawning，并控制 foreground utility Gaussians 数量。

各 loss term 的详细定义在 Appendix A，当前 PDF 文本不含 appendix，因此需要 `NEED_HUMAN_CHECK`。

### 4.8 Partial Opacity Reset

标准 3DGS periodic opacity reset 在 distractor-free / decomposition 设置中会造成训练不稳定。DeGauss 借助 foreground-background formulation 的额外稳定性，周期性对 background-foreground Gaussians 执行 50% partial opacity reset。

论文称该策略能稳定训练、控制 Gaussian density、处理 local minima。具体 reset interval / target opacity / selection rule 在抽取文本中未给出。

## 5. 数学目标与损失

### 5.1 Reconstruction objective

主 reconstruction 由 $L_1$ 和 $L_{SSIM}$ 等项驱动；但为了控制 densification，DeGauss 不把所有 loss 的 gradient 都用于 density control。这个细节比公式本身更重要：它把“优化参数”与“触发 densification 的梯度”分开。

### 5.2 Decomposition regularizers

从 loss 名称可见，DeGauss 至少使用：

* $L_{diversity}$: 推动前景/背景或 mask 表达多样性，防止塌缩；具体定义 `NEED_HUMAN_CHECK`。
* $L_{reg}$: 常规正则；具体定义 `NEED_HUMAN_CHECK`。
* $L_{depth}$: 促进 background geometry 平滑，并松散约束前景/背景深度预测；ablation 显示能减少固定相机稀疏输入下的遮挡 artifacts。
* $L_f,L_b$: 与 foreground/background 分支相关；具体定义 `NEED_HUMAN_CHECK`。
* $L_{entropy}$: 可能约束 mask confidence；具体定义 `NEED_HUMAN_CHECK`。
* $L_{brightness}$: 约束 brightness control；具体定义 `NEED_HUMAN_CHECK`。
* $L_{scale}$: 控制 Gaussian scale；具体定义 `NEED_HUMAN_CHECK`。

### 5.3 Composition objective

最终 loss 作用在 composed render $\hat{C}$ 与 input image 之间。因为 $\hat{C}$ 同时依赖 $P_f$、$P_b$、$C_f$、$\hat{B}$、$C_b$，梯度会同时推动 mask、foreground dynamics 和 background appearance。这个机制解释了为什么不需要外部 dynamic masks。

## 6. 训练与推理流程

### 6.1 初始化

* Scene boundary 和 background Gaussians: 由 COLMAP point clouds 初始化；Aria sequences 可用 sensor perception。
* Foreground Gaussians: 在 scene boundary 内随机生成点初始化。
* Foreground branch 初始含 mask attributes 和 brightness attribute。

### 6.2 Coarse training stage

coarse stage 中禁用 foreground deformation module，训练 foreground 和 background models：

* short video clips / image collections: 1000 iterations；
* long captures: iterations 等于 sequence length。

这个阶段的作用是先形成初步 foreground-background assignment，避免动态 deformation 一开始过强导致分解混乱。

### 6.3 Fine training stage

fine stage 端到端联合优化 foreground 和 background branches：

* 少于 500 images 的 short clips / image collections: 20k iterations；
* 几千帧 long video clips: 120k iterations。

训练中执行：

1. foreground deformation via HexPlane + MLP；
2. foreground mask / brightness / color rasterization；
3. background rasterization；
4. compose after rendering；
5. 用 $L_{main}+L_{uti}$ 更新参数；
6. 仅用 $L_{main}$ gradient 做 densification；
7. periodic partial opacity reset；
8. pruning 错误或低效 Gaussians。

### 6.4 推理

推理时可以输出：

* foreground render；
* clean background render；
* composition mask；
* composed dynamic render。

Figure 1 报告 dynamic scene modeling 中 DeGauss mLPIPS 0.062、FPS 151，而 4DGS mLPIPS 0.083、FPS 44。Figure 7 在 RTX4090 fixed-view rendering 上展示 Ours FPS 157 vs 4DGS FPS 53。

## 7. 实验设置与结果

### 7.1 数据集

Egocentric videos:

* ADT、AEA、Hot3D、EPIC-Fields；
* 每个 dataset 取一个 sequence；
* 约 2800 到 5000 frames；
* 每 5 帧 hold out 1 帧训练外评估或展示。

NeRF-on-the-Go:

* 数百张带 moving distractors 的训练图像；
* 少量 clean hold-out views 用于测试；
* 用于 distractor-free image collection reconstruction。

Neu3D:

* 15 到 20 个静态相机；
* 相对简单活动；
* 300 frames；
* camera view 0 为 test，其余训练。

HyperNeRF:

* 真实活动 smooth camera trajectories；
* 由于 camera poses 不准，论文主要做 qualitative visualization。

### 7.2 NeRF-on-the-Go distractor-free reconstruction

Table 1 显示 DeGauss 在 NeRF-on-the-Go 上平均 PSNR 23.91、SSIM 0.819、LPIPS 0.113。对比：

* SpotlessSplats: PSNR 23.42、SSIM 0.813、LPIPS 0.145；
* DeSplat: PSNR 22.58、SSIM 0.813、LPIPS 0.130；
* WildGaussian: PSNR 22.16、SSIM 0.746、LPIPS 0.182；
* 3DGS: PSNR 19.30、SSIM 0.668、LPIPS 0.253。

结果表明 DeGauss 的主要收益体现在 LPIPS 和细节保留，Figure 5 也强调相比 SpotlessSplats 更少误分动态区域并保留训练视图细节。

### 7.3 Egocentric qualitative results

Figure 4 在 EPIC-Field、Hot3D、AEA、ADT 上对比 3DGS、SpotlessSplats、NeuralDiff。DeGauss 展示更干净的 static background 和更准确的 foreground separation。由于 egocentric sequences 缺少 clean reference，主文主要给定性比较。

### 7.4 Neu3D dynamic modeling

Table 2 中 DeGauss 在 Neu3D 上平均 PSNR 31.52、SSIM 0.942、LPIPS 0.047。对比：

* 4DGS: PSNR 31.12、SSIM 0.937、LPIPS 0.058；
* SWinGS: PSNR 31.12、SSIM 0.941、LPIPS 0.095；
* KPlanes: PSNR 31.63、SSIM 0.964、LPIPS 0.117；
* HyperReel: PSNR 30.72、SSIM 0.931、LPIPS 0.101。

DeGauss 的 PSNR 不是最高，但 LPIPS 最好，符合它强调 perceptual quality 和 foreground-background decomposition 的定位。

### 7.5 HyperNeRF qualitative results

Figure 8 对比 4DGS 和 DeGauss，论文声称 DeGauss 的 probabilistic controlled dynamic foreground representation 能正则 Gaussian movements，减少 unregularized moving artifacts。由于 camera poses 不准，未给主定量。

### 7.6 Ablation

Table 3 在 NeRF-on-the-Go 上报告：

* w/o BC: PSNR 23.54，SSIM 0.814，LPIPS 0.118；
* w/o POR: 23.56，0.814，0.117；
* w/o $L_{depth}$: 23.68，0.816，0.113；
* w/o $m'_b$: 23.83，0.817，0.115；
* Ours: 23.91，0.819，0.113。

定量提升不大，但 Figure 9 / Figure 10 显示这些组件对 separation cleanliness、illumination ambiguity、foreground/background depth occlusion 有明显影响。

## 8. 声称贡献 vs 实际技术增量

### 8.1 论文声称

论文声称：

* 提出 decoupled foreground-background design；
* 在 egocentric videos 和 casual image collections 上达到 SOTA distractor-free reconstruction；
* 同时支持 efficient high-quality dynamic scene modeling。

### 8.2 实际技术增量

实际技术增量在于把两类已有路线组合成一个稳定训练系统：

* dynamic Gaussian deformation 用于 foreground；
* static Gaussian splatting 用于 background；
* foreground rasterized masks 负责 soft coordination；
* brightness mask 专门缓解 illumination 引起的动静态歧义；
* loss-gradient-separated densification 和 partial opacity reset 解决 3DGS density control 在 decomposition 场景下的训练不稳定。

这不是单一公式创新，而是一个系统级训练 recipe。对于 dynamic GS 分类矩阵，它更接近“foreground-background decomposition / distractor suppression”路线，而不是纯粹追求动态新视角合成的 deformation 方法。

### 8.3 证据强度

证据强的部分：

* NeRF-on-the-Go 上有 clean test views 和完整表格；
* Neu3D 上有动态建模定量表；
* 多个 egocentric datasets 有定性分解对比；
* ablation 覆盖 BC、POR、$m'_b$、$L_{depth}$。

证据弱的部分：

* egocentric 部分缺少 clean GT 定量，主要定性；
* Appendix A 的 loss 细节未在当前 PDF 中呈现；
* partial opacity reset 的具体 schedule 未报告；
* HyperNeRF 因 pose 不准只做定性，难以判断泛化能力。

## 9. 局限与隐藏假设

显式局限不多，论文 conclusion 没有单独 limitations。可从实验和方法中归纳以下限制：

* 对相机 pose 和 scene boundary 初始化仍有依赖，尤其是长 egocentric sequences。
* Foreground branch 随机点初始化可能需要足够 scene boundary 覆盖动态区域。
* Mask 是自监督形成的，遇到长期静止但语义上动态的物体，可能被背景吸收。
* brightness control 帮助光照变化，但也可能把真实动态外观变化解释成背景亮度。
* Loss 设计复杂，若 Appendix / code 不可用，复现风险较高。
* 在 Neu3D 上 LPIPS 优势明显，但 PSNR / SSIM 并非全面第一，说明目标更偏 perceptual / decomposition，而不是纯像素保真。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法名称 | DeGauss |
| 输入类型 | casual image collections; long egocentric videos; Neu3D multi-view videos |
| 核心表示 | foreground deformable Gaussians + background static Gaussians |
| 动态建模 | foreground HexPlane encoder + multi-head MLP deformation |
| 分解机制 | foreground rasterized $P_f,P_b$ probabilistic masks |
| 背景增强 | brightness control mask $\hat{B}$ |
| Composition | render foreground/background independently, compose after rendering |
| Density control | only $L_{main}$ gradients for densification |
| Opacity reset | periodic 50% partial opacity reset |
| 初始化 | background from COLMAP / sensor perception; foreground random within boundary |
| 训练轮数 | coarse 1000 or sequence length; fine 20k or 120k |
| 主数据集 | NeRF-on-the-Go; ADT; AEA; Hot3D; EPIC-Fields; Neu3D; HyperNeRF |
| 主优势 | robust distractor-free reconstruction and clean dynamic-static decomposition |
| 主短板 | loss details in appendix; egocentric quantitative GT limited; initialization dependence |

## 11. 对我的研究可复用组件

1. Render-then-compose：动态/静态支路先独立 rasterize，再用 learned mask 合成，避免 ray-level early termination。
2. Foreground-rasterized masks：mask 作为 Gaussian attribute 被同一 splatting 管线生成，而不是外部 2D segmentation。
3. Brightness control branch：对光照变化单独建模，避免把 illumination residual 误判为动态物体。
4. Loss-gradient-separated densification：参数更新用全 loss，但 densification 只看主 loss 梯度，可用于其他 multi-branch GS。
5. Partial opacity reset：在 decomposition 场景中替代标准 opacity reset，降低训练震荡。
6. Utility foreground Gaussians：允许某些前景点服务于 mask / brightness，而非直接服务于 color。

## 12. Gap and Idea Seeds

### 12.1 Gap: 自监督 mask 的语义一致性不足

DeGauss 的 foreground/background 是重建驱动的，不保证和语义动态对象一致。可加入 weak semantic priors 或 tracking consistency，让长期静止的人/物体不被背景永久吸收。

### 12.2 Gap: brightness control 可能过拟合光照

$\hat{B}$ 允许强 over-brightness modeling，$k=35$ 很激进。可以研究物理约束或 temporal smoothness，区分 illumination flicker、specular highlight 和真实动态遮挡。

### 12.3 Gap: Egocentric 缺少定量评价

论文在 egocentric videos 上主要定性。可以设计带 clean static background / dynamic segmentation GT 的 egocentric benchmark，量化 static cleanliness、foreground completeness 和 temporal flicker。

### 12.4 Gap: Loss 体系复杂但解释有限

Eq. 11 包含很多 loss terms，主文没有定义。可以做最小化版本研究：只保留 probabilistic masks + POR + $L_{depth}$，评估哪些项真正必要。

### 12.5 Gap: 与可编辑动态 GS 的结合

DeGauss 得到 foreground dynamic branch，但不是面向编辑。可结合 SC-GS 的 sparse control graph，把 foreground deformable Gaussians 变成可编辑 dynamic foreground。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: Appendix A 中各 loss term 的具体定义、权重和实现细节。
* `NEED_HUMAN_CHECK`: Partial Opacity Reset 的周期、选择规则和 reset 后 opacity 值。
* `NEED_HUMAN_CHECK`: project page 是否包含代码仓库；PDF 只明确给出项目页。
* `NEED_HUMAN_CHECK`: Eq. 1 原文符号把 query point 和 mean 都写作 $x$，note 中按标准 3DGS 解释。
* `NEED_HUMAN_CHECK`: Eq. 9 foreground render 变量命名在正文中复用 $C_f$，note 中用 $\hat{C}_f$ 区分。
* `NEED_HUMAN_CHECK`: Figure 1 的 mLPIPS / FPS 与 Figure 7 的 FPS 设置不同，引用时需注明上下文。

## 14. Evidence Anchors

* Abstract: dynamic elements modeled with foreground Gaussians, static content with background Gaussians, probabilistic mask coordinates composition。
* Figure 1: DeGauss 同时做 distractor-free static modeling 和 dynamic scene modeling；mLPIPS / FPS 对比。
* Section 1 Introduction: static Gaussians 稳定但产生 floaters；dynamic Gaussians 容易 overfit；提出 decoupled foreground-background representation。
* Section 2 Related Work: 对比 NeRF-on-the-go、WildGaussians、SpotlessSplats、NeuralDiff、D2NeRF、4DGS、Deformable-GS。
* Section 3.1 / Eq. 1-2: 3DGS Gaussian 和 alpha blending。
* Section 3.2 / Eq. 3: foreground Gaussian 扩展属性 $m_f,m_b,b$ 和 HexPlane + multi-head MLP deformation。
* Section 3.3 / Eq. 4-6: foreground/background probabilistic mask rasterization。
* Section 3.4 / Eq. 7-8: brightness control mask 与 piece-wise activation，$k=35$。
* Section 3.5 / Eq. 9: dynamic foreground render。
* Section 3.6 / Eq. 10: composed render $\hat{C}=P_f*C_f+P_b*\hat{B}*C_b$；render-then-compose rationale。
* Section 3.7 / Eq. 11: $L_{main}$ 与 $L_{uti}$ 分组，只有 $L_{main}$ gradient 用于 densification。
* Section 3.8: periodic 50% partial opacity reset。
* Section 4.1: initialization、coarse training、fine training iterations。
* Section 4.2: datasets and splits，ADT/AEA/Hot3D/EPIC-Fields、NeRF-on-the-Go、Neu3D、HyperNeRF。
* Section 4.3 / Table 1: NeRF-on-the-Go average PSNR 23.91、SSIM 0.819、LPIPS 0.113。
* Section 4.3 / Table 2: Neu3D average PSNR 31.52、SSIM 0.942、LPIPS 0.047。
* Figure 4: egocentric distractor-free qualitative comparison。
* Figure 5: NeRF-on-the-Go occlusion handling against SpotlessSplats。
* Figure 7: Neu3D qualitative comparison with 4DGS and FPS on RTX4090。
* Figure 8: HyperNeRF qualitative comparison with 4DGS。
* Section 5 / Table 3 / Figure 9-10: BC、POR、$m'_b$、$L_{depth}$ ablations。
