# Instant Gaussian Stream: Fast and Generalizable Streaming of Dynamic Scene Reconstruction via Gaussian Splatting

## 0. Metadata

- Title: Instant Gaussian Stream: Fast and Generalizable Streaming of Dynamic Scene Reconstruction via Gaussian Splatting
- Authors: Jinbo Yan; Rui Peng; Zhiyan Wang; Luyang Tang; Jiayu Yang; Jie Liang; Jiahao Wu; Ronggang Wang
- Venue/Year: CVPR 2025
- Zotero item key: `BYGRKFF5`
- Zotero PDF attachment key: `IBREUE5G`
- PDF path: `/Users/wangyibo/Zotero/storage/IBREUE5G/Yan 等 - Instant Gaussian Stream Fast and Generalizable Streaming of Dynamic Scene Reconstruction via Gaussi.pdf`
- Local note path: `notes/Instant Gaussian Stream: Fast and Generalizable Streaming of Dynamic Scene Reconstruction via Gaussian Splatting.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

Instant Gaussian Stream 用一个跨场景训练的 Anchor-driven Gaussian Motion Network 从多视角相邻帧的 2D motion features 推断 3D anchor motion，再插值驱动所有 Gaussians，实现单次前向的 frame-to-frame streaming reconstruction，并用 key-frame refinement 控制误差累积和点数增长。

## 2. Problem Formulation

Free-viewpoint video 的 streaming reconstruction 希望动态场景可以边采集边重建，减少 offline full-video training 带来的延迟。现有 streaming 方法如 3DGStream 虽可逐帧更新，但仍依赖 per-frame optimization，单帧常需 10s+，且长序列会有 error accumulation。

IGS 的目标是在 multi-view dynamic inputs 下，把每帧重建时间降到 2s+，同时保持高质量和低存储。关键设定是：不是每帧优化一个 transformation cache，而是训练一个 generalized network，在测试场景中直接从相邻帧图像推断 Gaussian motion。

输入是当前帧与 key/previous frame 的多视角图像和相机参数，以及 key frame 的 Gaussians；输出是 target frame 的 Gaussian positions / rotations，并按 key frame 周期做 refinement。

## 3. Method Overview

IGS 包含两个主要部分。第一是 Anchor-driven Gaussian Motion Network (AGM-Net)。它从相邻帧 multi-view image pairs 中提取 2D optical-flow motion features，采样一组 3D anchor points，把 2D motion features 投影/提升到 anchors 上，经 Transformer 聚合成 3D motion features，再通过 KNN interpolation 为每个 Gaussian 分配 motion feature，最后线性头输出 Gaussian position 和 rotation deformation。

第二是 Key-frame-guided Streaming strategy。每隔 $w$ 帧设置一个 key frame。Candidate frames 不优化 Gaussians，只从最近 key frame 通过 AGM-Net 单次推断；到达下一 key frame 时，对该 key frame 的 Gaussians 做 Max-points-bounded refinement，允许 3DGS-style clone/split/filter 以处理非刚性、出现/消失和累积误差，但限制总点数避免存储膨胀和 sparse-view overfitting。

AGM-Net 离线训练一次，可跨场景泛化；在线 streaming 只对 key frames 做短优化，candidate frames 是 feed-forward。

## 4. Method Details

### 4.1 Motion Feature Maps

给定当前帧 multi-view images $I'=(I'_1,\ldots,I'_V)$ 与上一/关键帧 images $I$，IGS 先构造 multi-view image pairs。使用 GM-Flow 提取 optical flow embeddings，再用 modulation layer 注入 viewpoint 和 depth information，得到 2D motion feature maps：

$$
F\in\mathbb{R}^{V\times C\times H\times W}.
$$

实现中使用 $V=4$ views，每个 motion map 有 $C=128$ channels，分辨率 $128\times128$。GM-Flow 大部分参数固定，只加 Swin-Transformer block 微调。

### 4.2 Anchor Sampling

直接为每个 Gaussian 计算 motion feature 成本高，因此 IGS 从 $N$ 个 Gaussians 的 centers 中用 Farthest Point Sampling 采样 $M$ 个 anchor points：

$$
C=\mathrm{FPS}(\{\mu_i\}_{i\in N}).
$$

其中 $C\in\mathbb{R}^{M\times3}$，实验中 $M=8192$。Anchors 承载局部 3D motion features，并通过邻域插值驱动周围 Gaussians。

### 4.3 Projection-Aware 3D Motion Feature Lift

每个 anchor $C_i$ 投影到各视角 motion feature map 上，用 bilinear interpolation 取 feature，再对视角平均：

$$
f_i=\frac{1}{V}\sum_{j\in V}\Psi(\Pi_j(C_i),F_j).
$$

其中 $\Pi_j$ 是第 $j$ 个 camera projection，$\Psi$ 是 bilinear interpolation。得到的 $f_i\in\mathbb{R}^C$ 是 anchor 的 3D motion feature。随后所有 anchor features 输入 Transformer self-attention：

$$
\{z_i:z_i\in\mathbb{R}^{C}\}_{i\in M}=\mathrm{Transformer}(\{f_i\}_{i\in M}).
$$

Transformer 让 anchors 在 3D scene 中交换 motion information。

### 4.4 Interpolation and Motion Decode

对每个 Gaussian $G_i$，从其 $K$ 个最近 anchors 插值 motion feature：

$$
z_i=\frac{\sum_{k\in N(i)}e^{-d_k}z_k}{\sum_{k\in N(i)}e^{-d_k}}.
$$

其中 $d_k$ 是 Gaussian 到 anchor $C_k$ 的 Euclidean distance。然后用 Linear head 解码 position 和 rotation deformation：

$$
d\mu_i,d\mathrm{rot}_i=\mathrm{Linear}(z_i).
$$

更新 Gaussian center 和 rotation：

$$
\mu'_i=\mu_i+d\mu_i.
$$

$$
\mathrm{rot}'_i=\mathrm{norm}(\mathrm{rot}_i)\times\mathrm{norm}(d\mathrm{rot}_i).
$$

这里 $\times$ 是 quaternion multiplication。AGM-Net 只预测 position 和 rotation，不直接更新 opacity、scale 或 color，因此对刚性/近刚性短间隔 motion 更有效。

### 4.5 Key-Frame-Guided Streaming

从 frame 0 开始，每隔 $w$ 帧设一个 key frame：$\{K_0,K_w,\ldots,K_{nw}\}$。从 key frame $K_{iw}$ 出发，AGM-Net 直接推断后续 candidate frames，直到下一个 key frame $K_{(i+1)w}$。到达 key frame 后，对 key frame Gaussians 做 refinement，再继续后续段。

这个策略避免 candidate-to-candidate 连续传播导致的误差累积，因为每个 candidate 都从最近 refined key frame 出发。同时，candidate frames 不优化，因此 per-frame latency 很低。实验最终选择 $w=5$。

### 4.6 Max-Points-Bounded Key-Frame Refinement

Key frame refinement 优化所有 Gaussian attributes，并允许 3DGS-style cloning、splitting 和 filtering，以处理 object deformation、appearance changes 和 point birth/death。但如果每个 key frame 都无限 densify，点数和存储会持续增长，也容易在 sparse-view dynamic scenes 上 overfit。

IGS 用 Max Points Bounded Refine 控制 densification：在 densify Gaussian points 时调整每个点的 gradient，使总点数不超过预设 maximum。表 4 显示 $w=1$ 时每帧都优化，PSNR 33.55、train 6.38s、storage 36.0MB；$w=5$ 达到 PSNR 33.62、train 2.67s、storage 7.90MB；$w=10$ 降到 PSNR 30.14。

## 5. Mathematical Objectives and Losses

AGM-Net 离线训练和 key-frame online refinement 都使用同一 view synthesis loss：

$$
L=(1-\lambda)L_1+\lambda L_{\mathrm{D-SSIM}}.
$$

离线训练时优化 AGM-Net 参数，让预测 frame 的 rendered views 对齐 ground truth views。在线 key-frame refinement 时不更新 network，而是优化 Gaussian primitive attributes。

底层 3DGS alpha blending 为：

$$
c=\sum_{i=1}^{n}c_i\alpha'_i\prod_{j=1}^{i-1}(1-\alpha'_j).
$$

注意抽取文本中 Eq. 2 的 product 下标疑似有排版错误；标准形式应为对前方 Gaussians 的 transmittance product。

## 6. Training and Inference Procedure

数据方面，Neural 3D Video 包含 6 个动态场景、21 cameras、2704x2028、300 frames。Meeting Room 包含 3 个动态场景、13 cameras、1280x720、300 frames。训练集使用 N3DV 四个 sequences，测试使用 cut roasted beef 和 sear steak；为所有训练帧预先构建 3D Gaussians，总计 1200 frames，需要 192 GPU hours。每个 frame 的 Gaussian 向前/向后五帧构造 motion pairs，总计 12,000 pairs。

AGM-Net 训练使用 4 张 A100 40GB，batch size 16，15 epochs。随机选 4 views 输入、8 views 监督。Anchor 数 $M=8192$，3D motion feature lift module 的 Transformer 为 4 layers，channel 数 128。Optimizer 为 Adam，weight decay 0.05，$\beta=(0.9,0.95)$。抽取文本中学习率段落被截断。

Streaming 推理时，candidate frame 约 0.8s，key frame refine 约 4s (small) 或 7.5s (large)，平均 $w=5$ 时约 2.67s/frame。渲染速度报告为 204 FPS。

## 7. Experimental Setup and Results Summary

Figure 1 显示 IGS 在质量、训练速度和存储上优于 streaming baselines。主结果声称 IGS-l / IGS-s 在 N3DV 上达到约 34.15 PSNR、204 FPS、2.67s/frame、7.9MB/frame，并在 quality-train time tradeoff 上优于 3DGStream、StreamRF、K-Planes、4DGS、SpaceTime-GS 等。

Key-frame interval ablation 表明 $w=5$ 是最佳折中。$w=1$ 每帧 key frame，过度优化导致测试质量没有提高且 train/storage 大；$w=10$ 间隔太长，AGM-Net 需要跨太远 motion，PSNR 明显下降。最终 $w=5$：PSNR 33.62，train 2.67s，storage 7.90MB。

Independent per-frame reconstruction time 具有周期模式：candidate frames 0.8s，key frames 4s/7.5s，均低于 3DGStream 的 16s。论文还报告 in-domain 和 cross-domain evaluations，证明 AGM-Net 有跨场景泛化能力。

Qualitative comparison on N3DV 显示 IGS 相比 3DGStream、SaRo-GS、4DGS 在动态区域细节和整体质量上更好。但讨论中也指出 IGS 相邻帧会有 jitter，因为当前框架缺少 temporal dependencies；3DGStream 因假设相邻帧运动小会更平滑，但大运动失败。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 generalized AGM-Net、key-frame-guided streaming strategy 和跨域 SOTA performance。实际技术增量在于把 per-frame optimization 替换为 learned feed-forward Gaussian motion prediction，并用 anchors 把 multi-view 2D motion features lift 到 3D Gaussian domain。

与 3DGStream 的 Neural Transformation Cache 相比，IGS 不为每帧优化 cache，而是对 candidate frames 只做一次 inference，因此 per-frame reconstruction time 大幅降低。与 offline 4DGS / SpaceTimeGS 相比，IGS 不需要等待完整视频训练，更适合 streaming FVV。与 generalizable static 3DGS 方法相比，IGS 把泛化思想用于 dynamic streaming 的 inter-frame Gaussian motion。

## 9. Limitations / Assumptions

IGS 的 candidate frame 更新只预测 position 和 rotation，对强非刚性、拓扑变化、出现/消失仍依赖 key-frame refinement。如果 keyframe interval 太长，质量会快速下降。

当前框架缺少 temporal dependency modeling，导致 adjacent frames 可能 jitter。论文计划未来把 motion 建模为 time series 来增强鲁棒性。

AGM-Net 离线训练需要预先为 1200 frames 构建 Gaussians，成本为 192 GPU hours；这不是在线成本，但说明训练 generalized model 的前置代价较高。

方法面向 multi-view dynamic inputs，并依赖光流模型、深度/视角 modulation 和关键帧 Gaussians 质量。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Task | Streaming dynamic scene reconstruction for FVV |
| Input | Multi-view adjacent/key-frame image pairs plus key-frame Gaussians |
| Core network | Anchor-driven Gaussian Motion Network |
| Motion features | GM-Flow embeddings with viewpoint/depth modulation |
| 3D lifting | Project anchors into multi-view feature maps and average |
| Motion propagation | KNN anchor interpolation to all Gaussians |
| Predicted updates | Gaussian position and rotation |
| Streaming control | Key frames every $w=5$ with max-points-bounded refinement |
| Strength | 2s+ per-frame reconstruction and cross-scene generalization |
| Weakness | Jitter; limited non-rigid modeling between key frames |

## 11. Reusable Components

- Anchor-based motion representation for large Gaussian clouds.
- Projection-aware lifting of multi-view optical flow features to 3D anchors.
- Transformer over anchors for scene-level motion context.
- Exponential-distance KNN interpolation from anchors to Gaussians.
- Key-frame-guided streaming to avoid candidate-frame error accumulation.
- Max-points-bounded densification for streaming storage control.
- Offline generalized network + online keyframe refinement hybrid.

## 12. Gap / Idea Seeds

- Add recurrent or temporal-attention state to AGM-Net to reduce jitter.
- Predict scale/opacity/color residuals for candidate frames with confidence gating.
- Adaptive key-frame selection based on motion magnitude or prediction uncertainty instead of fixed $w$.
- Replace optical-flow backbone with event/RGB motion features for high-speed scenes.
- Distill key-frame refinement into a second feed-forward update head to further reduce latency.

## 13. Human Check List

- NEED_HUMAN_CHECK: Implementation hyperparameters after learning-rate description are truncated in extracted text; consult PDF/code for exact LR schedule.
- NEED_HUMAN_CHECK: Some result tables before the ablation section are missing from extracted text; note uses visible Figure 1 and Table 4 claims.
- NEED_HUMAN_CHECK: Venue/year inferred from CVPR open-access watermark and Zotero date 2025.

## 14. Evidence Anchors

- Abstract and Figure 1: 2.67s/frame, 204 FPS, quality/speed/storage claims.
- Section 3.3: AGM-Net, anchor sampling, projection-aware feature lift and motion decode.
- Section 3.4: key-frame-guided streaming and max-points-bounded refinement.
- Section 3.5: view synthesis loss for AGM-Net and key-frame optimization.
- Section 4.1-4.3: datasets, AGM-Net settings and streaming setup.
- Table 4: key-frame interval ablation.
- Section 6: independent per-frame reconstruction time and jitter limitation.
