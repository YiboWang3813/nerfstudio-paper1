# SplineGS: Learning Smooth Trajectories in Gaussian Splatting for Dynamic Scene Reconstruction

## 0. Metadata

- Title: SplineGS: Learning Smooth Trajectories in Gaussian Splatting for Dynamic Scene Reconstruction
- Authors: Jihwan Yoon; Sangbeom Han; Jaeseok Oh; Minsik Lee
- Venue/Year: ICLR 2025
- Zotero item key: `WF85HVEX`
- Zotero PDF attachment key: `PACUAF2A`
- PDF path: `/Users/wangyibo/Zotero/storage/PACUAF2A/Yoon 等 - 2025 - SPLINEGS LEARNING SMOOTH TRAJECTORIES IN GAUSSIAN SPLATTING FOR DYNAMIC SCENE RE- CONSTRUCTION.pdf`
- Local note path: `notes/SplineGS: Learning Smooth Trajectories in Gaussian Splatting for Dynamic Scene Reconstruction.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

SplineGS 用 NURBS 学习一组 representative position/rotation trajectories，并让每个 Gaussian 的轨迹成为这些代表轨迹的 hash-MLP 权重线性组合，从结构上同时注入 temporal smoothness 和 spatial smoothness，避免额外 trajectory regularizer。

## 2. Problem Formulation

动态 3DGS 的关键在于如何表示 Gaussian blobs 的随时间 deformation。MLP deformation field 有表达灵活性，但缺少明确的时空运动 inductive bias，常需要额外 smoothness regularizer 或复杂训练策略。直接优化 4D Gaussians 又提高维度，可能导致 floating artifacts 和长训练时间。

SplineGS 的目标是用显式且平滑的 trajectory representation 替代普通神经 deformation。它希望轨迹在时间上天然连续，在空间邻近 Gaussians 之间也平滑，同时保持训练效率。

方法只建模 Gaussian position 和 rotation 的 deformation，不建模 scale、color、density 的时间变化。这是有意选择，用来避免额外自由度带来的过拟合和优化不稳定。

## 3. Method Overview

SplineGS 在原始 3DGS 上加入 spline deformation module。它不为每个 Gaussian 单独学习一条 NURBS 轨迹，而是学习 $L$ 条 representative trajectories。每条 representative trajectory 分别包含 position NURBS 和 rotation NURBS。

对每个 Gaussian，根据其 canonical position $\mu_j$ 查询 multi-resolution hash table，再经 MLP 输出组合权重 $\beta_j\in[-1,1]^L$。该 Gaussian 在时间 $t$ 的 position offset 和 rotation offset 由 $L$ 条 representative trajectories 加权求和得到。Position offsets 在 3D 空间直接加权；rotation offsets 先在 axis-angle 空间加权，再转换成 quaternion。

NURBS 本身提供 temporal smoothness；共享 representative trajectories 加 linear combination 提供 spatial smoothness；因此方法不需要显式 trajectory smoothness regularizer。优化目标只包含 reconstruction loss 和 opacity sparsity。

## 4. Method Details

### 4.1 B-Spline Basis

B-spline 由 knots $t_0,t_1,\ldots,t_{p+M+1}$、degree $p$ 和 $M$ 个 control points 定义。$p=0$ 时 basis function 为：

$$
B_{i,0}(t)=
\begin{cases}
1,& t_i\le t<t_{i+1},\\
0,& \mathrm{otherwise}.
\end{cases}
$$

高阶 basis 由 Cox-de Boor recursion 给出：

$$
B_{i,p}(t)=\frac{t-t_i}{t_{i+p}-t_i}B_{i,p-1}(t)+
\frac{t_{i+p+1}-t}{t_{i+p+1}-t_{i+1}}B_{i+1,p-1}(t).
$$

B-spline curve 是 control points 的 basis-weighted sum：

$$
S(t,P)=\sum_{i=0}^{n}B_{i,p}(t)P_i.
$$

### 4.2 NURBS Trajectory

NURBS 在 B-spline 基础上为每个 control point 加权重 $w_i$：

$$
S(t,w,P)=\frac{\sum_{i=0}^{M}B_{i,p}(t)w_iP_i}{\sum_{i=0}^{M}B_{i,p}(t)w_i}.
$$

当 $w_i$ 全相同时等价于普通 B-spline；非均匀权重允许更细粒度调整局部曲线。SplineGS 将 NURBS 表示为相对 canonical position / rotation 的 offset trajectory，而不是绝对 trajectory。

Degree $p$ 和 control point 数 $M$ 是超参数；knots 在整个时间范围内等间距设置。论文实验表明 $p=3$ 通常在平滑性、表达力和计算成本之间最佳。

### 4.3 Representative Trajectories

若为每个 Gaussian 独立学习 NURBS，内存和优化复杂度都高，也不能保证空间邻近轨迹平滑。SplineGS 因此学习少量 representative trajectories，并让每个 Gaussian 用加权组合得到自己的 trajectory。

每个 representative trajectory $k$ 包含 position control points $P_k^{\mathrm{pos}}\in\mathbb{R}^{M\times3}$、rotation control points $P_k^{\mathrm{rot}}\in\mathbb{R}^{M\times3}$ 和 NURBS weights $w_k\in\mathbb{R}^M$。这些参数都是 learnable。

### 4.4 Hash-MLP Combination Weights

对第 $j$ 个 Gaussian，用其 canonical center $\mu_j$ 查询 hash table，再经 MLP 输出权重：

$$
\beta_j=\tanh(\mathrm{MLP}(\mathrm{Hash}(\mu_j))).
$$

$\beta_j\in\mathbb{R}^L$，范围被 $\tanh$ 限制在 $[-1,1]$。这种 spatial-keyed weight field 让空间相近 Gaussians 倾向于拥有相近组合权重，从而隐式实现 spatial smoothness。方法不使用 KNN 或 kernel regression，避免额外复杂度。

### 4.5 Position and Rotation Deformation

Position offset 由 representative position trajectories 加权：

$$
\Delta\mu_j(t)=\sum_{k=0}^{L-1}\beta_{j,k}\cdot S(t,w_k,P_k^{\mathrm{pos}}).
$$

Rotation offset 先在 axis-angle 表示中加权，再转换成 quaternion：

$$
\Delta R_j(t)=Q\left(\sum_{k=0}^{L-1}\beta_{j,k}\cdot S(t,w_k,P_k^{\mathrm{rot}})\right).
$$

最终 position 和 rotation 为：

$$
\mu_j(t)=\mu_j+\Delta\mu_j(t).
$$

$$
R_j(t)=R_j\cdot\Delta R_j(t).
$$

这里 $Q$ 是 axis-angle-to-quaternion conversion。Scale、opacity 和 SH color 保持静态参数，不随时间由 spline module 更新。

## 5. Mathematical Objectives and Losses

Reconstruction loss 沿用 3DGS 的 $L_1$ 与 D-SSIM：

$$
L_{\mathrm{recon}}=(1-\lambda)L_1+\lambda L_{\mathrm{D-SSIM}}.
$$

为减少复杂真实场景中无用 Gaussians 和 floating artifacts，SplineGS 对 opacity 加 $L_1$ sparsity：

$$
L=L_{\mathrm{recon}}+\lambda_o\sum_{j=1}^{N}|o_j|.
$$

没有额外 trajectory smoothness loss。论文强调 smoothness 来自 NURBS 和 representative trajectory combination 的结构本身。

## 6. Training and Inference Procedure

训练时同时优化 static Gaussian parameters、representative NURBS trajectory parameters、hash table 和 MLP。输入时间 $t$ 时，先计算所有 representative trajectories 在 $t$ 的 offset，再根据每个 Gaussian 的 $\beta_j$ 合成 individual deformation，并用 3DGS rasterizer 渲染。

D-NeRF 使用 800x800 分辨率，包含 8 个 synthetic monocular scenes。Neu3D 使用 half resolution 1352x1014，使用除 Flame Salmon 外的 5 个 scenes。D-NeRF 表中报告 40K 和 80K iterations；Neu3D 报告 20K 和 40K。

Representative trajectory 数 $L$ 在 D-NeRF/Neu3D per-scene attributes 中通常为 128，Mutant 和 Bouncing Balls 使用 64。D-NeRF 训练时间大致 28-42 分钟，FPS 133-263；Neu3D 训练约 50-67 分钟，FPS 62-84。

## 7. Experimental Setup and Results Summary

D-NeRF 平均结果：SplineGS 40K 为 PSNR 39.11、SSIM 0.9866；80K 为 39.44、0.9868。它接近 SC-GS 的 39.53 / 0.9906，并明显优于 4D-GS 的 34.06 / 0.9787、D-3DGS 的 38.50 / 0.9857。LPIPS 表中 SplineGS 平均 0.0080，优于 D-3DGS 0.0124、SC-GS 0.0119、4D-GS 0.0210。

Neu3D 平均结果：SplineGS 20K 为 PSNR 32.52、SSIM 0.9484；40K 为 32.60、0.9496。它略高于 STG 的 32.57 / 0.9740 和 4DGS 的 32.53，在 PSNR 上达到最佳或相近，但 SSIM 低于一些 baseline。论文强调其训练时间更短、渲染速度较高。

HyperNeRF vrig 上，SplineGS 在 3D Printer / Chicken / Broom 的 PSNR 为 21.97 / 29.13 / 20.56；与 4D-GS 的 22.10 / 28.70 / 22.00 和 D-3DGS 的 20.28 / 22.76 / 20.47 相比，表现可比但不是全面最好。论文指出 HyperNeRF camera poses 不够准确，需要额外 pose optimization。

消融显示，去掉 hash 改用 positional encoding、去掉 MLP 直接从 hash 输出权重、或去掉 NURBS 让 MLP 直接输出 trajectory values，通常都会降低性能，说明 hash+MLP spatial weights 和 NURBS temporal representation 都是必要组件。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 NURBS temporal trajectory、representative trajectory low-rank combination 和无需 smoothness regularizer 的快速训练。实际技术增量在于把 per-Gaussian deformation field 重参数化为“少数显式 smooth basis trajectories + per-Gaussian spatial weight field”。

与 MLP deformation methods 相比，SplineGS 的时序平滑来自 NURBS 基函数，而不是网络隐式学习或正则项。与 Fourier / polynomial basis 相比，NURBS 是局部支撑曲线，控制点局部变化不会影响全局 trajectory，更适合长序列或局部 motion。与 SC-GS 这类控制点方法相比，SplineGS 的空间共享发生在 trajectory basis weight field 上，不显式做 KNN warping。

## 9. Limitations / Assumptions

SplineGS 只建模 position 和 rotation deformation，不建模 scale variation。附录指出这会限制 jelly/smoke-like structures，但作者认为大多数物体局部近似刚性，scale modeling 反而容易过拟合。

方法不处理 color 和 density 的高频时变。现实动态场景中的光照、反射、对象出现/消失可能需要额外模型；论文把高阶 NURBS、Fourier series 或 wavelets 留作未来方向。

Representative trajectories 隐含低秩假设。如果场景中不同区域有大量独立复杂轨迹，有限 $L$ 可能不足。

HyperNeRF 上 pose 不准会影响性能，方法本身不包含 camera pose optimization。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Dynamic scene images with timestamps and poses |
| Output | Dynamic 3DGS with spline-based position/rotation deformation |
| Temporal model | NURBS representative trajectories |
| Spatial model | Hash-MLP weights $\beta_j$ from Gaussian position |
| Deformed attributes | Position $\mu$ and rotation $R$ |
| Static attributes | Scale, opacity, SH color |
| Loss | $L_1$ + D-SSIM reconstruction plus opacity sparsity |
| Strength | Smooth trajectories without explicit regularizer; fast training |
| Weakness | No scale/color/density dynamics; low-rank trajectory assumption |

## 11. Reusable Components

- NURBS trajectory basis for Gaussian motion.
- Representative trajectory dictionary shared across Gaussians.
- Hash-MLP spatial weight field for trajectory blending.
- Axis-angle blending then quaternion conversion for rotation offsets.
- Opacity sparsity to reduce floating Gaussians in spline deformation.
- Degree $p=3$ as a practical default for NURBS motion smoothness.
- Avoiding explicit trajectory smoothness loss by architectural bias.

## 12. Gap / Idea Seeds

- Add separate high-frequency modules for opacity/color changes while keeping spline geometry smooth.
- Use adaptive number of representative trajectories per scene or per region.
- Combine SplineGS with dynamic/static decomposition so static regions use zero trajectory weights.
- Add pose optimization for HyperNeRF-style real-world datasets.
- Explore wavelet/NURBS hybrid for local abrupt motion without losing smoothness.

## 13. Human Check List

- NEED_HUMAN_CHECK: Main Table 1 is partially truncated in extracted text; appendix Tables 5-9 provide detailed per-scene values used here.
- NEED_HUMAN_CHECK: Exact ablation Table 3/4 numeric values are not visible in extraction; note summarizes qualitative conclusions from visible text.
- NEED_HUMAN_CHECK: This note is for ICLR 2025 NURBS SplineGS, distinct from `SplineGS: Robust Motion-Adaptive Spline...` already processed earlier.

## 14. Evidence Anchors

- Abstract and Introduction: NURBS trajectories and representative trajectory blending.
- Section 3.2: B-spline and NURBS definitions.
- Section 3.3: hash-MLP weights and linear combination equations.
- Section 3.4: reconstruction and opacity sparsity losses.
- Appendix A-B: excluded scale variation and color/density discussion.
- Appendix Tables 5-9: D-NeRF, LPIPS, Neu3D, HyperNeRF and per-scene speed/blob results.
