---
title: "Free360: Layered Gaussian Splatting for Unbounded 360-Degree View Synthesis from Extremely Sparse and Unposed Views"
authors: "Chong Bao, Xiyu Zhang, Zehao Yu, Jiale Shi, Guofeng Zhang, Songyou Peng, Zhaopeng Cui"
year: 2025
venue: "CVPR 2025"
zotero_item_key: "5BKUYBTS"
pdf_attachment_key: "UBNC6AHV"
pdf_path: "/Users/wangyibo/Zotero/storage/UBNC6AHV/Zhang 等 - Free360 Layered Gaussian Splatting for Unbounded 360-Degree View Synthesis from Extremely Sparse an.pdf"
note_path: "notes/Free360: Layered Gaussian Splatting for Unbounded 360-Degree View Synthesis from Extremely Sparse and Unposed Views.md"
tags: ["3D Gaussian Splatting", "pose-free reconstruction", "sparse-view synthesis", "360-degree view synthesis", "unbounded scenes", "generative prior"]
---

## 0. 一句话总结

Free360 面向极端困难的 3-4 张无位姿输入、无界 360 度大场景重建：先用 DUSt3R 类 dense stereo 得到粗 pose 和点云，再把场景分为前景层和背景层做 layered Gaussian Splatting 与 layer-specific bootstrap optimization，最后迭代融合 3D 重建和视频扩散生成，并用 uncertainty-aware training 过滤生成视图中的不一致内容。

## 1. 问题与动机

无界 360 度 inward-facing 场景中，输入只有 3-4 张且无位姿时，传统 3DGS/NeRF sparse-view 方法很难工作。COLMAP 在低重叠下容易失败；DUSt3R/MASt3R 虽能估 pose 和点云，但在无界场景中深度跨度大、点云噪声多，直接初始化 3DGS 会产生 needle-like artifacts 和错误背景结构。

另一方面，视频扩散模型可以生成额外 novel views，但低重叠 360 场景超出其训练分布，生成图常出现 identity shift 和 multi-view inconsistency。Free360 的动机是把重建和生成互相约束：3DGS 提供一致条件给扩散模型，扩散模型提供额外观测给 3DGS。

## 2. 适用场景

该方法适合 unposed、extremely sparse、unbounded 360-degree scene reconstruction，例如 Mip-NeRF360 和 Tanks and Temples 中只给 3/4/6/9 张输入图的设置。

它适合低重叠大场景和需要完整 360 novel view synthesis 的场景，也能输出较完整的 surface reconstruction。它不适合不需要生成先验的简单 forward-facing 小场景，整体流程也比普通 3DGS 复杂得多。

## 3. 方法定位

Free360 是 pose-free sparse-view 360 NVS 框架，不是单纯的 3DGS 优化，也不是单纯的视频生成。它以 dense stereo reconstruction model 为初始几何/位姿来源，以 layered 2DGS/3DGS 为可优化表示，以 ViewCrafter 视频扩散模型为 generative prior。

相对 InstantSplat，它不直接相信 DUSt3R 点云，而是先 layer partition、bootstrap optimization 清理几何；相对 ViewCrafter，它不直接把生成视图当最终结果，而是用生成视图迭代增强 3DGS。

## 4. 核心创新

第一，提出 layered Gaussian-based representation。根据相机视锥交集和深度结构，把无界场景划分为 front layer 和 back layer，分别处理近处多视图可见内容与远处/背景内容。

第二，提出 layer-specific bootstrap optimization。front layer 用下采样点云初始化并通过 photometric、mask、normal、depth 约束清理噪声和补细节；back layer 则通过 depth inpainting 补不可见区域。

第三，提出 reconstruction-generation iterative fusion。用当前 3DGS 渲染作为已知视图条件，结合点云渲染条件，让视频扩散模型逐步生成新视图；再筛选可靠生成帧加入训练集，反过来更新 3DGS。

第四，提出 uncertainty-aware training。对同一 viewpoint 生成多次图像，估计 epistemic uncertainty，降低不一致生成内容对 3DGS 优化的影响，避免错误传播。

## 5. 方法细节

首先用 dense stereo reconstruction model 估计输入 sparse images 的 camera poses 和 initial point cloud。场景被划分为 front layer 和 back layer：front layer 是包含所有 camera frustums 交集区域的最小 bounding sphere 内部；back layer 是剩余区域。也可以基于单目深度精细标注前后层。

每一层 $i$ 独立建模为一组 Gaussian primitives：

$$
G_i=\{G_{i,k}\mid k=1,\dots,K\}
$$

每个 primitive 由 center $\mu_{i,k}$、scale $S_{i,k}$、rotation $R_{i,k}$ 和 SH color $c_{i,k}$ 表示。渲染时合并所有 layer 的 Gaussians，并执行一次 rasterization，以保证效率和抗锯齿。

front layer bootstrap optimization 对初始点云做 voxel-based uniform downsampling，voxel size 为 point cloud bounding box 的 1%-3%，避免把大量错误点初始化为 Gaussians。优化损失为：

$$
L_{bs}=L_c+\lambda_m L_m+\lambda_n L_n+\lambda_d L_d
$$

其中 $L_c$ 是输入图 photometric loss，$L_m$ 是 alpha map 与 layer mask 的 binary entropy loss，$L_n$ 是 rendered normal 与 monocular normal 的 cosine loss，$L_d$ 是 rendered depth 与 stereo depth 的 L1 loss。论文设 $\lambda_m=1.0$、$\lambda_n=0.25$、$\lambda_d=0.1$。

back layer 对输入视角不可见区域做 depth inpainting。作者采样若干 novel viewpoints，根据 back-layer point cloud 渲染 visibility mask，再用 ray-box intersection 估计 invisible pixels 的 depth，并向 back layer point cloud 添加新点。

iterative fusion 中，已知图像集合和位姿集合初始为输入 sparse views：$I_{known}=I_{input}$、$V_{known}=V_{input}$。每轮从输入 pose 采样起点并插值一段 sequential poses $V_{gen}=V_{known,gen}\cup V_{novel}$。已知相机用真实图或 GS-rendered images 作为生成条件，未知相机用全场景 point cloud rendering 作为条件，再由 ViewCrafter 生成 $I_{gen}=I_{known,gen}\cup I_{novel}$。

由于生成质量随离已知相机越远而降低，作者只选择距离已知 pose 最近的 $P'$ 个 novel frames 加入训练：

$$
I'_{novel},V'_{novel}=\arg\min_{I'_{novel},V'_{novel}}\sum_{v^{(p)}_{novel}\in V'_{novel}}\min_{v\in V_{known,gen}}\|v^{(p)}_{novel}-v\|
$$

uncertainty-aware training 中，对同一 viewpoint 生成多张图，包括未扰动和扰动 point cloud rendering 条件，计算生成图方差作为 epistemic uncertainty。最终训练 loss 为：

$$
L=u\cdot[\lambda_c(L_c+L_{lpips})+\lambda_mL_m+\lambda_nL_n+\lambda_{reg}L_{reg}]
$$

其中 $u$ 是 uncertainty map，$\lambda_m=1.0$、$\lambda_n=0.25$。$\lambda_c$ 随到输入 sparse views 的距离 $x$ 衰减：$\lambda_c=\max(0.5e^{-20x},0.05)$。训练时关闭 densification，避免基于不一致生成图的错误位置梯度继续 densify。

## 6. 实验设置

数据集包括 Mip-NeRF360 和 Tanks and Temples。Mip-NeRF360 选择 8/9 个场景，排除 DUSt3R 在 sparse views 下失败的 Flower，按 3DGS split 选择 3、6、9 views 作为输入。Tanks and Temples 使用 6 个 360 度 outdoor scenes，选择 4、6、9 views 作为输入，因为 3 views 不足以覆盖 360 场景。

对比方法包括 FSGS、InstantSplat、ZeroNVS、ViewCrafter。为公平，FSGS* 和 ZeroNVS* 使用同样来自 DUSt3R 的输入点云和相机位姿。评价 NVS 使用 PSNR、SSIM、LPIPS；surface reconstruction 在 Tanks and Temples 有 GT mesh 的 4 个场景上用 F1-score。

## 7. 主要结果

Mip-NeRF360 上，Free360 在 3-view 时达到 16.20 PSNR、0.378 SSIM、0.499 LPIPS，优于 ViewCrafter 的 15.63 PSNR 和 InstantSplat 的 14.10 PSNR。6-view 时达到 16.83 PSNR、0.397 SSIM、0.458 LPIPS；9-view 时达到 17.35 PSNR、0.423 SSIM、0.435 LPIPS，均为最佳。

Tanks and Temples 上，4-view 时 Free360 达到 14.69 PSNR、0.476 SSIM、0.409 LPIPS，显著优于 ViewCrafter 的 13.56 PSNR 和 InstantSplat 的 13.03 PSNR。6-view 时为 15.67 PSNR、0.523 SSIM、0.368 LPIPS；9-view 时为 16.73 PSNR、0.564 SSIM、0.328 LPIPS。

surface reconstruction 上，Tanks and Temples 四个场景平均 F1-score 中，2DGS 为 0.284/0.367/0.418（4/6/9 views），Free360 为 0.423/0.430/0.439，说明 layered bootstrap 和 iterative fusion 改善了不可见区域和背景几何。

## 8. 消融与分析

设计消融在 Mip-NeRF360 的 Bicycle 和 Garden 3-view 上进行。Baseline 为 16.16 PSNR、0.289 SSIM、0.532 LPIPS；加入 multi-layer 后为 16.56 PSNR；加入 bootstrap optimization 后为 16.65；加入 iterative fusion 后为 16.81；最终加入 uncertainty 后为 16.95 PSNR、0.321 SSIM、0.480 LPIPS。

定性结果显示，FSGS 和 InstantSplat 受 DUSt3R noisy point cloud 影响，有 foggy geometry 和 needle-like distorted Gaussians；ViewCrafter 直接生成视图会出现 split wheels、missing horse leg、sky stuck to foreground 等多视图不一致。Free360 通过 iterative fusion 和 uncertainty filtering 缓解这些错误。

iterative fusion 消融显示，没有迭代融合时，视频扩散模型在多个 viewpoint 的生成不一致；加入迭代融合后，扩散模型被更一致的 GS rendering 条件约束，生成视图质量和跨视角一致性都更好。

## 9. 与相关工作的关系

相对 FSGS/DNGaussian 等 sparse-view 3DGS，Free360 不假设已知 pose，也不局限 forward-facing；它处理的是无位姿、极稀疏、360、无界场景。

相对 InstantSplat，Free360 同样利用 DUSt3R 的 pose 和 point cloud，但不直接用 noisy point cloud 训练 3DGS，而是 layer partition + bootstrap optimization 清理和补全结构。

相对 ZeroNVS/ViewCrafter 等 generative NVS，Free360 不把生成图作为直接输出，而是把生成作为补充观测，并用 3DGS 的一致性反过来约束生成过程。

## 10. 优点

Free360 的优点是把无界 360 场景的空间歧义显式拆成前后层，避免近处结构和远处背景在一个统一优化中互相污染。front/back layer 的优化目标不同，符合可见性差异。

第二个优点是生成与重建互补。扩散模型负责补稀疏输入中缺失的 observations，3DGS 负责把生成视图压回多视图一致的 3D 表示。

第三个优点是能兼顾渲染和表面重建，F1-score 上也优于直接 2DGS。

## 11. 局限

方法依赖 DUSt3R/MASt3R 类 dense stereo model 的初始 pose 和 point cloud。虽然后续 bootstrap 可以修正噪声，但如果初始 pose/geometry 大范围失败，框架仍会受限。

另一个局限是流程复杂且计算成本较高：layer partition、bootstrap optimization、ViewCrafter 多轮生成、uncertainty estimation 和最终 3DGS training 都需要串联。生成模型的不确定性只能被过滤，不能保证生成内容真实。

## 12. 可复现要点

复现时先用 dense stereo model 估 pose 和点云，再做 front/back layer partition。front layer 必须先 downsample 初始化并开启 densification 做 bootstrap；back layer 要基于 visibility mask 和 ray-box intersection 补不可见区域。

iterative fusion 中，不要一次生成所有 novel views 后训练。应逐轮选择靠近 known poses 的可靠生成帧加入 $I_{known},V_{known}$，每轮都用更新后的 GS rendering 改善下一轮生成条件。训练 generated views 时要使用 uncertainty map，并关闭 densification。

## 13. 可能扩展

一个扩展是用更强的 pose-free Gaussian 模型替代 DUSt3R 初始化，减少初始点云噪声和尺度错误。另一个扩展是把 layer 数从 front/back 两层扩展为多深度层或对象/背景层，进一步处理复杂遮挡。

第三个扩展是把 uncertainty-aware training 与生成模型采样策略耦合，让扩散模型主动重采样高不确定区域，而不是只在 3DGS 训练阶段降权。

## 14. 个人理解

Free360 的关键价值在于把极稀疏 360 重建从“直接优化一个全局 Gaussian cloud”改成“先分层清理几何，再用生成补观测，再用 uncertainty 过滤生成错误”。这比单纯套 DUSt3R+3DGS 或 video diffusion 更稳。

这篇文章也说明，生成模型在 sparse-view 3DGS 中最好作为可筛选的观测来源，而不是直接当真值。只有当 3D reconstruction 和 generation 迭代互相约束，并且显式处理不确定性时，生成 prior 才能真正帮助 3D 一致重建。
