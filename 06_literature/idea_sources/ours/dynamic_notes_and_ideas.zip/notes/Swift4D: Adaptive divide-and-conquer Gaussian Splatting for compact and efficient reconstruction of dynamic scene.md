# Swift4D: Adaptive divide-and-conquer Gaussian Splatting for compact and efficient reconstruction of dynamic scene

## 0. Metadata

- Title: Swift4D: Adaptive divide-and-conquer Gaussian Splatting for compact and efficient reconstruction of dynamic scene
- Authors: Jiahao Wu; Rui Peng; Zhiyan Wang; Lu Xiao; Luyang Tang; Jinbo Yan; Kaiqiang Xiong; Ronggang Wang
- Venue/Year: ICLR 2025
- Zotero item key: `TIXL4SA6`
- Zotero PDF attachment key: `QUD79XZQ`
- PDF path: `/Users/wangyibo/Zotero/storage/QUD79XZQ/Wu 等 - 2025 - SWIFT4D ADAPTIVE DIVIDE-AND-CONQUER GAUSSIAN SPLATTING FOR COMPACT AND EFFICIENT RECONSTRUCTION OF.pdf`
- Local note path: `notes/Swift4D: Adaptive divide-and-conquer Gaussian Splatting for compact and efficient reconstruction of dynamic scene.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

Swift4D 用一个可学习 dynamic parameter $d$ 将 canonical Gaussians 分解为 static 和 dynamic primitives，只对 dynamic primitives 使用 compact multi-resolution 4D hash + multi-head MLP deformation，从而减少动态建模冗余、加速训练并降低存储。

## 2. Problem Formulation

很多动态 3DGS 方法对所有 Gaussians 一视同仁：不管背景静态点还是前景动态点，都进入 time-aware deformation 或 4D representation。这会带来三类问题。第一，静态点占多数，却消耗大量 hash/MLP capacity 和存储。第二，静态区域参与动态建模会干扰 deformation field，使动态区域更模糊。第三，训练时间和模型大小不必要地增加。

Swift4D 的基本假设是，动态场景中大部分 Gaussian primitives 实际是静态背景，不需要动态属性。只要能可靠地区分 dynamic 和 static points，就可以把动态建模集中在少数点上，改善效率和质量。

输入是多视角动态视频，输出是可实时渲染的 dynamic 3DGS representation。方法当前不支持 monocular dynamic reconstruction，也不面向 human-specific reconstruction。

## 3. Method Overview

Swift4D 是三阶段 pipeline。第一阶段，用每个视角的 first-frame images 训练 canonical 3D Gaussians，得到稳定 canonical point cloud。第二阶段，为每个 Gaussian 加入 learnable dynamic parameter $d$，用从训练视频生成的 2D dynamic-static masks 监督 $d$，把 Gaussians 分类为 static 或 dynamic。这个阶段通常 1 分钟内完成。

第三阶段，冻结 $d$，只对 dynamic Gaussians 查询 compact 4D multi-resolution hash $h_{4d}$ 和 MLP deformation decoders，预测 mean、scale、rotation、opacity、SH 的 residual deformation；static Gaussians 保持时不变。最后把 static Gaussians 和 deformed dynamic Gaussians 混合，用标准 Gaussian splatting 渲染。

为减少 canonical/deformation field 耦合导致的 floaters，Swift4D 还提出 temporal importance pruning。Lite version 移除 SSIM loss 并缩小 hash table，使模型平均约 30 MB，其中 Gaussian point cloud 约 22 MB、hash table 约 8 MB。

## 4. Method Details

### 4.1 First-Frame Canonical Initialization

Swift4D 先用 first frame images from each viewpoint 训练一组 canonical 3D Gaussians。每个 Gaussian 基本参数为 $G=\{\mu,q,s,\sigma,c,d\}$，其中 $d$ 是后续用于 dynamic-static decomposition 的新增参数，初始化为 0。

这种初始化让 canonical space 更接近静态/初始状态，避免从随机点云直接学习动态分解。

### 4.2 Dynamic-Static Pixel Mask

对每个训练视角，Swift4D 根据像素随时间的 intensity 标准差生成 2D dynamic-static mask。像素 $x$ 的 temporal std 为：

$$
S(x)=\sqrt{\frac{1}{T}\sum_{t=1}^{T}\left(C(x,t)-\frac{1}{T}\sum_{t=1}^{T}C(x,t)\right)^2}.
$$

再用阈值 $\gamma=0.02$ 二值化：

$$
D(x)=
\begin{cases}
1,& S(x)\ge \gamma,\\
0,& S(x)<\gamma.
\end{cases}
$$

附录中还提到对 variance map 使用 31x31 Gaussian filter 平滑，以减少噪声。

### 4.3 Learnable Dynamic Parameter Rendering

Swift4D 不是直接用 mask 反投影分类 3D points，而是把每个 Gaussian 的 $d_i$ 像 color / opacity 一样用 alpha compositing 渲染成 dynamic value map：

$$
\hat D(x)=\mathrm{Sigmoid}\left(\sum_i d_i\alpha_i(x)\prod_{j=1}^{i-1}(1-\alpha_j(x))\right).
$$

然后用 binary cross-entropy 优化：

$$
L_d=\mathbb{E}_x[-D(x)\log \hat D(x)-(1-D(x))\log(1-\hat D(x))].
$$

由于 $d$ 在 sigmoid 前可向 $-\infty$ 或 $+\infty$ 展开，静态/动态 differentiation 会变得更明确。最终，若 $d>\zeta$ 则 Gaussian 被归为 dynamic，否则为 static；默认 $\zeta=7.0$。论文称 $\zeta$ 从 3 到 9 对 PSNR 和 dynamic point ratio 影响不大。

这个设计也能一定程度处理 occlusion：同一个 Gaussian 如果在某视角被动态物体遮挡收到正梯度，但在其他视角落在静态区域收到更强负梯度，最终仍可归为静态。

### 4.4 4D Multi-Resolution Hash for Dynamic Points

只对 dynamic Gaussians 建模 temporal deformation。给定 dynamic Gaussian 的 canonical position $\mu$ 和 timestamp $t$，4D hash 在 $L$ 个 resolution levels 上查询 features：

$$
f_h=[h_{4d}(\mu,t;0),h_{4d}(\mu,t;1),\ldots,h_{4d}(\mu,t;L-1)]\in\mathbb{R}^{LF}.
$$

其中 $L$ 通常为 16。随后小 MLP $\phi_d$ 得到 deformation feature $f_d=\phi_d(f_h)$。因为 hash space 只服务于 dynamic points，而不是整场景，所需容量更小，训练也更快。

### 4.5 Multi-Head Gaussian Deformation Decoder

Swift4D 使用五个 shallow MLP heads 分别预测 mean、scale、rotation、opacity、color residuals：

$$
d\mu,ds,dq,d\sigma,d_{\mathrm{sh}}=\mathrm{MLPs}(f_d).
$$

动态 Gaussian 在时间 $t$ 的参数为：

$$
(\mu',r',q',\sigma',sh')=(\mu+d\mu,r+dr,q+dq,\sigma+d\sigma,sh+d_{\mathrm{sh}}).
$$

Static Gaussians 不经过 4D hash 和 deformation decoder，直接与 deformed dynamic Gaussians 混合渲染。

### 4.6 Temporal Importance Pruning

论文指出 dynamic-static decomposition 不完全时，某些静态背景可能被误分为 dynamic，并在 temporal deformation 中产生 floaters。Swift4D 因此提出 temporal importance pruning，替代简单 opacity reset。Figure 9 显示有/无 opacity reset 都可能有 artifact，而 importance pruning 渲染更干净。

抽取文本中 pruning 公式和 Tab. 3 周边被截断，因此这里只记录其作用：清理低 temporal importance 的动态 floaters，降低 canonical points 和 deformation field 的耦合错误。

## 5. Mathematical Objectives and Losses

Swift4D 有两个核心训练目标。第二阶段用 $L_d$ 训练 dynamic parameter，实现 dynamic-static binary classification。第三阶段联合优化 Gaussian attributes 和 spatio-temporal structure，用标准 image reconstruction losses。Lite version 移除 SSIM loss 以减少 Gaussian 数量和模型大小。

底层 3DGS rendering 仍为：

$$
C(x)=\sum_{i\in N(x)} c_i\alpha_i(x)\prod_{j=1}^{i-1}(1-\alpha_j(x)).
$$

其中：

$$
\alpha_i(x)=\sigma_i\exp\left(-\frac{1}{2}(x-\mu_i^{2D})^\top\Sigma_i'^{-1}(x-\mu_i^{2D})\right).
$$

分解阶段的 $d$ gradient 与 occlusion、self-opacity 和 depth order 相关。附录给出对 Gaussian $g$ 的梯度项，核心比例为 $\alpha'_g\prod_{j=1}^{g-1}(1-\alpha'_j)$，即越透明、越被前景遮挡，动态参数获得的梯度越弱。

## 6. Training and Inference Procedure

训练流程为三阶段。第一阶段用 SfM points 和 first-frame multi-view images 训练 canonical Gaussian points。第二阶段用 pixel-level dynamic-static masks 训练 $d$。第三阶段冻结 $d$，联合训练 Gaussian attributes、4D hash 和 deformation MLP heads。

主版本使用完整 loss 和较大 hash table；Lite version 去掉 SSIM loss，hash table size 设为 $2^{15}$，平均模型约 30 MB。论文曲线显示 5 分钟训练已可得到 competitive results，约 10 分钟 / 7000 iterations 达到高质量，完整训练继续提升细节。

推理时，先根据 $d>\zeta$ 把 Gaussians 分组。Static group 直接渲染；dynamic group 对每个 timestamp 查询 4D hash 和 MLP heads 得到 residual deformation；两组混合后 splat。NV3D 平均 FPS：Swift4D 约 125，Swift4D Lite 约 215。

## 7. Experimental Setup and Results Summary

主要结果在 Neural 3D Video / NV3D 上比较。Swift4D 平均 PSNR 32.23，高于 SpaceTimeGS 32.05、Real-Time4DGS 32.01、3DGStream 31.67、K-Planes 31.63、4DGS 31.15。Swift4D Lite 为 31.79，质量略低但更小更快。

NV3D per-scene 表中，Swift4D 在 Coffee Martini 29.13、Spinach 33.05、Cut Beef 33.80、Flame Salmon 29.75、Flame Steak 33.67、Sear Steak 33.98，mean 32.23。与 Real-Time4DGS mean 32.01 和 SpaceTimeGS mean 32.05 接近但略高。

ENeRF 数据集上，Swift4D 得到 PSNR 26.12、SSIM 0.911、LPIPS 0.070，优于 4K4D 的 25.815 / 0.898 / 0.147、ENeRF 的 25.452 / 0.809 / 0.273 和 KPlanes 的 21.310 / 0.735 / 0.454。

Basketball court 数据集上，Swift4D 为 PSNR 29.03、SSIM 0.933、LPIPS 0.187，高于 4DGS 的 27.87 / 0.921 / 0.191。论文也展示了 decomposition results 和 hierarchical rendering based on $d$。

效率方面，摘要称 Swift4D 比 prior SOTA training 快 20x，real-world datasets 最小存储约 30 MB。Figure 1 中 Swift4D FPS 125、Lite FPS 215，训练时间和模型大小在同类方法中更低。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 dynamic-static decomposition、compact 4D hash spatio-temporal structure 和 SOTA speed/storage/quality tradeoff。实际技术增量的关键是用 2D temporal variance masks 监督每个 Gaussian 的 learnable $d$，再把 4D modeling capacity 只花在 dynamic subset 上。

相对 4DGS / Deformable GS，Swift4D 不是让所有点都进 deformation field，而是显式排除静态点。相对需要外部分割模型的 dynamic/static 方法，Swift4D 的 mask 来自 pixel temporal variance，且 $d$ 通过 differentiable splatting 优化。相对 HexPlane/K-Planes 类全场景时空结构，它的 4D hash 只覆盖动态点，因此 hash footprint 可以很小。

这个方法更像一个可插拔工程策略：把动态建模资源集中到真正需要的 primitives，而不是追求更复杂的 deformation network。

## 9. Limitations / Assumptions

Dynamic-static decomposition 不完美。纹理弱的小运动区域可能被误判为 static；静态区域也可能因为影子或前景运动干扰被判为 dynamic。论文认为后者在视觉上有时合理，因为这些区域确实需要时间变化来解释输入。

方法依赖 multi-view scene reconstruction，目前不支持 monocular dynamic datasets，也不处理 human-specific reconstruction。

训练时间中约 40% 被 disk I/O 消耗，因为数据集接近 6000 images。论文指出如果消除 I/O overhead，可把高质量训练时间降到约 10 分钟。

Pruning 细节在主文本抽取中不完整，实际复现需要查看补充材料或代码。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Multi-view dynamic videos |
| Output | Mixed static Gaussians and deformed dynamic Gaussians |
| Decomposition signal | 2D temporal-variance dynamic-static masks |
| Learnable classifier | Per-Gaussian dynamic parameter $d$ rendered by alpha compositing |
| Dynamic model | Compact multi-resolution 4D hash + five MLP heads |
| Static model | Time-invariant canonical Gaussians |
| Pruning | Temporal importance pruning for dynamic floaters |
| Main benefit | Faster training, compact storage, less static/dynamic interference |
| Main limitation | Multi-view only; imperfect dynamic-static separation |

## 11. Reusable Components

- Per-Gaussian learnable dynamic score supervised by 2D temporal variance masks.
- Rendering dynamic score through alpha compositing for differentiable decomposition.
- Thresholded dynamic/static splitting before time-aware modeling.
- 4D hash restricted to dynamic primitives to reduce hash footprint.
- Five-head residual decoder for Gaussian attributes.
- Lite configuration: remove SSIM loss and shrink hash table for 30 MB models.
- Temporal importance pruning for deformation-induced floaters.

## 12. Gap / Idea Seeds

- Replace hard $d>\zeta$ splitting with soft compute allocation so uncertain points receive lightweight deformation.
- Use optical flow or segmentation priors to improve masks for textureless moving regions.
- Combine Swift4D decomposition with node-guided or spline-based dynamic models.
- Make dynamic/static labels temporally adaptive rather than fixed after stage 2.
- Stream images into GPU memory or cache features to remove the reported 40% disk I/O overhead.

## 13. Human Check List

- NEED_HUMAN_CHECK: Section 3.4 pruning formula and some Table 3 content are truncated in extracted text; note summarizes visible pruning behavior only.
- NEED_HUMAN_CHECK: Main experimental table beyond NV3D appendix table is partially absent; note uses visible Figure 1/Table 4/Table 5/Table 6 numbers.
- NEED_HUMAN_CHECK: The title capitalization in Zotero differs from PDF; note preserves Zotero title in filename and heading.

## 14. Evidence Anchors

- Abstract and Figure 1: speed/storage/quality claims and 30 MB Lite model.
- Figure 2: decomposition idea compared to NeRF and dynamic 3DGS deformation.
- Figure 3: three-stage Swift4D pipeline.
- Section 3.2 / Figure 4: dynamic parameter $d$, 2D masks and BCE decomposition.
- Section 3.3: 4D hash and multi-head deformation decoder.
- Section 5: decomposition failure modes, threshold robustness and training time discussion.
- Appendix A.1-A.2: implementation details, Lite version and $d$ gradient.
- Appendix Tables 4-6: NV3D, basketball court and ENeRF results.
