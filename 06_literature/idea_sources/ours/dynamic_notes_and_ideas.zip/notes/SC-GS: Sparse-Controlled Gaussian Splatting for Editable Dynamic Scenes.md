# SC-GS: Sparse-Controlled Gaussian Splatting for Editable Dynamic Scenes

## 0. Metadata

* Title: SC-GS: Sparse-Controlled Gaussian Splatting for Editable Dynamic Scenes
* Authors: Yi-Hua Huang; Yang-Tian Sun; Ziyi Yang; Xiaoyang Lyu; Yan-Pei Cao; Xiaojuan Qi
* Year: 2024
* Venue: CVPR 2024
* PDF source: `/Users/wangyibo/Zotero/storage/K22H65MK/Huang 等 - 2024 - SC-GS Sparse-Controlled Gaussian Splatting for Editable Dynamic Scenes.pdf`
* Local note path: `notes/SC-GS: Sparse-Controlled Gaussian Splatting for Editable Dynamic Scenes.md`
* Zotero item key: `E2QMZKYX`
* Zotero PDF attachment key: `K22H65MK`
* URL: https://openaccess.thecvf.com/content/CVPR2024/html/Huang_SC-GS_Sparse-Controlled_Gaussian_Splatting_for_Editable_Dynamic_Scenes_CVPR_2024_paper.html
* Code: Not specified in extracted PDF text
* Project page: Not specified
* Dataset link: Not specified
* Main task: monocular dynamic novel view synthesis and motion editing
* Domain: dynamic Gaussian Splatting; sparse control graph; deformation and editing
* Input: monocular dynamic video with estimated camera poses; canonical 3D Gaussians; learned sparse control points
* Output: dynamic novel-view renderings and edited motion renderings
* Main representation: dense canonical Gaussians for appearance/geometry plus sparse control points for motion bases
* Supervision type: per-scene photometric optimization from monocular video frames
* Core contribution in one sentence: 用约 512 个可学习 sparse control points 通过 deformation MLP 预测 6DoF 运动，再用 RBF 权重和 LBS 驱动约 100K 个 3D Gaussians，从而把外观/几何与运动解耦，并支持动态场景编辑。
* Note status: `complete`

## 1. 一句话技术摘要

这篇论文处理单目动态视频的新视角合成与运动编辑，通过在 canonical space 中学习 dense 3D Gaussians 和 sparse control points，并让控制点的 time-varying 6DoF transformations 经 RBF/LBS 插值驱动高斯变形；关键技术差异是用紧凑控制图约束运动场，而不是给每个 Gaussian 直接预测独立 deformation。

## 2. 问题形式化

### 2.1 任务

给定单目动态视频、相机位姿和训练帧，学习一个 canonical Gaussian scene 和一个时间相关 motion field，使模型能在任意训练时间 $t$ 和新视角下渲染图像，同时允许用户在 sparse control points 上施加编辑约束，生成 appearance-preserved edited motion。

### 2.2 表示拆分

SC-GS 明确把动态场景拆为两部分：

* appearance / geometry: dense canonical 3D Gaussians $G=\{G_j:\mu_j,q_j,s_j,\sigma_j,sh_j\}$；
* motion: sparse control points $P=\{(p_i,o_i)\}$ 及其 time-varying 6DoF transforms。

论文动机是：真实世界运动通常稀疏、空间连续、局部刚性；因此不需要每个 Gaussian 单独预测运动，可以用少量控制点作为 motion bases。

### 2.3 输入输出

* 输入: monocular dynamic video，camera poses，canonical Gaussian 初始化和控制点初始化。
* 输出: time-dependent warped Gaussians，渲染图像，以及基于控制点图的 motion editing 结果。
* 关键超参: 每个 Gaussian 使用 $K=4$ 个最近控制点；ARAP 轨迹构图中随机采样 $N_t=8$ 个时间步；控制点数量量级约 512，Gaussian 数量量级约 100K。
* 未明确项: 具体训练 iteration、learning rate、控制点初始分布、预训练 schedule 在 supplementary 中，正文抽取文本未给出。

## 3. 方法概览

SC-GS 的 pipeline 是：

1. 在 canonical space 中维护 3D Gaussians 和 sparse control points。
2. 用 deformation MLP $\Psi$ 输入 control point coordinate $p_i$ 和时间 $t$，输出该控制点的 rotation 与 translation。
3. 对每个 Gaussian，用 KNN 找 $K=4$ 个邻近控制点。
4. 用 learned RBF radius $o_i$ 计算 Gaussian 到控制点的 interpolation weights。
5. 用 Linear Blend Skinning 将控制点的 6DoF transforms 插值为 Gaussian 的 dense motion field。
6. 渲染 warped Gaussians，并用 photometric loss + ARAP loss 优化。
7. 训练中自适应 clone/prune 控制点以匹配局部 motion complexity。
8. 训练后把控制点轨迹构成 graph，用 ARAP graph deformation 做用户控制的 motion editing。

这个方法的核心不是 deformation MLP 本身，而是 MLP 只查询少数控制点，而不是查询每个 Gaussian。这样既降低 MLP query overhead，又给运动场加入局部刚性和低维 motion basis 的归纳偏置。

## 4. 方法细节

### 4.1 3DGS 预备公式

论文沿用 3DGS 的 Gaussian 表示。每个 Gaussian 有 center $\mu$ 和 covariance $\Sigma$，Eq. 1 为 $G(x)=e^{-\frac{1}{2}(x-\mu)^T\Sigma^{-1}(x-\mu)}$。

协方差分解为 $\Sigma=RSS^TR^T$，其中 $R$ 由 quaternion $q\in SO(3)$ 表示，$S$ 是三维 scale vector。每个 Gaussian 还包含 opacity $\sigma$ 与 spherical harmonics coefficients $sh$。

渲染时投影到 2D image plane，pixel color Eq. 2 为 $C(u)=\sum_{i\in N}T_i\alpha_i SH(sh_i,v_i)$，其中 $T_i=\prod_{j=1}^{i-1}(1-\alpha_j)$。Eq. 3 中 $\alpha_i=\sigma_i e^{-\frac{1}{2}(p-\mu'_i)^T\Sigma'_i(p-\mu'_i)}$。

### 4.2 Sparse control points

控制点集合为 $P=\{(p_i\in R^3,o_i\in R^+)\}_{i=1}^{N_p}$。其中：

* $p_i$: canonical space 中的可学习控制点坐标；
* $o_i$: RBF kernel 的可学习半径参数，控制该控制点对附近 Gaussian 的影响衰减；
* $N_p$: 控制点数量，显著少于 Gaussian 数量。

对每个控制点 $i$，模型学习时间相关的 6DoF transformation $[R_i^t|T_i^t]\in SE(3)$。但这些 transform 不是逐时间逐点直接优化，而是由 deformation MLP 查询得到。Eq. 4: $\Psi:(p_i,t)\rightarrow(R_i^t,T_i^t)$。

实现中 rotation 用 quaternion $r_i^t$ 表示，以提升优化稳定性并方便后续插值组合。

### 4.3 RBF 权重与 LBS 驱动 Gaussian

对每个 Gaussian $G_j$，在 canonical space 中用 KNN 找 $K=4$ 个邻近控制点 $p_k,k\in N_j$。控制点 $p_k$ 对 Gaussian $G_j$ 的权重用 Gaussian-kernel RBF 计算。Eq. 5: $w_{jk}=\hat{w}_{jk}/\sum_{k\in N_j}\hat{w}_{jk}$，其中 $\hat{w}_{jk}=\exp(-d_{jk}^2/(2o_k^2))$。

$d_{jk}$ 是 Gaussian center 和控制点的距离，$o_k$ 是控制点 learnable radius。由于 $o_k$ 可学习，控制点影响范围也随训练调整。

有了权重后，SC-GS 用 LBS 计算每个 Gaussian 在时间 $t$ 的 warped center 和 quaternion。Eq. 6: $\mu_j^t=\sum_{k\in N_j}w_{jk}(R_k^t(\mu_j-p_k)+p_k+T_k^t)$。

Eq. 7: $q_j^t=(\sum_{k\in N_j}w_{jk}r_k^t)\otimes q_j$。这里 $\otimes$ 表示 quaternion composition。

注意：Eq. 7 对 quaternion 做加权求和再 composition，实际实现需要 normalization 否则可能偏离单位四元数；正文未显式说明 normalization，标为 `NEED_HUMAN_CHECK`。

### 4.4 两阶段优化

SC-GS 的动态场景表示包括 canonical control points $P$、canonical Gaussians $G$ 和 deformation MLP $\Psi$。

训练稳定化策略：

1. 先固定 Gaussians $G$，预训练 $P$ 和 $\Psi$，让控制点/MLP 学到 coarse scene motion。
2. 再 joint optimization，联合优化 Gaussians、control points 和 MLP。

预训练细节正文说在 supplementary material 中，当前 PDF 未包含 supplementary，因此精确 schedule 是 `NEED_HUMAN_CHECK`。

### 4.5 ARAP loss

ARAP loss 用来约束 control points 的运动局部刚性。它不是直接在 Gaussian 上算，而是在控制点轨迹图上算。

先为控制点构图。对控制点 $p_i$，随机采样 $N_t=8$ 个时间步，计算 trajectory descriptor。Eq. 8 可概括为 $p_i^{traj}=\frac{1}{N_t}(p_i^{t_1}\oplus p_i^{t_2}\oplus\cdots\oplus p_i^{t_{N_t}})$。这里 $\oplus$ 是 vector concatenation。原文公式中 $\frac{1}{N_t}$ 和 concatenation 同时出现，尺度意义略不清，按“trajectory descriptor”理解即可。

基于 trajectory descriptor 做 ball query，得到局部邻域 $N_i^c$。随机采样两个时间 $t_1,t_2$，对邻域中的点估计刚体旋转 $\hat{R}_i$。Eq. 9: $\hat{R}_i=\arg\min_{R\in SO(3)}\sum_{k\in N_i^c}w_{ik}\|(p_i^{t_1}-p_k^{t_1})-R(p_i^{t_2}-p_k^{t_2})\|^2$。该问题用 SVD 求解。

Eq. 10 定义 $L_{arap}(p_i,t_1,t_2)=\sum_{k\in N_i^c}w_{ik}\|(p_i^{t_1}-p_k^{t_1})-\hat{R}_i(p_i^{t_2}-p_k^{t_2})\|^2$。

直观上，ARAP 惩罚局部控制点相对位移在两个时间之间不能由单个局部 rotation 解释的部分，减少 control-point motion 的非刚性撕裂。

### 4.6 总损失

渲染损失 $L_{render}$ 使用 rendered image 与 ground-truth reference image 之间的 $L_1$ 和 D-SSIM 组合，沿用 3DGS。

总目标在正文写为 Eq. after Sec. 4.3: $L=L_{render}+L_{arap}$。

论文没有在正文中给出 $L_1$ 与 D-SSIM 的权重，也没有给出 $L_{arap}$ 的权重。如果实际代码中有权重系数，应通过 supplementary / code 确认。

### 4.7 Adaptive control points

SC-GS 类比 3DGS 的 densification/pruning，为控制点设计自适应密度调整。

Prune criterion：对控制点 $p_i$，计算它对所有把它纳入 KNN 的 Gaussians 的 overall impact。记这些 Gaussians 集合为 $\tilde{N}_i$，则 $W_i=\sum_{j\in\tilde{N}_i}w_{ji}$。当 $W_i$ 接近 0 时，控制点几乎不影响任何 Gaussian，执行 prune。阈值正文未给出。

Clone criterion：对控制点 $p_k$，统计相关 Gaussians 的 position gradient norm。Eq. 11: $g_i=\sum_{j\in\tilde{N}_i}\tilde{w}_j\|\frac{dL}{d\mu_j}\|_2^2$，其中 $\tilde{w}_j=w_{ji}/\sum_{j\in\tilde{N}_k}w_{ji}$。较大的 $g_k$ 表示局部重建差，需要 clone。

Clone placement：Eq. 12 把新控制点放到相关 Gaussians 的期望位置，$p'_k=\sum_{j\in\tilde{N}_k}\tilde{w}_i\mu_j$，并复制 radius，$\sigma'_k=\sigma_k$。原文此处符号把 radius 写成 $\sigma_k$，但前文 radius 是 $o_i$；需要 `NEED_HUMAN_CHECK` 判断这是符号复用还是 PDF 抽取错位。

### 4.8 Motion editing

训练后，SC-GS 用控制点构建 graph。每个 vertex 是控制点 $p_i$，边基于 Eq. 8 的 trajectory descriptor 做 ball query 连接，edge weights 使用 Eq. 5 风格的 RBF 权重。

用户指定 handle points $\{h_l\}$ 后，在控制图上做 ARAP deformation。Eq. 13: $E(P')=\sum_{i=1}^{N_p}\sum_{j\in N_i}w_{ij}\|(p'_i-p'_j)-\hat{R}_i(p_i-p_j)\|^2$，约束条件是 $p'_l=h_l$ for $l\in H$。

求解后得到每个控制点的编辑 rotation $\hat{R}_i$ 和 translation $\hat{T}_i=p'_i-p_i$。编辑渲染时，只要用这些 deformed control point transforms 替换 Eq. 6 和 Eq. 7 的 transforms，即可驱动 Gaussians 到编辑后的 motion。这个设计使 motion editing 与训练时的 motion representation 同构。

## 5. 数学目标与损失

### 5.1 Rendering loss

正文只说明 $L_{render}$ 是 $L_1$ + D-SSIM 的组合。完整权重未报告。按 3DGS 常规，可能存在 $L=(1-\lambda)L_1+\lambda L_{DSSIM}$，但这是 `inferred`，不能视为本文显式公式。

### 5.2 ARAP loss

核心正则是控制点局部刚性：

* 输入: 两个随机时间 $t_1,t_2$ 的控制点位置；
* 图连接: 基于 trajectory descriptor 而不是单帧距离；
* 局部 rotation: 每个中心点 $i$ 解一个 weighted Procrustes / SVD；
* 惩罚: 邻域相对向量在两时间之间偏离局部刚体变换的残差。

### 5.3 Adaptive density criterion

控制点的 prune 和 clone 都依赖它对 dense Gaussians 的影响：

* impact 小: 删除；
* 对 high-gradient Gaussian 区域贡献大: 克隆并放到相关 Gaussians 的加权中心。

这相当于把 3DGS 的 density control 从 Gaussian appearance/geometry 扩展到 motion bases。

## 6. 训练与推理流程

### 6.1 训练流程

1. 初始化 canonical Gaussians 和 sparse control points。
2. 固定 Gaussians，预训练 control points $P$ 与 MLP $\Psi$ 来拟合 coarse motion。
3. 对每个训练 iteration，采样时间 $t$ 和相机视角。
4. 用 $\Psi(p_i,t)$ 得到每个控制点的 $R_i^t,T_i^t$。
5. 对每个 Gaussian 找 $K=4$ 邻近控制点，计算 RBF weights。
6. 用 Eq. 6-7 得到 warped Gaussian center 和 rotation。
7. 用 Gaussian rasterizer 渲染图像。
8. 用 $L_{render}+L_{arap}$ 反向传播，更新 $G,P,\Psi$。
9. 按 adaptive control point strategy prune / clone 控制点。

### 6.2 推理流程

给定时间 $t$ 和目标相机：

1. 查询控制点 transform。
2. 用 KNN/RBF/LBS 得到所有 Gaussians 的 warped pose。
3. 用 3DGS rasterizer 渲染。

推理仍需要 deformation MLP，但只对 sparse control points 查询，而不是对所有 Gaussians 查询。论文认为这降低了 MLP query overhead。

### 6.3 编辑流程

1. 计算每个控制点跨时间 trajectory descriptor。
2. 基于 trajectory 建 control graph。
3. 用户固定或拖动部分 handle points。
4. 求解 ARAP graph deformation 得到 edited control transforms。
5. 用 edited transforms 替换训练时 transforms，驱动 Gaussians 生成编辑后动态渲染。

## 7. 实验设置与结果

### 7.1 数据集与指标

D-NeRF:

* 8 个动态 scenes；
* 360-degree viewpoint setting；
* 实验分辨率 $400\times400$；
* 指标: PSNR、SSIM、LPIPS(VGG)。

NeRF-DS:

* 7 个 captured videos；
* camera pose 由 COLMAP 估计；
* 包含 rigid 和 non-rigid deformation，以及 specular dynamic objects；
* 指标: PSNR、MS-SSIM、LPIPS(Alex)。

### 7.2 D-NeRF 主结果

Table 1 中 SC-GS 在 D-NeRF 平均 PSNR 43.31，SSIM 0.997，LPIPS 0.0063。对比：

* D-NeRF: PSNR 31.69，SSIM 0.975，LPIPS 0.0575；
* TiNeuVox-B: 33.76，0.983，0.0441；
* K-Planes: 32.32，0.973，0.0382；
* 4D-GS: 34.01，0.987，0.0316；
* per-Gaussian deformation MLP baseline: 38.51，0.992，0.0162。

结论：control points 不只是减少计算，还提升优化质量。直接给每个 Gaussian 用 MLP 预测 transform 更灵活，但轨迹噪声大，容易落入 local minima。

### 7.3 NeRF-DS 主结果

Table 2 中 SC-GS 平均 PSNR 24.1，MS-SSIM 0.891，LPIPS 0.140。对比：

* HyperNeRF: 22.5，0.827，0.206；
* NeRF-DS: 23.9，0.898，0.127；
* TiNeuVox-B: 21.5，0.843，0.162；
* baseline: 23.7，0.891，0.151。

SC-GS 平均 PSNR 最好，但 MS-SSIM 和 LPIPS 不总是最好。论文解释 NeRF-DS 对 specular parts 有 specialized design，因此在部分场景上会超过 SC-GS。

### 7.4 消融

Table 3 在 D-NeRF 上验证 control points 和 ARAP loss：

* w/o Control Points: PSNR 38.512，SSIM 0.9922，LPIPS 0.0162；
* w/o ARAP loss: PSNR 42.617，SSIM 0.9963，LPIPS 0.0067；
* Full: PSNR 43.307，SSIM 0.9976，LPIPS 0.0063。

解释：

* 移除 control points 后，Gaussian 轨迹更噪，优化更容易陷入 local minima；
* 移除 ARAP 后，控制点运动整体仍平滑，但局部刚性可能破裂，例如手臂点向躯干移动。

### 7.5 Motion editing

Figure 5 展示 reconstructed motion 与 edited motion。论文强调控制点图能支持训练序列之外的运动，因为 Gaussian-control weight 关系给了 out-of-sequence deformation 的局部刚性约束。

### 7.6 速度信息

正文多次声称 high rendering speed，并说 rendering speed comparison 在 supplementary material 中。当前 PDF 未包含速度表，因此 exact FPS 是 `NEED_HUMAN_CHECK`。

## 8. 声称贡献 vs 实际技术增量

### 8.1 论文声称

论文声称贡献包括：

* sparse control points + MLP 建模 scene motion；
* adaptive learning strategy 和 ARAP rigid regularization；
* sparse motion representation 支持 motion editing；
* 在 D-NeRF 和 NeRF-DS 上达到 SOTA 或更好质量。

### 8.2 实际技术增量

实际技术增量可概括为：把动态 GS 的 per-Gaussian deformation field 换成 sparse embedded deformation graph。这个控制图由 MLP 产生 time-varying SE(3) transforms，再通过 RBF/LBS 传播到 dense Gaussians。

与 Deformable 3D Gaussians / 4D-GS 类工作相比：

* 不是每个 Gaussian 查询 MLP；
* 不是把时间维直接编码进每个 Gaussian；
* 明确保留 control graph，因此可以做用户编辑；
* ARAP 提供局部刚性先验，减少无结构 Gaussian trajectory noise。

### 8.3 证据强度

证据强的部分：

* D-NeRF 上大幅超过 per-Gaussian MLP baseline；
* Table 3 直接消融 control points 和 ARAP；
* Fig. 6 可视化轨迹噪声和 ARAP 约束效果；
* Fig. 5 展示编辑可行性。

证据较弱的部分：

* 速度表不在正文，exact FPS 不可从当前 PDF 复核；
* NeRF-DS 上优势不全面，LPIPS / MS-SSIM 不一定优于 NeRF-DS；
* 预训练和 adaptive density 的实现细节缺失于 supplementary；
* motion editing 主要是定性展示，缺少编辑稳定性和用户控制误差的定量评价。

## 9. 局限与隐藏假设

显式局限：

1. 对 camera pose 不准确敏感；HyperNeRF 这类 pose 不准的数据会导致 reconstruction failure。
2. 对 common specular effects 处理不足，导致 NeRF-DS 上提升有限；作者建议结合 Spec-Gaussian。
3. 动态物体视频 blur 未处理；作者建议结合 deblurring techniques。

隐藏假设：

* 单目输入仍依赖较可靠 COLMAP poses。
* 控制点图的局部刚性假设适合 articulated / smooth non-rigid motion，但对拓扑突变、流体、烟雾可能不够。
* 约 512 个控制点是经验量级，不一定适合所有 scene complexity。
* 编辑效果依赖 control graph 的 trajectory-based connectivity；如果训练 motion 错，编辑图也会错。
* Appearance 与 motion 的解耦并不等于物理因果解耦；specular/highlight 仍可能被运动模型错误吸收。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法名称 | SC-GS |
| 输入类型 | Monocular dynamic video |
| 核心表示 | Dense canonical Gaussians + sparse control points |
| 时间建模 | Deformation MLP queried on control points |
| Gaussian motion | RBF weights + Linear Blend Skinning |
| 控制点参数 | coordinate $p_i$ and radius $o_i$ |
| 每点邻居数 | $K=4$ control points per Gaussian |
| 正则 | ARAP local rigidity on control point graph |
| 密度控制 | control point prune by low impact; clone by high Gaussian gradient |
| 编辑能力 | user handles + ARAP graph deformation |
| 主数据集 | D-NeRF; NeRF-DS |
| 主优势 | 低维运动基减少轨迹噪声并支持编辑 |
| 主短板 | pose error、specular、blur、supplementary 缺失细节 |
| 与 4DGS 差异 | 不直接 per-Gaussian / per-time 建模，改用 sparse motion basis |

## 11. 对我的研究可复用组件

1. Sparse motion basis：用少量控制点驱动 dense Gaussians，适合放入 dynamic GS 方法矩阵中的“motion carrier”维度。
2. Learned RBF radius：控制点不仅位置可学习，影响半径也可学习，可用于自适应运动支撑域。
3. Trajectory-based control graph：基于完整运动轨迹连边，而不是单帧空间距离，避免跨物体错误连边。
4. ARAP on motion bases：局部刚性正则施加在控制点层，比施加在所有 Gaussians 上更省且更稳定。
5. Control-point density control：把 3DGS densification 思想迁移到 motion basis 层。
6. Editing-compatible representation：如果要做可编辑动态 GS，控制图比纯 deformation MLP 更容易接用户交互。

## 12. Gap and Idea Seeds

### 12.1 Gap: specular 与 motion 混淆

SC-GS 在 NeRF-DS 上受 specular effects 限制。可以研究把控制点运动、view-dependent appearance、specular residual 三者分离，避免高光被控制点错误解释成几何运动。

### 12.2 Gap: pose error robustness

论文承认 inaccurate camera poses 会导致失败。一个方向是 joint pose refinement + control graph regularization，或在 ARAP 中加入 pose uncertainty weighting。

### 12.3 Gap: 控制点数量自适应但缺少全局预算策略

clone/prune 是局部 criterion。可以加入 global motion-basis budget，使控制点数量在显存/速度约束下最优分配到高复杂运动区域。

### 12.4 Gap: 编辑定量评价不足

论文主要展示编辑图像。可以设计 motion editing benchmark：handle trajectory error、local rigidity violation、appearance preservation、temporal flicker 等指标。

### 12.5 Gap: 拓扑变化和新物体

控制图假设局部连续。对于出现/消失、分裂/合并、流体，trajectory graph 可能不稳。可研究 dynamic graph rewiring 或 object lifecycle-aware control points。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: 预训练 $P,\Psi$ 的具体 schedule 在 supplementary，当前 PDF 未包含。
* `NEED_HUMAN_CHECK`: rendering speed comparison 在 supplementary，正文没有 exact FPS。
* `NEED_HUMAN_CHECK`: code / project URL 未在 PDF 文本中抽到。
* `NEED_HUMAN_CHECK`: Eq. 7 quaternion weighted sum 是否做 normalization，需要看代码。
* `NEED_HUMAN_CHECK`: Eq. 12 中新控制点 radius 符号在抽取文本里写作 $\sigma'_k=\sigma_k$，与前文 radius $o_i$ 不一致，需要核对 PDF 或代码。
* `NEED_HUMAN_CHECK`: ARAP loss 和 rendering loss 在实际实现中是否有权重系数，正文只写 $L=L_{render}+L_{arap}$。

## 14. Evidence Anchors

* Abstract: motion/appearance decomposition into sparse control points and dense Gaussians；control points learn compact 6DoF transformation bases；supports motion editing。
* Figure 1: 输入 monocular dynamic video，输出 dynamic view synthesis 和 motion editing。
* Section 1 Introduction: 控制点约 512，相比 Gaussians 约 100K；动机是真实运动稀疏、空间连续、局部刚性。
* Section 2 Dynamic Gaussian Splatting: 对比 per-Gaussian deformation MLP、hexplanes、4D Gaussians；强调 sparse control points reduce MLP query overhead。
* Section 3 / Eq. 1-3: 3DGS Gaussian、alpha blending 和 opacity 公式。
* Section 4 / Figure 2: pipeline，MLP 查询 control point transforms，KNN 控制 Gaussian deformation，rendering loss backprop。
* Section 4.1 / Eq. 4: $\Psi:(p_i,t)\rightarrow(R_i^t,T_i^t)$。
* Section 4.2 / Eq. 5: Gaussian-kernel RBF interpolation weights。
* Section 4.2 / Eq. 6-7: LBS warped Gaussian center 和 quaternion。
* Section 4.3: first pre-train $P,\Psi$ with $G$ fixed；then joint optimization。
* Section 4.3 / Eq. 8-10: trajectory descriptor、local rotation solve、ARAP loss。
* Section 4.3 / Eq. 11-12: adaptive control point clone/prune。
* Section 5 / Eq. 13: motion editing 的 ARAP graph deformation energy。
* Section 6.1: D-NeRF、NeRF-DS、PSNR/SSIM/MS-SSIM/LPIPS。
* Section 6.2 / Table 1: D-NeRF average PSNR 43.31，baseline 38.51，4D-GS 34.01。
* Section 6.2 / Table 2: NeRF-DS average PSNR 24.1，MS-SSIM 0.891，LPIPS 0.140。
* Section 6.4 / Table 3: w/o control points、w/o ARAP、full 的消融。
* Figure 5: edited motion sequence qualitative result。
* Figure 6: no control points leads noisy Gaussian trajectories；no ARAP causes local rigidity failure。
* Section 7 Conclusion and Future Works: pose inaccuracy、specular effects、motion blur as limitations/future work。
