# Sparse Gaussian Splatting Idea Report

本文综合 `notes/` 下标题包含 `sparse` 的 34 篇笔记。这个集合比单纯 “sparse-view 3DGS” 更宽，既包含稀疏视角重建，也包含 sparse primitives、sparse pixels、sparse time-variant attributes、slice-based sparse volumetric reconstruction 和 sparse-controlled dynamic editing。报告先逐篇回顾，再总结技术主线，并给出 10 个可尝试的组合型 idea。

## 1. 逐篇回顾

| # | 论文 | 主要创新点 | 典型应用场景 |
|---:|---|---|---|
| 1 | MVPGS | 用 learning-based MVS 挖掘 multi-view priors，把稀疏输入转成更丰富的初始化、未见视角外观先验和几何约束。 | sparse-view 3DGS 初始化、少视角几何稳定化。 |
| 2 | Point Cloud Densification for 3DGS from Sparse Input Views | 用 DPT depth lift + SfM alignment + random point sampling 做 point cloud densification，并用 SAOVS side views 施加 DINO semantic 和 GAN 约束。 | sparse-view initialization、semantic side-view regularization。 |
| 3 | Free360 | 面向极少、无位姿、无界 360 场景，用 layered 3DGS 与 video diffusion 互相约束，解决低重叠和背景错误。 | unposed 360 NVS、旅游/街景少图重建。 |
| 4 | SC-GS: Sparse-Controlled Gaussian Splatting | 用 sparse control points 的 time-varying 6DoF transformations 通过 RBF/LBS 驱动 dense Gaussians，实现动态场景编辑。 | editable dynamic scenes、对象运动控制。 |
| 5 | NexusGS | 利用 epipolar geometry 和 optical flow 显式求 metric depth，生成 dense point cloud 初始化，减少单目深度尺度歧义。 | sparse-view 3DGS 几何初始化、低纹理深度恢复。 |
| 6 | MAtCha Gaussians | 把场景表面表示成 chart atlas，在 chart 上附着 2D Gaussian surfels，同时优化 geometry 和 photorealistic rendering。 | sparse-view geometry/mesh reconstruction、表面资产生成。 |
| 7 | 3D Gaussian Rendering Can Be Sparser | 学习 per-Gaussian 2D fragment truncation threshold，减少 rasterization fragments，而不是只剪 primitives。 | 3DGS 渲染加速、fragment-level pruning。 |
| 8 | From Sparse to Dense / STDLoc | 将 3DGS 扩展为 Feature Gaussian，先 sparse landmarks PnP 初定位，再 dense feature matching 精定位。 | camera relocalization、3DGS feature rendering。 |
| 9 | D$^2$GS | 根据 Gaussian depth 和 density 控制 dropout，并增强远场监督，避免统一 dropout 同时损伤欠拟合区域。 | sparse-view regularization、远近场平衡。 |
| 10 | TranSplat | 用 DDMT 的 depth-aware deformable matching 和 DepthAnythingV2 prior 改善 MVSplat 在低纹理、重复纹理和 non-overlap 区域的深度。 | feed-forward sparse multi-view 3DGS。 |
| 11 | DropGaussian | 训练期随机 drop Gaussians 并补偿 opacity，增加被遮挡/远场 Gaussians 的梯度，抑制 sparse-view 过拟合。 | plug-and-play sparse-view 3DGS regularization。 |
| 12 | DNGaussian++ | 用 hard/soft depth、global-local depth normalization、instance depth regularizer 和 depth-guided geometry reorganization 改善稀疏视角几何。 | 单目深度引导的 sparse-view 3DGS。 |
| 13 | MVSplat | 用 plane-sweep cost volume 显式匹配多视图特征，预测 depth 并反投影成 Gaussian centers，只用 RGB rendering loss 训练。 | generalizable two-view / sparse-view 3DGS。 |
| 14 | CoMapGS | 构建 covisibility map，用 MASt3R correspondences 和 monocular depth 增强初始化，并按 covisibility count 加权 proximity loss。 | sparse NVS、共视不足区域补强。 |
| 15 | No Pose at All / SPFSplat | 用共享 ViT 从 unposed sparse views 一次性预测 canonical Gaussians 和相对 pose，并用 reprojection loss 约束 center/pose。 | pose-free sparse-view 3DGS。 |
| 16 | Speedy-Splat | 用 SnugBox/AccuTile 精确 tile intersection，再用 Hessian-inspired primitive pruning，同步减少 sparse pixels 和 sparse primitives。 | 高 FPS 3DGS、移动端/实时渲染。 |
| 17 | CoR-GS | 同时训练两个 3DGS，用 point disagreement co-pruning 和 pseudo-view rendering disagreement co-regularization 正则化错误几何。 | depth-free sparse-view regularization、紧凑几何。 |
| 18 | Binocular-Guided 3DGS | 用 rendered depth 形成 binocular stereo consistency，把 translated view warp 回输入视图，并配合 opacity decay 清理高斯。 | prior-free sparse-view consistency。 |
| 19 | SU-RGS | 在 unconstrained illumination 下，用语义特征 pseudo-label 替代光度一致性，做 sparse-view relightable Gaussian Splatting。 | 少视角、未知光照、可重光照场景。 |
| 20 | Taming Video Diffusion Prior | 用 scene-grounding guidance 约束 camera-controlled video diffusion，并用 hole-aware trajectory 生成补充视图训练 3DGS。 | sparse inputs 下的外推和遮挡补全。 |
| 21 | No Pose, No Problem / NoPoSplat | 不显式先估 pose，直接在 canonical Gaussian space 中从 sparse unposed images 预测可渲染 3D 表示。 | 无位姿少图重建、SfM 失败场景。 |
| 22 | FreeSplatter | 直接预测 Gaussian maps，使同一显式表示既能渲染又能估计相机，面向 pose-free sparse reconstruction。 | pose-free feed-forward 3DGS。 |
| 23 | DropoutGS | 用 Random Dropout Regularization 降低有效复杂度，再用 Edge-aware Scale Scheduling 恢复细节。 | sparse-view anti-overfitting。 |
| 24 | EDGS | 用 sparse anchor-grid、time-mask MLP 和 RBF kernel 只对动态 anchors 查询 time-variant attributes。 | 高效 monocular dynamic 3DGS、静态区域防抖。 |
| 25 | Generative Sparse-View GS | 用 depth-conditioned diffusion、LoRA scene adaptation、pseudo-view generation 和 3D/4DGS 交替优化补少视角缺失信息。 | diffusion-aided sparse-view reconstruction。 |
| 26 | CoherentGS | 每输入像素一个 ray-constrained Gaussian，用 implicit decoder 预测 residual depth/opacity，并用 depth TV 与 flow correspondence 保持一致。 | 极少视角、needle/floater 抑制。 |
| 27 | S2Gaussian | 同时处理 sparse-view 和 low-resolution 输入，用 sparse-view super-resolution 3DGS 恢复高分辨率细节。 | 少视角低分辨率重建、超分 NVS。 |
| 28 | Quantifying and Alleviating Co-Adaptation | 用 dropout-rendering variance 量化 Gaussian co-adaptation，并用 Gaussian dropout 与 opacity noise 降低 alpha compositing 纠缠。 | sparse-view artifact regularization。 |
| 29 | SplatFields | 训练期用 tri-plane neural fields 预测 Gaussian attributes，引入 spatial bias；训练后丢弃 generator 保留普通 Gaussians。 | sparse 3D/4D reconstruction、spatially coherent splats。 |
| 30 | UniGS | 避免每视图独立 local Gaussians concat，学习 unitary 3D Gaussians，减少 ghosting 并允许灵活输入视图数。 | generalizable sparse-view 3DGS。 |
| 31 | GaussianPile | 用 focus-aware physical model 和 additive Gaussian piling 统一 slice-based volumetric reconstruction，利用 sparse Focus Gaussians 表示体数据。 | ABUS、光片显微镜等切片体重建。 |
| 32 | LoopSparseGS | 循环生成伪视角并重跑 SfM 增密点云，用 scale-consistent PGI depth + monocular depth 做 sliding-window alignment，并用 SFS 拆 oversized Gaussians。 | per-scene sparse-view 3DGS。 |
| 33 | RegGS | 用 optimal-transport MW2 distance 做 differentiable Sim(3) 3DGS registration，把 feed-forward local submaps 对齐到全局。 | unposed sparse-view registration。 |
| 34 | HiSplat | 用 hierarchical coarse-to-fine 3DGS 表示，先建结构骨架，再补细节，改善 generalizable sparse-view 单尺度缺陷。 | feed-forward sparse reconstruction、多尺度细节恢复。 |

## 2. 综合观察

这 34 篇工作可以分成六条技术主线。

第一条是几何初始化。MVS/MVSplat/TranSplat、DUSt3R/MASt3R、DPT/DNGaussian++、NexusGS、PCD、LoopSparseGS 都说明 sparse-view 3DGS 的关键瓶颈是 Gaussian centers。如果初始中心差，后续 densification 会放大错误。

第二条是正则化和抗过拟合。DropGaussian、DropoutGS、D$^2$GS、CoR-GS、CoherentGS、Binocular-Guided 3DGS、Co-adaptation 论文都在处理少视角下 alpha-compositing 过拟合和 floaters。它们的共同点是让训练视图之外也产生约束，或降低局部高斯之间的过强协同。

第三条是生成先验。Free360、Generative Sparse-View GS、Taming Video Diffusion Prior 用 diffusion/video diffusion 生成额外视图，但都必须处理多视角一致性和 hallucination。生成先验的价值在未知区域，风险在已知区域污染。

第四条是 pose-free / unposed。NoPoSplat、SPFSplat、FreeSplatter、RegGS、Free360 都在绕过或弱化 COLMAP。趋势是把 pose、geometry 和 Gaussians 联合估计，而不是先 pose 后重建。

第五条是 generalizable feed-forward。MVSplat、TranSplat、HiSplat、UniGS 等把 per-scene optimization 前移到大数据训练阶段，但仍受 depth matching、view overlap 和 fixed-scale Gaussian 表示限制。

第六条是效率和稀疏表示。Speedy-Splat、fragment pruning、EDGS、GaussianPile 说明 sparse 不只指输入视角少，也指渲染 fragments、time-variant attributes、体数据 primitives 的稀疏化。未来 sparse 3DGS 需要同时考虑数据稀疏、表示稀疏和计算稀疏。

## 3. 10 个可以尝试的组合型 Idea

### Idea 1: Confidence-gated Hybrid Initialization for Sparse 3DGS

组合来源：MVSplat/TranSplat 的 cost volume depth，DNGaussian++ 的 normalized monocular depth，NexusGS 的 epipolar metric depth，PCD/LoopSparseGS 的 point densification。

要做的是把多种 depth / point prior 统一成带 confidence 的 initialization pool。cost volume 匹配置信高的区域用 metric depth；non-overlap 区域用 monocular depth，但只作为弱初始化；epipolar/flow 一致区域给高权重；低置信点只进入候选池，需经过 co-regularization 或 photometric validation 才激活。

### Idea 2: Uncertainty-aware Diffusion View Augmentation

组合来源：Taming Video Diffusion Prior 的 scene-grounding guidance，Free360/GS-GS 的 diffusion pseudo views，CoR-GS 的 rendering disagreement，UA-4DGS 的 uncertainty gating。

要做的是不把所有生成视图都当监督，而是先用 3DGS uncertainty/disagreement/hole mask 找到外推和遮挡区域，再让 video diffusion 只补这些区域。生成图进入训练前还要过 cross-view consistency filter：同一 3D 点在多条生成轨迹中一致才作为强监督。

### Idea 3: Pose-free Feed-forward plus Per-scene Co-regularization

组合来源：NoPoSplat/SPFSplat/FreeSplatter 的 pose-free feed-forward，RegGS 的 3DGS registration，CoR-GS 的双模型 disagreement。

要做的是先用 feed-forward pose-free 模型输出 canonical/local Gaussians 和 coarse poses，再训练两套 per-scene refinement。两套模型之间的 point disagreement 用于发现 pose/geometry 不一致，RegGS-style registration 用于对齐 local submaps，最终保留一致且高置信的 Gaussians。

### Idea 4: Adaptive Dropout by Depth, Density, and Co-adaptation

组合来源：DropGaussian、DropoutGS、D$^2$GS、Quantifying Co-adaptation。

要做的是把 dropout rate 从全局 schedule 改为 per-Gaussian policy，由 depth、local density、dropout-rendering variance、opacity noise sensitivity 共同决定。近场高密度高 co-adaptation 区域强 dropout；远场低密度区域低 dropout 但增强监督；边缘高频区域使用 edge-aware scale schedule 恢复细节。

### Idea 5: Hierarchical Unitary Gaussian Decoder

组合来源：UniGS 的 unitary Gaussians，HiSplat 的 hierarchical representation，MAtCha 的 chart atlas，MVSplat/TranSplat 的 feed-forward depth。

要做的是构建 view-count-agnostic 的层级 unitary Gaussian 表示：coarse level 预测全局结构 Gaussians，中层对 chart/plane/segment 分配 Gaussians，fine level 只在边界和纹理区域生成局部 detail Gaussians。输入视图数增加时更新同一套 unitary Gaussians，而不是 concat per-view Gaussians。

### Idea 6: Semantic-illumination Robust Sparse Relightable GS

组合来源：SU-RGS 的 semantic feature pseudo-label，FMGS/GaussTR 的 foundation feature field，DNGaussian++ 的 depth normalization。

要做的是在 unconstrained illumination 的 sparse views 中，用 foundation semantic features 建立跨光照一致的 pseudo-label，同时用 normalized depth regularization 保持几何。外观分解为 albedo、illumination 和 view-dependent residual；semantic consistency 只约束 albedo/geometry，不强制不同光照下 RGB 一致。

### Idea 7: Sparse-view Super-resolution with Generated Consistency

组合来源：S2Gaussian 的 sparse-view SR，Taming Video Diffusion Prior 的 generated views，CoherentGS 的 flow correspondence，MAtCha 的 surface charts。

要做的是先在低分辨率 sparse views 上恢复 coherent geometry，再用生成式 SR/视频扩散生成高分辨率 pseudo views。监督不是逐像素硬拟合，而是通过 chart/surface correspondence、flow consistency 和 feature consistency 约束高频纹理，避免 2D SR 逐图不一致导致 3D 伪影。

### Idea 8: Fragment-aware Sparse-view Training

组合来源：3D Gaussian Rendering Can Be Sparser、Speedy-Splat、PUP、DropGaussian。

要做的是把 fragment count 纳入训练目标，而不是训练后才剪。每个 Gaussian 同时学习 geometry、opacity 和 screen-space truncation threshold；高不确定/低贡献 fragments 在训练期逐步降权。这样可以得到既适合 sparse-view 泛化、又适合部署的 compact splats。

### Idea 9: Focus-aware Sparse Volumetric Gaussian Splatting for Medical 3D

组合来源：GaussianPile 的 focus-aware physics，sparse-view 3DGS 的 point densification，Horseshoe/uncertainty 的 scale sparsity。

要做的是把 GaussianPile 的 slice physics 与 sparse-view uncertainty/pruning 结合，用物理 PSF 控制 axial support，用 posterior scale uncertainty 控制体素区域是否需要更多 Focus Gaussians。适合 ABUS、显微镜、CT/MRI sparse slices 等体数据。

### Idea 10: Dynamic Sparse Attributes for Sparse-view 4D Reconstruction

组合来源：EDGS 的 sparse time-variant attributes，SC-GS 的 sparse control points，SplatFields 的 neural spatial bias，UA-4DGS 的 uncertainty-aware dynamic densification。

要做的是少视角动态重建中不要让所有 Gaussians 都有独立 deformation。先用 sparse control/anchor graph 表示运动，再只对高 motion uncertainty 或高 residual 区域分配 time-variant attributes。静态背景使用 time-invariant Gaussians，动态对象用 RBF/control graph，遮挡区域用 uncertainty-gated densification。

## 4. 优先级建议

最快能做出实验的是 Idea 4、Idea 8 和 Idea 1：它们可以在现有 sparse-view 3DGS 训练管线上以 score/policy/initializer 的形式加入。

最适合写成方法论文的是 Idea 2、Idea 3、Idea 5 和 Idea 10：它们分别对应 diffusion augmentation、pose-free refinement、层级 feed-forward 表示和 sparse dynamic attributes，技术差异更鲜明。

最适合跨领域或应用落地的是 Idea 6、Idea 7 和 Idea 9：它们分别面向未知光照、低分辨率输入和医学/切片体重建，任务设定更具体，评估也更容易定义。
