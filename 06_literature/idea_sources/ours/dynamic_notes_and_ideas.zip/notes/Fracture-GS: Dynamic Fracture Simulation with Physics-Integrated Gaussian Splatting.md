# Fracture-GS: Dynamic Fracture Simulation with Physics-Integrated Gaussian Splatting

## 0. Metadata

- Title: Fracture-GS: Dynamic Fracture Simulation with Physics-Integrated Gaussian Splatting
- Authors: Xiaogang Wang; Hongyu Wu; Wenfeng Song; Kai Xu
- Venue/Year: ICLR 2026
- Zotero item key: `CH94EXYB`
- Zotero PDF attachment key: `49BQWMZJ`
- PDF path: `/Users/wangyibo/Zotero/storage/49BQWMZJ/Wang 等 - 2026 - FRACTURE-GS DYNAMIC FRACTURE SIMULATION WITH PHYSICS-INTEGRATED GAUSSIAN SPLATTING.pdf`
- Local note path: `notes/Fracture-GS: Dynamic Fracture Simulation with Physics-Integrated Gaussian Splatting.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

Fracture-GS 将 multi-view object reconstruction、增强版 Collision-MPM 和 fracture-aware 3D Gaussian rendering 连接成一个 fracture simulation pipeline，通过基于 normalized mass distribution 的动量守恒界面力消除 MPM 碰撞粘连，并用 hardening-aware fracture tracking 与 MVEE-based Gaussian optimization 渲染新暴露的断裂面。

## 2. Problem Formulation

现有 physics-integrated Gaussian 方法多处理弹性变形、流体或中等强度接触，对 extreme mechanical collisions 下的 fracture 不够稳健。典型问题有两个：第一，传统 MLS-MPM 在多体断裂碰撞中可能出现 non-physical adhesion，碎片粘在其他物体表面；第二，断裂后新暴露的内部表面缺少已训练 Gaussian attributes，直接渲染会产生断裂界面 artifact，或者需要后处理渲染器。

Fracture-GS 的任务不是从视频重建自然动态场景，而是从 multi-view images 重建初始碰撞对象，然后做物理驱动的 extreme collision / fracture simulation，并直接用 Gaussian splatting 可视化整个过程。目标是让 simulation 和 rendering 共享粒子/Gaussian 表示，使 fracture surface 可以在模拟中被追踪、生成和渲染。

输入是多视角对象图像；输出是 100-frame 级别的 fracture simulation sequence 和对应 Gaussian rendering。系统需要支持 homogeneous materials、heterogeneous composites 和 multi-body collisions。

## 3. Method Overview

Fracture-GS 有三阶段。第一阶段，从 multi-view images 通过 implicit reconstruction 得到 object SDF，在 SDF-constrained volume 内采样 surface particles 和 internal particles。Surface particles 通过 3D Gaussian splatting 学习 visual attributes，internal particles 用于物理离散化。

第二阶段，用增强版 Collision-MPM 模拟 extreme mechanical collision 和 dynamic fracture。与普通 MLS-MPM 不同，它对两个物体的 particle information 分别 P2G，在 grid node 上估计 normalized mass distributions 和 interface normal tendency，再根据 relative velocity 与 momentum conservation 计算 interface collision forces，从而减少碎片粘连。

第三阶段，使用 hardening-aware criterion 追踪 fracture particles。当内部 particles 因断裂暴露为可见表面时，Fracture Particle Gaussian Optimization (FPGO) 通过邻近外部 surface particles 和 MVEE-based interpolation 生成/优化 Gaussian attributes，使断裂面无需离线后处理也能渲染。

## 4. Method Details

### 4.1 Initial Reconstruction and Particle/Gaussian Setup

系统先从多视角图像重建对象 SDF，并在 SDF 内进行 voxelization 与采样。每个碰撞对象的 particles 包含 mass $m$、volume $V$、velocity gradient $C$、deformation gradient $F$、velocity $v$、position $x$ 和 elastoplastic parameters $\theta$。

$\theta$ 包括 Young's modulus $E$、Poisson's ratio $\nu$、hardening tracking parameters $\alpha$、cohesion coefficient $\beta$ 和 hardening factor $\xi$。不同材质组件可以设置不同参数，例如 ficus leaf、branch、pot，或者 table top 和 table leg。

Surface particles 同时承担 visual Gaussian kernels，初始使用 isotropic Gaussian reconstruction。Internal particles 主要用于 MPM simulation；当 fracture 发生并暴露内部区域时，再为相关 particles 生成 Gaussian attributes。

### 4.2 Baseline MLS-MPM Stages

论文以 MLS-MPM 为基础。Particle-to-grid 阶段把 particle mass 和 momentum 插值到 grid nodes：

$$
m_i^n=\sum_p w_{ip}^n m_p.
$$

$$
m_i^nv_i^n=\sum_p w_{ip}^n m_p\left(v_p^n+C_p^n(x_i-x_p^n)\right).
$$

Grid update 通过显式 Euler 解 momentum equation：

$$
m_i^n(v_i^{n+1}-v_i^n)=-\Delta t\cdot f_i^*+\Delta t\cdot f_i^{\mathrm{ext}}.
$$

Grid-to-particle 阶段把 updated grid velocity 插值回 particles，并更新 position：

$$
v_p^{n+1}=\sum_i w_{ip}^nv_i^{n+1},\quad x_p^{n+1}=x_p^n+\Delta t v_p^{n+1}.
$$

这些步骤提供 continuum mechanics 基础，但单独使用时在多体断裂接触中会产生粘连。

### 4.3 Collision-MPM Interface Direction

Fracture-GS 对两个物体 $P_a$ 和 $P_b$ 的粒子分别 transfer 到 grid。完成 P2G 和 grid update 后，在 grid node $G_i$ 上计算两个物体的 normalized mass distribution tendencies $\hat n_{ia}$ 和 $\hat n_{ib}$。抽取文本中的 Eq. 9-10 有符号重复问题，但核心是用 mass-weighted kernel gradients 估计每个物体在该 node 的局部分布方向。

Interface direction tendency 定义为：

$$
n_{ia}=-n_{ib}=\frac{\hat n_{ia}-\hat n_{ib}}{\|\hat n_{ia}-\hat n_{ib}\|}.
$$

这个方向可理解为接触界面的 normal direction tendency，用于决定 collision force 的方向。

### 4.4 Momentum-Conserving Collision Force

Collision force 只在 relative velocity 满足接触条件时启用。若 $(v_{ia}^{\mathrm{temp}}-v_{ib}^{\mathrm{temp}})\cdot n_{ia}>0$，则认为两个物体在 grid node 上需要碰撞响应。根据 momentum conservation，先计算 interface force：

$$
f_i^c=\frac{p_{ia}^{\mathrm{temp}}m_{ia}^n-p_{ib}^{\mathrm{temp}}m_{ib}^n}{(m_{ia}^n+m_{ib}^n)\Delta t}.
$$

再投影到 interface normal 并分配给两个物体：

$$
f_{ia}^c=-f_{ib}^c=\mu(f_i^c\cdot n_{ib})n_{ib}.
$$

然后更新两个物体在 grid node 上的 velocity：

$$
v_{ia}^{n+1}=v_{ia}^{\mathrm{temp}}+\frac{f_{ia}^c}{m_{ia}^n}\Delta t,\quad
v_{ib}^{n+1}=v_{ib}^{\mathrm{temp}}+\frac{f_{ib}^c}{m_{ib}^n}\Delta t.
$$

论文通过 bowl-teapot controlled experiment 显示 total momentum curve 在 collision interval 内保持常数，从而验证该 collision response 不引入非物理动量。

### 4.5 Fracture Tracking

Fracture-GS 使用 Wolper et al. 的 hardening-aware tracking criterion。Fracture particles 通过 hardening factor $\alpha$ 识别；当材料进入断裂或塑性演化区域，相关 internal particles 被标记为可能暴露的 fracture surface。

这种 tracking 有两个目的。第一，定位新暴露的内部 fracture surface，为其生成 visual Gaussian attributes。第二，过滤碰撞中产生的大量 isolated fine particles，避免它们都参与最终 rendering，从而保持物理和视觉合理性。

### 4.6 Fracture Particle Gaussian Optimization

FPGO 用来给 fracture particles 快速生成 Gaussian visual attributes。论文描述为基于相邻外部 surface particles 进行 interpolation，并使用 Minimal-Volume Enclosing Ellipsoid (MVEE) 优化新 Gaussian 的 shape / support，使断裂区域能获得合理的 covariance、opacity 和 appearance。

附录给出两个 spheres intersection 的 MVEE 估计方式。若两个球心为 $C_1,C_2$、半径为 $r_1,r_2$，距离 $d=\|C_1-C_2\|$，相交条件为：

$$
|r_1-r_2|<d<r_1+r_2.
$$

MVEE center 可近似为沿连接轴的加权点：

$$
c=C_1+\frac{r_1}{r_1+r_2}(C_2-C_1).
$$

主轴沿 $u=(C_2-C_1)/d$，major axis length 近似为 $a=r_1+r_2-d$，minor axes 来自交圆半径。这个过程为 fracture interface 上的 Gaussians 提供几何包围形状。

## 5. Mathematical Objectives and Losses

Fracture-GS 的核心 objective 不是一个端到端 image loss，而是 simulation equations + Gaussian attribute optimization。初始 surface Gaussian attributes 通过 splatting 从 multi-view images 学习；后续 fracture surface 的 attributes 通过 FPGO / MVEE interpolation 更新。

3DGS rendering 仍用 alpha compositing：

$$
C_i=\sum_{k\in I}\sigma_k c_k(d_i)\prod_{j=1}^{k-1}(1-\sigma_j).
$$

Simulation 部分遵循 MPM 的 mass/momentum transfer、stress update、collision response 和 fracture tracking。Collision-MPM 的关键数学目标是使界面 force 满足动量守恒，并避免 MLS-MPM 在多体接触中的 sticky artifact。

## 6. Training and Inference Procedure

预处理阶段：输入分辨率从 1024x1024 开始；每个碰撞对象采样 200,000 surface points 和 100,000 interior points。通过 SDF voxelization 找到 interior voxels，并在每个 voxel 内根据 density parameter $N_v$ 随机采样。

Gaussian 初始化阶段：对 surface particles 做 isotropic Gaussian reconstruction，学习可视 surface attributes。Simulation 阶段：基于 Warp 执行 MPM collision / fracture，生成 100-frame sequences。Rendering 阶段：每帧根据 particle positions 和 tracked fracture particles 更新/生成 Gaussian attributes，并用 splatting 渲染。

实现设备为 18-core Intel Xeon Gold 5220 CPU 和 NVIDIA RTX 3090 GPU。Fracture tracking 会增加 per-frame Gaussian rendering time：Ficus 从 49.19 ms 到 62.78 ms，Teapot 从 6.13 ms 到 10.87 ms，Teapot & Table 从 27.15 ms 到 29.85 ms。

## 7. Experimental Setup and Results Summary

实验覆盖单物体撞击刚性表面、多物体碰撞、heterogeneous material fracture 和 real-world DTU data validation。材料参数表包括 Bowl、Ficus leaf/branch/pot、Teapot、Table top/leg 的 $E$、$\nu$、density 和 NACC parameters。

物理评估方面，Figure 6 显示 Collision-MPM 相对 MLS-MPM 消除了 teapot-table collision 中 wood fragments 粘附到 teapot surface 的 artifact。Figure 7 显示无重力/无摩擦 bowl-teapot 对撞中 total momentum 保持常数。Figure 8 显示 teapot-table collision 前 50 帧的 kinetic、elastic、gravitational potential energy 有界，没有 non-physical energy blow-up。

渲染评估方面，论文将 Fracture-GS 与 PhyGaussian 和 GIC 对比。由于没有 ground-truth dynamic fracture sequence，附录采用 self-referencing protocol：取 fracture initiation 前最后一帧为 reference，对后续 5 帧计算 PSNR、LPIPS、FID，以衡量 fracture rendering 是否保持材料外观连续性。

采样密度分析显示 MPM 对 interior particle density 敏感。以 $N_v=200$ 为 convergence reference，$N_v=0/5/10/15/20/50/100$ 的 coordinate errors 逐步下降，例如 x-coordinate error 从 0.1998 降到 0.0935，z-coordinate error 从 0.0535 降到 0.0315，说明内部采样密度会影响 fracture pattern 和 collision dynamics。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是统一 physics-rendering framework、改进 Collision-MPM、动态 fracture tracking 和 fracture surface Gaussian reconstruction。实际技术增量主要有两个：一是把 interface collision force 加入 MPM grid update，用 normalized mass distribution 和动量守恒原则解决多体 fracture sticky artifact；二是把新暴露的 fracture particles 接入 Gaussian rendering，通过 FPGO/MVEE 生成 fracture-surface attributes。

相对 PhysGaussian，Fracture-GS 不只是把 3D Gaussians 当作 MPM particles 做变形，而是重点处理 fracture 后 surface topology / visibility 的变化。相对 GIC，它不只估计物理参数，而是面向 extreme collision simulation 和 dynamic fracture rendering。相对传统 MPM + Houdini 后处理，它直接在 simulation particles 上维护 Gaussian rendering。

## 9. Limitations / Assumptions

计算成本仍高，复杂场景无法实时 simulation。论文结论提到未来需要 GPU optimization 和 adaptive time-stepping。

材料参数需要手动设置。虽然表中给出不同材料的 $E$、$\nu$、density 和 NACC parameters，但自动参数估计仍是未来工作。

评价方法不够标准。由于缺少真实 fracture ground truth，PSNR/LPIPS/FID 使用 pre-fracture reference frame，属于折中指标，不能完全衡量物理真实性。

FPGO 对隐藏区域无法做真实 texture restoration。论文指出 hidden areas 的 Gaussian reconstruction 仍有限，未来可用 3D AI texture generative inpainting 改进。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Multi-view images of collision objects |
| Output | Fracture simulation sequence with Gaussian rendering |
| Reconstruction | SDF from multi-view images; surface and interior particle sampling |
| Simulation core | Enhanced Collision-MPM with interface forces |
| Fracture tracking | Hardening-aware particle tracking using $\alpha$ |
| Rendering core | Surface Gaussians plus FPGO-generated fracture Gaussians |
| Key fix | Reduces MLS-MPM non-physical adhesion in multi-body fracture |
| Evaluation | Momentum conservation, bounded energy, image metrics, sampling density |
| Strength | Handles extreme collisions and new fracture surfaces |
| Weakness | High compute, manual material parameters, imperfect hidden-surface texture |

## 11. Reusable Components

- Separate P2G for different colliding objects before interface force computation.
- Normalized mass distribution as grid-node contact normal tendency.
- Momentum-conserving collision force integrated into MPM grid update.
- Hardening-aware fracture particle tracking for Gaussian rendering.
- MVEE-based covariance/support generation for newly exposed fracture particles.
- Self-referencing fracture rendering evaluation when dynamic ground truth is absent.
- Interior particle density sweep as MPM convergence / sensitivity analysis.

## 12. Gap / Idea Seeds

- Learn material parameters from short observed fracture videos instead of manual tuning.
- Couple FPGO with generative texture inpainting for newly exposed hidden surfaces.
- Add adaptive particle refinement around crack fronts to reduce global sampling cost.
- Use differentiable Collision-MPM to calibrate collision force coefficient $\mu$ from data.
- Build a benchmark with real high-speed fracture ground truth to replace self-referencing metrics.

## 13. Human Check List

- NEED_HUMAN_CHECK: Section 3.2 after FPGO heading is truncated in extracted text; note summarizes FPGO from visible abstract, method overview, appendix MVEE and discussion.
- NEED_HUMAN_CHECK: Eq. 9-10 normalized mass distribution formulas appear symbol-corrupted/repeated in extraction; verify exact denominator and gradient notation from PDF.
- NEED_HUMAN_CHECK: Quantitative Figure 5 values for FPGO vs PhyGaussian/GIC are not visible in extracted text; note reports qualitative/metric protocol rather than exact numbers.
- NEED_HUMAN_CHECK: Venue/year taken from PDF header and Zotero metadata; confirm final citation if needed.

## 14. Evidence Anchors

- Abstract and Introduction: two core challenges, Collision-MPM and fracture-aware Gaussian representation.
- Figure 2 / Section 3: pipeline from SDF reconstruction to MPM simulation and FPGO rendering.
- Section 3.1: Collision-MPM mass distribution, interface tendency and collision force.
- Figure 3: mass distribution illustration and hardening-based fracture tracking.
- Figures 6-8: adhesion removal, momentum conservation and energy stability.
- Appendix A.1-A.2: material parameters, sampling and implementation setup.
- Appendix A.3-A.4: fracture assessment metrics and MVEE derivation.
- Appendix Table 2-3: fracture tracking rendering time and sampling density errors.
