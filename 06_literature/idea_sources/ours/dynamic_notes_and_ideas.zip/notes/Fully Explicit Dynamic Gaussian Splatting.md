# Fully Explicit Dynamic Gaussian Splatting

## 0. Metadata

* Title: Fully Explicit Dynamic Gaussian Splatting
* Authors: Junoh Lee; Changyeon Won; Hyunjun Jung; Inhwan Bae; Hae-Gon Jeon
* Year: 2024
* Venue: NeurIPS 2024
* PDF source: `/Users/wangyibo/Zotero/storage/LGA6YI78/Lee 等 - Fully Explicit Dynamic Gaussian Splatting.pdf`
* Local note path: `notes/Fully Explicit Dynamic Gaussian Splatting.md`
* Zotero item key: `VHFKWIA6`
* Zotero PDF attachment key: `LGA6YI78`
* Code: paper checklist says source code is provided in supplementary material; public URL is Not specified in extracted PDF text
* Project page: Not specified
* Dataset link: Not specified
* Main task: dynamic novel view synthesis / dynamic scene rendering
* Domain: multi-view dynamic scenes; Gaussian Splatting; explicit 4D representation
* Input: multi-view video frames, camera parameters, and COLMAP point cloud initialized only from the first frame in the main sparse setting
* Output: novel-view renderings at arbitrary observed timestamps, with static/dynamic Gaussian decomposition
* Main representation: static 3D Gaussians with linear motion plus dynamic 3D Gaussians represented by sparse temporal keyframes and interpolation
* Supervision type: per-scene photometric optimization from posed multi-view images
* Core contribution in one sentence: 将动态 3DGS 显式拆成静态线性运动点和动态关键帧插值点，并用 temporal opacity、progressive training、motion-based dynamic extraction 与 point backtracking 控制动态场景的存储和训练成本。
* Note status: `complete`

## 1. 一句话技术摘要

这篇论文处理多视角动态场景的新视角合成问题，通过把 3D Gaussians 显式分成静态点和动态点，并只在动态点上存储稀疏关键帧位置、旋转和时间透明度，再用 CHip、Slerp 与双高斯式 opacity 插值得到连续时间渲染；关键技术差异是避免 MLP/4D feature 编码，把时间建模保留为可直接存储、可插值、可裁剪的显式参数。

## 2. 问题形式化

### 2.1 任务

给定动态场景的多视角视频和相机参数，学习一个可在时间 $t$ 与视角 $v$ 下渲染图像 $\hat{I}_{v,t}$ 的显式 4D Gaussian 表示。

论文特别强调 sparse COLMAP 初始化：主设置只使用第一帧产生的 COLMAP point cloud，而不是每个时间帧的 dense point clouds。这使问题更接近真实视频预处理受限场景，也使新出现物体和快速运动更难处理。

### 2.2 输入与输出

* 输入图像: 多机位同步视频；Neural 3D Video 有 18 到 21 个相机、300 帧、原始分辨率 $2704 \times 2028$，训练和评估使用半分辨率。
* 输入几何: 第一帧 COLMAP 点云，用作初始化；对比中也报告 dense COLMAP input 的其他方法。
* 输出: 给定时间和相机位姿下的 RGB 渲染图像。
* 优化目标: 最小化渲染图像和 ground truth 图像之间的重建误差，同时约束静态和动态点的运动幅度。

### 2.3 论文假设

* 相机位姿可用，且多视角同步数据质量足够。
* 动态变化可以由“静态线性运动 + 动态关键帧插值”覆盖。
* 动态点比例可以通过 motion magnitude 自动触发，而无需 mask / scribble 等外部监督。
* keyframe interval 默认设为 10，适用于多数测试速度；更快运动时更小 interval 可能更好。

## 3. 方法概览

Ex4DGS 的方法结构可以拆成四层。

第一层是静态 Gaussian $G_s$。它保留 3DGS 的大部分参数，只允许位置随时间线性移动。这里的“static”不是完全不动，而是一个低自由度运动模型，用来吸收小漂移或全局对齐误差。

第二层是动态 Gaussian $G_d$。动态点只在稀疏 keyframes 上存储状态：位置、四元数旋转和 temporal opacity 参数。中间帧不存独立高斯，而是由相邻关键帧插值得到。

第三层是自动静态/动态分离。训练从所有点都是静态点开始；当静态点预测的运动在 image-space normalized motion 中排到 top-$\eta$ 时，就被转换为动态点。论文使用 $\eta = 2$。

第四层是训练稳定化：progressive growing 逐渐增加训练时间长度，linear regression 初始化新 keyframe 参数；point backtracking 根据图像误差反向分配到 Gaussian 并执行剪枝。

## 4. 方法细节

### 4.1 3DGS 基础表示

论文沿用 3DGS 的各向异性 Gaussian 形式。单个 3D Gaussian 由 mean $\mu$、covariance $\Sigma$、density / opacity 相关参数和颜色 $c$ 构成。Gaussian density 写作 Eq. 1：$G(x)=e^{-\frac{1}{2}(x-\mu)^\top \Sigma^{-1}(x-\mu)}$。

投影到相机平面时使用 affine approximation，camera-coordinate covariance 为 Eq. 2：$\Sigma' = J W \Sigma W^\top J^\top$，其中 $J$ 是 perspective projection 的 Jacobian，$W$ 是 view transform。协方差通过 scale 与 rotation 分解，Eq. 3：$\Sigma = R S S^\top R^\top$。

颜色渲染沿用 point-based alpha blending，Eq. 4 中 ray color 为 $C = \sum_{i=1}^{N} T_i(1-e^{-\sigma_i \delta_i})c_i$，其中 $T_i = e^{-\sum_{j=1}^{i-1}\sigma_j\delta_j}$。

### 4.2 静态 Gaussians

静态 Gaussian 的位置随归一化时间线性变化。Eq. 5：$\mu(t)=x+t'd,\ t'=t/l \in [0,1]$。

这里 $x$ 是 pivot position，$d$ 是 translation vector，$l$ 是 scene duration。用 $l$ 归一化时间的目的，是防止 $d$ 随绝对 timestamp 变得过大。这个设计给“静态”点一个很小的动态自由度，既能处理微小对齐误差，也为后续 motion-based dynamic extraction 提供可观测的运动量。

### 4.3 动态 Gaussians 与关键帧插值

动态 Gaussian 的状态只在 keyframes 上显式存储。论文定义 keyframe set 为 $K=\{t\mid t=nI,\ n\in Z,\ t\in T\}$，其中 $I$ 是统一 keyframe interval，$T$ 是 timestamp set。

动态点在中间时间的状态由相邻 keyframes 合成：

* position: Cubic Hermite interpolation, 简写为 CHip；
* rotation: Spherical Linear Interpolation, 即 Slerp；
* temporal opacity: 两段高斯衰减加中间完全可见平台。

这个设计的核心不是“更强的时序网络”，而是让每个动态 Gaussian 的时间参数都可以直接存储和读取：keyframe position、keyframe rotation、appearance/disappearance opacity 参数。

### 4.4 CHip 位置插值

CHip 使用三次多项式。给定 start point $p_0$、end point $p_1$、start tangent $m_0$、end tangent $m_1$，Eq. 6 写作 $CHip(p_0,m_0,p_1,m_1;t)=(2t^3-3t^2+1)p_0+(t^3-2t^2+t)m_0+(-2t^3+3t^2)p_1+(t^3-t^2)m_1$。

动态 Gaussian 在时间 $t$ 的位置由 Eq. 7 给出：$\mu(t)=CHip(p_n,m_n,p_{n+1},m_{n+1};t')$，其中 $n=\lfloor t/I \rfloor$，$t'=(t-nI)/I$，$m_n=(p_{n+1}-p_{n-1})/(2I)$，$m_{n+1}=(p_{n+2}-p_n)/(2I)$。

重要实现点：tangent 不额外存储，而是从相邻 keyframe positions 计算。这让 CHip 相比更高自由度轨迹模型更省存储，同时比 linear interpolation 有更强的平滑运动表达。

### 4.5 Slerp 旋转插值

旋转以 quaternion 存储。论文避免直接线性插值角度，因为线性插值旋转会有 angular bias。Eq. 8 定义 $Slerp(x_0,x_1;t)=\frac{\sin[(1-t)\Omega]}{\sin\Omega}x_0+\frac{\sin(t\Omega)}{\sin\Omega}x_1$，其中 $\cos\Omega=x_0\cdot x_1$。

应用到动态 Gaussian rotation 时，Eq. 9 为 $q(t)=Slerp(r_n,r_{n+1};t')$，其中 $r_n$ 是第 $n$ 个 keyframe 的 quaternion rotation。

### 4.6 Temporal opacity

Temporal opacity 用来表达物体出现、保持可见、消失。单个时间 Gaussian 难以同时覆盖突然出现、缓慢消失、长时间可见和再出现等情况；完整 Gaussian mixture 又太重。因此论文用两个 Gaussian 近似 appearance 与 disappearance，中间区域设为 fully visible。

令较早均值的 Gaussian 控制出现，较晚均值的 Gaussian 控制消失。Eq. 10 可概括为：

$$
\sigma_t(t)=
\begin{cases}
\exp(-((t-a_s^o)/b_s^o)^2), & t<a_s^o \\
1, & a_s^o \le t \le a_f^o \\
\exp(-((t-a_f^o)/b_f^o)^2), & t>a_f^o
\end{cases}
$$

这里 $a_s^o,b_s^o$ 是出现侧参数，$a_f^o,b_f^o$ 是消失侧参数。这个 opacity 设计的实际作用是减少为了表示长时间可见或间歇可见物体而复制多个 Gaussians 的需求。

### 4.7 Progressive training

训练不是一开始覆盖完整视频，而是先学习短时间片段，再逐步扩大 duration。默认 time interval 和 initial duration 都是 10；每 400 iterations 将 duration 增加一个 interval。

当 duration 扩张并引入新的 keyframe 时，论文使用最后 $\rho$ 帧做 linear regression 来估计 Gaussian position 与 rotation，使前一段时间学到的 motion information 可以延续到新 keyframe。$\rho$ 的具体数值在抽取文本中未给出，标记为 `Not specified`。

这个策略主要解决只用第一帧点云初始化时的优化局部最小值问题：如果一开始训练完整视频，未来帧中的物体位置可能和初始点云严重错位。

### 4.8 静态点到动态点的转换

所有点最初都是 static Gaussians。训练过程中，静态点的线性 motion vector $d$ 被用作动态性信号。为了避免远处点运动量被误判，论文把 translation 按点到相机距离归一化；如果最后 timestamp 的点到相机距离为 $\lambda$，使用的 motion score 是 $\|d\|/\|\lambda\|^2$。

然后按 score 排序，把 top-$\eta$ percent 转为 dynamic points。论文经验设定 $\eta=2$。转换时：

* dynamic position: 用当前 static $x$ 与 $d$ 估计各 keyframe 位置；
* dynamic rotation: 初始化为所有 keyframes 相同；
* dynamic opacity: 初始化为所有 keyframes 可见；
* 触发时机: duration 增长时或特定 iterations；具体 schedule 除 400-iteration duration growth 外未完全展开。

### 4.9 Point backtracking 与 pruning

动态场景里错误点可能只在某些时间可见，因此普通空间剪枝不够。论文提出 point backtracking，把像素误差在一次 backward pass 中分配回可见 Gaussians。

Eq. 11 中单个 Gaussian 的误差为 $E=\frac{\sum_k \sigma_i \prod_{j=1}^{i-1}(1-\sigma_j)q_k}{\sum_k \sigma_i \prod_{j=1}^{i-1}(1-\sigma_j)}$，其中 $q_k$ 是 pixel-space error，$i,j$ 是按深度排序的 Gaussian index。Eq. 12 中累计误差为 $E_{total}=\frac{\sum_{v\in D}E_v}{\sum_{v\in D}1}$。

训练会在预定义步数 prune 掉 $E_{total}$ 较高的点。pruning threshold 和 exact schedule 在文本中是 `Not specified`。

## 5. 数学目标与损失

### 5.1 Photometric loss

优化流程沿用 3DGS 的 differentiable rasterization 和 gradient backpropagation。论文明确使用 $L_1$ loss 与 SSIM loss 来度量 rendered image 和 ground truth 的差异。具体加权形式没有完全展开；按 3DGS 惯例可推测类似 $L=(1-\lambda)L_1+\lambda L_{DSSIM}$，但本文抽取文本没有给出该公式，因此应记为 `inferred`，不可当作论文显式公式。

### 5.2 Motion regularization

论文对 static 和 dynamic points 都加入大运动正则：

* static regularization: 最小化 $\|d\|$；
* dynamic regularization: 最小化 $\|p_{n+1}-p_n\|$。

Implementation details 中说 static 与 dynamic regularization parameters 都设为 0.0001。

### 5.3 Error-based pruning objective

point backtracking 不直接作为渲染 loss，而是作为 prune criterion。它将 $L_1$ 和 SSIM 相关的 image-space error $q_k$ 聚合到 Gaussian 上，再按视角集合 $D$ 累计为 $E_{total}$。这一机制对动态场景重要，因为一个 Gaussian 的错误可能跨多个 timestamp 累积，而不是在单帧中显著。

## 6. 训练与推理流程

### 6.1 初始化

1. 用第一帧 COLMAP point cloud 初始化 3DGS points。
2. 所有 points 初始为 static Gaussians。
3. static Gaussians 带有 pivot position $x$ 和 translation $d$。
4. dynamic Gaussians 尚未大量产生，后续由 motion trigger 从 static points 转换。

### 6.2 训练循环

1. 在当前 duration 内采样训练视角和时间。
2. 根据 point 类型计算当前时间状态：
   * static: 用 $\mu(t)=x+t'd$；
   * dynamic: 用 CHip 计算 $\mu(t)$，用 Slerp 计算 $q(t)$，用 temporal opacity 计算 $\sigma_t(t)$。
3. 用 3DGS / Mip-Splatting 风格 rasterizer 渲染。
4. 用 $L_1$、SSIM 和 motion regularization 更新参数。
5. 在 duration 扩张或指定 iteration 上，按 $\|d\|/\|\lambda\|^2$ 把 top-$\eta$ 静态点转为动态点。
6. 每 400 iterations 增加一个 interval 的 duration；新增 keyframe 用最后 $\rho$ 帧 linear regression 初始化。
7. 在预定义 pruning step 上，用 point backtracking 计算 $E_{total}$ 并删除高误差点。

### 6.3 推理

推理时不需要 MLP 查询。给定时间 $t$：

* static points 直接线性移动；
* dynamic points 从相邻 keyframes 显式插值得到位置、旋转和 opacity；
* 所有点经 rasterizer splat 到目标视角。

论文报告在 300-frame、$1352 \times 1014$ 场景上，单张 RTX 2080Ti 可达到 62 FPS；主表中在 NVIDIA 4090 上测得 120.6 FPS。

## 7. 实验设置与结果

### 7.1 数据集

Neural 3D Video dataset:

* 六个多视角室内视频场景；
* 18 到 21 个相机；
* 300 帧；
* 原始分辨率 $2704 \times 2028$，训练/评估用半分辨率；
* center camera held out as novel-view evaluation。

Technicolor dataset:

* $4 \times 4$ camera array；
* 每个相机时间同步；
* 分辨率 $2048 \times 1088$；
* 按 HyperReel protocol 保留 second row / second column intersection camera 做评估；
* 五个场景：Birthday、Fabien、Painter、Theater、Train。

### 7.2 指标与对比

指标包括 PSNR、SSIM、LPIPS、FPS、model size MB、training time。SSIM 报告两个版本：

* SSIM1: `scikit_image` 中 `data_range=1`；
* SSIM2: `data_range=2`。

主要对比包括 NeRFPlayer、HyperReel、DyNeRF、HexPlane、K-Planes、MixVoxels、4K4D、STG、4DGS、4DGaussians、3DGStream 等。论文特别区分 dense COLMAP point cloud input 与 sparse COLMAP point cloud input。

### 7.3 Neural 3D Video 主结果

Table 1 中 sparse COLMAP input 下，Ex4DGS 平均 PSNR 为 32.11，model size 为 115 MB，FPS 为 120.6，training time 为 0.6 hours。相比之下：

* sparse 4DGS: 平均 PSNR 30.19，6057 MB，72.0 FPS，4.2 hours；
* sparse 4DGaussians: 平均 PSNR 28.63，34 MB，146.6 FPS，1.5 hours；
* sparse STG: 平均 PSNR 30.64，109 MB，101.0 FPS，1.3 hours，但 STG 因内存问题在 H100 上只训练 150 frames；
* 3DGStream: 平均 PSNR 31.67，1200 MB，FPS 和训练时长未报告。

这支撑了论文的核心经验结论：在只用第一帧点云的稀疏初始化条件下，关键帧显式插值和 progressive training 比依赖 dense temporal point clouds 的方法更稳。

### 7.4 Technicolor 主结果

Table 2 中 Ex4DGS 在 Technicolor 平均 PSNR 33.62，SSIM1 0.916，SSIM2 0.962，LPIPS 0.088。STG 的 PSNR 为 33.23，SSIM1 0.912，SSIM2 0.960，LPIPS 0.085。论文解释 Technicolor 中快速运动较少，因此 STG 表现也很强。

### 7.5 静态/动态分离可视化

Figure 6 展示 Coffee Martini、Flame Steak、Fabien 中 static 和 dynamic points 的分离。动态点不只包含几何运动物体，也会捕捉颜色变化、反射、透明杯中的液体等现象。这说明 motion-based extraction 实际上学到的是“时间变化残差”，不严格等于语义动态对象。

### 7.6 消融

Table 3 使用 Neural 3D Video 的平均结果展示各组件贡献：

* Ours: PSNR 32.11，SSIM1 0.9422，LPIPS 0.0478，size 115 MB；
* w/ Linear position: PSNR 31.12，size 204 MB；
* w/ Linear rotation: PSNR 31.26，size 148 MB；
* w/o Temporal opacity: PSNR 31.42，size 186 MB；
* w/o Progressive growing: PSNR 31.02，size 168 MB；
* w/o Dynamic point extraction: PSNR 28.58，LPIPS 0.0756，size 58 MB；
* w/o Point backtracking: PSNR 31.40，size 169 MB。

最大性能崩塌来自移除 dynamic point extraction，说明方法的关键不是单个插值器，而是“从静态低自由度模型中自动释放出动态高自由度模型”的机制。

### 7.7 附录实验

Appendix B.1 表明只处理几何移动不够，颜色变化和阴影也需要 dynamic points；Coffee Martini 上 3DGS 为 PSNR 21.69，3DGS + Our dynamic 为 26.07，完整模型为 28.79。

Appendix B.3 研究 keyframe interval。Cook Spinach 上 interval 10 在 skipped frame 为 1 时达到 PSNR 33.04、size 119 MB；更大 interval 会降低模型大小，但太大或太小都可能损害质量。

Appendix B.4 研究 dynamic conversion rate。比例为 2% 时最好，PSNR 33.04，SSIM1 0.956，LPIPS 0.041，size 119 MB；过低动态点不足，过高容易 overfit 且 size 增大。

Appendix C 额外测试遮挡、新物体出现和 1000-frame 长视频。1000-frame Flame Salmon 上 Ex4DGS 为 PSNR 28.77、SSIM1 0.919、LPIPS 0.076、size 392 MB；4DGS size 为 6331 MB。

## 8. 声称贡献 vs 实际技术增量

### 8.1 论文声称

论文声称 Ex4DGS 是 fully explicit dynamic Gaussian Splatting，优势是：

* 不使用 MLP 或隐式 temporal encoding；
* 通过 keyframe interpolation 减少动态场景存储；
* 无需 mask 等额外监督即可分离 static/dynamic points；
* progressive training 让第一帧稀疏点云初始化也能训练长视频；
* point backtracking 改善动态场景剪枝。

### 8.2 实际技术增量

实际增量可以更精确地写成：对 3DGS 的每个点引入一个两级时间模型，先用 static linear motion 作为低自由度默认模型，再将高 motion score 的点提升为 keyframe-spline 动态模型。

与 4DGS / 4DGaussians 的差异不是简单“更显式”，而是：

* 4DGS 类方法容易在每帧或 4D 参数上消耗大量 primitives / storage；
* 4DGaussians 等隐式/轨迹方法会牺牲一部分 3DGS rasterization 的直接性；
* Ex4DGS 把位置、旋转、opacity 的时间变化全部写成 closed-form interpolation，推理不需要时间 MLP。

### 8.3 证据强度

证据较强的部分：

* sparse COLMAP input 下的主表对比；
* dynamic point extraction 消融；
* keyframe interval 和 conversion rate 附录敏感性实验；
* 1000-frame storage 对比。

证据较弱或需人工复核的部分：

* source code URL 未在 PDF 文本中抽出；
* exact prune schedule、threshold、learning rates 大多继承 3DGS/Mip-Splatting，没有完整逐项列出；
* 统计显著性未报告，checklist 明确回答 No。

## 9. 局限与隐藏假设

论文显式局限：

1. 新出现物体如果既没有初始化 3D points，也没有邻近帧相关 Gaussians，可能陷入 local minima。作者建议引入 depth 等几何先验。
2. 单目视频困难。由于 3DGS 本身存在 scale ambiguity，缺少每个 timestamp 的准确几何线索时，所有点可能都被当作 dynamic。作者建议加入 mask、optical flow 等 semantic / motion cue。

隐藏假设：

* 多视角设置仍然是核心实验条件；方法并没有证明在 casual monocular videos 上直接稳定。
* keyframe interval 是重要超参数，不同运动速度需要调整。
* dynamic point extraction 的 top-$\eta$ 策略依赖初始 static linear model 已经能产生有意义 motion score。
* temporal opacity 可以处理出现/消失，但 reappearing object 可能被当成新对象；这对跨时间 identity consistency 不一定友好。
* 反射、阴影、颜色变化也会被归为 dynamic points，说明分离结果不是物理或语义层面的动态对象分割。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法名称 | Ex4DGS |
| 核心表示 | static linear Gaussians + dynamic keyframe Gaussians |
| 时间建模 | CHip position + Slerp rotation + two-Gaussian temporal opacity |
| 是否使用 MLP | 否，主张 fully explicit |
| 初始化 | 第一帧 COLMAP point cloud |
| 动态识别 | static motion score $\|d\|/\|\lambda\|^2$，top-$\eta$ 转 dynamic |
| 默认关键超参 | interval 10；initial duration 10；duration 每 400 iterations 增长；$\eta=2$；regularization 0.0001 |
| 优化器 | RAdam |
| 正则 | static $\|d\|$；dynamic $\|p_{n+1}-p_n\|$ |
| 剪枝 | point backtracking accumulated error |
| 主数据集 | Neural 3D Video；Technicolor |
| 主优势 | sparse first-frame point cloud 下质量、速度、存储均衡 |
| 主要短板 | 新出现物体无邻近点时困难；单目 scale ambiguity |
| 可复现风险 | code URL 未在正文抽出；部分 schedule/threshold 未完全写明 |

## 11. 对我的研究可复用组件

1. Static-to-dynamic promotion：先用低自由度模型训练所有点，再按误差或运动量把部分点提升到高自由度动态模型。这个模式适合构建动态 GS taxonomy 中的“adaptive temporal capacity”轴。
2. Keyframe-only storage：只在 sparse timestamps 存状态，中间帧 closed-form interpolation。可作为压缩动态 GS 或 streaming GS 的 baseline 组件。
3. Temporal opacity plateau：用 appear / visible / disappear 三段式 opacity 替代单峰 temporal Gaussian。适合处理 occlusion 和 object lifecycle。
4. Image-space normalized motion score：$\|d\|/\|\lambda\|^2$ 比世界坐标 motion 更适合从渲染贡献角度判断动态性。
5. Point backtracking pruning：把 image error 回传到点级别累计，适合动态场景中跨时间错误点清理。

## 12. Gap and Idea Seeds

### 12.1 Gap: dynamic point extraction 不是语义动态

Ex4DGS 会把阴影、反射、颜色变化和几何运动都归入 dynamic points。这有利于重建，但不利于可编辑动态场景。可以研究把 dynamic points 分成 geometry-motion、appearance-change、view-dependent residual 三类。

### 12.2 Gap: 新出现物体仍依赖邻近点

论文在 limitation 中承认如果没有初始化点或邻近 Gaussians，会陷入 local minima。可以结合 monocular depth / stereo depth / segmentation proposal，在 progressive duration 扩张时主动 seed new Gaussians，而不是只从 static points 转换。

### 12.3 Gap: keyframe interval 固定

统一 interval 简洁但对不同区域运动速度不自适应。可以设计 per-Gaussian adaptive keyframe allocation：高加速度点更多 keyframes，近静态点更稀疏。

### 12.4 Gap: point identity 与 reappearing object

Appendix B.2 暗示 reappearing object 会被视为新对象。这对短期渲染可接受，但对 tracking / editing / physical simulation 不够。可以加入 temporal correspondence regularization 或 object-level ID memory。

### 12.5 Gap: 单目扩展

作者指出单目因 scale ambiguity 很难。一个可行方向是把 Ex4DGS 的 static-to-dynamic promotion 与 flow/depth confidence 结合，只在几何可靠区域允许动态提升。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: PDF 文本没有抽出公开 GitHub / project URL；需要人工查看 supplementary 或论文页面。
* `NEED_HUMAN_CHECK`: exact learning rates、density control schedule、point backtracking prune threshold 未在抽取文本中完整列出，可能藏在 code / supplementary。
* `NEED_HUMAN_CHECK`: Eq. 10 的排版在 PDF 抽取中有符号错位，note 中按上下文重构为 squared exponential piecewise opacity。
* `NEED_HUMAN_CHECK`: RAdam 与 3DGS/Mip-Splatting hyperparameters 的完整配置需要代码确认。
* `NEED_HUMAN_CHECK`: 62 FPS on 2080Ti 与 Table 1 的 120.6 FPS on 4090 是不同硬件/设置；引用时不要混为同一实验。

## 14. Evidence Anchors

* Abstract: 声称分离 static/dynamic Gaussians，动态点在 sparse timestamps 上显式采样位置和旋转，并报告 62 FPS on 2080Ti。
* Section 1 Introduction: 说明现有 dynamic 3DGS 依赖 dense point clouds 或隐式表示，提出 keyframe interpolation、motion-based triggers、progressive training、point backtracking。
* Section 3 Preliminary: Eq. 1 到 Eq. 4 回顾 3DGS Gaussian、projection、covariance decomposition 与 alpha blending。
* Section 4 Methodology / Figure 1: 总览 static/dynamic separation、progressive learning、point backtracking 和 interpolation。
* Section 4.1 / Eq. 5: static Gaussian 的线性位置模型 $\mu(t)=x+t'd$。
* Section 4.2 / Figure 2: dynamic Gaussian 通过相邻 keyframes 插值得到中间帧状态。
* Section 4.2.1 / Eq. 6-7: CHip 位置插值和 tangent 从邻近 keyframes 计算。
* Section 4.2.2 / Eq. 8-9: Slerp 旋转插值。
* Section 4.2.3 / Figure 3 / Eq. 10: temporal opacity 的双 Gaussian / 三段式可见性模型。
* Section 4.3 / Figure 4: progressive learning、duration expansion、dynamic point extraction；$\eta=2$。
* Section 4.4 / Eq. 11-12: point backtracking error 与 accumulated error。
* Section 4.5: 3DGS + Mip-Splatting codebase；first-frame COLMAP；interval 10；每 400 iterations 增长；regularization 0.0001；RAdam。
* Section 5.1 / Table 1: Neural 3D Video 主结果和 sparse COLMAP 对比。
* Section 5.2 / Table 2: Technicolor 主结果。
* Section 5.3 / Figure 6: static/dynamic point separation 可视化。
* Section 5.4 / Table 3: 组件消融，dynamic point extraction 和 progressive growing 的影响。
* Section 6 Conclusion / Limitations: 新出现物体和 monocular scale ambiguity 两个显式局限。
* Appendix B.1 / Table 4: color change 也需要 dynamic points。
* Appendix B.3 / Table 5: keyframe interval 和 skipped frames 敏感性。
* Appendix B.4 / Table 6: dynamic point conversion rate，2% 最优。
* Appendix C.1-C.3 / Table 7-9: 遮挡、新出现物体、1000-frame 长视频额外测试。
* NeurIPS checklist: code claimed in supplementary；无统计显著性分析；compute resource 信息在 implementation details。
