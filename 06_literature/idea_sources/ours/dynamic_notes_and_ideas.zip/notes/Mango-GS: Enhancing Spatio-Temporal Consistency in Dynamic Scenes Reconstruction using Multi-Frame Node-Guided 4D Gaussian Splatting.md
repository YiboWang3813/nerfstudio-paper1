# Mango-GS: Enhancing Spatio-Temporal Consistency in Dynamic Scenes Reconstruction using Multi-Frame Node-Guided 4D Gaussian Splatting

## 0. Metadata

- Title: Mango-GS: Enhancing Spatio-Temporal Consistency in Dynamic Scenes Reconstruction using Multi-Frame Node-Guided 4D Gaussian Splatting
- Authors: Tingxuan Huang; Haowei Zhu; Jun-hai Yong; Hao Pan; Bin Wang
- Venue/Year: ICLR 2026
- Zotero item key: `BKD3KMHM`
- Zotero PDF attachment key: `FNJ3UVN6`
- PDF path: `/Users/wangyibo/Zotero/storage/FNJ3UVN6/Huang 等 - 2026 - MANGO-GS ENHANCING SPATIO-TEMPORAL CON- SISTENCY IN DYNAMIC SCENES RECONSTRUCTION USING MULTI-FRAME.pdf`
- Local note path: `notes/Mango-GS: Enhancing Spatio-Temporal Consistency in Dynamic Scenes Reconstruction using Multi-Frame Node-Guided 4D Gaussian Splatting.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

Mango-GS 用少量 decoupled control nodes 表示动态场景的稀疏运动骨架，在 node space 上用 multi-frame temporal Transformer 一次预测时间窗口内的 node deformation，再通过 learned position-feature affinity 把运动传播到密集 3D Gaussians，以提升动态 Gaussian Splatting 的时序一致性和实时渲染效率。

## 2. Problem Formulation

动态 3DGS 通常把 canonical Gaussians 通过时间条件 MLP 或逐帧 deformation network 变形到每一帧。这类 per-frame optimization 容易记忆单帧状态，而不是学习跨帧 motion dynamics，因此在快速运动、非刚性运动和复杂局部变形中会出现 blur、ghosting 和 temporal flicker。

直接把 temporal Transformer 用到全部 Gaussians 又不现实，因为动态场景可能包含数十万到数百万 Gaussians，attention 的计算和显存开销会破坏 3DGS 的效率优势。已有 sparse control node 方法可以降低成本，但如果节点和 Gaussians 只靠 canonical 空间 k-NN 绑定，初始邻域在大运动后可能不再语义一致。

Mango-GS 的目标是在保持 3DGS 实时 rasterization 的前提下，引入跨帧时序建模。核心问题可以表述为：给定 canonical Gaussian cloud $G=\{g_j\}_{j=1}^N$ 和稀疏 control nodes $N=\{n_i\}_{i=1}^M$，其中 $M\ll N$，学习一个在时间窗口 $T$ 内同时预测 node motion 的模型，并稳定传播到所有 Gaussians。

## 3. Method Overview

Mango-GS 的整体 pipeline 是 sparse-to-dense dynamic Gaussian deformation。首先维护一组 canonical 3D Gaussians 和稀疏 control nodes，每个 node 不是单纯三维位置，而是 decoupled representation $n_i=(p_i,f_i)$，其中 $p_i$ 是 canonical position，$f_i$ 是 learnable latent code。

对每个 Gaussian，模型在 position-feature joint space 中找到 top-$k$ semantic neighboring nodes，并计算 softmax influence weights。然后 temporal attention network $\Phi$ 接收所有 node positions 和一个 $T$ 帧时间窗口，输出每个 node 在窗口内的 translation、rotation 和 scaling deformation。Dense Gaussians 的 deformation 由 neighboring node deformations 加权混合得到，最终用标准 differentiable Gaussian rasterizer 渲染并端到端训练。

训练时引入 temporal input masking，让网络不能只记忆 timestamp；loss 由 top-$k$ hard-frame photometric loss 和 motion-aware temporal loss 组成，分别强调困难帧质量和跨帧一致性。附录还使用 sparse stride sampler 与 interpolation sampler 组合构造 multi-frame groups。

## 4. Method Details

### 4.1 Decoupled Control Node Representation

每个 control node $n_i=(p_i,f_i)$ 分离位置和 latent feature code。位置 $p_i\in\mathbb{R}^3$ 提供空间锚点，feature $f_i\in\mathbb{R}^D$ 提供可学习语义锚点。相较于 SC-GS 式纯空间 k-NN，这种表示允许 Gaussian 关联到空间上不一定最近、但运动语义更一致的 nodes。

对 Gaussian $g_j$，canonical attributes 记为 $\phi_j=(x_j,q_j,s_j)$。论文描述为用 lightweight MLP 将 Gaussian canonical parameters 映射到 embedding，再与 node code 计算 affinity score；取 top-$k$ 后 softmax 得到 influence weights。概念上，权重写作：

$$
w_{ij}=\frac{\exp(-D(g_j,n_i))}{\sum_{i'\in K(j)}\exp(-D(g_j,n_{i'}))},\quad i\in K(j).
$$

这里 $K(j)$ 是 Gaussian $g_j$ 的 top-$k$ nodes，$D$ 是 joint position-feature distance 或 learned affinity 的等价距离。这个 learned neighborhood 是 Mango-GS 防止 correspondence drift 的关键。

### 4.2 Multi-Frame Temporal Attention Network

Temporal deformation network 在 sparse node space 上工作，而不是在 dense Gaussian space 上工作。对每个 node，将 canonical position encoding 与时间 embedding $t_0,\ldots,t_{T-1}$ 拼接，形成 $H^{(0)}\in\mathbb{R}^{N\times T\times C_{\mathrm{in}}}$。网络主体是 MLP layers，中间插入 temporal self-attention blocks，只沿时间维做 attention。

网络一次输出窗口内所有 node deformation：

$$
\{\Delta p_i(t),\Delta q_i(t),\Delta s_i(t)\}_{t=0}^{T-1}
=\Phi(\{p_i\}_{i=1}^{M},\{t\}_{t=0}^{T-1};\Theta).
$$

在第 $l$ 层，temporal attention block 先把 $H^{(l)}$ 投影到 temporal attention space，然后对每个 node 的时间序列做 multi-head self-attention：

$$
H_{\mathrm{attn}}=\mathrm{MHA}(H_{\mathrm{in}}^{(l)},H_{\mathrm{in}}^{(l)},H_{\mathrm{in}}^{(l)}).
$$

attention 结果通过 lightweight gate 融入主干特征：

$$
H^{(l+1)}=H^{(l)}\otimes\sigma(w_{\mathrm{gate}})+w_{\mathrm{bias}}.
$$

这种 gated update 比简单 residual 更灵活，可以控制每个 node、每个时间步吸收多少跨帧信息。

### 4.3 Sparse-to-Dense Motion Propagation

Node motion 预测完成后，Gaussian deformation 由相邻 nodes 加权混合。以位置为例：

$$
\{\Delta x_j(t)\}_{t=0}^{T-1}
=\sum_{i\in K(j)} w_{ij}\{\Delta p_i(t)\}_{t=0}^{T-1}.
$$

Rotation 和 scale 也用类似方式传播。最终得到每个时间步的 deformed Gaussian cloud $g_j(t)$。因为 temporal modeling 只作用在 $M$ 个 nodes 上，而不是 $N$ 个 Gaussians 上，所以 Mango-GS 能在较高质量下保持实时渲染速度。

### 4.4 Temporal Input Masking

为了避免网络把 timestamps 当作 frame ID 记忆，训练时随机 mask 一部分 input time embeddings。网络需要利用可见 temporal context 预测整个窗口的 deformation。这相当于轻量 temporal augmentation，使模型更依赖 motion trend 而不是单帧索引。

### 4.5 Multi-Frame Group Sampling

附录给出两种 training window 采样方式。Sparse stride sampler 从同一 view-specific sequence 中以固定 stride 选取 $T$ 个真实帧，让窗口覆盖更长时间跨度。Interpolation sampler 在真实帧之间加入线性插值的 placeholder timestamps；placeholder 通过网络但没有 image supervision，用作平滑 temporal anchors。默认 sparse:interpolation 比例为 0.7:0.3。

## 5. Mathematical Objectives and Losses

总体 loss 为 top-$k$ hard-frame photometric loss 和 motion-aware loss 的加权和：

$$
L=0.8L_{\mathrm{frame}}+0.2L_{\mathrm{motion}}.
$$

$L_{\mathrm{frame}}$ 是多帧窗口上的 hard-frame photometric objective：先对窗口内每帧计算 photometric error，再聚焦 top-$k$ 困难帧，避免平均 loss 被简单帧主导。$L_{\mathrm{motion}}$ 是 motion-aware temporal loss，用来惩罚跨帧不一致和运动不平滑。论文正文抽取文本中该段有截断，因此这里保留 high-level 形式；可见实验表明 top-$k$ loss 提升空间质量，motion-aware loss 进一步降低 tLPIPS。

底层 rendering 仍是 3DGS alpha compositing。单个 3D Gaussian density 为：

$$
G(x)=\exp\left(-\frac{1}{2}(x-\mu)^\top\Sigma^{-1}(x-\mu)\right).
$$

协方差分解为 $\Sigma=RSS^\top R^\top$，projection 后用 2D footprint 做 rasterization。像素颜色通过 front-to-back alpha compositing 计算：

$$
C=\sum_{i=1}^{N}c_i\alpha'_i\prod_{j=1}^{i-1}(1-\alpha'_j).
$$

## 6. Training and Inference Procedure

训练分两阶段。第一阶段是 node initialization 和 warm-up，持续 5,000 iterations；第二阶段是 main dynamic training，持续 35,000 iterations，联合优化 canonical Gaussians、control nodes、learned affinity 和 temporal attention network。

默认 temporal window 为 $T=6$，初始 control nodes 数量为 2048，邻居数 $K=3$。静态 Gaussian attributes 遵循原始 3DGS 设置。DSSIM 权重 $\lambda_{\mathrm{dssim}}=0.2$。实验在单张 NVIDIA RTX 3090 上完成。

推理时，temporal network 对窗口内 $T$ 个 timestamps 一次输出 node deformation，再传播到 dense Gaussians 并渲染。由于网络在 sparse nodes 上做 temporal attention，HyperNeRF-vrig 平均达到 149.5 FPS；附录报告 544x960 下连续结果约 155.6 FPS。

## 7. Experimental Setup and Results Summary

评测主要使用 Neural 3D Video 和 HyperNeRF-vrig。Neural 3D Video 指标包括 PSNR、SSIM、LPIPS；HyperNeRF-vrig 指标包括 PSNR、MS-SSIM、tLPIPS、FPS 和 storage。对比方法包括 D-3DGS、E-D3DGS、4DGS、SC-GS、GaGS、MotionGS 和 TimeFormer。

主表中，Neural 3D Video 上 Mango-GS 取得 PSNR 31.89、SSIM 0.942、LPIPS 0.049。PSNR 高于 TimeFormer 的 31.84 和 4DGS 的 31.58；SSIM 与 4DGS 接近，LPIPS 略弱于 E-D3DGS 的 0.048 但明显好于 D-3DGS 的 0.078。

HyperNeRF-vrig 上 Mango-GS 取得 PSNR 26.2、MS-SSIM 0.78、tLPIPS 0.0196、FPS 149.5、storage 60 MB。它在 PSNR、MS-SSIM 和 tLPIPS 上均优于表中 baselines，同时速度显著高于 MotionGS 的 39.9 FPS、TimeFormer 的 40.9 FPS 和 4DGS 的 45.0 FPS。

时间窗口消融显示 $T=6$ 是质量和速度的折中点：$T=2/4/6/8$ 的 PSNR 分别为 27.53/28.19/28.35/28.24，FPS 分别为 87.9/117.8/149.5/156.2。邻居数消融显示 $K=3$ 最优，PSNR 28.39、SSIM 0.942、tLPIPS 0.0196。

组件消融从 single-frame baseline 的 25.15 PSNR、0.0250 tLPIPS 出发，加入 decoupled nodes、multi-frame temporal modeling、temporal attention、top-$k$ loss 和 motion-aware loss 后，full model 达到 28.32 PSNR、0.942 SSIM、0.071 LPIPS、0.0192 tLPIPS。说明 decoupled affinity、multi-frame attention 和 motion-aware loss 都对 temporal coherence 有贡献。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献包括 decoupled control node representation、multi-frame temporal Transformer for node dynamics，以及 end-to-end Mango-GS framework 在动态重建上的高质量和高速表现。

实际技术增量主要在两个点。第一，node representation 从位置点变成 position + latent code，并用 learned affinity 替代纯空间 k-NN，使 sparse control propagation 更能承受大运动。第二，temporal attention 被放在 sparse node space，而不是 dense Gaussian space，因此能引入跨帧 reasoning 而不承担百万 Gaussians 的 attention 成本。

相对 SC-GS，Mango-GS 的差异是 learned semantic neighborhood 和 multi-frame node dynamics；相对 TimeFormer 这类直接建模 deformable Gaussians temporal relation 的方法，Mango-GS 通过 sparse nodes 提升效率；相对 4DGS / Grid4D 等时空编码方法，它更强调短窗口 motion dependency 和 temporal coherence。

## 9. Limitations / Assumptions

Mango-GS 假设 sparse control nodes 足以描述主要动态。如果场景存在大量独立细碎运动、拓扑变化或遮挡导致的不可观测区域，node-guided propagation 可能仍会过平滑或错绑。

Temporal window 是短窗口，默认 $T=6$。它能改善局部 temporal coherence，但不等价于全序列 memory；论文结论也把 lightweight memory 和 long-video online adaptation 列为未来工作。

Learned affinity 虽缓解 correspondence drift，但仍依赖训练数据监督。如果 large motion 区域缺少视角或纹理监督，semantic neighborhood 可能学习不稳定。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Monocular or multi-view dynamic videos |
| Output | Temporally coherent deformed 3D Gaussian sequence |
| Core representation | Canonical Gaussians plus decoupled control nodes $n_i=(p_i,f_i)$ |
| Motion model | Temporal Transformer over sparse nodes in a $T$-frame window |
| Propagation | Learned top-$k$ position-feature affinity from nodes to Gaussians |
| Training tricks | Temporal input masking; sparse/interpolation multi-frame group sampling |
| Losses | Top-$k$ hard-frame photometric loss plus motion-aware temporal loss |
| Default settings | $T=6$, initial nodes 2048, $K=3$, 5k warm-up + 35k training |
| Strength | Better temporal coherence with real-time rendering speed |
| Weakness | Short-window modeling; relies on node coverage and learned affinity stability |

## 11. Reusable Components

- Decoupled node representation $n_i=(p_i,f_i)$ for semantic motion anchors.
- Learned Gaussian-node affinity using canonical Gaussian parameters and node codes.
- Temporal attention only over sparse control nodes to reduce dynamic 3DGS temporal modeling cost.
- Gated temporal attention fusion for per-node trajectory prediction.
- Temporal input masking to discourage timestamp memorization.
- Sparse stride + interpolation sampler for multi-frame dynamic reconstruction training.
- Top-$k$ hard-frame loss for dynamic sequences with uneven frame difficulty.

## 12. Gap / Idea Seeds

- Add long-horizon memory to connect adjacent $T=6$ windows and reduce window-boundary artifacts.
- Combine node affinity with optical flow / scene flow priors to stabilize extremely fast motion.
- Let node count be adaptive by motion complexity instead of using a fixed 2048-node initialization.
- Use uncertainty-aware weights so low-confidence node-Gaussian bindings rely more on local per-Gaussian correction.
- Extend temporal masking into self-supervised interpolation/extrapolation losses for unobserved timestamps.

## 13. Human Check List

- NEED_HUMAN_CHECK: The extracted text truncates the detailed definition of top-$k$ hard-frame loss and motion-aware loss after Eq. 8; verify exact formulas from PDF pages around Section 4.4 if needed.
- NEED_HUMAN_CHECK: The paper text uses both $N$ for node count in the temporal network description and $N$ for Gaussian count in 3DGS preliminaries; this note normalizes conceptually but keeps the original ambiguity in mind.
- NEED_HUMAN_CHECK: ICLR 2026 status is taken from the PDF header and Zotero metadata; confirm final publication metadata if citation exactness matters.

## 14. Evidence Anchors

- Abstract and Introduction: per-frame optimization limitation and Mango-GS motivation.
- Figure 1 / Section 4.1: sparse control nodes, learned k-NN relationship and end-to-end pipeline.
- Section 4.2: decoupled node representation with position and latent code.
- Section 4.3: temporal deformation network with temporal self-attention and gated fusion.
- Section 4.4: temporal input masking and composite loss.
- Table 1: Neural 3D Video and HyperNeRF-vrig comparison.
- Tables 2-3: temporal window, neighbor count and component ablations.
- Appendix A.1: sparse stride and interpolation samplers.
