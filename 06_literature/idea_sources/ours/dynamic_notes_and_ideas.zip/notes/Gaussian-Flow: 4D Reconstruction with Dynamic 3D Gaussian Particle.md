# Gaussian-Flow: 4D Reconstruction with Dynamic 3D Gaussian Particle

## 0. Metadata

* Title: Gaussian-Flow: 4D Reconstruction with Dynamic 3D Gaussian Particle
* Authors: Youtian Lin; Zuozhuo Dai; Siyu Zhu; Yao Yao
* Venue/Year: CVPR 2024
* DOI: `10.1109/CVPR52733.2024.01997`
* URL: `https://ieeexplore.ieee.org/document/10658506/`
* Project: `https://nju-3dv.github.io/projects/Gaussian-Flow`
* Zotero item key: `K3L39QYC`
* Zotero PDF attachment key: `BR9FP5G4`
* PDF path: `/Users/wangyibo/Zotero/storage/BR9FP5G4/Lin 等 - 2024 - Gaussian-Flow 4D Reconstruction with Dynamic 3D Gaussian Particle.pdf`
* Local note path: `notes/Gaussian-Flow: 4D Reconstruction with Dynamic 3D Gaussian Particle.md`
* Tags: Dynamic 3DGS; Explicit Deformation; Polynomial; Fourier; Monocular; Multi-view

## 1. One-Sentence Technical Summary

Gaussian-Flow 将 4D scene 表示为一组 dynamic 3D Gaussian particles，并用显式 Dual-Domain Deformation Model 为每个 Gaussian 的 position、rotation 和 radiance 拟合时间残差，避免 per-frame 3DGS 和 neural deformation field，从而在 monocular 与 multi-view 动态重建中同时获得高训练速度、高 FPS 和较高 novel-view quality。

## 2. Problem Formulation

### 2.1 输入

* monocular videos 或 multi-view videos。
* 对多视角 Plenoptic dataset 使用已知/给定相机设置。
* 对 HyperNeRF/D-NeRF 等动态数据集，目标是从视频重建可随时间渲染的 4D scene。

### 2.2 输出

* 一组 3D Gaussian particles。
* 每个 Gaussian 的 base attributes 和显式时间函数参数。
* 任意时间 $t$ 下可直接得到 Gaussian attributes，并用标准 3DGS rasterization 实时渲染。

### 2.3 目标

* 不训练每帧独立 3DGS。
* 不引入隐式 neural deformation field。
* 保留 3DGS 接近原生的训练和渲染速度。
* 支持 long video footage 中复杂 motion。

### 2.4 关键建模假设

* Gaussian 的 scale $s$ 和 opacity $\alpha$ 可以保持常量。
* 动态主要体现在 position $\mu$、rotation $q$ 和 radiance $c$ 的 time-dependent residual。
* 单个 Gaussian 每个 attribute dimension 可独立用 polynomial + Fourier residual 拟合。

## 3. Method Overview

Gaussian-Flow 的 pipeline 可以概括为：

1. 初始化 3D Gaussians。
2. 对每个 Gaussian，保留 reference frame 的 base attributes。
3. 用 Dual-Domain Deformation Model 拟合动态 residual。
4. 使用 adaptive timestamp scaling 让每个 Gaussian 有自己的 time dilation。
5. 用 time smoothness 和 KNN rigid regularization 约束时间与空间连续性。
6. 按时间 $t$ 计算当前 attributes，并使用 3DGS rasterizer 渲染。

核心思想是：动态模型完全显式化为每个点的少量时间函数参数，避免在渲染时 query MLP。

## 4. Method Details

### 4.1 3DGS recap

每个 3D Gaussian particle 包含 mean $\mu$、covariance $\Sigma$、opacity $\alpha$ 和 view-dependent radiance $c$。covariance 通常分解为 scale vector $s$ 和 rotation matrix $R$，rotation 用 quaternion $q$ 参数化。

3DGS 将 3D Gaussian 投影成 2D Gaussian splats，再通过 alpha blending 生成 pixel color。Gaussian-Flow 沿用这个 rasterization pipeline。

### 4.2 Dynamic attributes

Gaussian-Flow 假设只有三类 attributes 随时间变化：

* position $\mu(t)$。
* rotation $q(t)$。
* radiance $c(t)$。

scale $s$ 和 opacity $\alpha$ 固定为 base values。这一选择降低了动态自由度和计算开销。

### 4.3 Dual-Domain Deformation Model

对任一 attribute $S\in\{\mu,c,q\}$，使用 reference time $t_0$ 的 base attribute $S_0$ 加 time-dependent residual $D(t)$：

$$
S(t)=S_0+D(t).
$$

Residual 由 time-domain polynomial 和 frequency-domain Fourier series 相加：

$$
D(t)=P_N(t)+F_L(t).
$$

polynomial $P_N(t)$ 擅长拟合平滑运动；Fourier series $F_L(t)$ 擅长拟合剧烈和周期性变化。两者结合能减少单独 polynomial 的振荡过拟合，也避免单独 Fourier 对平滑运动需要手调阶数的问题。

### 4.4 Per-dimension fitting

论文明确假设 attribute 的不同维度独立变化。因此，position 的三个维度分别有自己的 residual functions，例如用 $\{D_{\mu_i}(t)\}_{i=0}^{3}$ 描述 position motion。这里原文下标范围疑似排版沿用了 4 维 notation；实际 position 是 3D，需以代码为准。

### 4.5 Adaptive timestamp scaling

直接把 normalized frame index $t\in[0,1]$ 输入 residual function，会让短时间剧烈运动需要很大的系数，导致优化不稳定。Gaussian-Flow 为每个 Gaussian 学习 time dilation：

$$
t_s=s\cdot t+b.
$$

$s$ 和 $b$ 分别是该 Gaussian 的 dilation factor 与 base factor，初始化为 1 和 0。DDDM 实际使用 $t_s$ 作为输入。

### 4.6 Regularization

Time smoothness:

对输入时间加 perturbation $\epsilon$，鼓励 $D(t)$ 与 $D(t+\epsilon)$ 一致：

$$
L_t=||D(t)-D(t+\epsilon)||_2.
$$

论文设置 $\epsilon=0.1/\text{frames}$。

KNN rigid loss:

由于 Gaussian points 会因 adaptive density control 动态增删，论文把优化分成交替阶段：前一阶段允许 density control，后一阶段不增删点，并在后一阶段加 KNN rigid constraint：

$$
L_s=\sum_{j\in N_i}||D_i(t)-D_j(t)||_2.
$$

该项鼓励空间近邻 Gaussians 的 motion residual 相近，提升局部空间连贯性。

## 5. Mathematical Objectives and Losses

### 5.1 Dynamic Gaussian attribute model

每个 Gaussian 的可优化参数包括：

* base attributes $\{\mu_0,q_0,s_0,c_0,\alpha_0\}$。
* $D_\mu(t)$ 的 polynomial/Fourier coefficients。
* $D_q(t)$ 的 polynomial/Fourier coefficients。
* $D_c(t)$ 的 polynomial/Fourier coefficients。
* adaptive timestamp scaling 参数 $s,b$。

### 5.2 Rendering objective

Gaussian-Flow 仍通过 3DGS differentiable rendering 的 photometric loss 反向传播，优化 base attributes 与 DDDM parameters。论文没有在主文重新展开完整 photometric loss，默认 follow 3DGS setting。

### 5.3 Regularized objective

总优化可理解为：

$$
L=L_{render}+\lambda_tL_t+\lambda_sL_s.
$$

主文给出两个正则的形式，但未在正文表述中清晰列出 $\lambda_t,\lambda_s$ 的具体权重。

## 6. Training and Inference Procedure

### 6.1 Implementation details

* optimizer: Adam。
* position learning rate: $4\times10^{-4}$，exponential decay 为 $8\times10^{-7}$。
* rotation learning rate: 0.002。
* all DDDM parameters learning rate: $4\times10^{-4}$。
* all parameters weight decay: $8\times10^{-7}$。
* 其他 learning rates follow 3DGS。
* 训练 30K 或 60K steps。
* 单张 NVIDIA RTX 4090 24GB。
* DDDM 用 Taichi 实现，parallelize 每个 Gaussian 的 polynomial/Fourier computation。

### 6.2 Training loop

1. 初始化 Gaussian particles。
2. 初始化每个 Gaussian 的 base attributes。
3. 初始化 DDDM coefficients 和 timestamp scaling。
4. 采样训练帧时间 $t$，计算 $t_s=s\cdot t+b$。
5. 对每个 Gaussian 计算 $\mu(t)$、$q(t)$、$c(t)$。
6. 用 3DGS rasterizer 渲染当前帧。
7. 用 photometric loss 和 regularization 反向传播。
8. 交替执行带 density control 和不带 density control 的优化阶段，在后一阶段加 KNN rigid loss。

### 6.3 Inference

Inference 时不需要 query neural deformation network。只需：

1. 输入时间 $t$。
2. 对每个 Gaussian 计算 DDDM residual。
3. 更新 position、rotation、radiance。
4. 用标准 3DGS rasterizer 渲染。

这解释了它能达到 125 FPS 的关键原因。

## 7. Experimental Setup and Results Summary

### 7.1 Datasets

D-NeRF:

* synthetic blender scenes。
* 用于比较 monocular dynamic reconstruction quality。

HyperNeRF:

* iPhone monocular real-world videos。
* 包含 rigid / non-rigid scenes、large motions、complex lighting、thin structures。
* 使用 4 个 `vrig` scenes。
* 图像下采样到 $540\times960$。

Plenoptic Video:

* 21 cameras，原始 resolution $2704\times2028$。
* 使用公开 6 scenes。
* 实验下采样到 $1352\times1014$。

### 7.2 Ablations

Regularization ablation:

| Variant | PSNR | SSIM |
|---|---:|---:|
| w/o KNN rigid | 28.48 | 0.92 |
| w/o Time smooth | 29.12 | 0.93 |
| full model | 29.92 | 0.94 |

Deformation model ablation:

* polynomial only: motion 更平滑，artifact 较少，但画面容易 blur。
* Fourier only: 高频细节更强，但 artifacts 更多。
* DDDM: 保留较 sharp details，同时减少 artifacts。

DDDM order ablation:

* 在 HyperNeRF 上，Fourier/order 增加到 16 时效果最好。
* 超过 32 后性能下降，推测因为 over-parameterization。

### 7.3 D-NeRF results

| Method | PSNR | SSIM | LPIPS |
|---|---:|---:|---:|
| TiNeuVox | 32.67 | 0.97 | 0.04 |
| K-Planes | 31.61 | 0.97 | / |
| 4D-GS | 33.30 | 0.98 | 0.03 |
| Gaussian-Flow | 34.27 | 0.98 | 0.03 |

### 7.4 HyperNeRF results

| Method | Train Time | FPS | Mean PSNR | Mean SSIM |
|---|---:|---:|---:|---:|
| NeRF | 16 h | 0.013 | 20.1 | 0.745 |
| Nerfies | 16 h | 0.011 | 22.2 | 0.803 |
| HyperNeRF | 32 h | 0.011 | 22.4 | 0.814 |
| NeRFPlayer | 6 h | 0.208 | 23.7 | 0.803 |
| TiNeuVox | 30 min | 0.5 | 24.3 | 0.837 |
| Ours 30K | 7 min | 125 | 25.6 | 0.847 |
| Ours 60K | 12 min | 125 | 26.3 | 0.862 |

### 7.5 Plenoptic Video results

| Method | Train Time | PSNR | SSIM |
|---|---:|---:|---:|
| LLFF | - | 23.2 | - |
| DyNeRF | 1344 h | 29.6 | 0.96 |
| NeRFPlayer | 5.5 h | 30.7 | - |
| K-Planes | 1.8 h | 31.6 | 0.96 |
| 4D-GS | 2 h | 31.0 | 0.94 |
| Ours 30K | 22.5 min | 30.5 | 0.97 |
| Ours 60K | 41.8 min | 32.0 | 0.97 |

## 8. Claimed Contribution vs Actual Technical Delta

### 8.1 Claimed contributions

* 提出 Gaussian-Flow，用 point-based differentiable rendering 做 dynamic 3D scene reconstruction。
* 提出 DDDM，避免 per-frame 3DGS 和 implicit neural fields。
* 证明 explicit Gaussian particle representation 支持 segmentation、editing 和 composition。

### 8.2 Actual technical delta

实际技术增量集中在动态模型的显式参数化：

* 不用 MLP deformation field，而为每个 Gaussian 存 polynomial + Fourier coefficients。
* 只对 position/rotation/radiance 建模时间变化，scale/opacity 不变。
* adaptive timestamp scaling 让每个 Gaussian 自适应局部运动速度。
* KNN rigid regularization 试图补回点表示缺少邻域连接的问题。

### 8.3 Trade-off

Gaussian-Flow 的 trade-off 很清楚：用 per-Gaussian explicit temporal functions 换取极快速度和高 FPS，但细结构和复杂局部运动可能受限于函数阶数、正则和 per-point independent modeling。

## 9. Limitations / Assumptions

* thin structures 的高保真保持仍不足，例如 HyperNeRF 3D Printer 的 thread 不清晰。
* 当前 deformation model 对复杂 motion patterns 的细节捕捉有限。
* Fourier/polynomial order 对性能敏感，过高会过参数化，过低会欠拟合。
* scale 和 opacity 固定可能限制拓扑变化、显著遮挡变化或 appearance density changes 的表达。
* per-Gaussian independent residual 需要正则维持空间一致性，否则容易失去局部连贯。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| Task | monocular/multi-view 4D reconstruction |
| Representation | dynamic 3D Gaussian particles |
| Motion model | explicit per-Gaussian DDDM |
| Time domain | polynomial residual |
| Frequency domain | Fourier series residual |
| Dynamic attributes | position, rotation, radiance |
| Static attributes | scale, opacity |
| Neural deformation field | no |
| Time adaptation | per-Gaussian timestamp scaling |
| Regularization | time smoothness, KNN rigid |
| Training | 30K/60K steps on RTX 4090 |
| HyperNeRF result | 7 min, 125 FPS, 25.6 PSNR for 30K |
| Plenoptic result | 41.8 min, 32.0 PSNR for 60K |
| Main weakness | thin structures and complex fine motion |

## 11. Reusable Components

* **Per-Gaussian temporal residuals**: 可替代 dynamic GS 中的 deformation MLP。
* **Polynomial + Fourier hybrid motion basis**: 适合显式粒子/点轨迹拟合。
* **Adaptive timestamp scaling**: 可用于任何 per-point temporal basis，缓解局部剧烈运动。
* **Alternating density-control / rigid-regularization schedule**: 解决动态增删点时 KNN constraint 难定义的问题。
* **Taichi parallel DDDM evaluation**: 对大量点的显式时间函数计算有工程参考价值。

## 12. Gap / Idea Seeds

* 为 thin structures 引入 geometry-aware local basis 或 anisotropic trajectory constraints。
* 让 scale/opacity 也有 sparse temporal residual，仅在需要时变化。
* 用 learned order selection 为每个 Gaussian 自适应选择 polynomial/Fourier 阶数。
* 将 DDDM 与 control-point / superpoint grouping 结合，减少 per-point 独立导致的噪声。
* 对 trajectory coefficients 加 frequency sparsity，降低 over-parameterization。
* 探索 DDDM 对 streaming/online dynamic 3DGS 的增量更新形式。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: Project URL 在 PDF 抽取中有空格，需确认最终链接是否为 `https://nju-3dv.github.io/projects/Gaussian-Flow`。
* `NEED_HUMAN_CHECK`: DDDM 中 polynomial/Fourier 默认阶数在主文图示提到 16 最好，但完整默认配置需查代码/supplement。
* `NEED_HUMAN_CHECK`: $D_{\mu_i}$ 的维度下标在 PDF 抽取中疑似有排版错误，position 应为 3D。
* `NEED_HUMAN_CHECK`: 正则权重 $\lambda_t,\lambda_s$ 未在主文抽取文本中明确。
* `NEED_HUMAN_CHECK`: 60K 与 30K 的 density-control schedule 是否相同需查代码。
* `NEED_HUMAN_CHECK`: editing/composition 能力在正文贡献中提到，但主文实验摘要中主要是重建质量，需看 project/supplement。

## 14. Evidence Anchors

* Abstract: DDDM models Gaussian attribute deformation with polynomial fitting and Fourier series fitting.
* Sec. 3.2: only rotation, radiance, and position change over time; scale and opacity remain constant.
* Eq. 5-7: $S(t)=S_0+D(t)$ and $D(t)=P_N(t)+F_L(t)$.
* Sec. 3.3: adaptive timestamp scaling $t_s=s\cdot t+b$.
* Sec. 3.4: time smoothness and KNN rigid regularizations.
* Eq. 9: $L_t=||D(t)-D(t+\epsilon)||_2$.
* Eq. 10: KNN residual consistency loss.
* Sec. 4.1: Adam settings, learning rates, 30K/60K steps, RTX 4090, Taichi implementation.
* Fig. 4: polynomial/Fourier/DDDM qualitative ablation.
* Fig. 5: DDDM order ablation.
* Table 1: regularization ablation.
* Table 2: D-NeRF quantitative comparison.
* Table 3: HyperNeRF time/FPS/PSNR comparison.
* Table 4: Plenoptic Video comparison.
* Sec. 6: limitation on thin structures and complex motion patterns.
