# Superpoint Gaussian Splatting for Real-Time High-Fidelity Dynamic Scene Reconstruction

## 0. Metadata

- Paper title: Superpoint Gaussian Splatting for Real-Time High-Fidelity Dynamic Scene Reconstruction
- Authors: Diwen Wan; Ruijie Lu; Gang Zeng
- Venue / year: ICML 2024
- Project / code: `https://dnvtmf.github.io/SP_GS.github.io`
- Zotero item key: `TYFWPSSL`
- Zotero PDF attachment key: `PQHA5D6V`
- Zotero PDF path: `/Users/wangyibo/Zotero/storage/PQHA5D6V/Wan 等 - 2024 - Superpoint Gaussian Splatting for Real-Time High-Fidelity Dynamic Scene Reconstruction.pdf`
- Local note path: `notes/Superpoint Gaussian Splatting for Real-Time High-Fidelity Dynamic Scene Reconstruction.md`

## 1. One-Sentence Technical Summary

SP-GS 将 canonical 3D Gaussians 聚合成具有相似刚性运动的 superpoints，只对 superpoints 预测时间相关的旋转和平移，再把该变形传播到组内 Gaussians，从而在动态场景中接近 3DGS 的实时渲染速度并保留较高画质。

## 2. Problem Formulation

输入是动态场景的单目或多视角视频及相机参数，目标是在任意时间和视角渲染高保真图像。直接给每个 Gaussian 配一个 deformation network 虽然灵活，但当 Gaussian 数量很大时，训练和推理成本会快速上升。SP-GS 的基本假设是：同一局部刚性区域内，相邻 Gaussians 的 translation 和 rotation 在所有时间上应相似，因此不必为每个 Gaussian 独立预测 deformation。

该问题可以看作 dynamic Gaussian representation 的分组运动建模：学习 canonical 3D Gaussians、学习 Gaussian-to-superpoint association、学习 superpoint deformation，并通过渲染损失与 property reconstruction loss 共同约束。

## 3. Method Overview

SP-GS 先进行 3k iterations warm-up，在不使用 deformation network 的情况下得到较稳定的 canonical 3D Gaussians。随后用 farthest point sampling 初始化 $M$ 个 superpoints，并维护一个 learnable association matrix $A \in \mathbb{R}^{P \times M}$，把 $P$ 个 Gaussians 软分配到 K-nearest superpoints。

每个 superpoint 的 canonical position $p_j^c$ 和时间 $t$ 经 positional encoding 后输入 superpoint deformation network $F$，输出 superpoint-level relative rotation $\Delta R_j^t$ 和 relative translation $\Delta t_j^t$。组内 Gaussian 的中心和旋转由对应 superpoint 的刚性变换得到。property reconstruction loss 让同一 superpoint 内的 Gaussian properties 更一致，强化 As-Rigid-As-Possible 先验。可选的 non-rigid network $G$ 可在 superpoint rigid motion 之后为每个 Gaussian 添加残差形变。

## 4. Method Details

### 4.1 Canonical 3D Gaussian Representation

每个 3D Gaussian $G_i$ 包含 center $\mu_i$、scale $s_i$、rotation quaternion $q_i$、opacity $\sigma_i$ 和 SH coefficients $h_i$。其 3D density 为：

$$
G_i(x)=\exp\left(-\frac{1}{2}(x-\mu_i)^\top\Sigma_i^{-1}(x-\mu_i)\right).
$$

covariance 分解为 $\Sigma_i=R_iS_iS_i^\top R_i^\top$。渲染时把 3D Gaussians 投影到相机平面，按 depth 排序并 alpha blend：

$$
C(p)=\sum_{i=1}^{P}c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j),
$$

其中 $\alpha_i=\sigma_i\exp\left(-\frac{1}{2}(p-\mu_i')^\top\Sigma_i'^{-1}(p-\mu_i')\right)$。基础图像损失沿用 3DGS：

$$
L_{\mathrm{img}}=(1-\lambda)L_1+\lambda L_{\mathrm{D\text{-}SSIM}},
$$

论文设置 $\lambda=0.2$。

### 4.2 Superpoint-Level Rigid Deformation

SP-GS 假设只有 center 和 rotation 随时间变化，opacity、scale、SH coefficients 保持不变。若 Gaussian $G_i$ 属于 superpoint $S_j$，则时间 $t$ 的中心与旋转为：

$$
\mu_i^t=\Delta R_j^t\mu_i^c+\Delta t_j^t, \qquad R_i^t=\Delta R_j^tR_i^c.
$$

superpoint deformation network $F$ 以 superpoint canonical position 和时间为输入：

$$
(\Delta R_j^t,\Delta t_j^t)=F(\gamma(p_j^c),\gamma(t)).
$$

位置编码为：

$$
\gamma(x)=\left(\sin(2^kx),\cos(2^kx)\right)_{k=0}^{L-1}.
$$

实验中，$\gamma(p_j^c)$ 使用 $L=10$，$\gamma(t)$ 使用 $L=6$。$F$ 是 8-layer MLP，hidden dimension 为 256。

### 4.3 Association Matrix and Local Superpoints

作者使用 learnable association matrix $A \in \mathbb{R}^{P \times M}$ 表示 Gaussians 到 superpoints 的关联。为了避免全连接分配，每个 Gaussian 只考虑 canonical space 中 K-nearest superpoints $N_i$。关联概率为：

$$
a_{ij}=
\begin{cases}
\frac{\exp(A_{ij})}{\sum_{j\in N_i}\exp(A_{ij})}, & j\in N_i,\\
0, & \mathrm{otherwise}.
\end{cases}
$$

最终用于变形的 hard assignment 是最大关联概率的 superpoint：

$$
j^\ast=\arg\max_{j\in N_i}a_{ij}.
$$

初始化时，用 farthest point sampling 选取 $M$ 个 Gaussian centers 作为 superpoints。若某 superpoint 由第 $i$ 个 Gaussian 初始化，则 $A_{ij}$ 初始化为 0.9，否则为 0.1。

### 4.4 Property Reconstruction Loss

property reconstruction loss 是 SP-GS 的关键正则。对于任意时间 $t$，Gaussian properties $v_i$ 可取 position $\mu_i^t$、relative rotation $\Delta R_i^t$ 或 relative translation $\Delta t_i^t$。先用 Gaussian properties 重建 superpoint property：

$$
R_{g\to sp}: u_j=\sum_{i\mid j\in N_i}\bar{a}_{ij}v_i,
\qquad
\bar{a}_{ij}=\frac{a_{ij}}{\sum_{i\mid j\in N_i}a_{ij}}.
$$

再从 adjacent superpoints 重建 Gaussian property：

$$
R_{sp\to g}: v_i'=\sum_{j\in N_i}a_{ij}u_j.
$$

property loss 为：

$$
L_v=\frac{1}{P}\sum_i\left\lVert v_i,v_i'\right\rVert.
$$

其中 rotation 使用 Lie algebra $\mathfrak{se}(3)$ 表示以支持线性插值。直观上，如果一个 superpoint 内的 Gaussians 真有相似运动，那么先聚合到 superpoint 再重建回 Gaussian 的误差应较小。

### 4.5 Inference Interpolation and Optional Non-Rigid Network

推理时可以预计算所有训练时间戳上的 superpoint deformations。对训练时间范围内的新时间 $t$，在最近两个时间戳 $t_1,t_2$ 之间线性插值：

$$
\Delta t_j^t=(1-w)\Delta t_j^{t_1}+w\Delta t_j^{t_2}, \qquad
\Delta R_j^t=(1-w)\Delta R_j^{t_1}+w\Delta R_j^{t_2},
$$

其中 $w=(t-t_1)/(t_2-t_1)$。消融显示插值与直接运行 $F$ 的画质几乎相同，但 FPS 更高。

对于非刚性动态，作者提供可选 network $G$，为每个 Gaussian 在 superpoint rigid motion 后预测 residual rotation 和 translation：

$$
(\hat{\Delta R}_i^t,\hat{\Delta t}_i^t)=G(\gamma(\mu_i^t),\gamma(t)).
$$

最终变形为：

$$
\mu_i^t=\hat{\Delta R}_i^t(\Delta R_j^t\mu_i^c+\Delta t_j^t)+\hat{\Delta t}_i^t,\qquad
R_i^t=\hat{\Delta R}_i^t\Delta R_j^tR_i^c.
$$

SP-GS+NG 先用 SP-GS pretrained model 初始化，再仅用 $L_{\mathrm{img}}$ 训练 non-rigid module 20k iterations。

## 5. Mathematical Objectives and Losses

SP-GS 总损失为图像渲染损失加 property reconstruction losses：

$$
L=L_{\mathrm{img}}+\sum_{v\in\{\mu^t,\Delta R^t,\Delta t^t\}}\lambda_vL_v.
$$

权重设置为 $\lambda_{\mu^t}=10^{-3}$，$\lambda_{\Delta R^t}=1$，$\lambda_{\Delta t^t}=1$。附录消融显示这些 loss weights 在较大范围内变化对结果影响较小，但 warm-up stage 对训练稳定性极其关键：D-NeRF 上无 warm-up 只有 21.56 PSNR，有 warm-up 达到 37.98 PSNR。

## 6. Training and Inference Procedure

训练流程：先从 SfM point clouds 或随机点云初始化 3D Gaussians；前 3k iterations 只训练 canonical Gaussians，不启用 deformation network；warm-up 后初始化 superpoints 和 association matrix；之后联合优化 canonical Gaussians、superpoint association、deformation network $F$ 和 property reconstruction loss；按 3DGS 策略进行 densification/pruning/opacity reset；若使用 SP-GS+NG，再在 SP-GS 基础上训练 non-rigid network $G$。

推理流程：对目标时间 $t$，获取或插值 superpoint deformations；根据 hard association $j^\ast$ 更新每个 Gaussian 的 center 和 rotation；可选地叠加 non-rigid residual；使用标准 differentiable Gaussian rasterizer 渲染。对于训练时间范围内渲染，预计算和插值显著提高 FPS。

## 7. Experimental Setup and Results Summary

数据集包括 D-NeRF synthetic dataset、HyperNeRF、NeRF-DS，以及附录中的 NVIDIA Dynamic Scene Dataset。指标包括 PSNR、SSIM/MS-SSIM、LPIPS、渲染分辨率和 FPS。实验在单张 NVIDIA V100 32GB 上进行。

速度上，SP-GS 是主要亮点：D-NeRF 平均 219.95 FPS，HyperNeRF 平均 117.86 FPS，NeRF-DS 平均 251.70 FPS；在 GTX 1060 上 D-NeRF 仍有 140.34 FPS，明显快于 D-3D-GS 和 4D-GS。作者在摘要中报告 synthetic 800 x 800 可达 227 FPS，real 536 x 960 可达 117 FPS。

画质上，SP-GS 在 D-NeRF 上接近或优于多数 NeRF-style baselines，但在若干场景低于 D-3D-GS；SP-GS+NG 在 HyperNeRF 平均 PSNR/MS-SSIM/LPIPS 达 26.78/0.8920/0.1805，高于 4D-GS 的 25.02/0.8377/0.2915。NeRF-DS 上 SP-GS 画质竞争力较弱但仍保持极高速度。NVIDIA Dynamic Scene Dataset 上，SP-GS 在部分序列效果好，但平均 PSNR 略低于 RoDynRF/Point-DynRF，说明速度和刚性分组假设之间存在权衡。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是把 superpoint/superpixel 思想引入 dynamic Gaussian splatting，实现高保真实时动态场景渲染。实际技术增量集中在“按运动相似性对 Gaussians 分组”而不是新的渲染器：标准 3DGS renderer 保持不变，动态部分由 superpoint-level deformation network 和 association matrix 负责。

相比 per-Gaussian deformation MLP，SP-GS 以局部刚性先验换取速度，适合大部分区域近似刚性或分段刚性的场景。property reconstruction loss 是让 association 学到有意义 motion groups 的关键，否则 superpoints 可能只是任意聚类。

与 4D-GS/HexPlane 类方法相比，SP-GS 的表达更显式、更便于编辑，因为 superpoints 形成可操作的 Gaussian groups；但对强非刚性和拓扑变化，纯 superpoint rigid deformation 可能不够，需要 SP-GS+NG 补偿。

## 9. Limitations / Assumptions

主要假设是局部 As-Rigid-As-Possible。对于柔性物体、流体、衣物、大形变拓扑变化或复杂 specular dynamics，superpoint rigid motion 可能表达不足。可选 non-rigid network 能缓解，但会降低速度并增加训练步骤。

方法依赖 warm-up 后 canonical Gaussians 的稳定性。若 warm-up 形状不可靠，superpoint 初始化和 association matrix 会受到连锁影响。附录显示无 warm-up 性能大幅下降，说明该流程对初始 canonical geometry 很敏感。

推理插值主要适用于训练时间范围内或相邻时间戳之间；对外推时间的动态预测能力没有被充分讨论。

## 10. Matrix-Ready Summary

| Dimension | Entry |
|---|---|
| Input | Monocular or multi-view dynamic video with camera poses |
| Output | Dynamic novel-view rendering |
| Representation | Canonical 3D Gaussians plus superpoint groups |
| Motion model | Superpoint-level rigid rotation/translation; optional per-Gaussian non-rigid residual |
| Association | Learnable $P \times M$ matrix restricted to K-nearest superpoints |
| Key regularizer | Property reconstruction loss for position, rotation, translation |
| Training schedule | 3k warm-up, then 40k SP-GS; optional +20k NG |
| Renderer | Standard Gaussian splatting after deforming Gaussians |
| Main advantage | Very high FPS with competitive visual quality |
| Main limitation | Local rigidity assumption and warm-up sensitivity |

## 11. Reusable Components

- Superpoint grouping for dynamic Gaussians: reduce deformation evaluations by predicting motion per group.
- Learnable local association matrix: soft grouping during training, hard assignment for deformation.
- Property reconstruction loss: enforce group-level consistency without manual segmentation labels.
- Precomputed deformation interpolation: trade negligible quality loss for large FPS gain.
- Optional residual non-rigid module: add capacity only where rigid superpoint motion is insufficient.

## 12. Gap / Idea Seeds

- Adaptive superpoint count: allocate more superpoints to highly deformable regions and fewer to rigid background.
- Confidence-based hard assignment: prevent ambiguous Gaussians near motion boundaries from receiving unstable group transforms.
- Temporal consistency loss on association matrix: avoid group identity flickering across long sequences.
- Combine superpoints with semantic/object masks so editing groups correspond better to meaningful objects.
- Learn extrapolatable motion models for superpoints rather than relying on interpolation between observed timestamps.

## 13. Human Check List

- NEED_HUMAN_CHECK: Confirm whether project code was released and whether URL has moved from the original project page.
- NEED_HUMAN_CHECK: Verify exact K-nearest superpoint hyperparameter $K$ from code/supplement; extracted text defines it but does not show the value.
- NEED_HUMAN_CHECK: Check whether the published version calls the optional module SP-GS+NG or SP-GS+NR consistently; extraction contains both variants.

## 14. Evidence Anchors

- Abstract and Introduction: superpoints aggregate Gaussians with similar rotation/translation/location; real-time rendering and editing capability.
- Section 3.2: Eq. 5-8 superpoint deformation, positional encoding, inference interpolation.
- Section 3.3: association matrix, K-nearest superpoints, Gaussian-to-superpoint and superpoint-to-Gaussian reconstruction, property loss.
- Section 3.4: total loss, warm-up, optimizer and training schedule.
- Section 3.5: optional non-rigid deformation network and final transform.
- Appendix Tables 7-15: speed on different devices, training time, warm-up and interpolation ablations.
