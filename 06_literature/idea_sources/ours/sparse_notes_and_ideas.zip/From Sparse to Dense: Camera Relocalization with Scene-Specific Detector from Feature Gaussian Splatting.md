# From Sparse to Dense: Camera Relocalization with Scene-Specific Detector from Feature Gaussian Splatting

## 0. 元数据

* Title: From Sparse to Dense: Camera Relocalization with Scene-Specific Detector from Feature Gaussian Splatting
* Authors: Zhiwei Huang; Hailin Yu; Yichun Shentu; Jin Yuan; Guofeng Zhang
* Year: 2025
* Venue: CVPR
* PDF source: `/Users/wangyibo/Zotero/storage/28D27EA9/Huang 等 - From Sparse to Dense Camera Relocalization with Scene-Specific Detector from Feature Gaussian Splat.pdf`
* Zotero item key: `M5LRNKLB`
* Zotero PDF attachment key: `28D27EA9`
* Code: `https://zju3dv.github.io/STDLoc`
* Project page: `https://zju3dv.github.io/STDLoc`
* Dataset link: Not specified
* Main task: camera relocalization with Feature Gaussian scene representation
* Domain: visual localization, 3DGS feature field, sparse-to-dense matching
* Input: pre-built scene Feature Gaussian, query image
* Output: query camera 6DoF pose

## 1. 一句话技术摘要

STDLoc 将 3DGS 扩展为同时渲染 RGB 与局部特征的 Feature Gaussian，先通过 matching-oriented sampling 和 scene-specific detector 选出少量可匹配 landmarks 做 2D-3D sparse PnP 初定位，再渲染 dense feature map 与 query feature map 做 coarse-to-fine dense matching 来精定位。

## 2. 问题形式化

论文目标不是 novel view synthesis，而是 camera relocalization：给定 query image $I_q$ 和预建场景地图，估计 query 相机在场景坐标中的 6DoF pose。传统结构化方法依赖 SfM sparse point cloud 与局部特征匹配，弱纹理下 correspondences 不足；SCR 方法在室内较强但对大室外场景扩展有限；NeRF/GS inverse rendering 类方法常需要外部 initial pose 或受光照变化影响。

STDLoc 的形式化思路是用 Feature Gaussian 作为场景地图 $\mathcal{G}$，将定位分成 sparse stage 和 dense stage。Sparse stage 从 sampled landmarks $\tilde{\mathcal{G}}$ 与 query sparse features 建立 2D-3D correspondences，PnP 得到初始 pose $\xi_{\text{sparse}}$；dense stage 在 $\xi_{\text{sparse}}$ 下渲染 feature map 和 depth map，通过 dense feature matching 得到更多 2D-3D correspondences，PnP/RANSAC 得到精化 pose $\xi_{\text{dense}}$。

## 3. 方法概览

STDLoc 包含四个核心部分。

第一，Feature Gaussian training：在标准 3DGS primitive 上增加 feature attribute $f_i$，让 Gaussian 不仅能渲染 RGB，也能渲染由 SuperPoint/R2D2 等局部特征 extractor 蒸馏出的 dense feature map。

第二，matching-oriented sampling：从百万级 Gaussians 中选出几千个适合匹配的 landmarks。选择标准同时考虑特征可匹配性和空间分布，避免只选纹理丰富区域。

第三，scene-specific detector：训练一个针对当前场景的浅层 CNN，从 query dense feature map 中检测最适合与 sampled landmarks 匹配的 2D keypoints，而不是使用通用 SuperPoint keypoints。

第四，sparse-to-dense localization：先用 sparse landmark matching + PnP 得到 pose，再渲染 dense feature field 并做 coarse-to-fine dense matching refinement。

## 4. 方法细节

**Feature Gaussian。** 第 $i$ 个 Gaussian primitive 的可训练属性为 center $x_i$、rotation $q_i$、scale $s_i$、opacity $\alpha_i$、color $c_i$ 和 feature $f_i$。训练时颜色属性通过 alpha blending 渲染为 RGB，feature 属性用同样 rasterization 渲染为 feature map $\hat{F}_s$。ground-truth feature map $F_t(I)$ 来自通用 dense/local feature extractor，例如 SuperPoint。

**Matching-oriented sampling。** 直接把 query feature map 与所有 Gaussians 匹配不可行，而且大量 ambiguous Gaussians 会干扰匹配。STDLoc 先为每个 Gaussian 计算 matching score：把 Gaussian center 投影到每张可见训练图像中，在 $F_t(I)$ 上双线性采样 2D feature，与 Gaussian feature $f_i$ 做 cosine similarity，再在所有可见图像上平均。随后先用 random/farthest point sampling 取 anchors 保证空间分布，再对每个 anchor 找空间 $k$NN，在邻域中选 matching score 最高的 Gaussian 作为 landmark。

**Scene-specific detector。** 即使 landmarks 已减少到几千个，直接和 dense query feature 全匹配仍然昂贵，并且天空等无效区域会产生坏匹配。作者训练 shallow CNN $D_{\theta}$，输入 dense feature map $F_t(I)$，输出 heatmap $\hat{K}$，表示每个 2D feature 是否是当前场景 landmark 的概率。训练标签来自将 sampled landmark centers 投影到训练图像中得到的 binary heatmap $K$。推理时对 heatmap 做 NMS，并采样 2048 keypoints。

**Sparse stage。** 对 query image 提取 dense feature map，再用 $D_{\theta}$ 检测 sparse local features。每个 query local feature 与所有 sampled landmark features 计算 cosine similarity，取最高相似 landmark 作为匹配，形成 2D-3D correspondences。用 PnP + RANSAC 得到 $\xi_{\text{sparse}}$。

**Dense stage。** 在 $\xi_{\text{sparse}}$ 下从完整 Feature Gaussian $\mathcal{G}$ 渲染 dense feature map $\hat{F}_s$ 和 depth map $\hat{D}$。先在低分辨率上计算 query feature map 与 rendered feature map 的 correlation matrix，dual-softmax 得到 matching probability，MNN 得到 coarse matches；再围绕 coarse matches 在高分辨率 feature map 中裁剪 $8\times8$ patches，重复 correlation + dual-softmax + MNN 得到 refined matches。最后用 rendered depth 将 2D correspondences lift 到 3D，再通过 PnP + RANSAC 得到 $\xi_{\text{dense}}$。dense stage 可迭代。

## 5. 数学目标与损失

Feature Gaussian 的 RGB loss 为：

$$
L_{\text{rgb}}=(1-\lambda)L_1(I,\hat{I})+\lambda L_{\text{D-SSIM}}(I,\hat{I})
$$

Feature field loss 为：

$$
L_f=L_1(F_t(I),\hat{F}_s)
$$

总训练损失为：

$$
L=\alpha L_{\text{rgb}}+\beta L_f
$$

实现中 $\lambda=0.2$、$\alpha=1.0$、$\beta=1.0$。

Gaussian matching score 为：

$$
s(g_i)=\frac{1}{|V_i|}\sum_{I\in V_i}\langle f_i,F_t(I)[u_i,v_i]\rangle
$$

其中 $V_i$ 是 Gaussian $g_i$ 可见的训练图像集合，$(u_i,v_i)$ 是 $g_i$ center 投影到图像 $I$ 的坐标，$F_t(I)[u_i,v_i]$ 通过双线性插值得到。

Scene-specific detector 输出：

$$
\hat{K}=D_{\theta}(F_t(I))
$$

Detector 训练使用 binary cross-entropy：

$$
L_{\text{det}}=-K\log(\hat{K})-(1-K)\log(1-\hat{K})
$$

Dense matching 的 coarse probability 为：

$$
P_c=\text{softmax}(\frac{1}{\tau}S_c)_{\text{row}}\cdot\text{softmax}(\frac{1}{\tau}S_c)_{\text{col}}
$$

其中 $S_c$ 是 coarse feature maps 的 cosine similarity correlation matrix，$\tau$ 是 temperature。

## 6. 训练与推理流程

1. 使用 SfM point cloud 初始化 3DGS。
2. 用训练图像和 feature extractor 生成 $F_t(I)$。
3. 联合优化 RGB radiance field 和 feature field，得到 Feature Gaussian $\mathcal{G}$。每个场景训练 30,000 steps。
4. 对所有 Gaussians 计算 matching score。
5. 通过 anchor sampling + $k$NN + highest-score selection 得到 sampled landmarks $\tilde{\mathcal{G}}$。默认 anchors 为 16,384，nearest neighbors 为 32。
6. 将 landmarks 投影到训练图像生成 heatmap labels，训练 4-layer CNN scene-specific detector 30,000 steps。
7. 推理时，对 query image 提取 dense feature map，用 detector + NMS 选 2048 keypoints。
8. Sparse matching sampled landmarks，PnP/RANSAC 得到 initial pose。
9. 在 initial pose 下渲染 dense feature map 和 depth map，做 coarse-to-fine dense matching。
10. 用 refined 2D-3D correspondences 通过 PnP/RANSAC 得到 final pose；7-Scenes 做 4 次 dense iteration，Cambridge Landmarks 做 1 次。

训练细节：Feature field learning rate 为 0.001；默认 feature extractor 为 SuperPoint；Cambridge Landmarks 中使用 off-the-shelf segmentation mask 去掉动态物体和天空，并用 CLAHE 处理光照变化。单 RTX4090 上每场景 Feature Gaussian 约 90 分钟，detector 约 30 分钟。推理在 Cambridge Landmarks 上约 7 FPS。

## 7. 实验设置与结果摘要

数据集为 7-Scenes 和 Cambridge Landmarks。7-Scenes 是手持相机室内序列，包含强/弱纹理场景；Cambridge Landmarks 是手机拍摄的室外场景，含动态遮挡、光照变化和运动模糊。指标为 median translation/rotation error，以及 recall 阈值。

Baselines 包括 structure-based AS、HLoc、DVLAD+R2D2，regression/SCR 方法 DSAC*、ACE、NBE+SLD、NeuMap、GLACE，以及 radiance field-based DFNet+NeFeS、CROSSFIRE、PNeRFLoc、NeRFMatch 等。

7-Scenes 中，STDLoc 在平均 median error 和 recall 上达到最佳。表 3 显示平均 recall 为 99.1% at 5cm/5°、90.9% at 2cm/2°，高于 HLoc、DSAC*、ACE、NeRFMatch。

Cambridge Landmarks 中，STDLoc 平均误差为 10.1 cm / 0.14°，优于 NeRFMatch 的 14.5 cm / 0.29° 和 PNeRFLoc 的 35.8 cm / 0.35°。作者指出在个别 outdoor scenes 中，由于 3D Gaussian reconstruction 不足，translation accuracy 略低于 HLoc 或 NeuMap，但平均指标仍最好。

Ablation 表 4 显示 matching-oriented sampling 和 scene-specific detector 都有效：RS+M.O.+S.S.D. 达到 99.6% at 5m/10° 和 99.1% at 2m/5°，高于 FPS+SuperPoint 的 57.9%/47.1%。表 5 显示 sparse stage 已比 image retrieval 强很多；Dense (Feat.) 将平均误差从 13.8 cm / 0.21° 提升到 10.1 cm / 0.14°，而 Dense (RGB) 反而变差，说明直接渲染特征比先渲染 RGB 再提特征更抗光照和噪声。

## 8. 声称贡献与实际技术增量

* 声称贡献 1: sparse-to-dense relocalization pipeline。实际增量是用 Gaussian landmark sparse matching 做 coarse pose，再用渲染 feature field 做 dense refinement。
* 声称贡献 2: matching-oriented Gaussian sampling。实际增量是把 feature matchability 与空间覆盖结合，解决百万 Gaussians 不能全匹配的问题。
* 声称贡献 3: scene-specific detector。实际增量是从 Feature Gaussian landmarks 自动生成 detector supervision，让 detector 选择最适合本场景 landmark matching 的 query keypoints。
* 声称贡献 4: robust localization。实际证据来自室内弱纹理和室外光照变化场景，但依赖预建 Feature Gaussian。
* 与 sparse-view GS 的关系: 本文标题中的 sparse-to-dense 指 localization pipeline 中 sparse landmarks 到 dense feature matching，不是 sparse input view reconstruction。

## 9. 局限与隐含假设

* 需要为每个场景训练 Feature Gaussian 和 scene-specific detector，建图成本约 2 小时/场景。
* 受 Feature Gaussian 训练限制，作者明确说明方法暂不能扩展到 very large scenes，可能需要 LoD 或 chunked training。
* 3DGS floating artifacts 会影响 localization，dense stage 有轻微 recall 损失也与 floaters 遮挡 feature/RGB rendering 有关。
* 需要 SfM 初始化和训练图像；不是完全无地图 localization。
* 对动态物体和天空需要额外 mask；Cambridge 中使用了 segmentation 和 CLAHE，说明原始 Feature Gaussian/RGB 对光照和动态干扰仍敏感。
* Sparse stage 的 matching 是每个 query feature 对所有 landmarks 取最高相似，复杂场景中可能需要 ratio test、mutual check 或 uncertainty。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法类别 | Feature Gaussian based camera relocalization |
| 核心表示 | 3DGS primitives augmented with feature attributes |
| 核心流程 | Sparse landmark matching + dense feature field refinement |
| 输入 | Query image; pre-trained scene Feature Gaussian |
| 输出 | 6DoF camera pose |
| 关键模块 | Matching-oriented sampling; scene-specific detector; rendered dense feature matching |
| 主要优势 | 不依赖 pose prior，室内外定位精度高，抗弱纹理/光照变化 |
| 主要风险 | 每场景训练成本、very large scenes、3DGS floaters |

## 11. 对我研究可复用的组件

* **Feature Gaussian as matching map**: 可把 3DGS 从 NVS 表示扩展成 localization/matching 表示。
* **Matching-oriented sampling**: 对 Gaussian primitives 计算可匹配性分数，用于选择稳定 landmarks、pruning 或 active view planning。
* **Scene-specific detector self-supervision**: 通过投影 3D landmarks 自动生成 2D detector heatmap，避免手工标注。
* **Rendered feature map dense refinement**: 比 photometric alignment 更适合光照变化场景，可用于 GS pose refinement。
* **Sparse-to-dense two-stage design**: 先 robust coarse pose，再高精度 dense matching，适合无 pose prior 的重定位。

## 12. 缺口与想法种子

* **Sparse-view Feature Gaussian**: 将 STDLoc 与 sparse-view GS 正则结合，减少建图视角数量，同时保持 localization feature field 稳定。
* **Uncertainty-aware landmark sampling**: 在 matching score 外加入 visibility uncertainty、geometry uncertainty 和 Gaussian opacity stability。
* **Chunked STDLoc**: 对大场景分块训练 Feature Gaussian，并用 learned place recognition 或 landmark routing 选择 chunk。
* **Floaters-aware dense matching**: 用 depth uncertainty 或 alpha accumulation 过滤由 floaters 渲染出的错误 feature correspondences。
* **Joint localization-reconstruction loop**: 用 query localization 成功后的新视角反哺 Feature Gaussian，逐步从 sparse map 扩展到 denser map。

## 13. 人工检查清单

* `NEED_HUMAN_CHECK`: appendix 中各模块运行时间的完整表格。
* `NEED_HUMAN_CHECK`: failure case study，尤其是 floaters 和大场景失败模式。
* `NEED_HUMAN_CHECK`: dense stage 中 PoseLib 使用的具体 PnP/RANSAC 参数。
* `NEED_HUMAN_CHECK`: scene-specific detector heatmap 是否对多个 landmark 投影冲突做半径扩张或 soft label。

## 14. 证据锚点

* Abstract: STDLoc 使用 Feature Gaussian，无 pose prior 完成 relocalization，并提出 sparse-to-dense paradigm。
* Fig. 1: sparse landmarks 和 dense feature field 支持 localization。
* Sec. 1: 对传统 feature matching、SCR、NeRF/GS localization 的问题分析和四项贡献。
* Sec. 3 / Fig. 2: Feature Gaussian 同时优化 radiance field 和 feature field。
* Sec. 3.1 / Eq. (1)-(3): $L_{\text{rgb}}$、$L_f$ 和总损失。
* Sec. 3.2 / Fig. 3 / Eq. (4): matching-oriented sampling 和 Gaussian score。
* Sec. 3.3 / Fig. 4 / Eq. (5)-(6): scene-specific detector 和 BCE training。
* Sec. 3.4 / Fig. 5 / Eq. (7): sparse-to-dense localization、dual-softmax 和 MNN matching。
* Sec. 4: 7-Scenes、Cambridge Landmarks、训练和定位细节。
* Table 3: 7-Scenes recall。
* Table 4: sampling strategy 与 detector ablation。
* Table 5: image retrieval、sparse、dense RGB、dense feature pipeline ablation。
* Table 6: 3DGS/2DGS 与 SuperPoint/R2D2 feature 的组合实验。
* Sec. 5: limitations 包括 large scenes 和 3DGS floating artifacts。
