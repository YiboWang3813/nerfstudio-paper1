# ProDyG: Progressive Dynamic Scene Reconstruction via Gaussian Splatting from Monocular Videos

## 0. Metadata

- Title: ProDyG: Progressive Dynamic Scene Reconstruction via Gaussian Splatting from Monocular Videos
- Authors: Shi Chen; Erik Sandström; Sandro Lombardi; Siyuan Li; Martin R. Oswald
- Venue/Year: NeurIPS 2025
- Project page: https://cs-vision.github.io/ProDyG.github.io
- Zotero item key: `5LBGWHIC`
- Zotero PDF attachment key: `MJEDLLPZ`
- PDF path: `/Users/wangyibo/Zotero/storage/MJEDLLPZ/Chen 等 - ProDyG Progressive Dynamic Scene Reconstruction via Gaussian Splatting from Monocular Videos.pdf`
- Local note path: `notes/ProDyG: Progressive Dynamic Scene Reconstruction via Gaussian Splatting from Monocular Videos.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

ProDyG 把 Splat-SLAM 的在线位姿/静态地图更新与 MoSca 的动态 Motion Scaffolds 结合起来，用 residual-flow + SAM2 motion masks 做 motion-agnostic tracking，并以 progressive batch update 的方式在线扩展动态 Gaussians 和 scaffold nodes，从 monocular RGB 或 RGB-D 视频中同时保持全局位姿一致性和动态 NVS 表达。

## 2. Problem Formulation

论文目标是 practical dynamic 3D reconstruction：系统应在线运行，保持全局 pose/map consistency，能用 3DGS 表达细节，同时支持 RGB 和 RGB-D 输入。现有动态 SLAM 往往过滤动态物体，只重建静态背景；离线动态重建方法质量高但需要全局优化，不适合长视频和在线使用；feed-forward transformer 方法速度快但缺少全局一致性和外观细节。

ProDyG 将问题拆成两个耦合任务：在动态场景中鲁棒跟踪相机，并渐进式重建静态背景和动态前景。静态部分用 Splat-SLAM 的 3DGS map deformation 和 photometric optimization 维护；动态部分用 Motion Scaffolds 驱动 dynamic Gaussians，并随新帧 batch 增量扩展。

## 3. Method Overview

系统从 online RGB stream 出发，先在 Splat-SLAM 的 DBA 后端中估计相机和 keyframe disparities。为了避免动态物体破坏 tracking，ProDyG 根据 optical flow 与 camera-induced flow 的残差生成 coarse motion masks，再用 SAM2 point prompts 细化成 per-frame fine motion masks，并在 DBA confidence weights 中抑制动态区域。

重建阶段中，静态背景按 Splat-SLAM 更新；动态区域内用 CoTracker3 生成 2D tracks，结合相机位姿和 depth 提升为 3D tracks，初始化 MoSca nodes 和 dynamic Gaussians。每来一批新帧，系统用 overlap tracks 保持时间连续性，检测 newly-seen dynamic regions，补充新的 tracks/nodes/Gaussians，并在局部时间窗口中继续几何与 photometric 优化。

## 4. Method Details

### 4.1 Motion-Agnostic Camera Tracking

ProDyG 继承 Splat-SLAM 的 factor graph，优化 keyframe camera extrinsics $\omega_i$ 和 disparities $d_i$。DBA 的 reprojection error 使用 optical flow prediction $\tilde p_{ij}$ 与由当前几何投影得到的 $p_{ij}$，并通过 confidence weights 控制每个像素的影响。动态区域的置信权重会被 mask suppression。

coarse motion mask 来自 residual flow：$\hat r_{ij}=\tilde p_{ij}-p_{ij}$，即 optical-flow motion 减去 camera-induced flow。静态区域的 residual 应接近 0，动态区域 residual 较大。对 keyframe $i$，作者计算连接 target keyframes 上的 normalized mean residual magnitude $\bar r_i(x,y)$，并取 top 20% 阈值得到 coarse mask $C_i$。

### 4.2 Semantic-Guided Motion Mask Refinement

coarse masks 边界不够精确，ProDyG 用 SAM2 进一步生成 fine motion masks $M_i$。初始化时，对 median-filtered coarse masks 的 connected regions 取 centroid 作为 point prompts。增量阶段中，已有 object-wise masks 会传播到新帧，同时用 coarse masks 添加新的 segmentation，并用 prompt point candidates 数量过滤 false positives。随后 DBA 中把 coarse mask 替换为 fine mask，权重形式为 $\Sigma'_{ij}=\mathrm{diag}(w_{ij}(1-M_i))$。

这个设计的权衡很明确：tracking 需要抑制动态干扰，但 reconstruction 又需要准确的动态边界。相比只重建静态背景的 WildGS-SLAM，ProDyG 不能过度扩张 mask，否则会损害动态对象重建。

### 4.3 Static and Dynamic Map Representation

场景地图写作 $G=\{G_s,G_d(t)\}$。静态 Gaussians $G_s$ 与动态 Gaussians $G_d(t)$ 都有 mean $\mu_i$、rotation $R_i$、scale $s_i$、opacity $o_i$ 和 color $c_i$。渲染除了 RGB $C(p)$ 外，还使用 RaDe-GS 的 depth rendering $D_r(p)$，并额外计算 opacity map $O(p)$，用于后续 motion mask loss。

静态背景随 SLAM 后端的 pose/depth 更新进行 3DGS map deformation 和 photometric optimization。动态 Gaussians 不直接固定在世界坐标，而是定义在 MoSca node 的相对结构中；当 SLAM 的 pose/depth 更新时，Motion Scaffold nodes 会重新 anchor 到 3D，从而在优化前就保持动态 map consistency。

### 4.4 Non-Keyframe Poses and Dense Depths

Splat-SLAM 为效率只在 sparse keyframes 上做后端优化，但动态 reconstruction 需要 temporally dense supervision。ProDyG 对两个 keyframes 之间的 non-keyframes 建立 temporary local graph，运行 DROID-SLAM 风格 recurrent update 和 DBA，得到 non-keyframe poses。

non-keyframe depth 由邻近 keyframes 的 depths 反投影到 3D，再投影到目标 non-keyframe 得到 reprojection depth $D_t^{\mathrm{repro}}$。动态像素和 multi-view consistency 无效点会被过滤。最后把 monocular depth $D_t^{\mathrm{mono}}$ 用 scale $\theta_t$ 和 shift $\gamma_t$ 对齐到 reprojection depth：

$$
\theta_t,\gamma_t=\arg\min_{\theta,\gamma}\sum_{u,v}((\theta D_t^{\mathrm{mono}}(u,v)+\gamma)-D_t^{\mathrm{repro}}(u,v))^2,\quad D_t^{\mathrm{aligned}}=\theta_tD_t^{\mathrm{mono}}+\gamma_t.
$$

### 4.5 Dynamic Motion Scaffolds and Gaussians

ProDyG 采用 MoSca 的 Motion Scaffold。每个节点 $v^{(m)}=([Q_1^{(m)},Q_2^{(m)},\ldots,Q_T^{(m)}],r^{(m)})$，其中 $Q_t^{(m)}\in SE(3)$，$r^{(m)}$ 是 RBF radius。节点由 fine motion masks 内的 CoTracker3 2D trajectories 提升到 3D 后初始化；不可见时刻通过邻近可见观测线性插值。

动态 Gaussian 从参考时刻 $t_i^{\mathrm{ref}}$ warp 到查询时刻 $t$：

$$
G_d(t)=\{(T_i(t)\mu_i,T_i(t)R_i,s_i,o_i,c_i)\mid T_i(t)=W(\mu_i,w(\mu_i)+\Delta w_i;t_i^{\mathrm{ref}},t)\}_{i=1}^{N_d}.
$$

其中 $w(\cdot)$ 是 MoSca RBF skinning weights，$\Delta w_i$ 是 learnable per-Gaussian correction。warping function $W$ 使用 DQB，节点相对变换为 $\Delta Q^{(m)}=Q_{t_{\mathrm{dst}}}^{(m)}(Q_{t_{\mathrm{src}}}^{(m)})^{-1}$。

### 4.6 Progressive Construction

初始 bootstrapping 后，系统先在 fine motion masks 内运行 CoTracker3，提升 2D tracks 到 3D，采样为初始 MoSca nodes；然后按 MoSca 进行 geometry optimization，优化 ARAP、velocity consistency 和 acceleration consistency；再从 motion mask 内 back-projected pixels 初始化 dynamic Gaussians，并进行 photometric optimization。

增量更新时，每个新 frame batch 与已处理帧保留 8-frame overlap。系统先找 overlap 中至少 4 帧可见的 recently visible tracks 并延长到新 batch；再把新帧 motion masks 中没有邻近 3D track 的 pixels 标为 newly-seen，针对这些区域再次运行 tracker；最后还会在新帧全部动态区域运行第三次 tracking pass，以补足 track density。新 tracks 会提升到 3D，并用上一轮 Motion Scaffolds 通过 DQB warp 到过去时刻，以保持 temporal continuity。

## 5. Mathematical Objectives and Losses

动态 photometric optimization 沿用 MoSca 的 $L_{\mathrm{rgb}}$、$L_{\mathrm{depth}}$、$L_{\mathrm{track}}$、ARAP、velocity 和 acceleration losses。ProDyG 的新增项是 motion mask loss，用来阻止 dynamic Gaussians 泄漏到静态区域：

$$
L_{\mathrm{mask}}=\frac{1}{|P_t^{\mathrm{static}}|}\sum_{p\in P_t^{\mathrm{static}}}O(p).
$$

这里 $P_t^{\mathrm{static}}$ 是 motion mask $M_t$ 的反集，$O(p)$ 是 dynamic Gaussians 的 accumulated opacity。实验中 $\lambda_{\mathrm{mask}}=1$，其余 geometry / photometric loss weights 保持与 MoSca 相同。

方法的核心数学不在新渲染公式，而在三个约束耦合：residual-flow mask 让 DBA 不被动态物体拖偏；Motion Scaffold 让动态 Gaussians 通过低维节点保持跨时刻一致；motion mask loss 让动态/静态 Gaussian 分解在 photometric optimization 中不互相污染。

## 6. Training and Inference Procedure

ProDyG 是 online progressive pipeline。输入流进入 SLAM 后端后，keyframe selection 触发 tracking、mask refinement、static map deformation 和 dynamic reconstruction。每个 batch 都先更新相机、depth 和 motion masks，再扩展或优化 Motion Scaffolds 和 dynamic Gaussians。

如果使用 RGB-D 输入，depth supervision 和 pose estimation 有更直接的尺度信息；RGB-only 模式下，系统依赖 Splat-SLAM / monocular depth alignment 维持几何尺度。渲染时，静态背景 Gaussians 和通过 Motion Scaffold warp 到目标时刻的动态 Gaussians 一起 rasterize，输出 RGB / depth / opacity。

## 7. Experimental Setup and Results Summary

tracking 在 Bonn RGB-D Dynamic Dataset 和 TUM RGB-D dynamic scenes 上评估，指标为 ATE RMSE [cm]。Bonn 平均 ATE 中，ProDyG 为 3.29，优于 Splat-SLAM RGB 的 10.6、DROID-SLAM 的 5.3，也接近 WildGS-SLAM 的 2.94。TUM 平均 ATE 中，ProDyG 为 1.89，优于 Splat-SLAM 的 2.43、DROID-SLAM 的 2.25，略弱于 WildGS-SLAM / MegaSaM 的 1.63。

NVS 在 iPhone dataset 的 5 个 Shape-of-Motion sequences 上以 2x downsampled resolution 评估，指标为 PSNR、SSIM、LPIPS。MoSca 离线方法为 18.44 / 0.666 / 0.311。ProDyG 在在线 reconstruction、非在线 tracking、RGB-D setting 下为 17.65 / 0.634 / 0.390；在线 reconstruction + online tracking + RGB-D 下为 17.87 / 0.643 / 0.377。RGB-only 版本仍能运行，分别报告 15.41 / 0.603 / 0.462 和 15.40 / 0.582 / 0.492。

论文强调 ProDyG 是第一个支持从 monocular RGB 在线重建动态 3DGS 并做高质量 NVS 的方法。它在强约束在线设定下接近 MoSca 这类离线方法，并明显超过在线但依赖 precomputed poses 的 DynOMo，后者 NVS 为 11.98 / 0.436 / 0.748。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称的贡献包括 motion mask prediction、online Motion Scaffold dynamic reconstruction、RGB/RGB-D 支持和接近离线方法的 NVS 质量。实际技术增量主要是系统级：把 Splat-SLAM 的在线全局一致 tracking/mapping 与 MoSca 的 dynamic Gaussian representation 连接起来，并补齐在线场景所需的 mask refinement、non-keyframe depth/pose、progressive track extension 和 newly-seen region handling。

与 MoSca 相比，ProDyG 的 Motion Scaffold 本身不是新表示；新意在于如何让它在 streaming SLAM 中可增量更新。与动态 SLAM 相比，它不只过滤动态物体，而是保留并重建动态前景，用 3DGS 提供可渲染外观。

## 9. Limitations / Assumptions

论文明确指出，当物体大部分时间移出视锥后又重新出现时，Motion Scaffolds 缺少 photometric constraints，优化会被 regularization 主导，容易产生不期望的 deformation。

系统仍需要 per-scene test-time optimization，因此虽然 pipeline 是在线渐进式的，并不等价于无需优化的实时 feed-forward 重建。

大幅 novel viewpoint change 仍然困难，因为从单目视频中未观测区域无法凭几何约束恢复，需要 generative models 或 data-driven priors 去补全 unseen regions。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Online RGB stream；可选 RGB-D |
| Output | Static 3DGS + Motion-Scaffold-driven dynamic 3DGS |
| Tracking backend | Splat-SLAM / DBA with dynamic mask suppression |
| Motion mask | Residual flow coarse mask + SAM2 fine mask |
| Dynamic representation | MoSca nodes + dynamic Gaussians + DQB warping |
| Progressive update | 8-frame overlap, recently visible tracks, newly-seen regions, repeated CoTracker3 passes |
| Main new loss | Dynamic Gaussian opacity penalty on static pixels |
| Strength | 在线、全局一致、能重建动态前景而非只过滤 |
| Weakness | 依赖 test-time optimization；出视锥再出现和大视角外推困难 |

## 11. Reusable Components

- residual optical flow minus camera-induced flow for dynamic mask generation。
- SAM2 point-prompt refinement from coarse SLAM residual masks。
- fine motion mask injected into DBA confidence weights as dynamic suppression。
- non-keyframe pose/depth derivation for dense dynamic reconstruction supervision。
- progressive Motion Scaffold extension with overlap tracks and newly-seen region tracking。
- motion mask opacity loss for separating static and dynamic Gaussians。

## 12. Gap / Idea Seeds

- ProDyG 的 mask 边界必须同时服务 tracking 和 dynamic reconstruction，可以研究 separate masks：tracking 用更宽 soft uncertainty，reconstruction 用更精确 object boundary。
- 出视锥再出现的问题可以结合 object-level memory 或 learned shape priors，而不是完全依赖 Motion Scaffold regularization。
- newly-seen region detection 依赖 fixed spherical search radius $r_{\mathrm{search}}=0.02$m，可改成尺度自适应或 uncertainty-aware。
- RGB-only NVS 指标仍明显低于 RGB-D/离线版本，说明 monocular depth alignment 和 progressive optimization 还有尺度漂移空间。

## 13. Human Check List

- NEED_HUMAN_CHECK: 项目页在 PDF 中写作 `cs-vision.github.io/ProDyG.github.io`，本笔记补全为 `https://cs-vision.github.io/ProDyG.github.io`。
- NEED_HUMAN_CHECK: PDF 未给出完整 supplement 细节，本笔记只记录主文可核对的算法和实验设置。
- NEED_HUMAN_CHECK: RGB-only ProDyG 在 Table 2 有两个列配置，分别对应是否 online tracking；本笔记按表格顺序记录。

## 14. Evidence Anchors

- Section 3.1: flow residual mask、SAM2 refinement、DBA confidence suppression。
- Section 3.2: static/dynamic Gaussian map representation and RGB/depth/opacity rendering。
- Section 3.3: non-keyframe poses/depths、Motion Scaffolds、dynamic Gaussian warping、progressive construction。
- Equation 11: motion mask loss。
- Table 1: Bonn / TUM tracking ATE RMSE。
- Table 2: iPhone dataset novel view synthesis under online/RGB-only settings。
- Limitations paragraph in Section 4.3: out-of-frustum reappearance、test-time optimization、large viewpoint changes。
