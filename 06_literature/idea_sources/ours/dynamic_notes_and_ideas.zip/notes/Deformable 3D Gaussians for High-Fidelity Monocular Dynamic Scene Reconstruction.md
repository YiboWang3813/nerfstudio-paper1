# Deformable 3D Gaussians for High-Fidelity Monocular Dynamic Scene Reconstruction

## 0. Metadata

* Title: Deformable 3D Gaussians for High-Fidelity Monocular Dynamic Scene Reconstruction
* Authors: Ziyi Yang; Xinyu Gao; Wen Zhou; Shaohui Jiao; Yuqing Zhang; Xiaogang Jin
* Year: 2024
* Venue: CVPR 2024
* PDF source: `/Users/wangyibo/Zotero/storage/4M3UHI55/Yang 等 - Deformable 3D Gaussians for High-Fidelity Monocular Dynamic Scene Reconstruction.pdf`
* Local note path: `notes/Deformable 3D Gaussians for High-Fidelity Monocular Dynamic Scene Reconstruction.md`
* Zotero item key: `Q9SDISBN`
* Zotero PDF attachment key: `4M3UHI55`
* Existing Zotero Markdown attachment key: `7XEBQH8Z`
* Code: https://github.com/ingra14m/Deformable-3D-Gaussians
* Project page: Not specified
* Dataset link: Not specified
* Main task: monocular dynamic scene reconstruction, novel-view synthesis, and time interpolation
* Domain: dynamic Gaussian Splatting; canonical-space deformation; monocular dynamic rendering
* Input: monocular dynamic scene images with timestamps, SfM camera poses, and sparse point cloud from COLMAP or random initialization
* Output: dynamic novel-view / time-interpolated renderings and depth visualization from deformed 3D Gaussians
* Main representation: canonical 3D Gaussians plus an MLP deformation field predicting per-Gaussian position, rotation, and scale offsets
* Supervision type: per-scene photometric optimization from posed monocular images
* Core contribution in one sentence: 在 canonical space 中学习 3D Gaussians，并用一个以 detached Gaussian position 和 time 为输入的 MLP deformation field 输出 $\delta x,\delta r,\delta s$，再用 annealing smooth training 缓解真实单目数据中的 pose jitter。
* Note status: `complete`

## 1. 一句话技术摘要

这篇论文处理单目动态场景重建，通过把 3D Gaussians 保存在 canonical space，并用 time-conditioned MLP deformation field 将它们变形到当前时间帧；关键技术差异是把 3DGS 的显式点渲染速度与 NeRF-style canonical deformation 结合，并加入对时间编码的退火噪声来提升真实数据中的时间插值平滑性。

## 2. 问题形式化

### 2.1 任务

给定一组单目动态场景图像、每张图像的时间标签 $t$、SfM 估计的相机位姿和稀疏点云，学习一个可在时间 $t$ 和目标视角下渲染图像 $C(p,t)$ 的动态 3D Gaussian 表示。

任务包括：

* novel-view synthesis: 固定时间，改变视角；
* time synthesis / interpolation: 在时间轴上插值，渲染未观测时间；
* real-time rendering: 利用 3DGS rasterizer 达到实时帧率。

### 2.2 表示目标

直接为每个时间训练一套 3DGS 只适合离散时间多视角捕获；对连续单目视频不可行。论文采用 canonical representation：

* Canonical component: 3D Gaussians $G(x,r,s,\sigma)$，包含中心 $x$、rotation quaternion $r$、scale $s$、opacity $\sigma$ 和 SH appearance；
* Dynamic component: deformation MLP $F_\theta$，输入 Gaussian position 和 time，输出 $\delta x,\delta r,\delta s$；
* Rendering component: deformed Gaussians $G(x+\delta x,r+\delta r,s+\delta s,\sigma)$ 进入 differentiable Gaussian rasterizer。

### 2.3 关键假设

* 动态场景可通过从 canonical space 到 deformed space 的 smooth deformation field 表示。
* 对 MLP 输入使用 positional encoding 足以保留高频动态细节。
* 单目真实数据中的 pose jitter 主要影响 time interpolation；对 fixed-time novel view 相对影响较小。
* 3DGS adaptive density control 仍适用于动态场景，只要 canonical Gaussians 与 deformation field 联合训练。

## 3. 方法概览

Deformable 3D Gaussians 的 pipeline 很直接：

1. 用 COLMAP/SfM 点云或随机点初始化 canonical 3D Gaussians。
2. 前 3k iterations 只训练 3D Gaussians，不训练 deformation field，让点的位置和形状先稳定。
3. 之后联合训练 canonical Gaussians 和 deformation MLP。
4. 对每个时间 $t$，MLP 输入 detached Gaussian center $sg(x)$ 的 positional encoding 和 time positional encoding。
5. MLP 输出 $\delta x,\delta r,\delta s$，形成 deformed Gaussians。
6. 用 3DGS tile-based differentiable rasterizer 渲染。
7. 用 Gaussian adaptive density control 做 prune、clone、split。
8. 真实数据上对 time encoding 加入线性衰减的高斯噪声，即 Annealing Smooth Training。

方法的本质是把 HyperNeRF / Nerfies 类 canonical deformation 思路搬到 3DGS 表示上。它保留了 3DGS 的实时渲染优势，但仍需要 MLP deformation 查询，因此不是 fully explicit temporal representation。

## 4. 方法细节

### 4.1 3DGS canonical rendering

论文沿用 3DGS 的 differentiable Gaussian rasterization。3D Gaussian 投影到 2D 时，2D covariance 为 Eq. 1: $\Sigma'=JV\Sigma V^T J^T$，其中 $J$ 是 projective transform 的 affine approximation Jacobian，$V$ 是 view matrix。

3D covariance 按 Eq. 2 分解为 $\Sigma=RSS^TR^T$，其中 $R$ 来自 quaternion $r$，$S$ 来自 scale vector $s$。

像素颜色按 point-based volume rendering 累积。Eq. 3: $C(p)=\sum_{i\in N}T_i\alpha_i c_i$，其中 $\alpha_i=\sigma_i e^{-\frac{1}{2}(p-\mu_i)^TP'(p-\mu_i)}$，$T_i=\prod_{j=1}^{i-1}(1-\alpha_j)$。

### 4.2 Adaptive density control

训练中保留 3DGS 的 density control：

* pruning: 根据 opacity $\sigma$ 删除透明 Gaussians；
* densification: 在几何细节不足区域增加 Gaussians；
* clone: 对小且不足以刻画细节的 Gaussians，沿位置梯度方向复制并移动；
* split: 对过大且重叠严重的 Gaussians，拆分并缩小 scale。

论文沿用 3DGS 的 position-gradient threshold $t_{pos}=0.0002$ 来判断需要调整的 Gaussians。这里的一个重要观察是，动态区域的 deformation field 会产生更大梯度，从而帮助 canonical Gaussians 在动态区域 densify。

### 4.3 Deformation MLP

给定 canonical Gaussian center $x$ 和时间 $t$，deformation MLP 输出属性增量。Eq. 4: $(\delta x,\delta r,\delta s)=F_\theta(\gamma(sg(x)),\gamma(t))$。

其中：

* $sg(\cdot)$ 是 stop-gradient，对 MLP 输入的 $x$ detach，避免 deformation field 的梯度反向改变 canonical Gaussian center；
* $\gamma(\cdot)$ 是 positional encoding；
* 输出 $\delta x,\delta r,\delta s$ 分别作用于 position、rotation 和 scale；
* opacity $\sigma$ 和 SH appearance 不由 deformation MLP 直接变形。

Stop-gradient 是方法中容易被忽略但很关键的实现点。它让 canonical Gaussians 主要由 rasterization loss 优化，而 deformation MLP 只学从 canonical 到当前时间的 offset，减少两者互相追逐导致的不稳定。

### 4.4 Positional encoding

Eq. 5: $\gamma(p)=(\sin(2^k\pi p),\cos(2^k\pi p))_{k=0}^{L-1}$。

设置：

* synthetic scenes: $x$ 使用 $L=10$，$t$ 使用 $L=6$；
* real scenes: $x$ 和 $t$ 都使用 $L=10$；
* deformation network depth $D=8$；
* hidden width $W=256$。

论文强调 positional encoding 能提升高频细节，但真实数据中高阶 time PE 又容易放大 pose jitter，因此需要 AST。

### 4.5 Annealing Smooth Training

真实单目数据的 COLMAP poses 常有小抖动。隐式 NeRF 的 MLP smoothness 能部分吸收这种误差，但显式 point rendering 会放大它，尤其在 time interpolation 中表现为 temporal jitter。

AST 在训练早期向 time positional encoding 加高斯噪声，并线性衰减。Eq. 6: $\Delta=F_\theta(\gamma(sg(x)),\gamma(t)+X^{(i)})$，其中 $X^{(i)}=N(0,1)\cdot\beta\cdot\Delta t\cdot\max((1-i/\tau),0)$。

超参：

* $\beta=0.1$；
* $\Delta t$ 是 mean time interval；
* $\tau=20k$ iterations；
* 噪声随 iteration $i$ 线性衰减到 0。

AST 的作用是早期提升时间泛化和平滑性，后期不再加噪以保留动态细节。相比显式 smooth loss，它没有额外前向/后向计算开销。

### 4.6 Warm-up 与联合优化

训练总共 40k iterations。前 3k iterations 只训练 3D Gaussians，让 canonical geometry 先稳定；之后联合训练 Gaussians 和 deformation MLP。

优化器：

* 单个 Adam optimizer；
* Adam $\beta=(0.9,0.999)$；
* 3D Gaussians 学习率与官方 3DGS implementation 相同；
* deformation network learning rate 指数衰减，从 $8e-4$ 到 $1.6e-6$。

所有实验在 NVIDIA RTX 3090 上完成。Synthetic datasets 使用黑背景和 full resolution $800\times800$。

## 5. 数学目标与损失

### 5.1 Photometric reconstruction

正文没有单独列出完整 loss 公式，基本沿用 3DGS photometric objective。可合理推断使用 3DGS 的 $L_1$ 和 SSIM / D-SSIM 组合，但当前 PDF 抽取文本没有明确给出权重，因此记为 `NEED_HUMAN_CHECK`。

### 5.2 Deformation objective

deformation MLP 没有额外显式 smoothness loss。它通过渲染误差的梯度学习 $\delta x,\delta r,\delta s$，并通过 AST 的输入扰动获得时间平滑先验。

### 5.3 Density-control objective

density control 不作为单独 loss，而是基于 position gradients 和 opacity 触发 clone/split/prune。由于 deformation field 与 Gaussians 联合反传，动态区域更大的 reconstruction gradients 会促使 Gaussians 在动态细节处增加密度。

### 5.4 AST regularization interpretation

AST 可理解为对 time-conditioned deformation field 的 data augmentation：训练早期把相邻时间的 encoding 模糊化，迫使 MLP 学习更平滑的 temporal mapping；训练后期噪声消失，允许高频细节恢复。它不是 explicit smooth loss，所以不会增加额外渲染或 pairwise time sampling 成本。

## 6. 训练与推理流程

### 6.1 训练流程

1. 从 SfM / COLMAP sparse points 初始化 3D Gaussians。
2. 训练前 3k iterations：只更新 3D Gaussians。
3. 进入联合阶段：对每个训练样本取时间 $t$ 和相机。
4. 对每个 Gaussian，计算 $\gamma(sg(x))$ 和 $\gamma(t)$。
5. 如果启用 AST，则用 $\gamma(t)+X^{(i)}$ 替代 $\gamma(t)$。
6. MLP 输出 $\delta x,\delta r,\delta s$。
7. 构造 $G(x+\delta x,r+\delta r,s+\delta s,\sigma)$。
8. 用 differentiable Gaussian rasterizer 渲染并回传。
9. 根据 opacity 和 position gradients 做 pruning / densification / clone / split。
10. 训练到 40k iterations。

### 6.2 推理流程

推理时给定时间和相机：

1. 查询 deformation MLP；
2. 得到 deformed Gaussians；
3. 用 3DGS rasterizer 渲染。

渲染速度与 Gaussian 数量相关。当 Gaussian 数量低于 250k 时，论文报告在 RTX 3090 上超过 30 FPS。

### 6.3 与完全显式动态 GS 的差异

该方法仍需按时间查询 MLP，因此不同于 keyframe / trajectory / per-frame 显式参数化方法。它的优势是简单、质量高、能复用 canonical deformation 先验；短板是 MLP 查询和动态复杂度仍随 Gaussian 数量增长。

## 7. 实验设置与结果

### 7.1 数据集

Synthetic:

* D-NeRF dataset；
* full resolution $800\times800$；
* 对比 3D-GS、D-NeRF、TiNeuVox、Tensor4D、K-Planes。

Real-world:

* NeRF-DS；
* HyperNeRF；
* HyperNeRF 部分 pose 很不准，因此论文不纳入定量 PSNR 分析，主要做 qualitative comparison。

### 7.2 Synthetic D-NeRF 结果

Table 1 中 Deformable 3D Gaussians 在 8 个 synthetic scenes 上整体显著领先。典型结果：

* Hell Warrior: PSNR 41.54，SSIM 0.9873，LPIPS 0.0234；
* Mutant: 42.63，0.9951，0.0052；
* Stand Up: 44.62，0.9951，0.0063；
* Jumping Jacks: 37.72，0.9897，0.0126。

对比方法中 K-Planes、TiNeuVox、D-NeRF 在部分场景有较好结果，但总体细节和 perceptual metrics 不如该方法。Figure 3 显示该方法在 hands、skeletons 等细节上更清晰。

需要注意：论文指出 D-NeRF Lego 的 train/test motion 存在不一致，因此使用 validation set 作为 test set；引用 Lego 结果时需注明。

### 7.3 NeRF-DS 结果

Table 2 平均结果：

* 3D-GS: PSNR 20.29，SSIM 0.7816，LPIPS 0.2920；
* TiNeuVox: 21.61，0.8234，0.2766；
* HyperNeRF: 23.45，0.8488，0.1990；
* NeRF-DS: 23.60，0.8494，0.1816；
* Ours w/o AST: 23.97，0.8346，0.2037；
* Ours: 24.11，0.8525，0.1769。

AST 带来 PSNR、SSIM、LPIPS 的一致改善，尤其 LPIPS 从 0.2037 降到 0.1769。

### 7.4 渲染效率

论文报告当 3D Gaussians 数量低于 250k 时，RTX 3090 上可超过 30 FPS。详细 per-scene speed 在 supplementary，当前 PDF 正文未提供表格。

### 7.5 深度可视化

Figure 6 展示 D-NeRF 场景的 depth maps。作者用它说明 deformation network 学到的是 temporal transformation，而不是 color hard-coding。这个证据是定性，不能直接证明几何完全准确，但能支持“不是纯颜色拟合”的论点。

### 7.6 AST 消融

Figure 4 对比 $6pe$ w/o AST、$10pe$ w/o AST 和 ours。低阶 time PE 更平滑但损失高频细节，高阶 time PE 保留细节但容易 temporal overfitting；AST 在真实数据中兼顾高频细节和 temporal smoothness。

## 8. 声称贡献 vs 实际技术增量

### 8.1 论文声称

论文声称：

* 第一个通过 deformation field 扩展 3DGS 到 dynamic scenes 的框架；
* 支持 monocular dynamic scene 的 high-fidelity reconstruction 和 real-time rendering；
* AST 在不增加计算开销的情况下改善时间插值平滑性。

### 8.2 实际技术增量

实际技术增量是把 3DGS 作为 canonical radiance/geometry representation，再外接一个 time-conditioned coordinate deformation MLP。这是对 Nerfies/HyperNeRF canonical deformation 范式的 3DGS 化。

具体增量包括：

* MLP 只预测 position/rotation/scale offsets，不直接预测颜色；
* 对 Gaussian center 输入 stop-gradient，降低 geometry/deformation coupling；
* warm-up 先稳定 canonical Gaussians；
* AST 用 time encoding noise 替代额外 smooth loss；
* 复用 3DGS adaptive density control，让动态高梯度区域自动增加 Gaussians。

### 8.3 证据强度

证据强的部分：

* D-NeRF synthetic full-resolution 表格大幅领先；
* NeRF-DS 上 AST 量化有效；
* implementation details 给出训练轮数、学习率、网络大小、硬件；
* depth visualization 和 qualitative comparisons 支持几何/细节质量。

证据较弱的部分：

* HyperNeRF 因 pose 不准没有定量；
* rendering speed 详细表在 supplementary；
* loss 公式和权重未在正文详细列出；
* 复杂人脸表情等高动态场景未充分验证。

## 9. 局限与隐藏假设

论文显式局限：

1. 3D Gaussians 收敛高度依赖 viewpoint diversity；稀疏视角和有限覆盖会过拟合。
2. 方法依赖 pose estimation accuracy；COLMAP pose 偏差会影响结果，HyperNeRF PSNR 不佳。
3. 时间复杂度与 Gaussian 数量正相关；大量 Gaussians 会增加训练时长和显存。
4. 实验主要覆盖 moderate motion dynamics；复杂人体动作、细微表情等仍是 open question。

隐藏假设：

* Monocular dynamic scene 的 canonical space 足够稳定，且所有时间能被同一个 canonical Gaussian set 覆盖。
* Deformation MLP 的 smoothness 足以处理时间连续性，但不会过度平滑快速运动。
* Stop-gradient 的使用是稳定训练关键，但也可能限制 deformation 和 canonical geometry 的协同调整。
* 该方法没有显式处理遮挡/出现/消失的 object lifecycle；依赖 densification 和 deformation 间接吸收。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法名称 | Deformable 3D Gaussians |
| 输入类型 | Monocular dynamic images with SfM poses |
| 核心表示 | Canonical 3D Gaussians + deformation MLP |
| 时间建模 | MLP $F_\theta(\gamma(sg(x)),\gamma(t))$ |
| 变形属性 | $\delta x,\delta r,\delta s$ |
| 颜色建模 | SH on Gaussians, not deformed by MLP |
| 关键稳定化 | 3k warm-up; stop-gradient on $x$; AST |
| AST 超参 | $\beta=0.1$; $\tau=20k$; noise decays linearly |
| 网络 | MLP depth 8, width 256 |
| 训练 | 40k iterations; Adam; deformation LR $8e-4$ to $1.6e-6$ |
| Density control | 3DGS pruning / clone / split; $t_{pos}=0.0002$ |
| 主数据集 | D-NeRF; NeRF-DS; HyperNeRF qualitative |
| 主优势 | 高质量、实时、简单 baseline |
| 主短板 | pose/viewpoint sensitive; MLP query cost; moderate motion only |

## 11. 对我的研究可复用组件

1. Canonical 3DGS + deformation MLP baseline：动态 GS 论文矩阵中最基础的 MLP deformation 分支。
2. Stop-gradient on Gaussian center：可以作为稳定 canonical geometry 与 deformation 解耦的通用 trick。
3. AST：对时间编码加退火噪声，是处理 COLMAP pose jitter 的低成本正则。
4. Warm-up training：先让 Gaussians 稳定，再打开 deformation field，适合大多数 canonical dynamic GS 方法。
5. Density-control coupling：动态区域的 deformation gradients 可辅助 Gaussian densification。
6. Failure axis：viewpoint diversity、pose accuracy、Gaussian count、motion complexity 是比较动态 GS 方法时的重要列。

## 12. Gap and Idea Seeds

### 12.1 Gap: 没有显式 appearance dynamics

MLP 只预测 $\delta x,\delta r,\delta s$，不预测 opacity 或 color。对于光照变化、反射、高光、拓扑显隐，纯几何/形状变形可能不足。可扩展为分离 geometry deformation 和 appearance residual。

### 12.2 Gap: object lifecycle 不显式

出现/消失、遮挡后的重现依赖 canonical set 和 deformation 间接表示。可以加入 temporal opacity 或 birth/death gates，与 4DGS / Ex4DGS 的 temporal opacity 对比。

### 12.3 Gap: AST 只作用于 time encoding

pose jitter 同时影响 camera pose 和 geometry alignment。可研究 joint pose refinement + AST，或把噪声注入 camera/time jointly。

### 12.4 Gap: Gaussian 数量决定速度

论文报告低于 250k 才能超过 30 FPS。可以结合 compression、motion-basis sharing 或 sparse active set，降低 MLP query 和 rasterization cost。

### 12.5 Gap: moderate motion 限制

复杂人脸表情、手物交互和大拓扑变化未充分测试。可以构造更高 motion rank benchmark，比较 MLP deformation、control graph、keyframe explicit representation 的上限。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: photometric loss 的确切形式和权重，正文未给完整公式。
* `NEED_HUMAN_CHECK`: supplementary 中 per-scene rendering speed、更多 ablation 和 scene-level metrics。
* `NEED_HUMAN_CHECK`: Lego 使用 validation set 作为 test set，做横向表格时需避免和其他论文默认 split 混用。
* `NEED_HUMAN_CHECK`: random initialization 的具体策略只在 Figure 2 / method 中简单提到，细节需看代码。
* `NEED_HUMAN_CHECK`: rotation offset $\delta r$ 的具体参数化和 normalization 需看代码。
* `NEED_HUMAN_CHECK`: 3DGS 官方 learning rates “exactly the same” 未展开，复现需查 3DGS config。

## 14. Evidence Anchors

* Abstract: canonical 3D Gaussians + deformation field；AST 缓解 inaccurate poses；real-time rendering。
* Figure 1: 输入 monocular multi-view images 和 camera poses，输出 novel-view synthesis 与 time synthesis。
* Figure 2: pipeline；SfM points initialization；$\gamma(sg(x))$ and $\gamma(t)$ input；first 3k warm-up；joint optimization。
* Section 3 Method: deformed Gaussians $G(x+\delta x,r+\delta r,s+\delta s,\sigma)$ 进入 tile-based rasterizer。
* Section 3.1 / Eq. 1-3: 2D covariance、covariance decomposition、point-based rendering。
* Section 3.1: adaptive density control；$t_{pos}=0.0002$；clone/split/prune。
* Section 3.2 / Eq. 4-5: deformation MLP、stop-gradient、positional encoding、$L=10/6$、$D=8,W=256$。
* Section 3.3 / Eq. 6: AST noise schedule；$\beta=0.1$；$\tau=20k$。
* Section 4.1: PyTorch implementation；40k iterations；3k Gaussian-only warm-up；Adam；LR $8e-4$ to $1.6e-6$；RTX 3090。
* Section 4.2 / Table 1: D-NeRF synthetic full-resolution quantitative results。
* Figure 3: synthetic qualitative comparison，hands/skeleton details。
* Figure 4: AST ablation，6pe / 10pe / ours。
* Figure 5: NeRF-DS qualitative comparison。
* Section 4.2 / Table 2: NeRF-DS mean metrics and AST effect。
* Section 4.2 Rendering Efficiency: >30 FPS when Gaussians <250k on RTX 3090。
* Figure 6: depth visualization。
* Section 5 Limitations: viewpoint diversity、pose accuracy、Gaussian count、moderate motion limitations。
