# Frequency-aware Dynamic Gaussian Splatting

## 0. Metadata

- Title: Frequency-aware Dynamic Gaussian Splatting
- Authors: Qiaowei Miao; Jinsheng Quan; Kehan Li; Yichao Xu; Yi Yang; Yawei Luo
- Venue/Year: ICLR 2026
- Zotero item key: `72CN9LW3`
- Zotero PDF attachment key: `FLHYETV3`
- PDF path: `/Users/wangyibo/Zotero/storage/FLHYETV3/Miao 等 - 2026 - FREQUENCY-AWARE DYNAMIC GAUSSIAN SPLATTING.pdf`
- Local note path: `notes/Frequency-aware Dynamic Gaussian Splatting.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

FAGS 将动态 3DGS 的 motion blur 解释为高频外观细节与高频运动建模之间的 spectral conflict，并通过 Frequency-Differentiated Gaussian Kernel、Fourier-Deformation Network、frequency-aware gate 和 Fourier frequency loss，把 Gaussian 表示责任与 deformation motion 责任显式按频率拆开。

## 2. Problem Formulation

现有 deformation-field dynamic 3DGS 依赖 canonical Gaussians 加时间条件 deformation network。标准 Gaussian kernel 的 opacity profile 固定为中心不透明、边界渐透明，因此要表达高频边界或细节时，系统往往需要堆叠多个 Gaussians。动态场景中，deformation network 同时要控制这些密集 Gaussians 的逐帧位置和跨帧轨迹，容易在高频细节与高频运动之间折中为过平滑运动，表现为 novel view 下的 motion blur。

FAGS 的核心设定是：motion blur 不只是 deformation field 不够强，而是 representation 和 motion modeling 的频谱职责耦合。方法希望让 Gaussians 自身更擅长表达 spatial high-frequency details，同时让 deformation network 更擅长表达 temporal high-frequency motion，并对低频区域抑制不必要 deformation。

给定 canonical Gaussian 的位置 $x$、rotation $R$、scale $S$、SH color $c_{\mathrm{SH}}$ 和 opacity $o$，传统 deformation network 对 timestamp $t$ 预测 $\Delta x,\Delta R,\Delta S$。FAGS 在此基础上加入每个 Gaussian 的 kernel frequency parameters、Fourier temporal embedding 和 motion gate。

## 3. Method Overview

FAGS 包含两个主要模块。第一个是 Frequency-Differentiated Gaussian Kernel (FDGK)，它把标准 3DGS 中固定的 projected Gaussian alpha profile 替换为一个带 learnable parameters 的 alpha modulation function $\epsilon(g)$。每个 Gaussian 学习参数 $\lambda$ 和 boundary parameter $\beta$，训练后自适应分化为 low-frequency Gaussians 和 high-frequency Gaussians：前者用于平滑区域，后者用于 sharp boundaries 和复杂纹理。

第二个是 Fourier-Deformation Network (FDN)。它以 Grid4D 的 4D decomposed hash encoding 为低频时空特征基础，再为每个 Gaussian 加入 high-frequency Fourier embedding。Fourier embedding 的频率固定、幅度由 Gaussian spatial feature 预测，使每个 Gaussian 可以拥有不同的高频运动模式。随后 frequency-aware gate 输出每个 Gaussian 在当前时间的相对运动强度，动态区域获得较大 deformation，低频/近静态区域被抑制。

优化上，FAGS 除了常规 image reconstruction 和 Grid4D smooth regularization，还加入 Fourier frequency loss，在频域对 rendered image 与 target image 的 amplitude spectra 进行约束，进一步强调高频细节。

## 4. Method Details

### 4.1 Frequency-Differentiated Gaussian Kernel

标准 3DGS 对 pixel $p$ 的 alpha contribution 可写为 $\omega_i=o_i g_i$，其中 $g_i$ 是 projected Gaussian 的指数衰减项。FAGS 将该项推广为 $\omega_i=\min(o_i\epsilon(g_i),0.99)$，用 $\epsilon(g)$ 调制 alpha profile，从而改变单个 Gaussian 从中心到边界的透明度变化速度。

论文先讨论一个线性形式 $\epsilon(g)=rg+b$：当 slope $r$ 较小，kernel 变化更慢，对应 low-frequency smooth Gaussian；当 $r$ 较大，kernel 有更 sharp transition，对应 high-frequency Gaussian。标准 Gaussian 对应 $r=1,b=0$。

FDGK 的实际设计是 piecewise differentiable activation function。它把 $g\in[0,1]$ 的映射范围分成左、中、右三个区间，并约束中央区间经过 $(0.5,0.5)$。学习参数 $\lambda$ 控制中央区间 slope，$\lambda=0.5$ 接近标准 Gaussian，$\lambda<0.5$ 倾向低频，$\lambda>0.5$ 倾向高频；boundary parameter $\beta$ 控制 differentiation region 的范围，使 frequency type 和作用区间可以独立学习。

这种设计和 DRK 的差别在于，FDGK 不只改变 kernel shape，还为每个 Gaussian 单独学习 differentiation boundary。论文观察到初始化时 $\lambda=0.5,\beta=0.5$，约 5,000 steps 后 $\lambda$ 分布分裂为 high/low 两组，比例约 3:2，之后保持稳定。

### 4.2 Fourier-Deformation Network

FDN 以 4D coordinate $(x,y,z,t)$ 为输入，但不是直接做单一 4D hash。它分解为四个 3D hash encodings：$(x,y,z)$、$(x,y,t)$、$(x,z,t)$、$(y,z,t)$。其中 spatial hash 产生 $f_{\mathrm{spa}}$，三个 spatiotemporal hash 拼接后产生 $f_{\mathrm{tem}}$：

$$
f_{\mathrm{spa}}=\mathrm{MLP}(H_{xyz}(x,y,z)).
$$

$$
f_{\mathrm{tem}}=\mathrm{MLP}(\mathrm{concat}[H_{xyt}(x,y,t),H_{xzt}(x,z,t),H_{yzt}(y,z,t)]).
$$

这些 hash features 提供低频、连续的 spatiotemporal representation，但对快速 temporal motion 不够敏感。因此 FAGS 为每个 Gaussian 额外构造 high-frequency Fourier embedding。

### 4.3 High-Frequency Fourier Embedding

FAGS 将每个 Gaussian 的 motion 看作一个可由多频 periodic components 组合的 trajectory segment。Fourier embedding 写为：

$$
f_{\mathrm{fre}}=[w_1\sin(\pi\gamma_1t),w_1\cos(\pi\gamma_1t),\ldots,w_m\sin(\pi\gamma_mt),w_m\cos(\pi\gamma_mt)]^\top.
$$

其中 $\gamma_i$ 是预设频率，$m=D/2$，$D$ 与 spatial feature dimension 对齐。每个 Gaussian 的 amplitude vector $[w_1,\ldots,w_m]$ 由其 spatial feature 预测：

$$
[w_1,\ldots,w_m]=\mathrm{MLP}(f_{\mathrm{spa}}).
$$

这样，高频 motion basis 是共享的，但每个 Gaussian 学到自己的频率幅度分布。它比纯 hash temporal feature 更容易表达短时间内的快速 displacement。

### 4.4 Frequency-Aware Gate

FDN 将 low-frequency feature $f_{\mathrm{tem}}$ 与 high-frequency feature $f_{\mathrm{fre}}$ 融合为 $f_{\mathrm{FD}}$，再用 decoder 预测 deformation parameters 和 gate score。概念形式为：

$$
D_\theta(f_{\mathrm{FD}})=\{\eta,R_x,T_x,\Delta r,\Delta s\}.
$$

其中 $\eta$ 是 frequency-aware gate，用来调制 deformation strength。更新后的 Gaussian 近似写作 $\mu'=\eta R_x\mu+\eta T_x$，$S'=S+\eta\Delta s$，$R'=R+\eta\Delta r$。高频运动区域的 $\eta$ 较大，允许快速变化；低频或近静态区域的 $\eta$ 较小，抑制 deformation network 对静态点的误调整。

论文强调这个 gate 不是硬分类静态/动态，而是相对 motion state 的连续权重。Fig. 7(c) 显示训练后大部分 Gaussians 集中在低频 motion regime，小部分承担高频 motion。

### 4.5 Fourier Frequency Loss

为了让高频 kernel 和高频 deformation 真正被优化目标利用，FAGS 在图像频域加入约束。对 rendered image $I'$ 和 target image $I$ 做 FFT，取 amplitude spectra $I'_{\mathrm{amp}}$ 和 $I_{\mathrm{amp}}$，定义 Fourier frequency loss：

$$
L_{\mathrm{fre}}=\|I'_{\mathrm{amp}}-I_{\mathrm{amp}}\|.
$$

总体优化目标包含 image color loss、Grid4D smooth regularization 和 Fourier frequency loss：

$$
L=\lambda_cL_c+\lambda_rL_r+\lambda_{\mathrm{fre}}L_{\mathrm{fre}}.
$$

实验默认 $\lambda_{\mathrm{fre}}=0.3$，$\lambda_c$ 和 $\lambda_r$ 沿用 Grid4D 设置。

## 5. Mathematical Objectives and Losses

FAGS 的数学核心不是引入新的 scene-level physical prior，而是改变 Gaussian alpha profile、deformation feature basis 和 frequency-domain supervision。

标准 alpha compositing 仍为：

$$
C(p)=\sum_{i=1}^{N}c_i\omega_i\prod_{j=1}^{i-1}(1-\omega_j).
$$

其中 FAGS 把 $\omega_i$ 从标准 Gaussian contribution 改为 $\omega_i=\min(o_i\epsilon(g_i),0.99)$。$\epsilon(g)$ 的 piecewise form 对 $\lambda$ 和 $\beta$ 可微，因此 FDGK 参数可直接通过 rendering loss 反传优化。Fourier embedding 的 amplitude $w_i$ 和 gate $\eta$ 由网络预测，也通过同一 differentiable rendering pipeline 优化。

## 6. Training and Inference Procedure

训练从 static canonical Gaussians 初始化开始，以保证收敛稳定。若 Gaussians 来自 SfM，论文缩短 static initialization stage 以提高效率。训练中采用 3DGS 的 adaptive density controller 和 opacity resetting。

实现上，FAGS 以 Grid4D 为 deformation backbone，CUDA/C++ 集成 FDGK rasterization。$\lambda$ 和 $\beta$ 的学习率为 0.002，实验在 NVIDIA 3090 GPU 上完成。初始时每个 Gaussian 取 $\lambda=0.5,\beta=0.5$，等价于标准 Gaussian kernel；训练过程中它们自适应分化。

推理时，每个 Gaussian 先通过 FDGK 得到 frequency-differentiated alpha contribution，再由 FDN 根据 $(x,y,z,t)$、Fourier embedding 和 gate 输出 deformation，最后用 modified alpha blending rasterize。

## 7. Experimental Setup and Results Summary

FAGS 在 D-NeRF、Neu3D 和 HyperNeRF 上评估。D-NeRF 是 synthetic monocular benchmark，分辨率 800x800；HyperNeRF 和 Neu3D 是 real-world captures，pose 由 COLMAP 估计，分辨率分别为 536x960 和 1352x1024。指标包括 PSNR、SSIM、LPIPS 和 MS-SSIM。

D-NeRF 平均结果中，FAGS 达到 PSNR 42.76、SSIM 0.995、LPIPS 0.007，优于 Grid4D 的 41.99 / 0.993 / 0.008，也优于 SC-GS 的 41.59 / 0.994 / 0.015。单场景上，Ours 在 Bouncing Balls、Hell Warrior、Hook、Jumping Jacks、Mutant、Standup、Trex 多数指标取得最佳或接近最佳。

Neu3D 平均结果中，FAGS 为 PSNR 32.18、SSIM 0.946、LPIPS 0.146；Grid4D 为 31.63 / 0.937 / 0.149，4D-GS 为 30.65 / 0.934 / 0.161。HyperNeRF interpolation subset 上，FAGS 为 PSNR 29.02、SSIM 0.850、LPIPS 0.195、MS-SSIM 0.994；rig subset 上，FAGS 为 PSNR 25.63、SSIM 0.719、LPIPS 0.269、MS-SSIM 0.885，均高于表中 4D-GS 和 Grid4D。

消融表显示 full model 在 D-NeRF 平均 PSNR 42.76。去掉 FDGK 降到 42.11，去掉 HFE 降到 42.38，去掉 frequency gate 降到 42.70，去掉 $L_{\mathrm{fre}}$ 降到 42.50，同时去掉 gate 和 frequency loss 降到 42.43。只去掉 FDGK 的 $\lambda$ 或 $\beta$ 分别降到 42.30 和 42.26，说明 kernel frequency 和 boundary 两个参数都重要。

论文还对 motion blur dataset 进行讨论：在 BARD-GS 的 real-world motion blur setting 下，FAGS 不做 MPRNet deblurring 也具有竞争力，加入 MPRNet 预处理后可超过 BARD-GS。Fig. 11 的 temporal power spectrum 显示 FAGS 相比 Grid4D 有更多 Gaussians 落在 high-frequency band。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是从 frequency perspective 解释 dynamic 3DGS 的 motion blur，并提出 FDGK、FDN、frequency-aware gate 和 Fourier frequency loss。实际技术增量可以分成 representation、deformation 和 supervision 三层。

Representation 层，FDGK 把 Gaussian kernel 的 alpha profile 从固定形状改成可学习 frequency-differentiated shape，使单个 Gaussian 能承担 low-frequency smooth region 或 high-frequency boundary 的不同职责。Deformation 层，FDN 在 Grid4D low-frequency hash features 上叠加 per-Gaussian Fourier amplitudes，并用 gate 控制 motion strength。Supervision 层，频域 loss 直接约束 rendered image 和 target image 的 amplitude spectra。

相对 Grid4D，FAGS 不是替换 hash decomposition，而是在其上增加高频运动 basis 和 kernel differentiation。相对 DRK，FDGK 的关键是单 Gaussian 可学习 boundary $\beta$，避免所有相同 slope 的 Gaussians 共享同一 differentiation region。相对 BARD-GS，FAGS 不是专门建模 blur formation，而是改善动态重建中的频谱表达与运动控制。

## 9. Limitations / Assumptions

FAGS 依赖 frequency decomposition 的解释假设：motion blur 主要来自高频外观和高频运动之间的优化冲突。对于由错误 pose、严重遮挡、错误几何初始化或 rolling shutter 造成的 blur，它不一定直接解决。

Fourier embedding 把 motion 建模为多频 periodic components 的组合，适合短期快速运动，但对于非周期、突变、拓扑变化或长时记忆依赖，表达可能仍有限。

FDGK 增加了 rasterization 中的 kernel parameters 和 piecewise alpha modulation，对实现和数值稳定性有要求。抽取文本中 Eq. 3-4 的符号存在 OCR/编码错误，精确实现需回看 PDF。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Dynamic scene video with camera poses |
| Output | Frequency-aware dynamic 3D Gaussian representation |
| Backbone | Grid4D-style decomposed hash deformation |
| Kernel module | FDGK with learnable frequency parameter $\lambda$ and boundary $\beta$ |
| Motion module | Fourier-Deformation Network with per-Gaussian amplitudes |
| Gate | Frequency-aware gate $\eta$ modulates deformation strength |
| Loss | Color/reconstruction loss + Grid4D smooth regularization + $L_{\mathrm{fre}}$ |
| Main benefit | Reduces motion blur and sharpens high-frequency structure |
| Main risk | More complex rasterization; exact FDGK formula and stability need implementation care |

## 11. Reusable Components

- Frequency-differentiated alpha modulation for Gaussian splatting kernels.
- Per-Gaussian learnable high/low frequency classification through $\lambda$.
- Learnable boundary parameter $\beta$ for controlling kernel differentiation span.
- Fourier temporal embedding with per-Gaussian amplitudes predicted from spatial features.
- Continuous frequency-aware gate for suppressing unnecessary deformation on low-frequency points.
- FFT amplitude-spectrum loss for emphasizing high-frequency rendering fidelity.
- Grid4D + Fourier hybrid deformation feature design.

## 12. Gap / Idea Seeds

- Combine FAGS with explicit blur formation models such as exposure-time integration for real blurred input.
- Replace fixed Fourier frequency schedule with adaptive learned frequency banks per scene or per motion cluster.
- Use FDGK frequency type to guide densification/pruning, allocating more Gaussians to high-frequency regions.
- Add uncertainty to gate $\eta$ so ambiguous motion regions can avoid overconfident deformation.
- Study whether FDGK helps static anti-aliasing / Mip-NeRF-style view-dependent filtering beyond dynamic scenes.

## 13. Human Check List

- NEED_HUMAN_CHECK: Eq. 3-4 for FDGK piecewise function and gradients are symbol-corrupted in extracted text; verify exact $\lambda/\beta$ notation and intervals from the PDF.
- NEED_HUMAN_CHECK: Eq. 8-10 around gate update and total loss are partially corrupted/truncated; note records the visible conceptual form, not an implementation-ready formula.
- NEED_HUMAN_CHECK: BARD-GS motion blur comparison is discussed in text/figures, but the extracted Table 7 numbers are missing.
- NEED_HUMAN_CHECK: The paper header says ICLR 2026; confirm final metadata if exporting citations.

## 14. Evidence Anchors

- Introduction and Fig. 1: spectral conflict between high-frequency rendering details and high-frequency motion.
- Section 3.2 and Fig. 2: Frequency-Differentiated Gaussian Kernel with adaptive alpha modulation.
- Section 3.3 and Fig. 3: Fourier-Deformation Network, decomposed hash features, Fourier embedding and gate.
- Section 3.4: Fourier frequency loss and overall optimization.
- Tables 1-3: D-NeRF, Neu3D and HyperNeRF quantitative comparisons.
- Table 4 and Fig. 8: component ablations for FDGK, HFE, FG and $L_{\mathrm{fre}}$.
- Fig. 7 and Fig. 11: frequency parameter distribution and temporal motion spectrum.
