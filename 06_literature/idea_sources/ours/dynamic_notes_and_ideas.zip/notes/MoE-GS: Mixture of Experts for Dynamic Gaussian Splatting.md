# MoE-GS: Mixture of Experts for Dynamic Gaussian Splatting

## 0. Metadata

- Paper title: MoE-GS: Mixture of Experts for Dynamic Gaussian Splatting
- Authors: In-Hwan Jin; Hyeongju Mun; Joonsoo Kim; Kugjin Yun; Kyeongbo Kong
- Venue / year: ICLR 2026
- Project / code: `https://cvsp-lab.github.io/MoE-GS`
- Zotero item key: `V6XUSFUE`
- Zotero PDF attachment key: `D34D73PK`
- Zotero PDF path: `/Users/wangyibo/Zotero/storage/D34D73PK/Jin 等 - 2025 - MoE-GS Mixture of Experts for Dynamic Gaussian Splatting.pdf`
- Local note path: `notes/MoE-GS: Mixture of Experts for Dynamic Gaussian Splatting.md`

## 1. One-Sentence Technical Summary

MoE-GS 把 HexPlane、per-Gaussian deformation、polynomial trajectory、keyframe interpolation 等不同动态 Gaussian 专家集成到 Mixture-of-Experts 框架中，并用 Volume-aware Pixel Router 将 Gaussian-level routing 信号 splat 到 pixel space，自适应融合不同专家在空间、时间和视角上的优势。

## 2. Problem Formulation

动态 Gaussian Splatting 方法有不同 deformation priors，但没有单一方法在所有场景、空间区域和时间步都最优。论文通过 scene-level、patch-level 和 time-level PSNR 分析指出：4DGaussians 适合低运动和平滑区域，E-D3DGS 适合快速但相干的运动，Ex4DGS 适合不规则局部运动，STG 适合低曲率全局平滑运动。真实动态场景通常混合多种运动模式，因此需要自适应选择或融合专家。

问题定义为：给定多个已经训练好的 dynamic GS experts $E_1,\ldots,E_N$，学习一个 router，在每个像素、视角和时间上生成 gating weights，把专家渲染结果融合成更高质量的动态图像。与 LLM 中追求稀疏计算的 MoE 不同，MoE-GS 的主要目标是提升表示能力和重建质量，效率优化是后续补充。

## 3. Method Overview

MoE-GS 使用两阶段训练。Stage 1 独立训练每个 expert，使其保留不同 deformation prior 的建模能力。候选 experts 包括 HexPlane embedding-based、per-Gaussian embedding-based、interpolation-based 和 polynomial-based dynamic GS。Stage 2 冻结所有 experts，只训练 Volume-aware Pixel Router 来融合专家输出。

Router 的核心是先给每个 Gaussian 学一个包含基础、view-dependent、time-dependent 分量的 per-Gaussian weight，再通过 differentiable Gaussian rasterization 将这些 3D weights 投影到 pixel-aligned embeddings，最后用轻量 MLP 和 softmax 得到每个像素的 expert weights。这样既保留 Gaussian 的体积/可见性/几何信息，又在 pixel space 上稳定优化。

为缓解多专家带来的开销，论文还提出 single-pass multi-expert rendering、gate-aware Gaussian pruning，以及 routing-weighted distillation。前两者服务于 full MoE 推理效率，后者把 MoE 的区域专家选择知识迁移回单个 expert。

## 4. Method Details

### 4.1 Standard MoE Form

标准 MoE 对输入 $x$ 的输出为多个专家输出的加权和：

$$
\operatorname{MoE}(x)=\sum_{k=1}^{N}G_k(x)\cdot E_k(x).
$$

gating weights 由 router softmax 得到：

$$
G_k(x)=\operatorname{Softmax}(R_k(x)).
$$

MoE-GS 把 $E_k(x)$ 具体化为第 $k$ 个 dynamic GS expert 在像素 $u$ 处的渲染结果 $I_{E_k}(u)$，把 $G_k(x)$ 具体化为 pixel-wise expert gate $G_k'(u)$。

### 4.2 Why Pixel Router and Volume Router Are Insufficient

纯 pixel router 只基于 2D pixel features、time 和 view direction 预测权重，优化容易，但忽略 Gaussian 的 3D geometry、opacity、scale 和 visibility。纯 volume router 直接在 Gaussian level 分配 expert weights，更有几何意识，但 Gaussian 参数对最终像素贡献的关系间接，训练困难。

MoE-GS 的 Volume-aware Pixel Router 采用折中方案：routing signal 定义在 Gaussian level，但通过 rasterization splat 到 pixel space 再做 softmax blending。它把 3D volumetric information 变成可优化的 2D pixel-aligned expert gates。

### 4.3 Per-Gaussian Weights

每个 Gaussian $G_i$ 由位置 $\mu_i$、旋转 $R_i$ 和 scale $S_i$ 定义：

$$
G_i=\exp\left(-\frac{1}{2}(x-\mu_i)^T\Sigma_i^{-1}(x-\mu_i)\right), \qquad
\Sigma_i=R_iS_iS_i^TR_i^T.
$$

标准 splatting 中，像素颜色为：

$$
C=\sum_{i\in N}c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j), \qquad \alpha_i=\sigma_iG_i.
$$

Router 构造时复制每个 Gaussian，并把 color attribute $c_i$ 替换成 learnable per-Gaussian weights：

$$
w_i^{\mathrm{per}}=[w_i,w_i^{\mathrm{dir}},(t\cdot w_i^{\mathrm{time}})]^T.
$$

其中 $w_i$ 是基础权重，$w_i^{\mathrm{dir}}$ 和 $w_i^{\mathrm{time}}$ 分别编码 view-dependent 与 time-dependent variations。

### 4.4 Weight Splatting and Expert Blending

per-Gaussian weights 经 differentiable rasterizer 投影到像素平面，得到 $w_{\mathrm{2D}}(u)$、$w_{\mathrm{2D}}^{\mathrm{dir}}(u)$ 和 $w_{\mathrm{2D}}^{\mathrm{time}}(u)$。轻量 MLP $\Phi$ 结合 pixel ray direction $r(u)$ 输出 router logits：

$$
R'(u)=w_{\mathrm{2D}}(u)+\Phi\left(w_{\mathrm{2D}}^{\mathrm{dir}}(u),w_{\mathrm{2D}}^{\mathrm{time}}(u),r(u)\right).
$$

expert gates 通过 softmax 得到，并融合各专家渲染图：

$$
I_{\mathrm{MoE}}(u)=\sum_{k=1}^{N}G'_k(u)I_{E_k}(u), \qquad
G'_k(u)=\operatorname{Softmax}(R'_k(u)).
$$

Router 参数包括 $w_i^{\mathrm{per}}$ 和 $\Phi$，训练时使用标准 GS 的 $L_1$ 与 SSIM loss。附录说明 $\Phi$ 采用 convolutional MLP 以增强局部空间一致性，并在所有 experts 间共享。

### 4.5 Efficiency: Rendering, Pruning and Distillation

Full MoE 需要多个专家渲染，计算开销天然更高。single-pass multi-expert rendering 在一个 batched pass 中处理所有 experts 的 Gaussians，避免重复 kernel launch 和多次 Gaussian buffer 遍历。作者比较了 CPU offloading 和 multi-GPU distribution，认为二者因 PCIe 或 inter-GPU synchronization 开销不划算。

gate-aware Gaussian pruning 利用 router 的贡献权重移除低影响 Gaussians，减少 full MoE 中低贡献 primitives。附录还给出 Gaussian-level interpretation：像素 gate 可以结合 Gaussian 的 transmittance $T_{k,j}(u)$ 和 opacity $\alpha_{k,j}(u)$ lift 回 Gaussian responsibility：

$$
C_{k,j}(u)=T_{k,j}(u)\alpha_{k,j}(u),
$$

$$
\tilde{C}_{k,j}(u)=G'_k(u)C_{k,j}(u),
$$

$$
\bar{R}_{k,j}=\frac{\sum_{u\in U}\tilde{C}_{k,j}(u)}{\sum_{u\in U}C_{k,j}(u)}.
$$

这些 responsibilities 可用于 post-hoc fused Gaussian model：保持几何属性不变，仅调整 opacity $\alpha_{k,j}^{\mathrm{fused}}=\bar{R}_{k,j}\alpha_{k,j}$，再拼接所有专家 Gaussians。

distillation 则训练单个 expert，让它同时接受 ground-truth supervision 和 MoE pseudo-labels；pseudo-label loss 按 router pixel weights 加权，使单专家学习 MoE 在不同区域选择的专家知识。该策略在 expert 数量较大时更实用，因为 full MoE 推理成本会随专家数增长。

## 5. Mathematical Objectives and Losses

Router 训练目标是让融合图像 $I_{\mathrm{MoE}}$ 匹配 ground truth，使用 standard Gaussian Splatting loss：

$$
L_{\mathrm{router}}=(1-\lambda)L_1(I_{\mathrm{MoE}},I_{\mathrm{gt}})+\lambda L_{\mathrm{SSIM}}(I_{\mathrm{MoE}},I_{\mathrm{gt}}).
$$

论文正文只说明使用 $L_1$ 和 SSIM，未在抽取文本中给出 $\lambda$ 的具体值。专家训练各自沿用原专家方法的重建目标。Distillation 的目标可概括为 ground-truth loss 加 MoE pseudo-label loss，后者由 router weights 做 pixel-wise adaptive weighting。

## 6. Training and Inference Procedure

训练流程：首先独立训练所有专家模型，确保不同 deformation priors 充分收敛；然后冻结专家，训练 Volume-aware Pixel Router 的 per-Gaussian weights 和 MLP；根据效率需求可执行 gate-aware pruning 或训练 distilled single expert。

推理流程有三种模式。Full MoE 模式运行所有专家并通过 router 融合，质量最高但 FPS 较低。Optimized MoE 模式使用 single-pass multi-expert rendering 和 pruning 降低开销。Distilled expert 模式只运行一个专家，部署最轻，但质量取决于蒸馏效果。

## 7. Experimental Setup and Results Summary

主要数据集包括 N3V、Technicolor，并在 HyperNeRF 上测试 monocular setting 可迁移性。候选专家包括 4DGaussians、E-D3DGS、STG、Ex4DGS。指标包括 PSNR、SSIM、LPIPS，也用 Multi-view Depth Consistency (MDC) 评估 post-hoc fused Gaussian geometry。

N3V 上，4-expert MoE-GS 在 Coffee Martini、Cook Spinach、Flame Salmon 等场景全面优于单专家。例如 Coffee Martini PSNR 达 30.43，高于 E-D3DGS 的 30.04 和 4DGaussians 的 29.09；Cook Spinach 达 35.08，高于 STG 的 34.15。Technicolor 上，3-expert MoE-GS 平均 34.58 PSNR、0.928 SSIM、0.083 LPIPS，高于 STG 的 33.61/0.918/0.087 和 Ex4DGS 的 33.48/0.916/0.089。HyperNeRF 上，2-expert MoE-GS 平均 PSNR 为 24.81，高于单专家。

附录重复训练实验显示 MoE-GS 的收益不是 best-of-N 随机波动：单专家多次训练的最好结果仍低于 MoE-GS。Distillation ablation 也表明 routing-weighted distillation 优于不加权 distillation。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称 MoE-GS 是第一个把 Mixture-of-Experts 引入 dynamic Gaussian splatting 的框架。实际增量核心是 Volume-aware Pixel Router：它既不是简单图像融合，也不是直接在 3D Gaussian 上做难优化的 hard routing，而是通过 weight splatting 将 Gaussian-level 体积信息转为 pixel-level gates。

从方法论看，MoE-GS 的价值在于承认 dynamic GS deformation priors 互补，而不是试图提出单一更强 prior。它把已有动态 GS 方法作为 experts 组合起来，形成一个上层选择/融合机制。

代价也明确：Full MoE 增加模型容量和推理开销。论文的效率方案更多是工程缓解和蒸馏，不改变 MoE 本身“以计算换质量”的本质。

## 9. Limitations / Assumptions

MoE-GS 依赖多个强专家作为基础。如果某类运动没有被任何 expert prior 覆盖，router 只能在不合适的候选之间融合，不能创造真正新的动力学模型。

Full MoE 的训练和存储成本高于单模型，专家数量增加时推理 FPS 会下降。single-pass rendering、pruning 和 distillation 能缓解，但也会引入实现复杂度或质量损失。

Router 在 pixel space 融合专家图像，虽然有 Gaussian-level lifting 解释和 MDC 评估，但仍可能在遮挡边界、深度不一致或专家几何差异很大时产生融合 artifact。

## 10. Matrix-Ready Summary

| Dimension | Entry |
|---|---|
| Task | Dynamic novel-view synthesis |
| Input | Multiple trained dynamic GS experts and training images |
| Experts | HexPlane, per-Gaussian deformation, interpolation, polynomial trajectory models |
| Router | Volume-aware Pixel Router |
| Routing signal | Per-Gaussian weights splatted to pixel embeddings |
| Blending | Pixel-wise softmax expert weights over expert-rendered images |
| Training | Stage 1 expert training; Stage 2 router training with frozen experts |
| Efficiency | Single-pass multi-expert rendering; gate-aware pruning; distillation |
| Main advantage | Robust quality across scene/space/time variations |
| Main limitation | More compute and dependence on expert coverage |

## 11. Reusable Components

- Volume-aware pixel routing: define routing features on Gaussians, optimize gates in pixel space.
- Weight splatting: reuse Gaussian rasterization to project non-color routing attributes.
- Expert prior analysis: characterize dynamic models by motion trajectory bias before ensembling.
- Routing-weighted distillation: transfer region-specific MoE strengths back to a single model.
- Gaussian responsibility lifting: use pixel gates and volumetric contribution to interpret/prune/fuse experts.

## 12. Gap / Idea Seeds

- Learn experts jointly with diversity regularization rather than training independent existing methods.
- Add top-k sparse routing to reduce full MoE compute while retaining adaptive prior selection.
- Introduce geometry-consistency loss between experts before blending to reduce depth-boundary artifacts.
- Use router uncertainty to trigger fallback to full MoE only in hard regions, distilled expert elsewhere.
- Extend MoE-GS to streaming settings where expert availability and scene dynamics change over time.

## 13. Human Check List

- NEED_HUMAN_CHECK: Zotero date is 2025/10/08, while full text says ICLR 2026; use final publication metadata when available.
- NEED_HUMAN_CHECK: Verify exact SSIM loss convention and $\lambda$ value used for router training in code.
- NEED_HUMAN_CHECK: Check gate-aware Gaussian pruning details in main text/code because extraction truncates Section 3.3.

## 14. Evidence Anchors

- Abstract and Introduction: no single dynamic GS method dominates; MoE-GS, Volume-aware Pixel Router, efficiency and distillation.
- Figure 1: scene/patch/time performance variation and expert motion trajectories.
- Figure 2: two-stage expert training and router training.
- Section 3.2: per-Gaussian weights, weight splatting, router logits and MoE image blending.
- Appendix B.4: single-pass multi-expert rendering rationale.
- Appendix C-D: N3V/Technicolor/HyperNeRF results, distillation, Gaussian-level responsibilities and MDC.
