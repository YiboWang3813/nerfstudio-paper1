# Real-time Photorealistic Dynamic Scene Representation and Rendering with 4D Gaussian Splatting

## 0. Metadata

* Title: Real-time Photorealistic Dynamic Scene Representation and Rendering with 4D Gaussian Splatting
* Authors: Zeyu Yang; Hongye Yang; Zijie Pan; Li Zhang
* Year: 2024
* Venue: ICLR 2024
* PDF source: `/Users/wangyibo/Zotero/storage/W43PWPBX/Yang 等 - 2024 - REAL-TIME PHOTOREALISTIC DYNAMIC SCENE REP- RESENTATION AND RENDERING WITH 4D GAUSSIAN SPLATTING.pdf`
* Local note path: `notes/Real-time Photorealistic Dynamic Scene Representation and Rendering with 4D Gaussian Splatting.md`
* Zotero item key: `T64JFPW2`
* Zotero PDF attachment key: `W43PWPBX`
* Project page: https://fudan-zvg.github.io/4d-gaussian-splatting
* Code: project page available; repository URL is Not specified in extracted PDF text
* Dataset link: Not specified
* Main task: dynamic novel view synthesis for monocular and multi-view dynamic scenes
* Domain: 4D Gaussian primitive; spatiotemporal splatting; dynamic scene rendering
* Input: posed image sequences / videos with time stamps; initial point cloud from first frame or additional initialization
* Output: novel-view rendering at arbitrary time via conditional 3D Gaussian slicing and splatting
* Main representation: unconstrained 4D Gaussians with 4D covariance, 4D rotation, temporal marginal, and 4D spherindrical harmonics appearance
* Supervision type: end-to-end photometric rendering loss only
* Core contribution in one sentence: 把动态场景看作 spatiotemporal 4D volume，用可旋转的 4D Gaussian primitives 直接拟合空间-时间联合分布，再在给定时间切片为 conditional 3D Gaussians 进行 3DGS-style splatting。
* Note status: `complete`

## 1. 一句话技术摘要

这篇论文处理动态新视角合成，通过优化一组具有完整 4D covariance 和 4D rotation 的 Gaussian primitives 来表示时空体，并在渲染时间 $t$ 时将每个 4D Gaussian 分解为 temporal marginal $p(t)$ 和 conditional 3D Gaussian $p(x,y,z|t)$；关键技术差异是避免显式追踪或 deformation field，用 4D Gaussian 的相关协方差自然表达运动。

## 2. 问题形式化

### 2.1 任务

动态场景的像素由 $(u,v,t)$ 索引，而不是静态场景的 $(u,v)$。模型需要在任意目标视角和时间合成图像 $I(u,v,t)$。

论文将动态场景建模为 underlying spatiotemporal 4D volume，并用多个 4D Gaussians 近似该 volume。渲染时对每个 4D Gaussian 在时间维上条件化，得到 3D Gaussian，再投影成 2D splat。

### 2.2 与 deformation-based 方法的差异

Deformable 3DGS / canonical-field 方法假设动态场景由固定 3D primitives 的运动或形变产生。本文不显式维护 tracking 关系，也不假设 scene elements 总是可见，而是把时空局部 support 直接放进 4D Gaussian。

### 2.3 核心假设

* 单个动态元素的时空轨迹可以由 4D anisotropic Gaussian 的长轴和旋转近似。
* 4D covariance 中的 space-time correlation 足以表达 coarse motion。
* 渲染损失无需显式 motion supervision，也能让 4D rotations 涌现出场景动态。
* 动态外观可由 4D spherindrical harmonics 建模，即 view-dependent + time-evolved color。

## 3. 方法概览

渲染流程：

1. 每个 primitive 是 4D Gaussian，mean 为 $\mu=(\mu_x,\mu_y,\mu_z,\mu_t)$，covariance 为 $4\times4$ matrix $\Sigma$。
2. 给定时间 $t$，把 4D Gaussian 分解为 marginal time probability $p(t)$ 和 conditional 3D Gaussian $p(x,y,z|t)$。
3. Conditional 3D Gaussian 通过 3DGS 的投影公式变成 2D planar Gaussian $p(u,v|t)$。
4. 在 alpha blending 中使用 $p(t)p(u,v|t)\alpha$ 作为时空可见性权重。
5. 颜色由 4D spherindrical harmonics $c(d,t)$ 表示，同时依赖 view direction 和时间差。
6. 训练中使用 rendering loss 和 spatiotemporal densification / pruning。

方法核心是“slice a 4D Gaussian at time $t$”，而不是“deform a 3D Gaussian to time $t$”。

## 4. 方法细节

### 4.1 3DGS 回顾

3DGS 中每个 Gaussian 是 unnormalized Gaussian function。Eq. 1: $p(x|\mu,\Sigma)=e^{-\frac{1}{2}(x-\mu)^T\Sigma^{-1}(x-\mu)}$。

3D covariance 分解为 $\Sigma=RS S^T R^T$，$S=diag(s_x,s_y,s_z)$，$R$ 由 unit quaternion $q$ 构造。每个 3D Gaussian 还包含 SH color coefficients 和 opacity $\alpha$。

静态像素渲染 Eq. 2: $I(u,v)=\sum_{i=1}^{N}p_i(u,v;\mu_i^{2d},\Sigma_i^{2d})\alpha_i c_i(d_i)\prod_{j=1}^{i-1}(1-p_j(u,v;\mu_i^{2d},\Sigma_i^{2d})\alpha_j)$。

2D mean Eq. 3 为 $\mu_i^{2d}=Proj(\mu_i|E,K)_{1:2}$，2D covariance Eq. 4 为 $\Sigma_i^{2d}=(JE\Sigma E^TJ^T)_{1:2,1:2}$。

### 4.2 4D Gaussian splatting

动态渲染扩展为 Eq. 5: $I(u,v,t)=\sum_{i=1}^{N}p_i(u,v,t)\alpha_i c_i(d)\prod_{j=1}^{i-1}(1-p_j(u,v,t)\alpha_j)$。

因为 $p_i(u,v,t)=p_i(t)p_i(u,v|t)$，Eq. 6 写成 $I(u,v,t)=\sum_i p_i(t)p_i(u,v|t)\alpha_i c_i(d)\prod_{j<i}(1-p_j(t)p_j(u,v|t)\alpha_j)$。

如果只给 3D Gaussian 加独立的 1D temporal Gaussian，即假设 $p(x,y,z|t)=p(x,y,z)$，会得到 block-diagonal covariance。论文把这个 baseline 称为 No-4DRot，实验显示它能拟合 temporal support，但很难捕捉真实运动。

### 4.3 4D Gaussian representation

完整 4D Gaussian covariance 由 Eq. 7 给出：$\Sigma=RSS^TR^T$。

其中：

* $S=diag(s_x,s_y,s_z,s_t)$；
* $R$ 是 4D rotation matrix；
* 4D rotation 可分解为一对 isotropic rotations，由两个 quaternions $q_l=(a,b,c,d)$ 和 $q_r=(p,q,r,s)$ 表示。

Eq. 8 给出 $R=L(q_l)R(q_r)$ 的矩阵构造。该参数化允许 Gaussian ellipsoid 在 space-time 中任意旋转，从而让时间维与空间维相关。

4D mean 为 $\mu=(\mu_x,\mu_y,\mu_z,\mu_t)$。

### 4.4 Conditional 3D Gaussian at time $t$

给定渲染时间 $t$，4D Gaussian 的 conditional 3D distribution 是 Gaussian。Eq. 9:

* $\mu_{xyz|t}=\mu_{1:3}+\Sigma_{1:3,4}\Sigma_{4,4}^{-1}(t-\mu_t)$；
* $\Sigma_{xyz|t}=\Sigma_{1:3,1:3}-\Sigma_{1:3,4}\Sigma_{4,4}^{-1}\Sigma_{4,1:3}$。

这就是运动表达的关键：当 $\Sigma_{1:3,4}$ 非零时，conditional mean 随 $t$ 线性变化，等价于 Gaussian 的空间期望沿时间移动。更复杂运动由多个 4D Gaussians 组合表达。

Temporal marginal Eq. 10: $p(t)=N(t;\mu_4,\Sigma_{4,4})$。渲染前可根据 $p(t)$ 过滤当前时间无贡献的 Gaussians。

### 4.5 4D Spherindrical Harmonics

3DGS 的颜色 $c_i(d)$ 只依赖 view direction。动态场景中 appearance 也随时间演化，因此本文提出 4D spherindrical harmonics。

定义 $c_i(d,t)$，其中 $d=(\theta,\phi)$ 是 spherical view direction，$t$ 是相对于 Gaussian temporal expectation 的时间差。4DSH 由 spherical harmonics 与 1D Fourier basis 组合。Eq. 11: $Z_{nl}^{m}(t,\theta,\phi)=\cos(2\pi n t/T)Y_l^m(\theta,\phi)$。

其中 $Y_l^m$ 是 3D spherical harmonics，$n$ 是 Fourier order，$l,m$ 是 SH degree/order。它提供了 view-dependent appearance 与 temporal appearance evolution 的统一基函数。

### 4.6 Training

训练沿用 3DGS 的 interleaved optimization and density control。监督只使用 rendering loss，论文强调不使用显式 motion supervision 或 regularization。

对 dramatic changes 场景，作者观察到 temporal flickering / jitter，认为与 suboptimal sampling 有关；直接采用 time batch sampling 比先验 regularization 更有效。具体 batch sampling schedule 在抽取文本中未完全展开，标为 `NEED_HUMAN_CHECK`。

### 4.7 Densification in spacetime

4DGS 不仅在空间 densify，也允许在时间维 split。过重建不仅发生在空间，也可能发生在时间。论文允许 Gaussian 按完整 4D Gaussian PDF 采样新位置进行 split，包括 time dimension。Table 3 中 No-Time split 消融显示 temporal split 有效。

### 4.8 初始化与长视频特性

Plenoptic Video dataset 中，作者使用第一帧点云初始化 Gaussians，并额外在包围场景的球面上均匀加 100,000 个点以拟合 COLMAP 未重建的远景背景；这些点在 10,000 iterations 后停止优化。

Appendix A 指出如果没有初始点，远处背景即便静态也难捕捉。球面初始化可以缓解背景缺失，但学到的可能只是 spherical Gaussian background map，不一定是正确 geometry。

Appendix E 显示 temporal variance 可自然形成 dynamic/static mask：背景 Gaussians 在时间维方差大，可覆盖长时间；动态 Gaussians temporal support 更局部。渲染时先按 $p_i(t)$ 过滤，参与 rasterization 的 Gaussians 数量随视频长度基本稳定。

## 5. 数学目标与损失

### 5.1 Rendering objective

论文只使用 rendering loss。没有显式 scene flow、tracking、rigidity 或 canonical consistency loss。

### 5.2 Space-time factorization

核心数学目标是正确实现 $p(u,v,t)=p(t)p(u,v|t)$。Appendix B 证明 unnormalized Gaussian 下条件概率分解仍成立，关键等式是 determinant decomposition $det(\Sigma)=det(\Sigma_t)det(\Sigma_{uv|t})$。

### 5.3 Ablation-defined objectives

三个重要组件通过消融体现：

* Full 4D rotation: 让 $\Sigma_{1:3,4}$ 非零，表达 motion；
* 4DSH: 建模 time-evolved appearance；
* Time split: 允许 densification 在 temporal dimension 发生。

## 6. 训练与推理流程

### 6.1 训练流程

1. 初始化 4D Gaussians 的 space/time mean、scale、4D rotation、opacity、4DSH coefficients。
2. 给定 mini-batch 中的 views 和 timestamps。
3. 对每个 Gaussian 计算 $p_i(t)$，并从 4D Gaussian 条件化得到 $p_i(x,y,z|t)$。
4. 将 conditional 3D Gaussian 投影到 2D，得到 $p_i(u,v|t)$。
5. 用 $p_i(t)p_i(u,v|t)\alpha_i$ 参与 alpha blending。
6. 用 4DSH 得到 $c_i(d,t)$。
7. 反向传播 rendering loss。
8. 执行 spatiotemporal densification / pruning，包括 time split。

### 6.2 推理流程

给定时间和相机：

1. 用 $p_i(t)$ 快速过滤 temporal support 很低的 Gaussians；
2. 对剩余 Gaussians 求 conditional 3D Gaussian；
3. 投影成 2D splats；
4. rasterize and alpha blend。

由于每帧实际参与 rasterization 的 Gaussians 数量接近稳定，渲染速度可随视频长度保持稳定。

## 7. 实验设置与结果

### 7.1 数据集

论文覆盖：

* Plenoptic Video / Neural 3D Video 多视角真实动态场景；
* D-NeRF synthetic monocular dynamic scenes；
* Appendix 中 Waymo Open Dataset urban scenes；
* Appendix 中长视频 temporal characteristic 分析。

### 7.2 多视角真实场景

Table 4 appendix 给出 Plenoptic Video per-scene PSNR：

* Coffee Martini: 28.33；
* Cook Spinach: 32.93；
* Cut Beef: 33.85；
* Flame Salmon: 29.38；
* Flame Steak: 34.03；
* Sear Steak: 33.51；
* Mean: 32.01。

主文强调该方法在 Plenoptic Video 上同时实现高质量与实时渲染。Figure 3 的 Flame Salmon 展示手、火焰枪、salmon 纹理等动态细节。

### 7.3 单目 synthetic D-NeRF

Table 2 平均结果：

* T-NeRF: PSNR 29.51，SSIM 0.95，LPIPS 0.08；
* D-NeRF: 29.67，0.95，0.07；
* TiNeuVox: 32.67，0.97，0.04；
* HexPlanes: 31.04，0.97，0.04；
* V4D: 33.72，0.98，0.02；
* 4DGS by Wu et al.: 33.30，0.98，0.03；
* Ours: 34.09，0.98，0.02。

论文强调在单目设置中不引入 topology-specific architectural priors，仍超过对比方法。

### 7.4 Ablation

Table 3 在 Flame Salmon 和 Cut Roasted Beef 上：

* No-4DRot: average PSNR 30.79，SSIM 0.96；
* No-4DSH: 31.38，0.97；
* No-Time split: 30.25，0.97；
* Full: 31.62，0.97。

结论：

* 4D rotation 对 motion fitting 很关键；
* 4DSH 对 dynamic appearance 有帮助；
* time split 对 spatiotemporal density control 有明显贡献。

### 7.5 Emerged dynamics

Figure 4 将每个 Gaussian 的 conditional mean $\mu_{xyz|t}$ 在相邻帧间的 3D displacement 投影到图像平面，并渲染为 optical flow。结果显示仅用 rendering loss 优化，也能产生 coarse scene dynamics。这是对“4D rotation 捕捉 underlying 3D movement”的定性支持。

### 7.6 Urban scenes

Appendix D 在 Waymo Open Dataset 上测试 urban scenes。由于 sparse observation 和 wide range，作者加入 LiDAR sparse inverse-depth supervision，关闭 4DSH temporal coefficients，并用 cubemap 建模 sky。这个 setting 已经超出主方法的纯 photometric 设定，引用时要单独说明。

## 8. 声称贡献 vs 实际技术增量

### 8.1 论文声称

论文声称：

* 首个支持 end-to-end training 和 real-time rendering 的 high-resolution photorealistic 4D Gaussian model；
* 用 4D Gaussian primitives coherent integrated modeling space and time；
* 用 4D spherindrical harmonics 建模 time-evolved view-dependent color；
* 多数据集上质量和效率超过 prior methods。

### 8.2 实际技术增量

实际增量是把 dynamic GS 的时间建模从“3D primitive + deformation”改为“4D primitive + conditional slicing”。4D covariance 的 cross terms 允许 space-time correlation，因此一个 Gaussian 的 conditional mean 可以随时间移动。

这使方法既不同于：

* Deformable 3DGS: 显式 MLP deformation；
* Dynamic3DGS: per-frame position/rotation tracking；
* 4DGS by Wu et al.: hex-plane / deformation-style 4D Gaussian Splatting；
* Ex4DGS: keyframe interpolation。

它的表达力来自 4D covariance geometry，而不是外部 motion network。

### 8.3 证据强度

证据强的部分：

* 4D rotation / 4DSH / time split 都有 ablation；
* Appendix 给出条件概率分解证明；
* 渲染 optical flow 可视化支持 motion emergence；
* 多视角、单目、urban appendix 都有实验。

证据弱的部分：

* 背景初始化依赖第一帧点云和额外球面点；
* 对无初始点远景背景承认困难；
* Urban scenes 使用额外 LiDAR depth、sky mask、cubemap，不能和主设定混为一谈；
* 复杂 motion 由多个 Gaussians 叠加表达，单个 4D Gaussian 只能表达局部近似线性/椭球时空结构。

## 9. 局限与隐藏假设

显式局限：

* 如果第一帧没有对应初始点，远处背景即使静态也难以重建。
* 球面初始化缓解背景缺失，但不保证正确 geometry。

隐藏假设：

* 4D Gaussian temporal locality 不会导致视频很长时 primitive 数量失控；Appendix E 支持但仍依赖场景。
* 4D Gaussian 的 conditional mean 随时间线性变化，复杂非线性运动依赖多个 Gaussians / split 表达。
* Rendering loss 足以学习 motion，但没有 motion regularization，可能在弱观测或遮挡中不稳定。
* 4DSH temporal basis 对周期或平滑 appearance 有利，但对突变 lighting / topology changes 的上限未充分讨论。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法名称 | 4DGS (Yang et al., ICLR 2024) |
| 核心表示 | full 4D Gaussian primitives |
| 时间建模 | 4D covariance + temporal marginal $p(t)$ |
| Motion 表达 | conditional mean $\mu_{xyz|t}$ changes with $t$ |
| Rotation | 4D rotation from two quaternions |
| Appearance | 4D spherindrical harmonics |
| Rendering | slice 4D Gaussian to conditional 3D Gaussian, then 3DGS splatting |
| Supervision | rendering loss only |
| Density control | spatiotemporal densification, including time split |
| 主数据集 | Plenoptic Video / Neural 3D Video; D-NeRF; appendix Waymo |
| 主优势 | 不需要 deformation MLP / tracking；实时；时空一体化 |
| 主短板 | 初始点依赖；复杂非线性运动需多个 primitives；远景背景 geometry 不保证 |

## 11. 对我的研究可复用组件

1. Conditional slicing view：把动态 GS 表示成 $p(t)p(x,y,z|t)$，适合放进 dynamic GS taxonomy 的“4D primitive / no deformation network”类别。
2. 4D rotation motion emergence：用 covariance cross term 表示 motion，可与 keyframe、control graph、MLP deformation 对比。
3. Temporal marginal filtering：按 $p_i(t)$ 过滤当前帧无贡献 primitives，是长视频加速思路。
4. 4DSH：appearance dynamics 的基函数建模方式，可与 time-dependent SH / MLP color head 对比。
5. Time split densification：把 3DGS density control 扩展到时间维，适合用于 spatiotemporal over/under-reconstruction 分析。

## 12. Gap and Idea Seeds

### 12.1 Gap: 非线性运动表达受限

单个 4D Gaussian 的 conditional mean 随 $t$ 线性变化。可研究 spline-4D Gaussian 或 mixture-with-shared-identity 表示更复杂轨迹。

### 12.2 Gap: 背景初始化依赖强

远处背景需要额外球面点。可结合 depth prior、sky model、unbounded Gaussian 初始化，形成更 principled 的背景建模。

### 12.3 Gap: 无显式 motion regularization

Rendering loss 可涌现粗光流，但在遮挡/弱纹理/多解场景可能不稳定。可加入弱 optical-flow consistency，但保持不依赖 tracking。

### 12.4 Gap: Appearance temporal basis 固定

4DSH 使用 Fourier temporal basis。对非周期突变 appearance，可尝试 adaptive temporal basis、wavelet 或 learned low-rank temporal color basis。

### 12.5 Gap: 与 streaming 的关系

4DGS 是 end-to-end 全视频训练，不是 online。可把 temporal marginal filtering 和 time split 迁移到 streaming setting，做 online 4D primitive 增量更新。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: Code repository URL 未在 PDF 文本中抽到，项目页可能包含。
* `NEED_HUMAN_CHECK`: Training 中 time batch sampling 的具体策略和超参需要查正文缺失段或代码。
* `NEED_HUMAN_CHECK`: 4D rotation 的 quaternion normalization / optimization details 需要代码确认。
* `NEED_HUMAN_CHECK`: Plenoptic Video 初始化中 100,000 sphere points 和 10,000 iteration stop 的具体实现需看代码。
* `NEED_HUMAN_CHECK`: Urban experiments 使用 LiDAR depth / sky mask / cubemap，和主实验设定不同，矩阵中应单独标注。
* `NEED_HUMAN_CHECK`: 同名/近名 4DGS 论文很多，引用时需写作者或标题全称避免和 Wu et al. 混淆。

## 14. Evidence Anchors

* Abstract: 4D primitives, anisotropic ellipses rotating in space-time, 4D spherindrical harmonics, real-time rendering。
* Figure 1: dynamic scene to 4D Gaussians to 2D image via temporal orthogonal projection and spatial projection。
* Figure 2: rendering pipeline: 4D Gaussian -> conditional 3D Gaussian + marginal 1D Gaussian -> 2D splat。
* Section 3.1 / Eq. 1-4: 3DGS unnormalized Gaussian, 2D projection, static blending。
* Section 3.2 / Eq. 5-6: dynamic pixel formula and $p(u,v,t)=p(t)p(u,v|t)$ factorization。
* Section 3.2 / Eq. 7-8: full 4D covariance and 4D rotation from two quaternions。
* Section 3.2 / Eq. 9-10: conditional 3D Gaussian and temporal marginal。
* Section 3.2 / Eq. 11: 4D spherindrical harmonics。
* Section 3.3: rendering loss only, end-to-end full-video training, time batch sampling comment。
* Table 2: D-NeRF average PSNR 34.09，SSIM 0.98，LPIPS 0.02。
* Figure 3: Flame Salmon qualitative comparison and FPS labels。
* Table 3: No-4DRot, No-4DSH, No-Time split ablations。
* Figure 4: rendered optical flow from conditional Gaussian trajectories。
* Section 5 Conclusion: real-time high-fidelity video synthesis claim。
* Appendix A: limitation on absent initial points and distant background。
* Appendix B: proof of Gaussian factorization for unnormalized functions。
* Appendix C / Table 4: Plenoptic Video per-scene PSNR, mean 32.01。
* Appendix D: Waymo urban scene modifications with LiDAR depth and sky cubemap。
* Appendix E / Figures 8-11: temporal distribution, marginal filtering, long-video Gaussian count stability, No-4DRot comparison。
