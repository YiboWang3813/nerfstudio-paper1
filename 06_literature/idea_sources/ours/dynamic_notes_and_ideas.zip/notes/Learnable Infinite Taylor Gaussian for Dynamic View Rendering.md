# Learnable Infinite Taylor Gaussian for Dynamic View Rendering

## 0. Metadata

- Title: Learnable Infinite Taylor Gaussian for Dynamic View Rendering
- Authors: Bingbing Hu; Yanyan Li; Rui Xie; Bo Xu; Haoye Dong; Junfeng Yao; Gim Hee Lee
- Venue/Year: CVPR 2025
- Project page: https://ellisonking.github.io/TaylorGaussian
- Zotero item key: `Q9MZL3F9`
- Zotero PDF attachment key: `8KNIF6T8`
- PDF path: `/Users/wangyibo/Zotero/storage/8KNIF6T8/Hu 等 - Learnable Infinite Taylor Gaussian for Dynamic View Rendering.pdf`
- Local note path: `notes/Learnable Infinite Taylor Gaussian for Dynamic View Rendering.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

TaylorGaussian 用 learnable infinite Taylor series 建模动态 3D Gaussians 的 position、scale、rotation 和 opacity 随时间变化：三阶 Taylor expansion 负责主导的大尺度运动，GP/LP deformation field 学习 Peano remainder，从而在显式多项式可解释性和隐式网络灵活性之间折中。

## 2. Problem Formulation

动态 3DGS 需要描述大量 Gaussian attributes 随时间变化，例如 position、rotation、scale 和 opacity。若直接用 end-to-end deformation network，表达力强但缺少显式监督，容易得到质量不稳定的 transformation field。若手写 time-conditioned polynomial trajectory，则可解释但泛化性差，且需要人工设计多项式复杂度。

本文把每个 Gaussian 的时变属性看成可由 Taylor formula 描述的函数，并将 transformation field 写成 dominant Taylor polynomial 加 learnable Peano remainder。这样显式项捕获平滑、大尺度、低阶运动，隐式 remainder 捕获高阶残差和局部细节。

## 3. Method Overview

方法从 COLMAP 初始化的点云和相机开始，构建动态 4D Gaussian 表示。对每个 Gaussian，opacity、position、scale 和 quaternion rotation 都成为时间相关函数。主导 motion component 使用三阶 Taylor expansion 建模，近似 position、scale 和 orientation 的连续变化。

为了补足有限阶 Taylor expansion 的误差，论文将 Gaussians 分为 Global Gaussian Primitives (GPs) 和 Local Gaussian Primitives (LPs)。GPs 通过 farthest point sampling 从 Gaussian map 中稀疏选出，作为对象骨架；一个 MLP 预测每个 GP 的 offset / rotation。LPs 的 Peano remainder 不直接逐点预测，而是用邻近 GPs 的 deformation 通过 Linear Blend Skinning 插值得到，以保持空间和时间一致性。

## 4. Method Details

### 4.1 Dynamic Gaussian Representation

静态 3DGS 中 Gaussian 由 mean $\mu$、covariance $\Sigma$、color $c$ 和 opacity $o$ 描述。本文加入 timestamp $t$，得到 $G_{4D}=[\mu,\Sigma,c,o,t]$。opacity 被建模为 time-dependent function：

$$
\alpha_i(t)=\sigma_i(t)\exp\left(-\frac{1}{2}(x-\mu_i(t))^\top\Sigma_i(t)^{-1}(x-\mu_i(t))\right).
$$

其中 $\mu_i(t)$ 和 $\Sigma_i(t)$ 随时间变化，$\sigma_i(t)$ 由 stationary opacity、temporal scale 和 temporal center 组成的 RBF-like function 描述。这使 Gaussian 是否在某一时间有效也可学习。

### 4.2 Learnable Infinite Taylor Formulation

Taylor formula 的目标是用多项式近似复杂函数。论文将 Gaussian 的 transformation field 写成两部分：$T_i(t)=f_k(t)+H_k(t)$。其中 $f_k(t)$ 是 Taylor expansion 的 dominant component，$H_k(t)$ 是由 deformation field 学习的 Peano remainder。

该表述的意义是：如果只使用有限阶 Taylor expansion，就会产生 approximation error；如果完全使用网络，又缺少可解释结构。TaylorGaussian 将低阶主运动放在显式多项式中，把高阶项留给可学习 remainder。

### 4.3 Taylor Expansion for Position, Scale, and Orientation

position motion 用时间相关多项式描述：

$$
p_i(t)=\sum_{k=0}^{n}\frac{1}{k!}f_p^{(k)}(t_\tau)(t-t_\tau)^k.
$$

scale consistency 类似，$s_i(t)=\sum_{k=0}^{m}\frac{1}{k!}f_s^{(k)}(t_\tau)(t-t_\tau)^k$。orientation motion 使用 quaternion $q_i(t)$ 建模，形式为 $q_i(t)=\sum_{k=0}^{l}\frac{1}{k!}f_q^{(k)}(t_\tau)(t-t_\tau)^k$。论文贡献中强调 dominant component 使用 third-order Taylor expansion 来估计大运动。

### 4.4 GP/LP Peano Remainder Modeling

GPs 是稀疏、全局代表性的 Gaussian primitives，作为动态对象的 skeleton。LPs 数量更多，用于高质量渲染。方法先用 farthest point sampling 选出少量 GPs，再用 time-dependent transformation prediction network 预测 GP 在 canonical coordinates 下的 translation 和 orientation offset。论文写作 $\Delta_{\mathrm{GP}}=\mathrm{MLP}(\mathrm{GP})$，表示 querying each GP 时 MLP 只给该 GP 的 offset。

LP 的 Peano remainder 由邻近 GP deformation field 通过 LBS 插值得到。GP $j$ 到 LP $i$ 的权重用 Gaussian-kernel RBF：

$$
w_{ij}=\frac{\hat w_{ij}}{\sum_{j\in N}\hat w_{ij}},\quad \hat w_{ij}=\exp\left(-\frac{d_{ij}^2}{2r_j^2}\right).
$$

其中 $r_j$ 是可学习 GP radius。LP 的位置和旋转 remainder 由邻近 GPs 的 rotation、translation offset 和权重合成。这种设计避免对所有 Gaussians 直接用 MLP 预测高阶项，同时让 LP 与邻近 GP 保持空间关系和时序一致 motion。

### 4.5 Rendering and Optimization

渲染仍使用 3DGS splatting。每个时间点先由 Taylor + Peano remainder 得到 Gaussian 的 position、scale、orientation 和 opacity，再投影到目标相机并 alpha blending。训练使用 Adam，在单张 NVIDIA RTX 4090 上进行。几何结构和 camera poses 由 COLMAP 初始化。

## 5. Mathematical Objectives and Losses

论文没有把主要创新写成一个新 photometric loss，而是写成 transformation field 的参数化。核心公式是 $T_i(t)=f_k(t)+H_k(t)$：$f_k(t)$ 为有限阶 Taylor 主项，$H_k(t)$ 为 Peano remainder。position、scale 和 rotation quaternion 都按 Taylor 形式展开。

GP/LP remainder 的约束来自 LBS 的结构先验：LP 的高阶 offset 由邻近 GP 的 offset 和 rotation 合成，而不是任意自由移动。RBF weights 中的 radius $r_j$ 可学习，使 GP 的影响范围能随数据调整。

## 6. Training and Inference Procedure

训练流程先用 COLMAP 重建相机和初始点云，再初始化动态 Gaussians。随后构造 time-dependent Gaussian attributes：time-opacity、time-motion、time-scale 和 time-rotation。GPs 通过 FPS 选出，LPs 通过邻近 GPs 的 LBS 获得 Peano remainder。

推理时，给定 timestamp $t$ 和目标相机，模型先计算每个 Gaussian 的 Taylor dominant component，再加上 GP/LP deformation remainder，得到当前时刻的 Gaussian parameters 并执行 3DGS rasterization。由于主运动是显式多项式，remainder 由稀疏 GP field 传播到 LPs，推理不需要对全部 Gaussians 逐点运行大网络。

## 7. Experimental Setup and Results Summary

实验使用 N3DV 和 Technicolor Light Field Dataset。N3DV 选 Cook Spinach、Cut Roasted Beef、Flame Steak、Sear Steak 四个场景，每个 300 frames；Technicolor 选 Birthday、Painter、Train、Fatma。指标为 PSNR、SSIM 和 LPIPS。

N3DV 上，Ours 在四个场景均取得最高 PSNR 和 SSIM。Cook Spinach 为 32.59 / 0.966 / 0.054，Sear Steak 为 33.12 / 0.973 / 0.049，Flame Steak 为 33.34 / 0.971 / 0.052，Cut Roast Beef 为 33.06 / 0.969 / 0.055。相比 SWinGS 的 31.96 / 0.946 / 0.094、32.21 / 0.950 / 0.092、32.18 / 0.953 / 0.087、31.84 / 0.945 / 0.099，提升集中在 PSNR/SSIM，LPIPS 有些场景不如 4DGS 的很低数值。

Technicolor 上，Ours 在 Birthday、Painter、Train、Fatma 分别为 34.72 / 0.988 / 0.013，38.37 / 0.985 / 0.022，35.30 / 0.990 / 0.008，38.91 / 0.945 / 0.071。表中对比 D3DGS、STG、FSGS 和 4DGS，Ours 几乎各项最优，尤其 Train 场景填补了 D3DGS 缺失结果。

消融表在 N3DV 上显示完整模型为 33.03 / 0.970 / 0.052。去掉 Time-opacity 为 31.17 / 0.952 / 0.096，去掉 Time-motion 为 29.24 / 0.920 / 0.154，去掉 Time-rotation 为 31.21 / 0.953 / 0.103，去掉 Time-scale 为 31.40 / 0.953 / 0.097，去掉 Peano remainder 为 31.51 / 0.935 / 0.103。Time-motion 和 Peano remainder 的影响最大，支持论文关于主项与 remainder 都必要的论点。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 learnable infinite Taylor Formula、third-order Taylor dominant field、Peano remainder deformation field 和更强的动态渲染结果。实际技术增量可以理解为一种 hybrid deformation parameterization：用低阶 Taylor polynomial 给动态 3DGS 明确的 temporal structure，再用稀疏 GP-driven LBS field 补充高阶 residual。

相对 D3DGS / 4DGS 这类直接学习 deformation 或 spatiotemporal feature 的方法，TaylorGaussian 更强调数学可解释性；相对纯 polynomial trajectory，它又通过 GP/LP Peano remainder 避免手工设定函数复杂度。其新意主要在表示设计，而不是 rasterizer 或 photometric objective。

## 9. Limitations / Assumptions

方法依赖 COLMAP 提供高质量初始点云和相机位姿；在弱纹理、快速运动或相机估计失败的场景中，初始化误差可能影响 Taylor field 学习。

第三阶 Taylor 主项假设大尺度 motion 可由低阶平滑函数描述。对突变、接触、遮挡导致的不连续变化，仍需 Peano remainder 弥补，可能增加对 GP selection 和 LBS weights 的依赖。

论文结论中提到未来需要处理更复杂和高度动态场景，说明当前模型在极端动态、强拓扑变化或更难多物体交互下仍可能需要进一步 refinement。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Multi-view dynamic videos with COLMAP initialization |
| Output | Time-dependent 4D Gaussians for dynamic view rendering |
| Core representation | Learnable infinite Taylor series: Taylor dominant term + Peano remainder |
| Dominant motion | Third-order Taylor expansion for position, scale, orientation |
| Remainder | GP/LP deformation field, GP MLP offsets, LP LBS interpolation |
| Time attributes | Time-opacity, time-motion, time-rotation, time-scale |
| Strength | Explicit temporal structure plus learnable residual flexibility |
| Weakness | 依赖初始化与 GP/LP skeleton；极端动态需进一步验证 |

## 11. Reusable Components

- Taylor polynomial parameterization for Gaussian position、scale、quaternion rotation。
- GP/LP split：少量 skeleton GPs 控制大量 rendering LPs。
- Learnable GP radius in RBF skinning weights。
- Peano remainder as deformation residual instead of only finite polynomial approximation。
- Time-opacity ablation pattern for modeling Gaussian temporal visibility。

## 12. Gap / Idea Seeds

- GP selection 用 FPS，可探索 motion-aware 或 uncertainty-aware GP sampling。
- Taylor expansion order 固定为三阶，可改成 scene-adaptive / Gaussian-adaptive order selection。
- Peano remainder 目前由 GP deformation field 插值，可结合 DQB 替代 LBS 以改善旋转插值。
- 对 LP 的 temporal visibility 与 motion uncertainty 可以联动，避免遮挡区域被错误 Taylor extrapolation。

## 13. Human Check List

- NEED_HUMAN_CHECK: 项目 URL 在 PDF 文本中带有空格 `https: //...`，本笔记归一化为 `https://ellisonking.github.io/TaylorGaussian`。
- NEED_HUMAN_CHECK: PDF 摘要称 learnable infinite Taylor Formula，但主文 dominant component 为有限三阶 Taylor expansion，infinite 部分依赖 Peano remainder 的建模解释。
- NEED_HUMAN_CHECK: N3DV 表中 Ours 的 LPIPS 不总是优于 4DGS，本笔记按表格保留该细节，避免只写“全面最优”。

## 14. Evidence Anchors

- Section 3.2: dynamic Gaussian representation and time-dependent opacity。
- Section 4.1: Taylor formula and Peano remainder background。
- Section 4.2: $T_i(t)=f_k(t)+H_k(t)$ learnable infinite Taylor formulation。
- Section 4.3: Taylor expansion for position, scale, orientation。
- Section 4.4: GP/LP split, GP MLP offset, RBF weights and LBS remainder。
- Tables 1-2: N3DV and Technicolor quantitative comparisons。
- Table 3: ablation on time-opacity, time-motion, time-rotation, time-scale, Peano remainder。
