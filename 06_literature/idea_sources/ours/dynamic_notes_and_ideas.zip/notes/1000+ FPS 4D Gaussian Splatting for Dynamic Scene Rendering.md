# 1000+ FPS 4D Gaussian Splatting for Dynamic Scene Rendering

## 0. Metadata

- Title: 1000+ FPS 4D Gaussian Splatting for Dynamic Scene Rendering
- Authors: Yuheng Yuan; Qiuhong Shen; Xingyi Yang; Xinchao Wang
- Venue/Year: NeurIPS 2025
- Project page: https://4dgs-1k.github.io/
- Zotero item key: `QX6TF42R`
- Zotero PDF attachment key: `ICMAZKG6`
- PDF path: `/Users/wangyibo/Zotero/storage/ICMAZKG6/Yuan 等 - 1000+ FPS 4D Gaussian Splatting for Dynamic Scene Rendering.pdf`
- Local note path: `notes/1000+ FPS 4D Gaussian Splatting for Dynamic Scene Rendering.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

4DGS-1K 通过分析 vanilla 4DGS 的 temporal redundancy，先用 spatial-temporal variation score 全局剪掉 short-lifespan Gaussians，再用 key-frame temporal filter 在渲染前跳过 inactive Gaussians，从而以约 2% 存储和 1000+ raster FPS 保持接近原 4DGS 的质量。

## 2. Problem Formulation

4D Gaussian Splatting 用 4D Gaussians 表示动态场景，质量高但存储和渲染开销大。N3V 上 vanilla 4DGS 每个场景可达约 2GB，包含数百万 Gaussians；而每帧渲染时，需要先把所有 4D Gaussians 条件化为 3D Gaussians 和 temporal opacity，再 rasterize。

论文指出主要冗余有两类。第一，short-lifespan Gaussians：大量 Gaussian 只在很短时间窗口内 flicker，用小 $\Sigma_t$ 拟合局部动态，导致总数量爆炸。第二，inactive Gaussians：任意时间只有少部分 Gaussians 对该帧有贡献，但 rasterization 预处理仍处理所有 Gaussians。

4DGS-1K 的目标不是提出新动态重建模型，而是在训练好的或训练中的 4DGS 表示上压缩和加速，同时保持图像质量。

## 3. Method Overview

4DGS-1K 有两个步骤。第一步是 transient Gaussian pruning。方法定义 spatial-temporal variation score，将每个 Gaussian 的空间渲染贡献和时间持久性结合。低分 Gaussians 通常贡献小、寿命短，被剪掉；剩余 Gaussians 继续优化若干 iterations 以补偿质量损失。

第二步是 temporal filtering。方法在稀疏 key-frame timestamps 上预先计算 active Gaussian masks。渲染任意测试时间 $t$ 时，取左右相邻 key frames 的 mask union，只对这些 active Gaussians 做 4D-to-3D decomposition 和 rasterization，从而跳过大部分 inactive Gaussians。

这两个步骤相互促进：剪掉短寿命 Gaussians 后，剩余 Gaussians 的 temporal influence 更长，active masks 在邻近帧更稳定，可以使用更稀疏 key frames，进一步降低 mask 存储。

## 4. Method Details

### 4.1 4DGS Conditional Gaussian

每个 4D Gaussian 有 mean $\mu=(\mu_x,\mu_y,\mu_z,\mu_t)$ 和 covariance $\Sigma\in\mathbb{R}^{4\times4}$。在时间 $t$，由 multivariate Gaussian condition 得到 3D Gaussian：

$$
\mu_{xyz|t}=\mu_{1:3}+\Sigma_{1:3,4}\Sigma_{4,4}^{-1}(t-\mu_t).
$$

$$
\Sigma_{xyz|t}=\Sigma_{1:3,1:3}-\Sigma_{1:3,4}\Sigma_{4,4}^{-1}\Sigma_{4,1:3}.
$$

Alpha blending 中，opacity 包含 temporal Gaussian term $p_i(t)$、2D projected Gaussian $p_t(u,v|t)$ 和 learned opacity $\sigma_i$：

$$
\alpha_i=p_i(t)p_t(u,v|t)\sigma_i,\quad p_i(t)\sim\mathcal{N}(t;\mu_t,\Sigma_{4,4}).
$$

论文把 $\Sigma_{4,4}$ 简记为 $\Sigma_t$。小 $\Sigma_t$ 意味着 Gaussian 的 temporal support 短。

### 4.2 Spatial Score

Spatial score 衡量 Gaussian 对所有训练视图像素的 alpha-compositing 贡献。对 Gaussian $i$，遍历所有训练视图的所有像素：

$$
SS_i=\sum_{k=1}^{NHW}\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j).
$$

这里 $N$ 是训练 views 数，$H,W$ 是图像高宽。该项类似 3DGS pruning 中的 contribution score，反映 Gaussian 是否真正影响 rendered color。

### 4.3 Temporal Score

Temporal score 旨在给 lifespan 更长、temporal opacity 更稳定的 Gaussians 更高分。Temporal opacity $p_i(t)$ 的二阶导为：

$$
p_i^{(2)}(t)=\left(\frac{(t-\mu_t)^2}{\Sigma_t^2}-\frac{1}{\Sigma_t}\right)p_i(t).
$$

短寿命 Gaussian 的 temporal opacity 变化快，二阶导幅度大；持久 Gaussian 的变化更平滑。论文用 tanh 映射构造 variation score：

$$
STV_i=\sum_{t=0}^{T}\frac{1}{0.5\cdot\tanh(p_i^{(2)}(t))+0.5}.
$$

再乘以 normalized 4D Gaussian volume $\gamma(S_i^{4D})=\mathrm{Norm}(V(S_i^{4D}))$ 得到 temporal score：

$$
ST_i=STV_i\gamma(S_i^{4D}).
$$

### 4.4 Spatial-Temporal Variation Score and Pruning

最终 pruning score 为：

$$
S_i=\sum_{t=0}^{T}ST_iSS_i.
$$

所有 4D Gaussians 按 $S_i$ 排序，低分者被剪掉。直觉上，低空间贡献且短寿命的 Gaussians 对整体时空重建贡献低，剪掉能减少存储并迫使剩余 Gaussians 使用更长 temporal spans 表达场景。

剪枝后，剩余 Gaussians 继续优化一段 iterations，以补偿剪枝造成的微小质量损失。

### 4.5 Key-Frame Temporal Filtering

为跳过 inactive Gaussians，4DGS-1K 预先选取均匀间隔 key-frame timestamps $\{t_i\}_{i=0}^{T}$。对每个 key frame，在所有训练 views 渲染并计算 visibility masks $m_{i,j}$。该 key frame 的 active mask 是所有训练 views 的 union：

$$
M_i=\bigcup_{j=1}^{N}m_{i,j}.
$$

渲染任意测试时间 $t_{\mathrm{test}}$ 时，找到相邻 key frames $t_l,t_r$，只使用 $M_l\cup M_r$ 中标记的 Gaussians 进行 4D-to-3D decomposition 和 rasterization。

这种方法利用了 active Gaussians 在相邻帧高度重叠的事实。论文观察到 Sear Steak 上相邻 20-frame window 内 active set IoU 超过 80%。

## 5. Mathematical Objectives and Losses

4DGS-1K 本身主要是 pruning/filtering framework，不改变 4DGS 的图像重建 loss。核心目标可理解为在保持 PSNR/SSIM/LPIPS 接近的前提下最小化 storage 和 per-frame active Gaussian count。

关键数学对象是 pruning score $S_i$ 和 temporal filter mask $M_i$。前者影响训练/压缩后的全局 Gaussian set，后者影响渲染时每帧参与计算的局部 subset。

后处理版本 Ours-PP 进一步压缩存储，从表中看质量几乎不变，但具体 post-processing 压缩细节在抽取文本中未完整显示。

## 6. Training and Inference Procedure

流程上先训练或加载 4DGS；然后计算所有 Gaussians 的 spatial-temporal variation score 并剪枝；对剩余 Gaussians 继续优化；最后构建 key-frame active masks。渲染阶段根据测试时间查找相邻 key frames，取 mask union 过滤 inactive Gaussians。

论文在 Neural 3D Video 和 D-NeRF 上评估。N3V 表中对官方 4DGS retrained model 标记为 4DGS2，原始有 3,333,160 Gaussians；Ours 剩 666,632 Gaussians。D-NeRF 上 4DGS1 有 445,076 Gaussians；Ours 剩 66,460。

Temporal filter 加速的是 rasterization 前的 4D Gaussian processing 和实际 rasterization，因此报告 both FPS 和 Raster FPS。

## 7. Experimental Setup and Results Summary

Neural 3D Video 表中，4DGS2 为 PSNR 31.91、SSIM 0.946、LPIPS 0.052、storage 2085MB、FPS 90、Raster FPS 118、#Gauss 3,333,160。Ours 为 31.88 / 0.946 / 0.052、storage 418MB、FPS 805、Raster FPS 1092、#Gauss 666,632。Ours-PP 为 31.87 / 0.944 / 0.053、storage 50MB，FPS/Raster FPS 不变。质量基本保持，storage 从 2085MB 到 50MB 约 41x，raster FPS 从 118 到 1092 约 9x。

D-NeRF 表中，4DGS1 为 PSNR 32.99、SSIM 0.97、LPIPS 0.03、storage 278MB、FPS 376、Raster FPS 1232、#Gauss 445,076。Ours 为 PSNR 33.34、storage 42MB、FPS 1462、Raster FPS 2482、#Gauss 66,460。Ours-PP storage 7MB，质量 33.37 / 0.97 / 0.03。

相对其他 dynamic methods，4DGS-1K 不总是最高 PSNR；例如 N3V 上 Swift4D 32.23、STG 32.05，高于 Ours 31.88。但 4DGS-1K 的重点是 4DGS representation 的 compression and rendering speed，在 Raster FPS 和 storage 上优势明显。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是分析 4DGS temporal redundancy、提出 spatial-temporal variation pruning 和 temporal filter，并实现 41x storage reduction 与 1000+ FPS。实际技术增量不是改进动态重建表达力，而是针对 4D Gaussian 的时域冗余做系统性压缩。

与 3DGS pruning/compression 方法相比，4DGS-1K 把 temporal lifespan 和 inactive ratio 纳入 pruning/filtering；与 MEGA 等 memory-efficient dynamic methods 相比，它直接作用于 vanilla 4DGS 的 4D Gaussian primitives；与 deformation-field methods 相比，它仍保留 explicit 4DGS 的条件 Gaussian 表示。

## 9. Limitations / Assumptions

Temporal filter 假设相邻帧 active Gaussian set 高度重叠。如果场景有快速出现/消失、闪烁、遮挡突变或长 key-frame interval，mask 可能漏掉必要 Gaussians，导致质量下降。

Spatial-temporal variation pruning 会鼓励长 temporal span Gaussians，但可能牺牲真正短暂、高频事件的表达能力。论文通过继续优化补偿，但极端短时动态可能受影响。

方法主要依赖已有 4DGS pipeline，并不解决 4DGS 在 complex motion 下的重建能力上限。它更适合作为压缩/加速插件。

主文后半实验设置和部分 ablation 在抽取文本中截断，具体 pruning ratio、mask interval 和 Ours-PP 细节需回看 PDF/supplement。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Target | Vanilla 4D Gaussian Splatting |
| Problem | Short-lifespan Gaussians and inactive Gaussians |
| Global compression | Spatial-temporal variation score pruning |
| Spatial term | Alpha-compositing contribution over training pixels |
| Temporal term | Temporal opacity second derivative and 4D volume |
| Runtime acceleration | Key-frame active mask temporal filter |
| Main result | 41x storage reduction; 9x raster speedup on N3V |
| Strength | 1000+ raster FPS with comparable quality |
| Weakness | Assumes active masks stable across adjacent frames |

## 11. Reusable Components

- Temporal redundancy analysis for 4DGS using $\Sigma_t$ distribution.
- Spatial alpha contribution score for pruning.
- Temporal lifespan score from temporal Gaussian second derivative.
- 4D volume normalization in temporal importance.
- Key-frame active Gaussian masks.
- Mask sharing across adjacent frames for fast rendering.
- Post-pruning fine-tuning to recover quality.

## 12. Gap / Idea Seeds

- Make temporal filter adaptive by motion speed instead of fixed key-frame interval.
- Add confidence fallback that includes extra Gaussians when mask coverage is uncertain.
- Combine 4DGS-1K with MEGA or Swift4D for both allocation and filtering gains.
- Preserve rare high-frequency transient events by class-aware or saliency-aware temporal pruning.
- Learn active masks with a small predictor rather than storing key-frame masks.

## 13. Human Check List

- NEED_HUMAN_CHECK: Main experimental settings and ablation after Section 5 are truncated in extracted text; note uses visible Tables 1-2 and method sections.
- NEED_HUMAN_CHECK: Eq. 6 uses tanh of $p_i^{(2)}(t)$ as extracted; verify exact absolute value/sign handling from PDF before implementation.
- NEED_HUMAN_CHECK: Ours-PP compression details are not visible in extraction; note records table numbers only.

## 14. Evidence Anchors

- Abstract and Figure 1: 1000+ FPS, 2% storage and temporal redundancy claim.
- Section 3: 4DGS conditional Gaussian and temporal opacity.
- Figure 2: $\Sigma_t$ distribution, active ratio and active-set IoU.
- Section 4.1: short-lifespan and inactive Gaussian analysis.
- Section 4.2.1: spatial-temporal variation score.
- Section 4.2.2: key-frame temporal filtering.
- Tables 1-2: N3V and D-NeRF quantitative storage/FPS/#Gauss comparisons.
