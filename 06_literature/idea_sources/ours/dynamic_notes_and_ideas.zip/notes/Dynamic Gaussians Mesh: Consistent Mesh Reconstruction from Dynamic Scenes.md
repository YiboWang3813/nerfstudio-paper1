# Dynamic Gaussians Mesh: Consistent Mesh Reconstruction from Dynamic Scenes

## 0. Metadata

* Title: Dynamic Gaussians Mesh: Consistent Mesh Reconstruction from Dynamic Scenes
* Authors: Isabella Liu; Hao Su; Xiaolong Wang
* Venue/Year: ICLR 2025
* Project: `https://www.liuisabella.com/DG-Mesh`
* Code: `https://github.com/Isabella98Liu/DG-Mesh`
* DOI: Not specified in Zotero metadata / extracted PDF
* Zotero item key: `9HMJ86QX`
* Zotero PDF attachment key: `H94LS6SQ`
* PDF path: `/Users/wangyibo/Zotero/storage/H94LS6SQ/Liu 等 - 2025 - DYNAMIC GAUSSIANS MESH CONSISTENT MESH RE- CONSTRUCTION FROM DYNAMIC SCENES.pdf`
* Local note path: `notes/Dynamic Gaussians Mesh: Consistent Mesh Reconstruction from Dynamic Scenes.md`
* Tags: Dynamic Gaussian Splatting; Mesh Reconstruction; Temporal Correspondence; DPSR; Marching Cubes

## 1. One-Sentence Technical Summary

DG-Mesh 从动态视频中联合优化 canonical 3D Gaussians、deformation networks 和 differentiable mesh extraction，通过 Gaussian-Mesh Anchoring 让每帧 Gaussians 均匀贴合 mesh faces，并用 cycle-consistent forward/backward deformation 把 anchored Gaussians 回投到 canonical space，从而得到高质量、时间一致且有跨帧 vertex correspondence 的动态 mesh。

## 2. Problem Formulation

### 2.1 输入

* 动态场景图像序列。
* 每帧的 time label 和 camera parameters。
* 可来自 synthetic、monocular real videos、multi-view videos 或 self-captured phone videos。

### 2.2 输出

* 每个时间步的 reconstructed mesh。
* mesh surface appearance / vertex color。
* 跨时间的 mesh vertex motion / correspondence。
* 可用于 dynamic texture editing、shape manipulation、physics/rendering engine integration 的 mesh sequence。

### 2.3 核心目标

* 不只是渲染 novel view，而是恢复 explicit mesh geometry。
* 支持 topology change。
* 保持跨帧 correspondence。
* 让 Gaussians 分布满足 Poisson surface reconstruction 对均匀 oriented point cloud 的需求。

### 2.4 关键困难

* 3DGS 原始 densification 会在高频或难重建区域堆积 Gaussians，点分布不均匀。
* DPSR/Poisson solver 假设 normal field 和 indicator function 在空间中较均匀采样。
* 每帧 mesh 独立提取容易失去跨帧 vertex correspondence。
* mesh template deformation 难处理 topology change。

## 3. Method Overview

DG-Mesh 维护一组 canonical 3D Gaussians，并通过 forward deformation network 将其变换到每个时间步。每个时间步的 deformed Gaussians 被视为 oriented point cloud，先经 differentiable Poisson Solver 得到 indicator function，再用 differentiable Marching Cubes 提取 watertight manifold mesh，最后用 Nvdiffrast 做 differentiable mesh rendering。

跨帧 correspondence 被拆成两个更容易的问题：

* **mesh-to-point correspondence**: 每个时间步内，mesh faces 与 deformed/anchored Gaussian points 对齐。
* **point-to-canonical-point correspondence**: 通过 canonical Gaussians 和 forward/backward deformation 追踪点跨时间运动。

Gaussian-Mesh Anchoring 负责前者，Cycle-Consistent Deformation 负责后者。

## 4. Method Details

### 4.1 Deformable 3D Gaussians

每个 canonical Gaussian 表示为 $G(x;\mu,r,s,\alpha)$，其中 $\mu$ 是中心，$r$ 是 quaternion rotation，$s$ 是 scale，$\alpha$ 是 opacity。

deformation network $F$ 输入 spatial position $x$ 和 time $t$ 的 positional encoding，输出 offsets：

$$
F(\gamma(x),\gamma(t))=(\delta x,\delta r,\delta s,\delta \alpha).
$$

deformed Gaussian 表示为 $G'(x+\delta x;\mu,r+\delta r,s+\delta s,\alpha+\delta\alpha)$。

### 4.2 Mesh reconstruction from Gaussians

DG-Mesh 不直接从 Gaussian opacity query density grid，而是把 3DGS 看作 oriented point cloud：

1. 用 differentiable Poisson Solver (DPSR) 得到 grid indicator function $\chi(x)$。
2. 用 differentiable Marching Cubes 提取 mesh。
3. 优化 vertex color。
4. 使用 Nvdiffrast 做 mesh rasterization。

这条 pipeline 是 differentiable 的，因此 mesh loss 能回传到 Gaussian/deformation 参数。

### 4.3 Laplacian regularization

为保持 mesh surface tessellation 平滑，使用 uniformly weighted mesh Laplacian：

$$
L_{lap}=\frac{1}{n}\sum_i ||\delta_i||^2,\quad \delta_i=v_i-\frac{1}{|N_i|}\sum_{k\in N_i}v_k.
$$

$N_i$ 是 vertex $v_i$ 的 one-ring neighbors。

### 4.4 Gaussian-Mesh Anchoring

Anchoring 的目标是让 deformed Gaussians 更均匀地覆盖 mesh faces，并建立 mesh-to-point correspondence。

给定 deformed Gaussian centers $\{x_i\}$ 和 mesh face centroids $\{f_j\}$，对每个 Gaussian 找最近 face centroid：

$$
n_{x_i}=\arg\min_f ||x_i-f||.
$$

然后做 mesh-guided densification/pruning：

* 如果一个 face 同时是多个 Gaussians 的最近邻，则 prune 原来的 $K$ 个 Gaussians，并用它们属性平均生成一个新 Gaussian。
* 如果一个 face 不是任何 Gaussian 的最近邻，则在该 face centroid 上创建新 Gaussian。
* 对已经一对一匹配的 Gaussian 和 face centroid 加 anchoring loss。

anchoring loss:

$$
L_{anchor}=\frac{1}{n}\sum_i||x_i-n_{x_i}||^2.
$$

这样得到的 anchored Gaussians 与 mesh faces 更接近一对一关系。

### 4.5 Cycle-Consistent Deformation

Anchoring 发生在 deformed/world frame 中，但 canonical space 也必须同步增删 Gaussians。DG-Mesh 为此引入 backward deformation network。

定义：

* forward deformation $F_f$: canonical Gaussian 到 deformed Gaussian。
* backward deformation $F_b$: anchored/deformed Gaussian 回 canonical Gaussian。

给定 canonical Gaussian $G$ 和 anchoring 后的 $G'$，论文约束：

$$
F_f(G,t)=-F_b(G',t).
$$

用两者的 L1 loss 作为 $L_{cycle}$。这让 deformed space 的 mesh-guided 增删调整能回投到 canonical space，维持 point-to-canonical-point correspondence。

### 4.6 Appearance model

mesh vertex color 不直接在 deformed space 查询。实现中把 deformed vertex 的位置投回 canonical space，再 query time-dependent appearance module。论文报告这种 canonical-space vertex color optimization 比在不同 deformed spaces 查询颜色更稳定。

## 5. Mathematical Objectives and Losses

### 5.1 Gaussian image loss

对 Gaussian splatted image $I_{gs}$ 和 ground truth $I_{gt}$：

$$
L_{gs}=(1-\lambda_{ssim})||I_{gs}-I_{gt}||+\lambda_{ssim}L_{ssim}(I_{gs},I_{gt}).
$$

mesh image loss $L_{mesh}$ 使用同类形式。

### 5.2 Mask loss

还计算 rasterized mask 的 L1 loss，记为 $L_{mask}$。

### 5.3 Final objective

最终损失：

$$
L=L_{gs}+L_{mesh}+L_{mask}+L_{lap}+L_{anchor}+L_{cycle}.
$$

其中 $L_{lap}$ 平滑 mesh tessellation，$L_{anchor}$ 建立每帧 mesh-to-Gaussian alignment，$L_{cycle}$ 维护 canonical/deformed consistency。

## 6. Training and Inference Procedure

### 6.1 Training schedule

* 使用 3DGS implementation 做 differentiable Gaussian rasterization。
* 总训练 50,000 iterations。
* 单张 RTX 3090Ti。
* 前 3k iterations 固定 forward/backward deformation networks，只训练 canonical Gaussians，使 canonical space 下的 Gaussian 位置和形状较稳定。
* 5k iterations 后加入 DPSR 和 differentiable Marching Cubes，从 Gaussian points 提取 mesh geometry。
* 每 100 iterations 执行一次 Gaussian-Mesh Anchoring。
* mesh rasterization 使用 Nvdiffrast。
* supervision 来自 Gaussian splatted image 和 rendered mesh image 两条路径。

### 6.2 Network architecture

Appendix B:

* forward/backward deformation networks 都是 MLP。
* depth $D=8$。
* hidden width $W=256$。
* spatial positional encoding $k=10$。
* time positional encoding $k=6$。
* final layer 是无 activation 的 linear layer，输出 $\delta x,\delta s,\delta r,\delta\alpha$。
* appearance network 架构与 deformation network 类似。

### 6.3 Inference / export

训练后可以：

1. 对任意时间 $t$ deform canonical Gaussians。
2. 用 DPSR + differentiable MC / mesh extraction 得到 mesh。
3. 使用 mesh vertex correspondence 做 texture editing 或 shape manipulation。
4. 把 mesh 插入 rendering engine 做 ray tracing / material editing。

## 7. Experimental Setup and Results Summary

### 7.1 Datasets

* D-NeRF synthetic dataset: 无 ground-truth mesh，因此主要评估 mesh rendering PSNR/SSIM/LPIPS 和可视化。
* DG-Mesh dataset: 作者渲染的 6 个 dynamic scenes，每个 200 frames，带 camera parameters、images 和 per-frame ground-truth mesh。
* Nerfies: monocular real-world dynamic objects。
* DyCheck, Unbiased4D, self-captured iPhone videos: supplementary qualitative/real-world tests。
* NeuralActor: multi-view moving humans。

### 7.2 DG-Mesh dataset mesh reconstruction

Table 1 报告 CD、EMD、volume rendering PSNR 和 mesh rendering PSNRm。DG-Mesh 是表中唯一显式支持 correspondence 的方法。典型结果：

| Scene | DG-Mesh CD | DG-Mesh EMD | DG-Mesh PSNRm |
|---|---:|---:|---:|
| Duck | 0.782 | 0.047 | 32.757 |
| Horse | 0.297 | 0.164 | 30.865 |
| Bird | 0.510 | 0.125 | 28.085 |
| Beagle | 0.623 | 0.114 | 33.572 |
| Torus2sphere | 1.572 | 0.177 | 25.703 |
| Girlwalk | 0.398 | 0.151 | 33.026 |

论文强调整体上 DG-Mesh 在 mesh quality metrics 上优于 baselines，尤其在 bird wings、horse tail 等 thin/detailed structures 上更稳。

### 7.3 D-NeRF mesh rendering

Table 2 显示 DG-Mesh 在多数 D-NeRF scenes 的 mesh rendering 质量最高：

| Scene | DG-Mesh PSNRm | SSIM | LPIPS |
|---|---:|---:|---:|
| Lego | 21.289 | 0.838 | 0.159 |
| Bouncingballs | 29.145 | 0.969 | 0.099 |
| Jumpingjacks | 31.769 | 0.977 | 0.045 |
| Hook | 27.884 | 0.954 | 0.074 |
| Mutant | 30.400 | 0.968 | 0.055 |
| Standup | 30.208 | 0.974 | 0.051 |
| Trex | 28.951 | 0.959 | 0.065 |
| Hellwarrior | 25.460 | 0.959 | 0.084 |

### 7.4 Ablations

Laplacian weight:

| $w_{lap}$ | CD | EMD | PSNRm | SSIMm | LPIPSm |
|---:|---:|---:|---:|---:|---:|
| 0 | 0.972 | 0.089 | 31.947 | 0.971 | 0.079 |
| 100 | 1.239 | 0.093 | 32.178 | 0.969 | 0.069 |
| 1000 | 0.762 | 0.073 | 33.890 | 0.982 | 0.061 |
| 2000 | 0.894 | 0.069 | 32.891 | 0.981 | 0.072 |

默认使用 $w_{lap}=1000$。

Gaussian-Mesh Anchoring:

| Variant | CD | EMD | PSNRm |
|---|---:|---:|---:|
| w/o anchor | 0.685 | 0.146 | 31.283 |
| w/ anchor | 0.516 | 0.128 | 32.734 |

Anchoring interval:

* 50: PSNRm 30.521, CD 0.314, EMD 1.307。
* 100: PSNRm 30.668, CD 0.306, EMD 1.298。
* 200: PSNRm 30.599, CD 0.319, EMD 1.295。
* 500: PSNRm 30.645, CD 0.320, EMD 1.298。

默认 interval 取 100，平衡 geometry quality 和 rendering performance。

### 7.5 Real scenes and speed

Nerfies table:

| Method | PSNR | PSNRm | FPSm |
|---|---:|---:|---:|
| Deformable-GS | 28.310 | - | 0.10 |
| DG-Mesh | - | 27.238 | 10.9 |

Fine-tuned mesh rendering comparison:

| Method | Fine-tuned PSNRm | Training Time | Inference Speed |
|---|---:|---:|---:|
| K-Plane | 24.683 | about 65 min | 0.9 FPS |
| TiNeuVox | 24.149 | about 70 min | 0.3 FPS |
| Deformable-GS | 22.519 | about 35 min | 185 FPS |
| DG-Mesh | 29.782 | about 80 min | 10.9 FPS |

## 8. Claimed Contribution vs Actual Technical Delta

### 8.1 Claimed contributions

* 第一个从 dynamic observations 恢复 high-fidelity meshes with cross-frame correspondences 的框架。
* Gaussian-Mesh Anchoring 让 Gaussians 更均匀，有利于 DPSR 和 mesh correspondence。
* Cycle-consistent deformation 维护 canonical/deformed consistency。
* 支持 texture editing、ray tracing 和 dynamic mesh downstream operations。

### 8.2 Actual technical delta

真正的新意在于把 dynamic 3DGS 和 differentiable mesh extraction 变成一个可训练闭环：

* 不是直接从每帧 Gaussian opacity 抽 mesh，而是 oriented point cloud -> DPSR -> differentiable MC。
* 不依赖 canonical mesh template，因此可处理 topology change。
* 用 mesh faces 反向指导 Gaussian densification/pruning，使点云满足 surface reconstruction 的均匀性要求。
* 将 correspondence 拆成 mesh-face to Gaussian 和 Gaussian to canonical 两段，避免直接对独立 mesh 求跨帧匹配。

### 8.3 Trade-off

DG-Mesh 牺牲了部分纯 3DGS/volume rendering 的速度和渲染 PSNR，换来 explicit mesh、跨帧 correspondence 和编辑能力。它的贡献不应只用 image PSNR 评价，而要看 mesh quality、time consistency 和 downstream editability。

## 9. Limitations / Assumptions

* 和其他 dynamic Gaussian methods 类似，extreme object motion 会失败。
* imperfect segmentation 会影响 real-world monocular videos。
* Mesh rendering FPS 约 10.9，低于 Deformable-GS 的 pure Gaussian rendering，但高于一些 volume baselines。
* 依赖 DPSR/MC 质量；Gaussian distribution 不均匀时 mesh 会退化，因此需要 anchoring。
* 训练 pipeline 较复杂，包含 Gaussian rendering、mesh extraction、mesh rasterization、forward/backward deformation 和 anchoring。
* 对 mask、camera parameters 和 foreground extraction 有依赖。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| Task | time-consistent dynamic mesh reconstruction |
| Input | dynamic images, time labels, camera parameters |
| Output | mesh sequence, appearance, vertex correspondence |
| Core representation | canonical 3D Gaussians + deformation networks |
| Mesh extraction | DPSR + differentiable Marching Cubes |
| Rendering | Gaussian rasterization + Nvdiffrast mesh rasterization |
| Correspondence | mesh-to-point + point-to-canonical-point |
| Key module | Gaussian-Mesh Anchoring |
| Consistency | cycle-consistent forward/backward deformation |
| Training | 50k iterations on RTX 3090Ti |
| Default anchoring interval | 100 iterations |
| Main metric | CD, EMD, PSNRm, SSIM, LPIPS |
| Main weakness | extreme motion / imperfect segmentation |

## 11. Reusable Components

* **Mesh-guided Gaussian densification/pruning**: 用 mesh faces 反向约束 Gaussian distribution。
* **Canonical-space color query for dynamic mesh**: deformed vertices 回投 canonical 后查询 appearance。
* **DPSR + differentiable MC on dynamic Gaussians**: 把 Gaussian point cloud 变成可训练 mesh path。
* **Two-stage correspondence decomposition**: mesh-to-point plus point-to-canonical-point。
* **Cycle-consistent anchoring projection**: 将 deformed-space topology/point changes 回写 canonical representation。

## 12. Gap / Idea Seeds

* 用 learned confidence 控制 anchoring，避免 noisy mesh faces 引导错误 densification。
* 将 anchoring 与 segmentation uncertainty 结合，处理 imperfect foreground masks。
* 加入 topology-change detector，在 topology stable 区域保留 stronger correspondence，在 topology-changing 区域放松约束。
* 研究更快的 mesh extraction 或 incremental DPSR，提升 FPSm。
* 将 DG-Mesh 的 time-consistent mesh 作为 physics simulator 初始化，再反向用 simulation prior 正则 deformation。
* 用 differentiable texture atlas 替代 vertex color，提升 texture editing 分辨率。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: DOI 未在 Zotero metadata 或 PDF 抽取中出现。
* `NEED_HUMAN_CHECK`: Table 1 的 best/second/third 标记在文本抽取中丢失，具体排名需看 PDF 原表。
* `NEED_HUMAN_CHECK`: $L_{cycle}$ 文中写 “between $F_f$ and $-F_d$”，但上下文应为 backward deformation $F_b$；需看原 PDF/代码确认符号。
* `NEED_HUMAN_CHECK`: Gaussian-Mesh Anchoring Algorithm 1 中 canonical/backward projection 的实现细节需看代码。
* `NEED_HUMAN_CHECK`: real-world datasets 的 mask/camera preprocessing 依赖外部工具，复现需确认 scripts。
* `NEED_HUMAN_CHECK`: DG-Mesh dataset 是否已公开下载，需看 GitHub/project。

## 14. Evidence Anchors

* Abstract: DG-Mesh reconstructs high-fidelity time-consistent mesh from dynamic input using Gaussian-Mesh Anchoring and cycle-consistent deformation.
* Fig. 3: main pipeline: canonical Gaussians, forward deform, Gaussian rasterization, DPSR + differentiable MC, Nvdiffrast, backward deform, anchored Gaussians.
* Sec. 3.1: deformable 3D Gaussians and deformation network outputs $\delta x,\delta r,\delta s,\delta\alpha$.
* Sec. 3.2: DPSR and differentiable Marching Cubes for mesh reconstruction; Laplacian regularization.
* Fig. 4 and Sec. 3.3: Gaussian-Mesh Anchoring procedure.
* Eq. for $L_{anchor}$: penalizes Gaussian-to-face-centroid distance.
* Sec. 3.3: Cycle-Consistent Deformation with forward and backward deformation.
* Sec. 3.4: final objective combining $L_{gs}$, $L_{mesh}$, $L_{mask}$, $L_{lap}$, $L_{anchor}$, and $L_{cycle}$.
* Sec. 4.1-4.2: datasets and implementation details.
* Table 1: mesh reconstruction results on DG-Mesh dataset.
* Table 2: D-NeRF mesh rendering results.
* Table 3: Laplacian regularizer ablation.
* Table 4: anchoring ablation.
* Table 5: Nerfies real scene evaluation.
* Appendix D-F: fine-tuned mesh rendering, appearance module, anchoring frequency.
* Appendix H: fail cases on DyCheck due to extreme motion or imperfect segmentation.
