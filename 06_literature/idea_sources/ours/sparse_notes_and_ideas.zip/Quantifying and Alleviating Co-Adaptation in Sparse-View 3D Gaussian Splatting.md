# Quantifying and Alleviating Co-Adaptation in Sparse-View 3D Gaussian Splatting

## 0. Metadata

* Title: Quantifying and Alleviating Co-Adaptation in Sparse-View 3D Gaussian Splatting
* Authors: Kangjie Chen; Yingji Zhong; Zhihao Li; Jiaqi Lin; Youyu Chen; Minghan Qin; Haoqian Wang
* Year: 2025
* Venue: NeurIPS
* PDF source: `/Users/wangyibo/Zotero/storage/ZI5V462G/Chen 等 - Quantifying and Alleviating Co-Adaptation in Sparse-View 3D Gaussian Splatting.pdf`
* Zotero item key: `3IPATZRN`
* Zotero PDF attachment key: `ZI5V462G`
* Code: Not specified
* Project page: Not specified
* Dataset link: LLFF, DTU, Blender
* Main task: sparse-view 3DGS artifact analysis and regularization
* Domain: sparse-view Gaussian Splatting, appearance artifacts, regularization
* Input: sparse-view 3DGS training setup
* Output: Co-Adaptation Score metric and regularized 3DGS variants
* Main representation: standard 3DGS with stochastic Gaussian dropout or opacity perturbation during training
* Supervision type: original method losses plus plug-and-play stochastic regularization
* Core contribution in one sentence: 提出 Co-Adaptation Score 量化 sparse-view 3DGS 中高斯之间过度协同拟合训练视角的程度，并用 Gaussian dropout 与 opacity noise 两个轻量训练策略削弱这种 co-adaptation。
* Note status: `complete`

## 1. 一句话技术摘要

This paper addresses appearance artifacts in sparse-view 3DGS by using a dropout-rendering variance metric to quantify co-adaptation among Gaussians, with the key technical novelty being plug-and-play Gaussian dropout and opacity noise regularization that reduce over-entangled alpha-composited splats.

## 2. 问题形式化

在 sparse-view 3DGS 中，训练视角渲染可能很真实，但 novel views 会出现不属于场景的颜色噪声和局部 appearance artifacts。论文认为核心原因不是只有几何错误，而是多个高斯在训练视角中通过 alpha compositing 过度协同，以脆弱组合拟合有限像素，忽略真实 appearance distribution。

这种现象被定义为 co-adaptation：一组高斯对某些像素形成强依赖，随机去掉部分高斯后渲染结果会剧烈变化。目标是量化这种依赖，并在训练时抑制它。

## 3. 方法概览

论文先提出 Co-Adaptation Score (CA)：

1. 对同一个目标视角，随机 dropout 50% Gaussians。
2. 重复渲染 $K$ 次。
3. 在所有渲染都可见的像素区域内计算逐像素颜色方差。
4. 平均得到 CA score。

然后基于观察提出两个训练策略：

* Gaussian dropout: 训练时随机丢弃一部分高斯，打破固定高斯组合的过拟合。
* Opacity noise injection: 训练时给 opacity 乘性噪声，扰动每个高斯对像素的贡献。

二者都不依赖特定 sparse-view 方法，可插入 3DGS、DNGaussian、FSGS、CoR-GS、Binocular3DGS。

## 4. 方法细节

### 4.1 Co-adaptation 的来源

3DGS 像素颜色由沿 ray 排序的高斯 alpha blending 得到：

$$
C(u)=\sum_{i\in N(u)}c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j)
$$

训练目标只约束最终渲染图像：

$$
G^*=\arg\min_G\sum_{v\in V_{train}}\mathcal{L}(R(G,v),I_v)
$$

它没有显式约束每个高斯的颜色、opacity、位置或它们的组合方式。因此在 sparse views 下，多个颜色差异较大的高斯也可能共同拟合一个训练像素，但在 novel view 中组合关系改变，就出现错误颜色。

### 4.2 Co-Adaptation Score

对视角 $v$，随机保留不同高斯子集并渲染 $K$ 次。令 $I_u^{(k)}$ 为第 $k$ 次 dropout rendering 在像素 $u$ 的颜色。只在共同可见区域 $\Omega_v$ 上统计：

$$
CA(v)=\frac{1}{|\Omega_v|}\sum_{u\in\Omega_v}\mathrm{Var}(I_u^{(1)},\ldots,I_u^{(K)})
$$

共同可见区域由 accumulated alpha 大于 0.8 的像素交集定义，避免在无贡献区域统计噪声。高 CA 表示渲染对“哪些高斯被保留”很敏感，即 co-adaptation 强。

### 4.3 Gaussian dropout

训练时对每个 Gaussian 独立采样 Bernoulli mask：

$$
G_{train}=\{g\in G|z_g=1\},\quad z_g\sim \mathrm{Bernoulli}(1-p)
$$

只用保留的高斯渲染并计算原训练损失。测试时使用所有高斯，但将 opacity 按 retention probability 缩放：

$$
\alpha_g^{test}=(1-p)\alpha_g^{train},\quad \forall g\in G
$$

直觉是每条 ray 即使少了一部分高斯也要能正确渲染，因此附近高斯会学习更可替代、更一致的 color/opacity，减少固定组合依赖。

### 4.4 Opacity noise injection

训练时给 opacity 加乘性噪声：

$$
\mathrm{opacity}\leftarrow \mathrm{opacity}\cdot(1+\epsilon),\quad \epsilon\sim \mathcal{N}(0,\sigma^2)
$$

作者测试了 position/color/scale 等参数噪声：position noise 不稳定且模糊，SH color noise 作用小，scale noise 降低 CA 但引入 blur。opacity noise 最有针对性，因为它直接扰动 alpha compositing 中每个高斯的贡献。

## 5. 数学目标和损失

论文不提出新的 photometric objective，而是在原方法训练 loss 外加入随机训练机制。CA 是分析/评估指标，不是直接 loss。dropout 和 opacity noise 都通过改变渲染过程中的高斯集合或 opacity 影响原有 loss 的梯度。

重要实现细节：当模型训练时已经用了 dropout rate $p$，测试计算 CA 时要调整随机丢弃比例，以保持不同方法的 CA scaling 可比。论文中无训练 dropout 时 CA 丢 50%；有 $p=0.2$ 时测试 CA 丢 60%。

## 6. 训练和推理流程

训练时：

1. 按 baseline sparse-view 3DGS 方法初始化和设置原 loss。
2. 若使用 dropout，每 iteration 随机保留 $1-p$ 的高斯。
3. 若使用 opacity noise，每 iteration 对 opacity 乘上 $1+\epsilon$。
4. 用原方法的监督信号更新参数。

推理时：

* dropout 方法使用所有高斯并按 $(1-p)$ 缩放 opacity；
* opacity noise 方法直接使用训练后的确定性高斯；
* CA 评估时重复随机子集渲染并计算方差。

## 7. 实验设置与结果摘要

数据集：

* LLFF: 3 training views，8x downsample。
* DTU: 3 training views，4x downsample。
* Blender: 8 views，2x downsample。

方法：3DGS、DNGaussian、FSGS、CoR-GS、Binocular3DGS。指标包括 PSNR、SSIM、LPIPS、Train CA、Test CA。

主要结论：

* Table 1: 在 LLFF/DTU 上，dropout 和 opacity noise 几乎都降低 Train/Test CA，并常常提升 PSNR/SSIM/LPIPS。
* Binocular3DGS on LLFF: baseline 21.44 PSNR，dropout 提升到 22.12，opacity noise 也到 22.12；Test CA 从 0.001951 降到约 0.000978 或 0.000762。
* FSGS on LLFF: baseline 20.43 PSNR，dropout 20.82，opacity noise 20.59。
* 同时使用两种策略没有明显叠加收益，说明它们缓解的是同一类 co-adaptation。
* Table 3: dropout probability $p=0.2$ 在 Binocular3DGS/LLFF 上整体最好。
* Table 4: 推理时使用所有高斯并 opacity 缩放的 Strategy C 与多次 dropout averaging 质量相近，但只需单次渲染。
* Table 5: opacity noise scale $\sigma=0.8$ 整体最好；CA 继续下降不一定带来更好质量。

## 8. 声称贡献 vs 实际技术增量

论文声称提出 co-adaptation 概念、CA score 和两个抑制策略。实际技术增量非常轻量，但有洞察力：把 sparse-view 3DGS 的错误颜色解释为 alpha-composited Gaussians 的过度依赖，而不是只归因于几何差。

两个策略本身很简单，类似 neural network dropout/noise regularization 在 3DGS 中的映射。真正可复用的是 CA score 这个诊断工具，以及“降低 CA 到合适范围但不要过低”的经验。

## 9. 局限性和隐藏假设

* CA 不是单调的质量指标，过低 CA 也可能损害渲染质量。
* dropout 可能鼓励高斯变大，可能在细结构或透明/反射场景中引入副作用。
* 主要分析 appearance artifacts，对 geometry artifacts 的直接建模较弱。
* CA 计算需要多次随机渲染，作为训练实时 loss 会有开销；本文主要用作评估。
* 对动态场景、unposed 场景未验证。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 任务 | sparse-view 3DGS artifact analysis/regularization |
| 输入 | sparse-view 3DGS model/training pipeline |
| 输出 | CA score, dropout/noise regularized model |
| 表示 | standard 3DGS |
| 关键模块 | CA metric, Gaussian dropout, opacity noise |
| 关键损失 | 原 baseline loss；随机机制作用于渲染过程 |
| 主要优点 | plug-and-play，跨多个 sparse-view 方法有效 |
| 主要风险 | CA 与质量不严格单调，过强正则会损害重建 |

## 11. 可复用组件

* CA score 可作为 sparse-view 3DGS 的诊断指标。
* Gaussian dropout 可作为任何 3DGS 训练的低成本 regularizer。
* opacity noise 适合与 depth/matching priors 并行使用，不改变模型结构。

## 12. Gap 和 idea seeds

* 将 CA score 变成 differentiable surrogate loss，直接优化 co-adaptation。
* 自适应 dropout：对高 CA 区域或高贡献高斯使用更强 dropout。
* 与 uncertainty pruning 结合：高 CA 且低 sensitivity 的高斯优先剪枝或重初始化。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: Appendix 中 CA 的 theoretical derivation 需要完整复核。
* `NEED_HUMAN_CHECK`: 代码是否公开和各 baseline 的 exact hyperparameters 需确认。

## 14. Evidence Anchors

* Abstract: CA score, dropout, opacity noise。
* Fig. 1: sparse-view 3DGS appearance artifacts。
* Fig. 2: co-adaptation toy cases。
* Sec. 3.1: co-adaptation characterization, Eq. (1)-(2)。
* Sec. 3.2: CA score, Eq. (3), Fig. 3-5。
* Sec. 3.3: dropout and opacity noise, Eq. (4)-(6)。
* Table 1-2: LLFF/DTU/Blender quantitative results。
* Table 3-5: dropout probability, rendering strategy, opacity noise scale ablations。
