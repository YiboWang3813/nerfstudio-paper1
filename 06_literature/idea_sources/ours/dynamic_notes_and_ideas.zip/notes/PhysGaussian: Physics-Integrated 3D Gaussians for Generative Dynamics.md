# PhysGaussian: Physics-Integrated 3D Gaussians for Generative Dynamics

## 0. Metadata

- Title: PhysGaussian: Physics-Integrated 3D Gaussians for Generative Dynamics
- Authors: Tianyi Xie; Zeshun Zong; Yuxing Qiu; Xuan Li; Yutao Feng; Yin Yang; Chenfanfu Jiang
- Venue/Year: CVPR 2024
- DOI: 10.1109/CVPR52733.2024.00420
- Project page: https://xpandora.github.io/PhysGaussian/
- Zotero item key: `NMEZZT2Q`
- Zotero PDF attachment key: `UUGT7DIS`
- PDF path: `/Users/wangyibo/Zotero/storage/UUGT7DIS/Xie 等 - 2024 - PhysGaussian Physics-Integrated 3D Gaussians for Generative Dynamics.pdf`
- Local note path: `notes/PhysGaussian: Physics-Integrated 3D Gaussians for Generative Dynamics.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

PhysGaussian 把 3D Gaussians 直接当作 Material Point Method 的 continuum particles，使同一组 Gaussian kernels 同时负责物理模拟和 splatting rendering，并用 deformation gradient 更新 Gaussian position/covariance、旋转 spherical harmonics，从而实现“what you see is what you simulate”的 generative dynamics。

## 2. Problem Formulation

传统 physics-based visual content pipeline 通常先重建视觉几何，再提取 mesh / tetrahedron / cage，转成 simulation-ready geometry，物理模拟后再渲染。这些中间表示会造成 resolution mismatch 和 simulation-rendering discrepancy。NeRF 编辑或物理方法也常依赖 mesh extraction 或 coarse proxy geometry。

PhysGaussian 的问题设定是：给定一个静态 3DGS scene，如何直接对其施加物理动力学，使它产生可渲染的新运动，而不经过 mesh、marching cubes、tetrahedralization 或 cage embedding。核心口号是 WS2: what you see is what you simulate。

目标不是从动态视频重建原始运动，而是生成 physics-grounded novel motion，包括 elastic objects、plastic metals、fracture、granular materials、viscoplastic paste 和 collisions。

## 3. Method Overview

PhysGaussian 先用原始 3DGS 从 input images 和 camera info 重建静态场景，必要时加入 anisotropy regularizer 防止过细 Gaussians。然后把每个 Gaussian kernel 视作一个 material particle，赋予物理属性：position、velocity、deformation gradient、volume、mass、density、stress、plasticity state 等。

动力学由 Material Point Method (MPM) 求解。MPM 在 Lagrangian particles 和 Eulerian grid 之间传递 mass/momentum，更新 velocity、position 和 deformation gradient。Gaussian 的中心位置随 particle position 演化，Gaussian covariance 通过 deformation gradient 更新，因此 visual ellipsoid 和 physical material deformation 同步。

渲染时不需要重建 mesh：直接把 deformed Gaussians splat 到图像平面。为保持 view-dependent appearance，方法还从 deformation gradient 的 polar decomposition 中提取 rotation，并对 spherical harmonic bases 做相应旋转。对于原始 3DGS 只覆盖表面、内部为空的问题，PhysGaussian 可用 opacity field 做 internal filling。

## 4. Method Details

### 4.1 Continuum Mechanics Foundation

Continuum mechanics 使用 deformation map $\phi(X,t)$ 将 material space $\Omega_0$ 中的点 $X$ 映射到 deformed world space $\Omega_t$ 中的位置 $x$：

$$
x=\phi(X,t).
$$

Deformation gradient 为：

$$
F(X,t)=\nabla_X\phi(X,t).
$$

$F$ 编码局部 stretch、rotation 和 shear。动量守恒形式为：

$$
\rho(x,t)\dot v(x,t)=\nabla\cdot\sigma(x,t)+f_{\mathrm{ext}}.
$$

Cauchy stress $\sigma$ 由 hyperelastic energy density $\Psi(F)$ 导出。为了支持 plasticity，总 deformation gradient 可分解为 elastic 和 plastic 部分：$F=F^EF^P$。

### 4.2 MPM Discretization

PhysGaussian 用 MPM 求解连续体动力学。Particles 携带 position $x_p$、velocity $v_p$、elastic deformation gradient $F_p^E$ 等 Lagrangian quantities；grid 用于 momentum update。可见主文给出的 grid momentum update 为：

$$
\frac{m_i}{\Delta t}(v_i^{n+1}-v_i^n)
=-\sum_p V_p^0\frac{\partial\Psi}{\partial F}(F_p^{E,n})F_p^{E,n\top}\nabla w_{ip}^n+f_i^{\mathrm{ext}}.
$$

Grid velocity 更新后转回 particles，更新 position：

$$
x_p^{n+1}=x_p^n+\Delta t\,v_p^{n+1}.
$$

Elastic deformation gradient 用 velocity gradient 更新：

$$
F_p^{E,n+1}=\left(I+\Delta t\sum_i v_i^{n+1}\nabla w_{ip}^{n\top}\right)F_p^{E,n}.
$$

随后通过 material-specific return mapping $Z(\cdot)$ 把 $F_p^E$ 投影回 elastic region，以支持不同 plasticity models。

### 4.3 Gaussian Kernels as Continuum Particles

静态 3DGS 中 material-space Gaussian 为：

$$
G_p(X)=\exp\left(-\frac{1}{2}(X-X_p)^\top A_p^{-1}(X-X_p)\right).
$$

在一般 deformation map 下，世界空间 kernel 为 $G_p(x,t)=G_p(\phi^{-1}(x,t))$，不一定仍是 Gaussian。PhysGaussian 使用局部 affine approximation：

$$
\tilde\phi_p(X,t)=x_p+F_p(X-X_p).
$$

则 deformed kernel 仍为 Gaussian：

$$
G_p(x,t)=\exp\left(-\frac{1}{2}(x-x_p)^\top(F_pA_pF_p^\top)^{-1}(x-x_p)\right).
$$

因此 time-dependent position 和 covariance 为：

$$
x_p(t)=\phi(X_p,t),\quad a_p(t)=F_p(t)A_pF_p(t)^\top.
$$

这就是 PhysGaussian 的核心：同一组 Gaussians 既是 MPM particles，又是 renderer primitives。

### 4.4 Spherical Harmonics Rotation

如果只更新 Gaussian center 和 covariance，而 spherical harmonics 仍固定在 material orientation 中，物体旋转时外观会随视角发生不一致变化。PhysGaussian 从 deformation gradient 的 polar decomposition $F_p=R_pS_p$ 中取得 local rotation $R_p$，用 inverse rotation 作用到 view direction：

$$
f^t(d)=f^0(R_p^\top d).
$$

这样等价于随 ellipsoid rotation 旋转 SH bases，不需要改 GS renderer 内部 hard-coded bases。

### 4.5 Incremental Gaussian Evolution

主公式依赖 total deformation gradient $F_p$。论文还给出 incremental covariance update，适配不使用 $F$ 作为 strain measure 的 material models。Covariance rate form 为 $\dot a=(\nabla v)a+a(\nabla v)^\top$，离散更新为：

$$
a_p^{n+1}=a_p^n+\Delta t(\nabla v_p a_p^n+a_p^n\nabla v_p^\top).
$$

SH rotation 也可增量更新：从 $R_p^0=I$ 开始，对 $(I+\Delta t\nabla v_p)R_p^n$ 做 polar decomposition 得到 $R_p^{n+1}$。

### 4.6 Internal Filling

原始 3DGS 多分布在物体表面，内部为空；如果直接模拟 volumetric object，可能在重力下塌陷或行为不真实。PhysGaussian 借用 3D opacity field：

$$
d(x)=\sum_p\sigma_p\exp\left(-\frac{1}{2}(x-x_p)^\top A_p^{-1}(x-x_p)\right).
$$

将其离散到 3D grid 后，用沿 6 个轴的 ray intersection 检测内部 candidate cells，再进一步用 intersection number 筛选。填充 particles 继承最近 Gaussian 的 opacity 和 SH coefficients，covariance 初始化为 isotropic sphere，半径 $r_p=(3V_p^0/4\pi)^{1/3}$。

### 4.7 Anisotropy Regularizer

3DGS 的 anisotropic ellipsoids 表达高效，但过细的 Gaussian 在大变形下可能产生 plush / burr artifacts。PhysGaussian 在 reconstruction 时可加入：

$$
L_{\mathrm{aniso}}=\frac{1}{|P|}\sum_{p\in P}\max\left\{\frac{\max(S_p)}{\min(S_p)},r\right\}-r.
$$

它约束 Gaussian major/minor axis ratio 不超过阈值 $r$，提高后续物理变形下的 visual stability。

## 5. Mathematical Objectives and Losses

PhysGaussian 的训练/优化分成视觉重建和物理演化。视觉重建阶段沿用 3DGS 的 $L_1$ 和 SSIM image loss，可选加入 $L_{\mathrm{aniso}}$。物理演化阶段不是通过 image loss 拟合视频，而是由 MPM equations 和 material constitutive models 推进状态。

3DGS rendering 仍为：

$$
C=\sum_{k\in P}\alpha_k\mathrm{SH}(d_k;C_k)\prod_{j=1}^{k-1}(1-\alpha_j).
$$

Material simulation 通过 hyperelastic energy $\Psi(F)$、stress、plastic return mapping 和 MPM transfer 决定。不同 material behavior 来自不同 constitutive model / return mapping，例如 von Mises plasticity、Drucker-Prager plasticity、Herschel-Bulkley viscoplasticity 等。

## 6. Training and Inference Procedure

首先用 COLMAP 获取初始点云和相机参数，训练静态 3DGS。可选对 Gaussian shape 加 anisotropy regularizer。然后用户选择 simulation region，将其 normalize 到边长为 2 的 cube，并设置材料参数、密度和初始速度。需要 volumetric behavior 时执行 internal filling。

Simulation 使用基于 Zong et al. 的 MPM，cuboid domain 离散为 dense 3D grid。通过选择性修改部分 particles 的 velocity 触发 controlled motion，其余 particles 按物理规律演化。实验在 24-core Intel i9-10920X 和 RTX 3090 上运行。

推理/渲染时，每个 time step 由 MPM 更新 $x_p$、$F_p$ 或 incremental covariance，再把 $a_p(t)$ 和 rotated SH 送入 3DGS renderer。部分简单 dynamics 可达到 real-time，如 plane 30 FPS、toast 25 FPS、jam 36 FPS。

## 7. Experimental Setup and Results Summary

Generative dynamics 使用 BlenderNeRF synthetic sofa suite、InstantNGP fox、Nerfstudio plane、DroneDeploy ruins，以及自采 iPhone toast 和 jam，每个 real scene 150 photos。展示材料包括 elastic fox、plastic metal plane、fracture toast、granular ruins、viscoplastic jam 和 collision sofa suite。

Lattice deformation benchmark 用 BlenderNeRF 合成 Wolf、Stool、Plant。每个场景用 100 multi-view undeformed renderings 训练，另有 bend/twist deformed ground truth。对比 NeRF-Editing、Deforming-NeRF、PAC-NeRF。PSNR 表中 Ours 在所有六个 test cases 最优：Wolf bend/twist 26.96/26.46，Stool bend/twist 31.15/26.15，Plant bend/twist 25.81/23.87。

消融包括 Fixed Covariance、Rigid Covariance、Fixed Harmonics。结果显示只平移 Gaussian 或只做刚体 covariance 会有明显 artifact；不旋转 SH 会略损失外观一致性。完整方法在每个 case 上都优于这些变体。

Internal filling 研究显示，不填内部 particles 的 object 像空壳，受重力时容易塌陷；填充后可通过 Young's modulus $E$ 和 Poisson ratio $\nu$ 控制 stiffness 和 volume preservation。Anisotropy regularizer 可减少大变形下由过细 Gaussians 引起的 burr artifacts。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 continuum mechanics for 3D Gaussian kinematics、统一 simulation-rendering pipeline 和多材料 benchmark。实际技术增量主要在 kinematics：用 deformation gradient 把 Gaussian covariance 从 $A_p$ 推到 $F_pA_pF_p^\top$，从而让 anisotropic visual primitive 正确跟随 continuum deformation。

与 NeRF-Editing / cage deformation 相比，PhysGaussian 不依赖 extracted surface mesh 或 cage，且使用一阶 deformation gradient 保留局部 stretch/shear 信息。与 PAC-NeRF 相比，它直接使用高质量 3DGS renderer 和 explicit ellipsoid kernels。与后续 Fracture-GS 类方法相比，PhysGaussian 是基础统一表示，但对极端 fracture interface rendering 和 non-adhesive collision 处理还不专门。

## 9. Limitations / Assumptions

阴影演化未建模。物体移动和变形后，lighting/shadow 不随物理状态一致更新。

材料参数需要手动设置。论文建议未来结合 GS segmentation 和 differentiable MPM 从视频中自动估计。

Internal filling 继承最近 surface Gaussian 的 opacity / SH，隐藏内部的真实纹理和材质不一定准确。对于 fracture 后暴露内部的场景，这会限制 realism。

方法主要用于生成 novel dynamics，不是从动态视频反演真实 motion；用户仍需选择 simulation region 和设置初始条件。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Static 3DGS reconstructed from images |
| Output | Physics-driven dynamic Gaussians and rendered videos |
| Core idea | Treat 3D Gaussians as MPM material particles |
| Position update | MPM evolves particle center $x_p(t)$ |
| Shape update | Covariance $a_p(t)=F_pA_pF_p^\top$ or incremental rate update |
| Appearance update | Rotate SH bases using polar decomposition rotation |
| Optional geometry | Internal filling from opacity field |
| Optional loss | Anisotropy regularizer for stable deformation |
| Strength | Unified simulation/rendering, no mesh embedding |
| Weakness | Manual parameters, no shadow evolution, approximate internal appearance |

## 11. Reusable Components

- WS2 design: one primitive set for simulation and rendering.
- Deformation-gradient-based covariance update for Gaussian ellipsoids.
- SH basis rotation by inverse local rotation from polar decomposition.
- Incremental covariance update via velocity gradient.
- Opacity-field-based internal particle filling for volumetric behavior.
- Anisotropy regularizer to make 3DGS reconstruction simulation-friendly.
- MPM material library plugged into 3DGS scene dynamics.

## 12. Gap / Idea Seeds

- Combine PhysGaussian with differentiable MPM to infer material parameters from observed videos.
- Add relighting or differentiable shadow update for physically consistent appearance.
- Use learned internal texture/material generation when internal filling creates exposed surfaces.
- Add fracture-specific surface Gaussian regeneration, as later Fracture-GS attempts.
- Automate simulation-region selection with 3DGS segmentation.

## 13. Human Check List

- NEED_HUMAN_CHECK: Supplemental return mappings for different materials are not included in the extracted main text; note summarizes visible material categories.
- NEED_HUMAN_CHECK: Exact anisotropy regularizer sign may need checking against PDF because the max expression in extraction is terse; concept is axis-ratio thresholding.
- NEED_HUMAN_CHECK: Project page URL in Zotero text has a space in extraction; normalized here to `https://xpandora.github.io/PhysGaussian/`.

## 14. Evidence Anchors

- Abstract and Introduction: WS2 motivation and unified simulation-rendering claim.
- Figure 2 / Section 3: pipeline overview.
- Sections 3.2-3.3: continuum mechanics and MPM equations.
- Section 3.4: Gaussian covariance update via deformation gradient.
- Section 3.5: spherical harmonics rotation.
- Sections 3.6-3.8: incremental evolution, internal filling and anisotropy regularizer.
- Table 1 / Figures 4-5: deformation benchmark and ablations.
- Figures 6-8: internal filling, volume conservation and anisotropy regularizer studies.
