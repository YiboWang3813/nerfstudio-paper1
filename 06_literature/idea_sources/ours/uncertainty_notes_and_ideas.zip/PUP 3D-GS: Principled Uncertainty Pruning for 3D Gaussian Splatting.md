# PUP 3D-GS: Principled Uncertainty Pruning for 3D Gaussian Splatting

## 0. Metadata

* Title: PUP 3D-GS: Principled Uncertainty Pruning for 3D Gaussian Splatting
* Authors: Alex Hanson; Allen Tu; Vasu Singla; Mayuka Jayawardhana; Matthias Zwicker; Tom Goldstein
* Year: 2025
* Venue: CVPR
* PDF source: `/Users/wangyibo/Zotero/storage/L5SJ7UXZ/Hanson 等 - 2025 - PUP 3D-GS Principled Uncertainty Pruning for 3D Gaussian Splatting.pdf`
* Zotero item key: `93MGWNQA`
* Zotero PDF attachment key: `L5SJ7UXZ`
* Code: Not specified
* Project page: Not specified
* Dataset link: Mip-NeRF 360, Tanks & Temples, Deep Blending
* Main task: post-hoc pruning/compression of pretrained 3DGS
* Domain: Gaussian Splatting compression, uncertainty/sensitivity estimation
* Input: converged pretrained 3DGS model and training camera poses
* Output: pruned/refined smaller 3DGS model
* Main representation: original 3DGS with per-Gaussian Fisher sensitivity score
* Supervision type: post-hoc sensitivity computation from rendered training views, followed by fine-tuning
* Core contribution in one sentence: 用 Fisher approximation 估计每个 Gaussian 的空间参数敏感度，并通过多轮 prune-refine 在高压缩率下保留视觉质量。
* Note status: `complete`

## 1. 一句话技术摘要

This paper addresses 3DGS model pruning by using a Fisher-approximated Hessian sensitivity score to transform a converged dense Gaussian set into a much smaller pruned model, with the key technical novelty being per-Gaussian uncertainty computed from mean and scale parameters over rendered training views.

## 2. 问题形式化

3DGS 往往包含大量高斯，内存大、渲染慢。常见 pruning heuristic 如 visibility/significance 可能保留大而冗余的高斯，丢失前景细节。PUP 3D-GS 把 pruning 问题定义为：如果扰动某个 Gaussian 的空间参数对训练视图重建误差影响很小，则它是不敏感/高不确定的，可以优先删除。

每个 Gaussian $G_i$ 有位置 $x_i$、scale $s_i$、rotation $r_i$、颜色 $c_i$、SH $h_i$ 和 opacity $\alpha_i$。论文只用 $x_i$ 和 $s_i$ 计算 sensitivity score。

## 3. 方法概览

pipeline 是 post-hoc 的：

1. 从已训练收敛的 3DGS 出发。
2. 对训练视图计算每个 Gaussian 关于 rendered image 的 Jacobian。
3. 用 Fisher information 近似 Hessian。
4. 取每个 Gaussian 的 block-diagonal Hessian，并只保留 mean/scale 参数。
5. 用 log determinant 得到 sensitivity score。
6. 剪掉低 sensitivity Gaussians，fine-tune 剩余模型。
7. 多轮重复 prune-refine。

## 4. 方法细节

### 4.1 Fisher approximation

L2 重建误差为：

$$
\mathcal{L}_2 = \frac{1}{2}\sum_{\phi \in P_{gt}}\|I_G(\phi)-I_{gt}\|_2^2
$$

二阶导包含 Jacobian outer product 和 residual 乘二阶项。对收敛模型，残差趋近于 0，因此 Hessian 近似为 Fisher information：

$$
\nabla_G^2 \mathcal{L}_2 \approx \sum_{\phi \in P_{gt}}\nabla_G I_G(\phi)\nabla_G I_G(\phi)^\mathsf{T}
$$

这只依赖 rendered images 对参数的梯度和 camera poses，而不显式依赖图像 residual。

### 4.2 Sensitivity pruning score

完整 Hessian 太大，因此采用 block diagonal，每个 Gaussian 独立一个 block：

$$
H_i = \nabla_{G_i}I_G \nabla_{G_i}I_G^\mathsf{T}
$$

再用 log determinant 转成 sensitivity score。最终只使用位置 $x_i$ 和 scale $s_i$：

$$
U_i = \log |\nabla_{x_i,s_i}I_G \nabla_{x_i,s_i}I_G^\mathsf{T}|
$$

直觉是：如果某个 Gaussian 的 mean/scale 有很多可能位置和大小都能解释训练图像，则它的空间约束弱、uncertainty 高、sensitivity 低，更适合剪掉。

### 4.3 Patch-wise uncertainty

逐像素 Fisher 计算昂贵。论文发现低分辨率 image patches 上计算的 sensitivity 与逐像素结果高度相关，因此渲染低分辨率图像、在 patch 级别累计 Fisher。实验使用 $4 \times 4$ patches。

### 4.4 Multi-round prune-refine

剪枝后模型 fine-tune，若 reconstruction residual 恢复到较小水平，Fisher approximation 仍然适用，可以再次剪枝。最终 pipeline 采用两轮：先剪 80%，fine-tune 5K steps；再剪剩余的 50%，fine-tune 5K steps，总体剪掉 90% Gaussians。

## 5. 数学目标和损失

PUP 不改变 3DGS 原训练目标，只新增 pruning score。3DGS 原 loss 是 L1 + SSIM；PUP 用 L2 residual 的 Hessian/Fisher 近似推导 sensitivity。fine-tuning 仍使用原 3DGS 训练损失，并关闭 densification。

重要假设：Fisher approximation 需要模型已收敛、residual 小。若模型未收敛，二阶 residual term 不可忽略，score 可能失真。

## 6. 训练和推理流程

流程：

1. 训练或读取 pretrained 3DGS。
2. 用自定义 CUDA kernel 计算每个 Gaussian 的 Fisher block。
3. 计算 $U_i$。
4. 删除最低 sensitivity 的 Gaussians。
5. fine-tune 5K iterations，无 densification。
6. 重复一轮。
7. 可选接 LightGaussian 的 Vectree Quantization 进一步压缩。

计算 pruning score 用秒级时间；实验渲染速度在 RTX A4000 上统计。

## 7. 实验设置与结果摘要

数据集：Mip-NeRF 360 的 4 个 indoor scenes，Tanks & Temples 的 truck/train，Deep Blending 的 drjohnson/playroom。使用数据集提供的 COLMAP poses。

主结果：

* Table 1: Mip-NeRF 360 上两轮剪 90% 后，size 从 746.46 MB 到 74.65 MB，FPS 从 63.88 到 204.81，PSNR 从 27.47 降到 26.67。
* Table 2: 与 LightGaussian 在相同 90% pruning 和相同 final size 下比较，PUP 在多数 PSNR/SSIM/LPIPS/FPS 指标更好。
* Table 3: 结合 Vectree Quantization 后，最终模型比原 3DGS 小约 51x，同时优于 LightGaussian。
* Table 4: 两轮 prune-refine 优于一次性剪 90%。
* Table 5: 只用 mean+scale 的 spatial score 优于加入 rotation 或只用 RGB sensitivity。

## 8. 声称贡献 vs 实际技术增量

论文声称是 principled uncertainty pruning。实际技术增量是把 second-order sensitivity/Fisher 信息落到 3DGS pruning 上，并证明只需 mean+scale 的小 block 就能有效指导剪枝。

它不是 Bayesian posterior uncertainty，而是“参数扰动对训练视图重建误差的敏感度”。这在实践上非常适合压缩，因为它对保留细节比 visibility heuristic 更有针对性。

## 9. 局限性和隐藏假设

* 假设原模型已收敛；未收敛时 Fisher approximation 不可靠。
* 需要额外 CUDA kernel 实现 Hessian/Fisher 计算。
* memory 随 $N \times 36$ 增长，超大模型仍可能有压力。
* score 基于训练视图，对训练视图外的大范围视角泛化不一定最优。
* 只处理 pruning/compression，不直接提升原始重建质量。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 任务 | post-hoc 3DGS pruning |
| 输入 | converged 3DGS + training poses |
| 输出 | pruned/refined smaller 3DGS |
| 表示 | original Gaussians + Fisher sensitivity |
| 关键模块 | block Fisher, mean+scale log-det score, multi-round prune-refine |
| 关键损失 | original 3DGS loss during refine |
| 主要优点 | 剪 90% 仍保留较好质量，FPS 大幅提升 |
| 主要风险 | 要求模型收敛，需要 CUDA 实现 |

## 11. 可复用组件

* Fisher sensitivity 可用于 dynamic 4DGS 中剪掉低贡献时间段/高斯。
* mean+scale score 可作为 densification/pruning 的替代 heuristic。
* multi-round prune-refine 适合与 quantization 组合。

## 12. Gap 和 idea seeds

* 把 PUP score 与 uncertainty-aware rendering 结合，对低 sensitivity 高斯降低 opacity 或转为低精度表示，而不是直接删除。
* 对 4DGS，可计算 temporal Fisher，判断某高斯的运动参数是否需要保留。
* 可将 Fisher pruning 作为训练中 regularization，而非只做 post-hoc。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: 代码是否公开以及 CUDA kernel 细节需确认。
* `NEED_HUMAN_CHECK`: Appendix A.2/A.4/A.8/A.10 有 patch size、per-scene 和可视化细节，复现前需补读。

## 14. Evidence Anchors

* Sec. 3: 3DGS background and standard loss。
* Fig. 2: spatial uncertainty intuition。
* Sec. 4.1: Fisher information matrix, Eq. (5)-(7)。
* Sec. 4.2: sensitivity pruning score, Eq. (8)-(10)。
* Sec. 4.3: patch-wise uncertainty。
* Sec. 4.4: multi-round pipeline。
* Table 1-5: pruning, LightGaussian comparison, quantization, ablations。
