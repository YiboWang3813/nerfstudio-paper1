# HiCoM: Hierarchical Coherent Motion for Dynamic Streamable Scenes with 3D Gaussian Splatting

## 0. Metadata

* Title: HiCoM: Hierarchical Coherent Motion for Dynamic Streamable Scenes with 3D Gaussian Splatting
* Authors: Qiankun Gao; Jiarui Meng; Chengxiang Wen; Jie Chen; Jian Zhang
* Year: 2024
* Venue: NeurIPS 2024
* PDF source: `/Users/wangyibo/Zotero/storage/RXVJUAJQ/Gao 等 - 2024 - HiCoM Hierarchical Coherent Motion for Dynamic Streamable Scenes with 3D Gaussian Splatting.pdf`
* Local note path: `notes/HiCoM: Hierarchical Coherent Motion for Dynamic Streamable Scenes with 3D Gaussian Splatting.md`
* Zotero item key: `ISQ5TCI5`
* Zotero PDF attachment key: `RXVJUAJQ`
* URL: https://openreview.net/forum?id=De4VWE4rbz
* Code: https://github.com/gqk/HiCoM
* Project page: Not specified
* Dataset link: Not specified
* Main task: online reconstruction and streamable free-viewpoint rendering for dynamic multi-view video streams
* Domain: dynamic 3D Gaussian Splatting; online learning; streaming FVV; compact motion representation
* Input: synchronized multi-view video streams, camera poses, initial COLMAP point cloud
* Output: per-frame compact 3DGS representation, rendered test-view video, shared hierarchical motion parameters, updated Gaussians
* Main representation: compact initial 3DGS plus hierarchical region-shared translation/rotation motion and continual Gaussian refinement
* Supervision type: per-frame supervised rendering from multi-view training cameras
* Core contribution in one sentence: 用 perturbation smoothing 学一个紧凑初始 3DGS，再用多层区域共享的显式 motion 参数替代 per-Gaussian MLP 形变，并通过新增/合并/等量低 opacity 删除维护 streaming 场景中的紧凑表示。
* Note status: `complete`

## 1. 一句话技术摘要

这篇论文处理多视角视频流的在线动态场景重建，通过初始帧的 noise-perturbed compact 3DGS、分层区域共享的 coherent motion 和 continual refinement，把每帧训练时间与存储成本显著降低；关键技术差异是显式按空间区域共享 $\Delta\mu,\Delta q$，而不是用隐式 MLP 为每个 Gaussian 预测运动。

## 2. 问题形式化

### 2.1 任务

给定同步多视角视频流，系统需要在 frame-by-frame online setting 中持续更新动态 3D 表示。每到一个新时间帧，模型应快速从前一帧表示适配到当前帧，并保持：

* 高质量 novel-view rendering；
* 每帧训练时间低；
* per-frame storage / transmission 小；
* 渲染速度实时；
* 长序列中误差不过快累积。

### 2.2 与离线动态 GS 的区别

离线动态 GS 可以看到完整视频后统一优化 4D 表示；HiCoM 面向 streamable scene，按时间顺序学习。它不追求为所有时间构建一个全局神经场，而是让前一帧 3DGS 成为后一帧的参考表示。

### 2.3 核心假设

* 相邻帧差异较小，motion 可由前一帧的 Gaussians 经局部平移/旋转表示。
* 3DGS 的空间分布非均匀，很多区域为空，因此区域级 motion 参数比 per-Gaussian 参数更省。
* 同一区域内的 Gaussians 具有局部一致运动。
* 场景逐渐变化，新加 Gaussians 在后续帧中仍有价值，不应像 3DGStream 那样简单丢弃。

## 3. 方法概览

HiCoM 包含四个关键组件。

第一，Initial 3DGS Representation Learning。首帧训练时对 Gaussian position 加小的随机扰动，得到更紧凑、更不易 overfit 的初始 3DGS。

第二，Hierarchical Coherent Motion。把空间按多个层级划分为 regions，只给非空 region 分配 motion 参数。每个 region 存 translation $\Delta\mu$ 和 rotation $\Delta q$，同一区域内所有 Gaussians 共享。一个 Gaussian 的 motion 是其所在多个层级 region motion 的累计。

第三，Continual Refinement。对 motion 无法解释的细节区域，clone 新 Gaussians 并优化；这些新 Gaussians 合并回基础 3DGS，供下一帧使用。同时删除等量低 opacity Gaussians，保持表示紧凑。

第四，Parallel Training。用 frame $t$ 的 3DGS 同时学习 $t+1$ 到 $t+k$，降低 wall time per frame。默认报告 HiCoM-P4 表示 4-frame parallel。

## 4. 方法细节

### 4.1 3DGS 基础与训练损失

论文回顾标准 3DGS。每个 Gaussian 由 mean $\mu$ 和 covariance $\Sigma$ 定义。Eq. 1: $G(x)=e^{-\frac{1}{2}(x-\mu)^T\Sigma^{-1}(x-\mu)}$。

Eq. 2 将 covariance 分解为 $\Sigma=RSS^TR^T$，其中 $S=diag(s_x,s_y,s_z)$，$R\in SO(3)$ 由 quaternion $q$ 参数化。颜色由 SH coefficients $h$ 表示，opacity 为 $\alpha$。

投影后 covariance Eq. 3: $\Sigma'=JW\Sigma W^TJ^T$。渲染 Eq. 4: $C=\sum_{i\in N}c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j)$。

训练损失 Eq. 5: $L=(1-\lambda)L_1+\lambda L_{D-SSIM}$，其中 $\lambda$ 通常设为 0.2。

### 4.2 Perturbation smoothing 初始化

动态场景捕获相机数量有限，首帧 3DGS 容易 overfit training views，并通过 excessive Gaussian growth 变得庞大。HiCoM 在首帧训练时对 position 加随机高斯噪声。Eq. 6: $\mu_p=\mu+\lambda_{noise}\epsilon$，其中 $\epsilon\sim N(0,1)$。

Implementation 中固定 $\lambda_{noise}=0.01$。附录说明该超参从 $\{0.001,0.01,0.1\}$ 中经验选择，0.01 在 PSNR 和 Gaussian 数量之间平衡较好。

作用：

* 降低 limited-view overfitting；
* 抑制 Gaussian 数量增长；
* 让首帧表示更 compact；
* 提升后续 frame learning convergence。

### 4.3 Region assignment

HiCoM 先把 scene 划分为等大小 regions。对 Gaussian center $\mu$ 和 region size $e$，Eq. 7 用类似 floor / quantization 的方式得到该 Gaussian 所在 region center $r$，可理解为 $r=(\lfloor \mu/e+0.5\rfloor)\cdot e$。

论文只给非空 regions 分配 motion 参数。由于 3DGS 在复杂区域密集、平滑区域稀疏，空间里大量 regions 为空，这使 region-level motion 参数数量远少于 dense grid 或 per-Gaussian motion。

### 4.4 Hierarchical coherent motion

每个非空 region 有两个 motion attributes：

* translation $\Delta\mu\in R^3$；
* rotation $\Delta q\in R^4$。

同一区域内 Gaussians 共享这些 motion attributes，保证 local consistency。为了表达更细粒度运动，HiCoM 使用多层区域划分。默认三层：fine、medium、coarse。

一个 Gaussian 的最终 motion 是它在所有层级所属 regions 的 motion 累计。Eq. 8: $\Delta\mu_g=\sum_{l=1}^{L}\Delta\mu^l$，$\Delta q_g=\sum_{l=1}^{L}\Delta q^l$。

这里 quaternion motion 用加法累计，实际是否归一化或怎样 composition 需要代码确认，标为 `NEED_HUMAN_CHECK`。从论文描述看，它强调轻量参数和快速收敛，而不是严格 SE(3) 组合。

### 4.5 Continual refinement

HCM 主要捕捉前后帧的 modest shifts，但新出现细节或剧烈内容变化可能无法仅靠已有 Gaussians 的 motion 表达。训练中，某些区域会积累大梯度，说明当前表示与真实图像存在残差。

HiCoM 跟随 3DGS / 3DGStream 风格，在 gradient 超过阈值的区域 clone Gaussians。新 Gaussians 经过进一步优化和 density control 后，并不会被丢弃，而是 merge 回当前 3DGS，作为下一帧的基础。

为了避免每帧合并导致 Gaussians 数量线性膨胀，HiCoM 在下一帧学习之前删除等量 low-opacity Gaussians。附录指出删除发生在下一帧之前，因此这些低 opacity Gaussians 仍参与当前帧表示。

### 4.6 Parallel training

顺序 pipeline 是用 frame $t$ 的 3DGS 学 frame $t+1$，再继续。但相邻多帧变化通常小，HiCoM 借鉴视频编码 reference frame，用 frame $t$ 的 3DGS 同时学习 $\{t+1,\ldots,t+k\}$。

处理完这组 frames 后，frame $t+k$ 的 3DGS 作为新 reference。Parallel training 不减少总 GPU computation，但减少 wall time per frame。4-frame parallel 可以把平均学习时间降到约四分之一，同时质量损失很小。

## 5. 数学目标与损失

### 5.1 Rendering loss

HiCoM 沿用 3DGS 的 photometric loss：$L=(1-\lambda)L_1+\lambda L_{D-SSIM}$，$\lambda=0.2$。这一 loss 用于首帧 3DGS、HCM motion learning 和 refinement。

### 5.2 Motion parameter optimization

HCM 的可学习变量是非空 regions 的 $\Delta\mu,\Delta q$，而不是 per-Gaussian MLP 权重。相同 region 内多个 Gaussians 共享 motion，因此每次优化的参数量更小、收敛更快。

### 5.3 Refinement trigger

New Gaussians 的生成基于 accumulated gradients 是否超过 predefined threshold。阈值具体数值未在主文抽出，标记为 `NEED_HUMAN_CHECK`。

### 5.4 Compactness control

Compactness 不是单独 loss，而是通过两处机制实现：

* 首帧 perturbation smoothing 抑制 excessive splitting；
* continual refinement 后删除等量 low-opacity Gaussians。

## 6. 训练与推理流程

### 6.1 首帧训练

1. 用 COLMAP 生成 initial point clouds。
2. 标准 3DGS 训练首帧，但 position 使用 $\mu_p=\mu+\lambda_{noise}\epsilon$。
3. N3DV 首帧训练 15k steps，Meet Room 首帧训练 10k steps。
4. splitting 在第 5k step 停止。
5. 得到 compact initial 3DGS。

### 6.2 每个新帧训练

1. 以前一帧 3DGS 为基础。
2. 构建 hierarchical regions，只为非空 regions 初始化 motion 参数。
3. Region motion 初始化为前一帧 motion 参数的 0.6 倍。
4. 执行 100 motion training steps，优化 $\Delta\mu,\Delta q$。
5. 根据 accumulated gradients clone new Gaussians。
6. 新 Gaussians 加入后再执行 100 refinement steps。
7. 将新 Gaussians merge 回当前 3DGS。
8. 删除等量 low-opacity Gaussians。
9. 当前帧 3DGS 成为下一帧基础。

### 6.3 Region hierarchy 设置

最小层 region 数由 initial 3DGS Gaussian 数量 $n$ 除以每 region 最大 Gaussian 数 $m=5$ 决定。更大层级的 region 数继续除以 $2^3$，以形成 coarse-to-fine 层级。只有包含 Gaussians 的 regions 拥有 motion 参数。

### 6.4 推理与传输

每帧需要传输或存储的主要是 compact representation 和 region motion / refinement 后参数。由于 motion 参数在 regions 内共享且大量 regions 为空，平均 per-frame storage 远低于 3DGStream。

## 7. 实验设置与结果

### 7.1 数据集与指标

N3DV:

* 六个动态室内场景；
* 18 到 21 个视频；
* 原始分辨率 $2704\times2078$，实验中 downsample 2 倍；
* 30 FPS；
* 使用前 300 frames。

Meet Room:

* 13 个同步 Azure Kinect cameras；
* 三个室内场景；
* 分辨率 $1280\times720$；
* 30 FPS；
* 使用前 300 frames。

测试设置：中心 reference camera 为 test，其余视角训练。指标包括 mean PSNR、average training time per frame、rendering FPS、average parameter storage per frame。

### 7.2 主结果

Table 1:

N3DV:

* Naive 3DGS: PSNR 30.69，Storage 95.8 MB，Train 337 s，Render 217 FPS；
* StreamRF: 30.68，17.7/31.4 MB，10.0 s，13 FPS；
* 3DGStream: 30.15，7.6/7.8 MB，8.2 s，210 FPS；
* HiCoM: 31.17，0.7/0.9 MB，6.7 s，274 FPS；
* HiCoM-P4: 31.00，0.7/0.9 MB，1.7 s，274 FPS。

Meet Room:

* 3DGStream: PSNR 25.96，4.0/4.1 MB，4.7 s，212 FPS；
* HiCoM: 26.73，0.4/0.6 MB，3.9 s，284 FPS；
* HiCoM-P4: 26.25，0.4/0.6 MB，1.0 s，284 FPS。

HiCoM 相比 3DGStream 平均每帧学习时间降低超过 17%，复杂场景超过 20%；存储小于 3DGStream 的 10%，论文摘要概括为 storage 减少约 85%。

### 7.3 定性结果

Figure 3 的 Coffee Martini 展示头部、手、杯中液体等动态区域。HiCoM 相比 3DGStream 更接近 GT，并因为新增 Gaussians 被带到后续帧，液体流入玻璃杯等时间变化更连贯。

### 7.4 组件消融

Table 2:

* Full 在 Coffee Martini / Flame Steak / Discussion 上分别 PSNR 28.04 / 32.87 / 26.69。
* 无 perturbation：26.61 / 32.52 / 26.19，说明首帧噪声平滑提高泛化并减少 overfit。
* 无 motion：25.71 / 27.33 / 21.61，性能大幅下降，说明 HCM 是核心。
* 无 refinement：27.87 / 31.73 / 26.51，说明新增 Gaussians 对强运动和细节更新有帮助。

### 7.5 收敛消融

Table 3 比较 motion learning steps $E_m$ 和 refinement steps $E_r$。默认 $E_m=100,E_r=100$ 在 N3DV / Meet Room 上为 PSNR 31.17 / 26.73，训练 6.7 / 3.9 秒。把 motion steps 从 50 增到 100 带来明显收益；再增到 150 收益很小。因此总共 200 learning steps 足够。

### 7.6 Motion levels 消融

Table 4 显示 fine level 单独已经不错；加入 medium / coarse 进一步提升。Coffee Martini 从 fine 27.79 提升到 full 28.04，Discussion 从 26.10 提升到 26.69。收益随层数增加而递减，说明少数层级足够。

### 7.7 Parallel training

Table 5 显示 parallel frames 为 2 或 4 时质量基本不变，有时还略升；8 时开始下降；16 时 PSNR 明显下降。4-frame parallel 把 Coffee Martini train time 从 7.02 降到 1.76 秒，Flame Steak 从 6.62 到 1.66 秒，Discussion 从 3.89 到 0.97 秒。

### 7.8 附录结果

附录报告：

* Per-scene N3DV / Meet Room results；
* PanopticSports large-scale motion；
* Particle-NeRF uniform periodic motion；
* 三次同 seed 重复实验的 PSNR std，波动较小；
* HiCoM 初始 3DGS 因 perturbation 显著减少 Gaussian 数量，同时略提升 PSNR。

## 8. 声称贡献 vs 实际技术增量

### 8.1 论文声称

HiCoM 声称：

* online dynamic scene reconstruction 的高效框架；
* perturbation smoothing 学紧凑初始 3DGS；
* HCM 用少量 region-shared 参数显式建模 motion；
* continual refinement 适配新内容；
* parallel training 将 wall time 降到每帧 2 秒以内；
* 学习效率提升约 20%，storage 减少 85%。

### 8.2 实际技术增量

实际增量在于用 region-quantized explicit motion 取代 MLP motion field。它利用了 3DGS 的离散点云性质：Gaussian 分布稀疏且局部一致，因此 motion 可以在非空空间块上共享。

与 3DGStream 的关键差异：

* 3DGStream 用 Neural Transformation Cache 隐式预测变化；HiCoM 用显式 hierarchical region motion。
* 3DGStream 新增 Gaussians 不带到后续帧以保持紧凑；HiCoM 将新 Gaussians merge，并删除等量低 opacity Gaussians。
* HiCoM 初始帧更 compact，减少后续学习负担。

### 8.3 证据强度

证据强的部分：

* Table 1 同时报告 PSNR、storage、train time、render FPS；
* Table 2-5 覆盖核心组件、收敛步数、层级数、并行帧数；
* 附录有 per-scene results 和三次重复 stability；
* 代码开源 URL 明确。

证据弱的部分：

* 主要实验是 indoor scenes，outdoor / unbounded scenes 未验证；
* online error accumulation 是显式 limitation；
* quaternion motion 加法的物理严谨性需要代码或补充确认；
* 3DGStream 是作者复现版本，附录说明官方 release 存在问题，横向对比需谨慎。

## 9. 局限与隐藏假设

显式局限：

1. 初始 3DGS 表示仍然关键，HiCoM 没有完全解决首帧质量依赖。
2. online learning 可能随时间误差累积。
3. 实验只在 indoor scenes 上，outdoor 或复杂环境泛化未验证。

隐藏假设：

* 相邻帧变化较小，reference frame 可预测后续少量 frames。
* 局部 region 内 motion 足够一致。
* 等量删除 low-opacity Gaussians 不会移除后续帧重要但当前低贡献的结构。
* 固定三层 fine/medium/coarse 对多数场景足够。
* Region size / hierarchy 由 Gaussian 数量间接决定，而不是根据场景语义或 motion complexity 自适应。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法名称 | HiCoM |
| 输入类型 | multi-view streaming videos |
| 场景模式 | online frame-by-frame dynamic reconstruction |
| 核心表示 | compact 3DGS + hierarchical region-shared motion |
| Motion 参数 | region-level $\Delta\mu,\Delta q$ |
| 层级 | default fine + medium + coarse |
| 初始化 trick | perturbation smoothing, $\lambda_{noise}=0.01$ |
| Refinement | clone high-gradient Gaussians, merge into current 3DGS |
| Compactness | remove same number of low-opacity Gaussians |
| Parallel | learn frames $t+1$ to $t+k$ from reference $t$ |
| 默认训练 | initial 15k/10k; split stop at 5k; 100 motion + 100 refinement steps |
| 数据集 | N3DV; Meet Room; appendix PanopticSports / Particle-NeRF |
| 主优势 | storage 极小、训练快、render FPS 高 |
| 主短板 | 首帧依赖、误差累积、indoor-only 主实验 |

## 11. 对我的研究可复用组件

1. Region-shared motion：动态 GS 可增加一类“spatial block motion basis”，区别于 per-Gaussian MLP、control-point graph、keyframe trajectory。
2. Perturbation smoothing for compact 3DGS：首帧加位置噪声抑制 overfit 和 Gaussian growth，可用于 sparse-view GS。
3. Merge-new-prune-low-opacity：比“新增后丢弃”更符合缓慢演化场景，可用于 streaming GS。
4. Parallel frame training：用于将 online training 的 wall time 与 GPU compute 解耦。
5. Motion-level ablation：fine/medium/coarse 是构建多尺度 motion sharing baseline 的好模板。

## 12. Gap and Idea Seeds

### 12.1 Gap: Region 划分不是 motion-aware

HiCoM 用空间量化和 Gaussian 数量决定层级，未根据真实 motion boundaries 自适应。可以研究 motion-gradient-aware region splitting，避免一个 region 横跨两个不同运动物体。

### 12.2 Gap: Quaternion 累计方式可能粗糙

Eq. 8 对 $\Delta q$ 做求和，可能不是严格 rotation composition。可以用 Lie algebra $se(3)$ 或 quaternion normalized blending 改进。

### 12.3 Gap: Error accumulation

Online pipeline 的通病是误差随时间累积。可加入 sliding-window re-optimization、keyframe correction 或 periodic global refresh。

### 12.4 Gap: Low-opacity pruning 可能短视

当前帧 low opacity 不代表未来不重要。可以引入 temporal utility score，基于多帧贡献决定 prune。

### 12.5 Gap: Indoor-only 主实验

Outdoor / unbounded scene 中 region grid、COLMAP 初始化和 visibility 更复杂。可研究与 large-scale 3DGS / unbounded GS 的结合。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: Eq. 8 中 $\Delta q$ 的加法累计是否在代码中 normalization 或转换为 rotation composition。
* `NEED_HUMAN_CHECK`: clone gradient threshold、low-opacity prune threshold 的具体值在主文未完整给出。
* `NEED_HUMAN_CHECK`: 3DGStream 对比为作者复现版本，需记录与官方处理数据/代码差异。
* `NEED_HUMAN_CHECK`: Table 1 的 Storage “without/with initial frame” 在矩阵中要拆成两个字段。
* `NEED_HUMAN_CHECK`: N3DV 原始分辨率在文中写作 $2704\times2078$，常见资料可能是 $2704\times2028$，需核对原数据。
* `NEED_HUMAN_CHECK`: checklist 称 open access to data/code；实际复现需确认 GitHub 仓库内容与数据处理脚本。

## 14. Evidence Anchors

* Abstract: perturbation smoothing, hierarchical coherent motion, continual refinement, 20% efficiency gain, 85% storage reduction, <2 seconds/frame parallel training。
* Figure 1: N3DV / Meet Room examples, training/render/storage/PSNR and speed-storage plot。
* Section 1 Introduction: 3DGStream limitations, initial 3DGS quality dependence, new Gaussians not carried over。
* Section 3 / Eq. 1-5: 3DGS representation and loss $L=(1-\lambda)L_1+\lambda L_{D-SSIM}$。
* Figure 2: full HiCoM pipeline: perturbation, HCM, continual refinement。
* Section 4.1 / Eq. 6: perturbation smoothing $\mu_p=\mu+\lambda_{noise}\epsilon$。
* Section 4.2 / Eq. 7: region center assignment。
* Section 4.2 / Eq. 8: hierarchical motion accumulation $\Delta\mu_g,\Delta q_g$。
* Section 4.3: high-gradient clone, merge new Gaussians, remove equal low-opacity Gaussians。
* Section 4.4: parallel training using frame $t$ as reference for $t+1$ to $t+k$。
* Section 5.1: datasets, metrics, implementation details, $\lambda_{noise}=0.01$，15k/10k initial steps，100+100 new-frame steps。
* Table 1: main quantitative results on N3DV and Meet Room。
* Figure 3: Coffee Martini qualitative temporal coherence。
* Table 2: perturbation / motion / refinement ablation。
* Table 3: convergence steps ablation。
* Table 4: motion levels ablation。
* Table 5: parallel training trade-off。
* Section 6 Limitations: initial 3DGS dependence, error accumulation, indoor-only validation。
* Appendix A: $\lambda_{noise}$ selection and 3DGStream implementation caveats。
* Appendix Tables 6-10: per-scene, stability, PanopticSports and Particle-NeRF extra results。
