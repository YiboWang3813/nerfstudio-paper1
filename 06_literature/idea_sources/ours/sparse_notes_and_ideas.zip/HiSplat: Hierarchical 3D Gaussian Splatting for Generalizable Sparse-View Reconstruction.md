---
title: "HiSplat: Hierarchical 3D Gaussian Splatting for Generalizable Sparse-View Reconstruction"
authors: "Shengji Tang, Weicai Ye, Peng Ye, Weihao Lin, Yang Zhou, Tao Chen, Wanli Ouyang"
year: 2025
venue: "ICLR 2025"
zotero_item_key: "3QLKX87B"
pdf_attachment_key: "BX9J94LY"
pdf_path: "/Users/wangyibo/Zotero/storage/BX9J94LY/Tang 等 - 2025 - HISPLAT HIERARCHICAL 3D GAUSSIAN SPLATTING FOR GENERALIZABLE SPARSE-VIEW RECONSTRUC-.pdf"
note_path: "notes/HiSplat: Hierarchical 3D Gaussian Splatting for Generalizable Sparse-View Reconstruction.md"
tags: ["3D Gaussian Splatting", "generalizable reconstruction", "sparse-view synthesis", "hierarchical representation", "feed-forward"]
---

## 0. 一句话总结

HiSplat 是一个面向两视图 sparse-view reconstruction 的 generalizable 3DGS 框架，它不再用单尺度 splatter image 一次性预测 Gaussian，而是分三阶段生成粗到细的层级 Gaussian：大而实的 Gaussian 负责全局结构，小而透明的 Gaussian 负责纹理细节，并通过 Error Aware Module 和 Modulating Fusion Module 让后续尺度补偿和修复前面尺度的错误。

## 1. 问题与动机

现有 generalizable 3DGS 方法如 PixelSplat、MVSplat、TranSplat 可以从少量参考图前馈预测每像素 Gaussian 参数，在新场景上不需要 per-scene optimization。但这类方法通常生成固定分辨率、单尺度的 Gaussian，难以同时表达大尺度结构和细粒度纹理。

单尺度 Gaussian 的典型问题包括：大结构定位不准、几何裂缝、边界模糊、局部纹理伪影。作者借鉴 2D 视觉中的多尺度特征和层级表示，提出显式 3D Gaussian 也应该具备 coarse-to-fine 层级结构：先建立结构骨架，再逐步补细节。

## 2. 适用场景

HiSplat 适合需要在未见过的新场景上，用两张带相机位姿的参考图快速合成目标视角的任务。它面向大规模训练后的 feed-forward 推理，适合 RealEstate10K、ACID 这类视频/多视角数据，也适合 zero-shot 泛化到 DTU、Replica 等分布不同的数据集。

它不适合没有相机位姿的场景，也不是针对单一场景慢速优化到最高质量的 per-scene 3DGS。它的目标是在 sparse input、无测试时优化的条件下，提高前馈 3DGS 的结构和纹理表达能力。

## 3. 方法定位

HiSplat 属于 generalizable 3D Gaussian Splatting 路线，与每场景优化的 3DGS/FSGS/DNGaussian 不同。输入是少量 reference images、相机参数和 target camera pose，输出是目标视角图像，推理时只用网络预测出的最终融合 Gaussian 渲染。

相对 MVSplat 这类基于 cost volume 的前馈 Gaussian 方法，HiSplat 的核心变化是把 Gaussian 表示做成多尺度层级，并且不让各尺度独立生成，而是显式传递误差信息和特征，让后续细尺度围绕粗尺度结果做补偿。

## 4. 核心创新

第一，提出 hierarchical 3D Gaussians。Stage 1 生成低分辨率、大尺度 Gaussian，用来建立 large-scale structure；后续 stage 生成更高分辨率、小尺度 Gaussian，用来补充缺失细节和复杂纹理。

第二，提出 Error Aware Module（EAM）。模型将上一阶段融合 Gaussian 渲染回输入视角，与输入图像比较得到 error map，再结合当前尺度特征预测深度 offset 和 Gaussian features，使细尺度 Gaussian 聚焦到前一阶段有错误或缺细节的位置。

第三，提出 Modulating Fusion Module（MFM）。它根据当前特征、历史尺度特征和输入视角渲染误差，预测对前序尺度 Gaussian opacity 的调制系数，从而修复早期错误 Gaussian，而不是简单把多尺度 Gaussian 全部堆叠。

第四，训练时对每个 stage 的 fused hierarchical Gaussians 都进行目标视角渲染监督，增加梯度流和深度约束；推理时只保留最后一阶段融合后的 Gaussian，保证实际渲染流程简洁。

## 5. 方法细节

整体框架使用共享 U-Net CNN 和 multi-view Transformer 提取跨视角层级特征。给定 $N$ 张参考图 $I_{in}^{ref}$，第 $i$ 个 stage 的跨视角特征为 U-Net decoder 特征与冻结 DINOv2 特征插值相加：

$$
F_i = \mathcal{N}(I_{in}^{ref};\theta_{\mathcal{N}})_i + \operatorname{Interp}(\mathcal{D}(I_{in}^{ref};\theta_{\mathcal{D}}))
$$

Stage 1 用 MVS plane-sweep cost volume 估计粗尺度深度。对于深度候选 $V=\{d_1,\dots,d_R\}$，将其他视角特征按候选深度 warp 到当前视角并构造 cost volume，经过轻量 CNN 后用 softmax 回归深度：

$$
D_i = \operatorname{softmax}(\hat{F}_{cv}^i)V
$$

后续 stage 不再构建高分辨率 cost volume，而是使用 EAM 预测相对深度 offset。给定上一阶段渲染到输入视角的图像 $\tilde{I}_{i-1}^{ref}$ 和输入图像 $I_{in}^{ref}$，EAM 以 error map $|\tilde{I}_{i-1}^{ref}-I_{in}^{ref}|$ 与当前特征 $F_i$ 为输入，输出 offset degree $\alpha_i$ 与 Gaussian feature $F_i^{GS}$：

$$
(\alpha_i,F_i^{GS})=\mathcal{U}(|\tilde{I}_{i-1}^{ref}-I_{in}^{ref}|,F_i;\theta_{\mathcal{U}})
$$

深度更新为 $D_i=\Delta D_i+\operatorname{Interp}(D_{i-1})$，其中 $\Delta D_i=(2\alpha_i-1)\eta\operatorname{Interp}(D_{i-1})$，典型 $\eta=0.1$。这会把细尺度 Gaussian 限制在粗尺度骨架附近，避免细节 Gaussian 跑得太远。

得到 $F_i^{GS}$ 和 $D_i$ 后，模型沿 pixel-aligned ray unproject 得到 Gaussian center，其余 opacity、covariance、spherical harmonics coefficients 由卷积预测头生成。

MFM 用当前尺度 Gaussian feature 和历史尺度 feature 拼接后，结合历史尺度渲染误差预测 opacity modulation coefficient $\xi_k$：

$$
\xi_k=\operatorname{Sigmoid}(\operatorname{MLP}_2(\operatorname{MLP}_1(F_k^{cat})\cdot \operatorname{Interp}(|\tilde{I}_k^{ref}-I_{in}^{ref}|)))
$$

随后用 $O_k:=O_k\cdot \xi_k$ 更新之前尺度的 opacity，实现对早期错误 Gaussian 的修复和重加权。

训练目标对三个 stage 的 target view 渲染都加监督：

$$
L_{all}=\sum_{i=1}^{3}\lambda_{mse}L_{mse}(\tilde{I}_i^{tar},I^{tar})+\lambda_{lpips}L_{lpips}(\tilde{I}_i^{tar},I^{tar})
$$

论文中 $\lambda_{mse}=1$、$\lambda_{lpips}=0.05$。除冻结 DINOv2 特征提取器外，其余参数均参与训练。

## 6. 实验设置

主实验在 RealEstate10K 和 ACID 上训练与测试。RealEstate10K 包含 67,477 个训练场景和 7,289 个测试场景；ACID 包含 11,075 个训练场景和 1,972 个测试场景。每个测试场景输入两张 context images，渲染三个 novel target views。

跨数据集泛化实验在 RealEstate10K 上训练，然后 zero-shot 测试到 DTU、ACID 和 Replica。输入图像 resize 到 256 x 256，Adam 优化 300k iterations，8 张 RTX 4090，batch size 2，训练约两天。

对比方法包括 feed-forward NeRF-based 方法 pixelNeRF、GPNR、AttnRend、MuRF，以及 Gaussian-based 方法 PixelSplat、MVSplat、TranSplat。指标为 PSNR、SSIM、LPIPS。

## 7. 主要结果

在 RealEstate10K 上，HiSplat 达到 27.21 PSNR、0.881 SSIM、0.117 LPIPS，超过 MVSplat 的 26.39 PSNR 和 TranSplat 的 26.69 PSNR。作者强调这是两视图重建任务中超过 27 PSNR 的结果。

在 ACID 上，HiSplat 达到 28.75 PSNR、0.853 SSIM、0.133 LPIPS，也优于 MVSplat 的 28.25 PSNR 和 TranSplat 的 28.35 PSNR。

跨数据集 zero-shot 泛化中，RealEstate10K 训练后测试 DTU，HiSplat 达到 16.05 PSNR、0.671 SSIM、0.277 LPIPS，明显高于 TranSplat 的 14.93 PSNR。测试 ACID 时，HiSplat 达到 28.66 PSNR、0.850 SSIM、0.137 LPIPS，甚至超过一些专门在 ACID 训练的方法。测试 Replica 时，HiSplat 相对次优方法提升约 3.19 PSNR，说明层级 Gaussian 对分布外室内场景也有效。

## 8. 消融与分析

消融结果说明，单纯做 vanilla hierarchical Gaussians 并不够。只使用层级 Gaussian 而不加 EAM、MFM、DINO 时，RealEstate10K 上只有 26.18 PSNR，低于 MVSplat 的 26.39。加入 EAM 后提升到 26.76，加入 MFM 后提升到 27.02，再加入 DINOv2 特征后达到 27.21。

这说明 HiSplat 的关键不是“多生成几个尺度的 Gaussian”，而是让尺度之间通过 error-aware 信息交互。EAM 让细尺度知道哪里需要补偿，MFM 让模型可以降低前面错误 Gaussian 的 opacity。

作者还分析了不同 stage 的 Gaussian 属性：Stage 1 的 Gaussian 稀疏、较大、opacity 更实，像场景骨架；后续 stage 的 Gaussian 更密、更小、更透明，像填充纹理和光照细节。误差图也显示，随着 stage 增加，复杂纹理区域的误差逐步下降。

## 9. 与相关工作的关系

相比 PixelSplat，HiSplat 保留了 per-pixel Gaussian prediction 的前馈性质，但加入跨视角层级特征、cost volume 和多阶段补偿。相比 MVSplat，HiSplat 不只是用 MVS depth 生成 Gaussian，而是把第一阶段深度当作骨架，再用 error-aware depth offset 生成更细尺度 Gaussian。

相比 TranSplat，HiSplat 的重点不是更复杂的 transformer matching 或单目深度先验，而是显式层级 Gaussian 表示与跨尺度修复。相比 per-scene sparse-view 3DGS 方法，HiSplat 训练一次后可泛化到新场景，推理时不需要为每个场景优化。

## 10. 优点

HiSplat 的最大优点是把 generalizable 3DGS 的表达瓶颈定位到“单尺度 Gaussian 不够表达结构和细节”，并给出了可解释的 coarse-to-fine 设计。粗尺度负责稳定几何，细尺度负责局部纹理，这比单尺度 splatter image 更符合多尺度场景结构。

第二个优点是跨数据集泛化强。DTU、ACID、Replica 的 zero-shot 结果说明，该方法不是只在训练分布上提高指标，而是对尺度变化和场景类型变化有一定鲁棒性。

第三个优点是推理仍保持前馈式，不需要测试时优化。对实时或大规模应用来说，这比 per-scene 训练方法更实用。

## 11. 局限

HiSplat 仍依赖已知相机内外参，且训练需要大规模多视角数据和较高算力。论文设置中输入分辨率为 256 x 256，真实高分辨率应用还需要考虑显存和细节恢复问题。

方法复杂度高于 MVSplat：U-Net、multi-view Transformer、DINOv2 特征、三阶段 Gaussian、EAM、MFM 都增加实现成本。另一个潜在风险是，如果第一阶段粗深度严重错误，后续 stage 的 depth offset 被限制在粗深度附近，可能难以完全纠正大尺度几何错误。

## 12. 可复现要点

复现时需要确保输入数据具有可靠相机参数，并按两张 context images、多个 target views 的方式组织训练。Stage 1 只在低分辨率构建 plane-sweep cost volume，后续 stage 用 error map 预测相对深度 offset，避免高分辨率 cost volume 的计算负担。

需要实现 multi-stage rendering supervision：每个 stage 的 fused Gaussians 都要渲染 target view 并计算 MSE 与 LPIPS。MFM 中对历史 Gaussian opacity 的调制也很关键，不能只把各 stage Gaussian 简单 concat 后渲染。

## 13. 可能扩展

一个方向是把层级 Gaussian 与不确定性结合，让 Stage 1 输出 depth/confidence，后续 stage 对低置信度区域允许更大的 depth offset，而不是固定 $\eta=0.1$。

第二个方向是扩展到更多输入视角或动态选择 stage 数。对于简单场景，两级可能足够；对于复杂大场景，可以根据 error map 自适应生成额外细节 stage。

第三个方向是和 per-scene optimization 结合：先用 HiSplat 前馈生成层级 Gaussian 初始化，再对新场景做少量优化，可能同时获得泛化模型的快速初始化和单场景优化的高精度。

## 14. 个人理解

HiSplat 的核心启发是：generalizable 3DGS 的 Gaussian 不应该只是“每个像素吐一个固定尺度 blob”，而应该像图像金字塔一样有层级分工。粗 Gaussian 提供位置和结构，细 Gaussian 修补局部错误，这个思想对 sparse-view 很自然。

这篇文章也提醒我们，层级表示本身不自动带来提升。裸多尺度甚至低于 MVSplat，真正有用的是跨尺度误差传递和 opacity 修复机制。也就是说，多尺度 Gaussian 要能互相看见和纠错，才不是简单堆参数。
