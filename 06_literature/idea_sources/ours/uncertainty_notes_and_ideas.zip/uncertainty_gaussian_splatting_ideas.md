# Uncertainty Gaussian Splatting Idea Report

本文综合 `notes/` 下标题包含 `uncertainty` 的 6 篇笔记，覆盖 Bayesian posterior、不确定性剪枝、动态 4DGS 可靠性、姿态细化和 in-the-wild regularization。报告先逐篇梳理主要创新点和应用场景，再总结共性技术路线，最后提出 8 个可以尝试的组合型 idea。

## 1. 逐篇回顾

| # | 论文 | 主要创新点 | 典型应用场景 |
|---:|---|---|---|
| 1 | Variational Multi-scale Representation for Estimating Uncertainty in 3D Gaussian Splatting | 在重要 base Gaussians 周围学习 local multi-scale offset table，只对 position、scale、opacity 做 variational posterior sampling，用 Monte Carlo rendering 得到 predictive uncertainty，并可用 posterior uncertainty 删除 floaters。 | 静态 3DGS uncertainty map、active view selection、自动 floater removal。 |
| 2 | Horseshoe Splatting | 在 covariance scales 上使用 global-local Horseshoe prior，通过 spike-at-zero 收缩噪声方向、heavy-tail 保留真实结构，并用 variational inference 输出 calibrated uncertainty。 | Bayesian 3DGS、不确定性校准、结构稀疏化、视角选择。 |
| 3 | PUP 3D-GS | 用 Fisher approximation 估计每个 Gaussian 的 sensitivity/uncertainty，做 post-hoc pruning，再 fine-tune 得到更小的 3DGS。 | 已训练 3DGS 压缩、部署前剪枝、低损高效渲染。 |
| 4 | Uncertainty Matters in Dynamic Gaussian Splatting for Monocular 4D Reconstruction | 估计逐 Gaussian 不确定性，用于 key node selection、graph edge weighting 和 loss weighting，使单目动态 4DGS 在遮挡、外推和稀疏监督下更稳。 | 单目动态 4D 重建、遮挡场景、动态节点图优化。 |
| 5 | Rethinking Pose Refinement in 3D Gaussian Splatting under Pose Prior and Geometric Uncertainty | 将姿态先验不确定性和 Fisher-style 几何不确定性结合，使用 Monte Carlo pose hypotheses、matching confidence 和 uncertainty-biased PnP sampling 做概率式姿态细化。 | 3DGS 场景定位、相机 relocalization、pose prior 较差时的 robust refinement。 |
| 6 | 4D Gaussian Splatting in the Wild with Uncertainty-Aware Regularization | 用 alpha contribution 衡量每个 Gaussian 的训练视角支撑度，只在高不确定区域施加 diffusion prior 和 depth TV，并用 dynamic region densification 修复动态区域初始化不足。 | handheld monocular 4DGS、in-the-wild 动态视频、生成先验 gated regularization。 |

## 2. 综合观察

这 6 篇工作中的 uncertainty 并不是同一种量，可以分成四类。

第一类是 posterior / predictive uncertainty。Variational Multi-scale 和 Horseshoe Splatting 都试图让 3DGS 参数有 posterior distribution，再用多次渲染方差或 likelihood 评估不确定性。它们更接近 Bayesian uncertainty，适合做校准、active view selection 和错误区域识别。

第二类是 sensitivity / pruning uncertainty。PUP 用 Fisher score 判断某个 Gaussian 被删除后对训练视图影响有多大，本质上是 post-hoc 参数敏感度。它适合压缩，但未必等价于 novel-view error。

第三类是 observation support uncertainty。UA-4DGS 用训练视图中的 alpha contribution 衡量某个 Gaussian 被观察得是否充分。这类不确定性非常实用，特别适合 gate diffusion、depth smoothing、pseudo-view supervision 等强先验，避免先验污染已可靠区域。

第四类是 task-specific geometric uncertainty。动态 4DGS 和 pose refinement 工作把 uncertainty 嵌入图优化、PnP sampling、key node selection、loss weighting 等下游模块。这里 uncertainty 不只是可视化输出，而是控制系统决策的权重。

一个明显趋势是：未来更有用的 uncertainty 不应只输出一张 heatmap，而应进入 densification、pruning、pose refinement、view selection、diffusion guidance、dynamic graph 和 deployment budget allocation。

## 3. 8 个可以尝试的组合型 Idea

### Idea 1: Dual-source Uncertainty for Sparse/Dynamic 3DGS

组合来源：Variational Multi-scale 的 posterior uncertainty，UA-4DGS 的 visibility contribution，Uncertainty Matters 的 dynamic graph weighting。

要做的是同时估计两种不确定性：`posterior ambiguity` 表示模型参数多解或观测冲突，`support uncertainty` 表示训练视图覆盖不足。前者用于识别歧义区域，后者用于决定是否引入外部先验。动态 4DGS 中，只有高 support uncertainty 且高 posterior ambiguity 的区域才启用强 depth/flow/diffusion regularization；低 posterior 但低 support 的区域只做保守 smoothness。

### Idea 2: Horseshoe-PUP Hybrid Compression

组合来源：Horseshoe Splatting 的 scale posterior shrinkage，PUP 的 Fisher pruning，Speedy-Splat / fragment pruning 类部署需求。

要做的是训练阶段用 Horseshoe prior 让 covariance scale 自动收缩，部署前再用 Fisher score 判断删除 Gaussian 或 fragment 的风险。剪枝条件可以是：posterior scale 接近零、opacity 低、Fisher sensitivity 低、novel-view uncertainty 低。这样比单独 PUP 更知道哪些 Gaussian 是结构噪声，也比单独 Horseshoe 更直接面向压缩指标。

### Idea 3: Uncertainty-biased Pose-Free Gaussian Splatting

组合来源：Rethinking Pose Refinement 的 Monte Carlo pose particles，Deep Gaussian from Motion / pose-free GS 的 learned correspondences，PUP / FisherRF 的 geometry uncertainty。

要做的是在 pose-free sparse 3DGS 中维护多个 camera pose hypotheses，用 learned 2D-3D correspondences 做 PnP，但采样和重投影加权由 geometry uncertainty 控制。高不确定 3D 点不进入 PnP minimal set，或者只以低权重参与一致性评估。训练 early stage 可以保留多个 pose particles，等 uncertainty 降低后再合并。

### Idea 4: Uncertainty-gated Video Diffusion Supervision

组合来源：UA-4DGS 的 uncertainty-aware diffusion，Taming Video Diffusion Prior 的 scene-grounding guidance，Variational Multi-scale 的 predictive uncertainty。

要做的是把 video diffusion 生成的 pseudo views 只用于“低可见支撑 + 高预测不确定”的区域。已知区域由 3DGS rendering anchor 约束，未知区域由 diffusion 补全；但 diffusion loss 的权重由 posterior predictive variance 和 visibility uncertainty 共同决定。这样可减少 generated-view hallucination 对可靠几何的污染。

### Idea 5: Uncertainty-aware Gaussian Densification Policy

组合来源：Variational offset posterior、UA-4DGS dynamic region densification、LoopSparseGS / PCD 的初始化增密。

要做的是把 densification 触发从 gradient threshold 改为 uncertainty policy。高 support uncertainty 区域优先从 depth / flow / MVS / foundation model 初始化新 Gaussians；高 posterior variance 但已有可见支撑的区域做 local split 或 offset sampling；低 uncertainty 高 density 区域则进入 pruning。这个策略可用于 sparse-view、dynamic 和 pose-free setting。

### Idea 6: Task-aware Uncertainty Calibration Benchmark

组合来源：AUSE/NLL uncertainty metrics、PUP compression、pose refinement、active view selection。

要做的是建立一个 3DGS uncertainty benchmark，不只评价 uncertainty 与 RGB error 的相关性，还评价它对四个下游任务的帮助：active view selection、pruning、pose refinement、pseudo-view filtering。不同 uncertainty 方法可能在不同任务上表现相反，benchmark 可以揭示 posterior、Fisher、visibility、disagreement 各自适合的使用场景。

### Idea 7: Semantic Uncertainty for Open-vocabulary 3DGS

组合来源：FMGS / GaussTR 的 foundation feature field，Horseshoe / Variational 的 pixel uncertainty，PUP 的 pruning。

要做的是给 Gaussian semantic feature 也建 uncertainty。几何可靠但语义不确定的区域继续保留几何、降低 text-query confidence；几何和语义都不确定的区域触发重新采样或请求更多视角。可用多 foundation model feature disagreement、CLIP/DINO similarity variance 和渲染 feature posterior 共同估计 semantic uncertainty。

### Idea 8: Static-Dynamic Uncertainty Separation

组合来源：Uncertainty Matters 的 dynamic key nodes，UA-4DGS 的 dynamic region densification，EDGS 的 time-mask。

要做的是把不确定性拆成 static uncertainty、motion uncertainty 和 appearance uncertainty。静态背景主要关注几何/pose uncertainty；动态物体关注 motion graph 和 temporal uncertainty；外观变化关注 SH/feature uncertainty。不同不确定性触发不同操作：背景做 pose refinement，动态节点做 graph rewire，外观区域做 feature regularization 或 exposure modeling。

## 4. 优先级建议

短期最容易验证的是 Idea 2 和 Idea 5，因为它们可以在已有 3DGS 训练或剪枝管线中添加新的 score 和 policy。

如果目标是更有论文差异化，优先尝试 Idea 1、Idea 4 和 Idea 8：它们把 uncertainty 从单一 heatmap 变成多源、多任务的控制信号。

如果目标是构建长期研究工具，Idea 6 最值得做。它能反过来评估所有 uncertainty 方法是否真的有用，而不是只在可视化上“看起来合理”。
