# DropGaussian: Structural Regularization for Sparse-view Gaussian Splatting

## 0. 元数据

* Title: DropGaussian: Structural Regularization for Sparse-view Gaussian Splatting
* Authors: Hyunwoo Park; Gun Ryu; Wonjun Kim
* Year: 2025
* Venue: CVPR
* PDF source: `/Users/wangyibo/Zotero/storage/N38S87C5/Park 等 - DropGaussian Structural Regularization for Sparse-view Gaussian Splatting.pdf`
* Zotero item key: `MDDFGE2H`
* Zotero PDF attachment key: `N38S87C5`
* Code: `https://github.com/DCVL-3D/DropGaussian_release`
* Project page: Not specified
* Dataset link: Not specified
* Main task: sparse-view 3D Gaussian Splatting novel view synthesis
* Domain: prior-free sparse-view 3DGS regularization
* Input: sparse posed training images and standard 3DGS initialization
* Output: trained 3DGS model with improved sparse-view novel view quality

## 1. 一句话技术摘要

DropGaussian 在训练期像 dropout 一样随机临时移除一部分 Gaussians，并对保留 Gaussians 的 opacity 做 $1/(1-r)$ 补偿，使被遮挡或远离相机的 Gaussians 获得更大可见性和梯度；同时随迭代逐步增大 dropping rate，以在后期抑制 sparse-view 3DGS 过拟合。

## 2. 问题形式化

在 sparse-view 3DGS 中，输入视角少导致许多 Gaussians 只在少数视角可见，甚至被前方 Gaussians 遮挡。这些低可见 Gaussians 的 transmittance $T_i$ 小，梯度反馈不足，无法充分更新几何、颜色、opacity 和尺度；模型最终容易过拟合训练视角，在 novel views 中产生 artifacts。

DropGaussian 的目标是在不引入单目深度、diffusion、optical flow 等外部 prior 的前提下，通过训练期随机 drop Gaussians 改变可见性和梯度分配，让剩余 Gaussians 在 sparse views 下获得更均衡的优化机会。

## 3. 方法概览

方法只改动 3DGS 训练流程。

训练每次渲染前，根据当前 dropping rate $r_t$ 随机选一部分 Gaussians 临时置零；被保留的 Gaussians 的 opacity 乘以 compensation factor $1/(1-r_t)$，以近似保持总 opacity/contribution。被 drop 的 Gaussians 本次不参与渲染和梯度，未被 drop 的 Gaussians 因遮挡减少而更可见，特别是远离相机或原本被遮挡的 primitives 能获得更大梯度。

推理阶段不 drop，使用完整 Gaussian set 渲染。DropGaussian 因此不是 pruning，也不是模型压缩，而是训练期 structural regularization。

## 4. 方法细节

**为什么随机 drop。** Sparse-view 下，远处 Gaussians 因可见视角少和 occlusion 更难获得梯度。随机移除部分前景/附近 Gaussians 后，剩余 Gaussians 的可见性提高。作者用 Fig. 3(a) 统计超过 densification gradient threshold 的 Gaussians 分布，显示 DropGaussian 让较远 Gaussians 也获得较大梯度。

**Opacity compensation。** 直接 drop 会降低每个 pixel 的累计 opacity 和颜色贡献，因此作者对保留 Gaussians 做 $1/(1-r)$ 放大。这样在期望意义上维持总贡献，同时仍保留随机遮挡扰动带来的正则效果。

**Progressive schedule。** 作者观察到 sparse-view 过拟合主要在训练后期加重，早期过强 drop 可能破坏初始重建。因此 dropping rate 随迭代线性增加。默认 scale factor $\gamma=0.2$，总训练 10,000 iterations。

**随机 drop 优于 selective drop。** Ablation 显示按 gradient 或 distance 选择性 drop 效果更差，因为这些指标可能反复丢弃对 sparse-view 重建关键的 Gaussians。随机临时 drop 则允许所有 Gaussians 在后续迭代重新参与。

**与 L1 pruning 的差异。** L1 regularization/永久 pruning 会移除低相关 elements，而 DropGaussian 只是临时 deactivation；强相关 Gaussians 若某次被 drop，后续仍可重新参与训练。

## 5. 数学目标与损失

第 $i$ 个 Gaussian 的基函数为：

$$
G_i(x)=\exp(-\frac{1}{2}(x-\mu_i)^T\Sigma_i^{-1}(x-\mu_i))
$$

像素 $p$ 的 alpha compositing 颜色为：

$$
C(p)=\sum_{i=1}^{N}c_i\alpha_iT_i
$$

其中：

$$
T_i=\prod_{j=1}^{i-1}(1-\alpha_j),\quad \alpha_i=o_i\cdot g_i^{2D}
$$

DropGaussian 对 opacity 做 mask/compensation：

$$
\tilde{o}_i=M(i)\cdot o_i
$$

其中 $M(i)=1/(1-r)$ 表示该 Gaussian 被保留，$M(i)=0$ 表示该 Gaussian 被 drop。$r$ 是当前 dropping rate。

Progressive dropping rate 为：

$$
r_t=\gamma\cdot\frac{t}{t_{\text{total}}}
$$

颜色重建损失沿用 3DGS：

$$
L_{\text{color}}=L_1(\hat{I},I)+\lambda L_{\text{D-SSIM}}(\hat{I},I)
$$

论文设置 $\lambda=0.2$。

## 6. 训练与推理流程

1. 使用标准 3DGS/SfM 初始化 Gaussians。
2. 每个 training iteration 根据 $r_t=\gamma t/t_{\text{total}}$ 计算当前 drop rate。
3. 对 Gaussian set 采样随机 binary mask。
4. 被 drop 的 Gaussians 本轮 opacity 置 0；保留 Gaussians opacity 乘 $1/(1-r_t)$。
5. 用 masked Gaussian field 渲染训练视角。
6. 用 $L_1+D$-SSIM color loss 优化所有参数；未被 drop 的 Gaussians 获得梯度。
7. 每 100 iterations 执行 densification，gradient threshold 为 $5\times10^{-4}$。
8. 训练 10,000 iterations。
9. 推理时关闭 DropGaussian，使用完整 Gaussian set 渲染 novel views。

实现细节：PyTorch，Adam optimizer，momentum 0.9/0.999，GPU 为 RTX 3090Ti。

## 7. 实验设置与结果摘要

数据集包括 LLFF、Mip-NeRF360、Blender 和 Replica。LLFF 使用 3、6、9 views，Mip-NeRF360 使用 12、24 views，Blender 使用 8 views；LLFF 和 Mip-NeRF360 downsample rate 为 8，Blender 为 2。指标为 PSNR、SSIM、LPIPS。

LLFF 表 1 中，DropGaussian 在 3 views 下 PSNR/SSIM/LPIPS 为 20.76/0.713/0.200，高于 3DGS 的 19.22/0.649/0.229，也略高于 CoR-GS 的 20.45 PSNR；6/9 views 下与 CoR-GS 接近并略有 PSNR/LPIPS 改善。

Mip-NeRF360 表 2 中，DropGaussian 在 12 views 下达到 19.74/0.577/0.364，优于 3DGS、FSGS、CoR-GS；24 views 下达到 24.13/0.762/0.225，同样优于 baselines。Blender 表 3 中，DropGaussian PSNR 为 25.42，最高；SSIM/LPIPS 略低于最佳 CoR-GS/DNGaussian，但仍竞争力强。

Replica 2-view 表 4 中，DropGaussian 作为 optimization method 达到 27.76 PSNR、0.866 SSIM、0.179 LPIPS，高于 pixelSplat/MVSplat/FreeSplat 的 PSNR 和 SSIM，但 LPIPS 略低于 FreeSplat/MVSplat。

Ablation 表 5 显示 progressive schedule 优于固定 drop rate，默认 $\gamma=0.2$ 效果最好。表 6 显示 random drop 优于 gradient/distance selective drop。表 7 显示 temporary dropping 优于 L1 regularization。

## 8. 声称贡献与实际技术增量

* 声称贡献 1: prior-free sparse-view 3DGS regularization。实际增量是训练期随机临时 drop Gaussians，不依赖 depth/diffusion/flow。
* 声称贡献 2: 改善低可见 Gaussians 的梯度。实际机制是遮挡扰动 + opacity compensation，让剩余 primitives 获得更多可见机会。
* 声称贡献 3: progressive dropping。实际增量是根据 overfitting 后期更严重的观察，线性增大 $r_t$。
* 技术定位: 更像 dropout-style regularization，而不是 densification/pruning/compression 方法。

## 9. 局限与隐含假设

* Dropping rate scale $\gamma$ 需要按数据集/任务调参；论文也指出这是限制。
* 随机 drop 只改变训练可见性，不能直接补足缺失几何或错误初始化；极端 sparse 或大遮挡区域仍可能失败。
* 方法没有引入跨视角几何一致性，因此对深度错误、pose noise、低纹理场景的约束弱于 depth/flow/covisibility 方法。
* 高 drop rate 固定使用会损害性能，需要 progressive schedule。
* 与其他 prior-based 方法的组合潜力未充分实验，例如 CoR-GS+DropGaussian 或 CoMapGS+DropGaussian。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法类别 | Prior-free dropout-style 3DGS regularization |
| 核心操作 | Randomly drop Gaussians during training with opacity compensation |
| 输入条件 | Sparse posed images; standard 3DGS setup |
| 外部先验 | 无 |
| 训练 schedule | Progressive drop rate $r_t=\gamma t/t_{\text{total}}$ |
| 推理 | 使用完整 Gaussian set，不 drop |
| 主要优势 | 简单、无额外模块、几乎无复杂度增加、可插拔 |
| 主要风险 | 不能解决缺失几何，需调 $\gamma$ |

## 11. 对我研究可复用的组件

* **Temporary Gaussian dropout**: 可作为任何 sparse-view GS 方法的训练正则。
* **Opacity compensation**: 保持渲染贡献期望稳定，避免 drop 直接造成图像变暗/透明。
* **Progressive regularization**: 后期加大正则，适合 sparse-view 中后期 overfitting。
* **Random over selective**: 对 sparse-view primitives，随机临时扰动可能比按梯度/距离删除更稳。
* **Gradient visibility analysis**: 可用“超过 densification threshold 的 Gaussians 距离分布”诊断训练是否只更新近处/可见 primitives。

## 12. 缺口与想法种子

* **Covisibility-aware DropGaussian**: 用 CoMapGS 的 covisibility map 调整 drop probability，在高共视区域更常 drop，低共视区域更少 drop 或更强 opacity compensation。
* **Uncertainty-conditioned schedule**: 根据 validation loss、render variance 或 Gaussian co-adaptation score 自适应 $\gamma$。
* **Drop + depth regularization**: 与 DNGaussian/CoherentGS 的 depth/flow loss 结合，让 drop 负责防过拟合，depth/flow 负责几何。
* **Structured dropout**: 按空间块、ray segment 或 object mask drop，而不是独立 Gaussian drop，模拟遮挡变化。
* **Dynamic Gaussian dropout**: 在动态 4DGS 中随机 drop time-dependent primitives，减少某些时间帧过拟合。

## 13. 人工检查清单

* `NEED_HUMAN_CHECK`: GitHub URL 在 PDF 抽取中有空格，应确认准确链接为 `https://github.com/DCVL-3D/DropGaussian_release`。
* `NEED_HUMAN_CHECK`: 表 5 中 progressive 标记符号在抽取文本中可能显示为 `7/X`，需以 PDF 表格确认含义。
* `NEED_HUMAN_CHECK`: 不同数据集的默认 $\gamma$ 是否全部为 0.2，主文说明默认 0.2 但可能有 appendix 细节。
* `NEED_HUMAN_CHECK`: 是否与 FSGS/CoR-GS 组合实验，主文主要比较未组合。

## 14. 证据锚点

* Abstract: prior-free DropGaussian，随机移除 Gaussians，提高剩余 Gaussians visibility 和 gradients。
* Fig. 1: sparse-view 下低可见 Gaussians 与 DropGaussian 的可见性改善示意。
* Sec. 1: 过拟合在训练后期更强，提出 progressive DropGaussian。
* Fig. 2: 训练期 drop，测试期使用完整 Gaussians。
* Sec. 3.1 / Eq. (1)-(3): 3DGS Gaussian、alpha compositing 和 transmittance。
* Sec. 3.2 / Eq. (4)-(5): opacity compensation 和 progressive drop rate。
* Fig. 3: DropGaussian 增加远处 Gaussians 的大梯度分布。
* Fig. 4: 后期过拟合曲线和 DropGaussian 缓解效果。
* Sec. 3.3 / Eq. (6): color reconstruction loss。
* Sec. 4.1-4.2: 训练设置、数据集和评估指标。
* Table 1: LLFF 3/6/9-view 定量结果。
* Table 2: Mip-NeRF360 12/24-view 定量结果。
* Table 3: Blender 定量结果。
* Table 4: Replica 2-view 与 feed-forward methods 对比。
* Table 5-7: drop rate、random/selective dropping、temporary dropping vs L1 regularization 消融。
* Sec. 4.4: $\gamma$ 超参数敏感性。
