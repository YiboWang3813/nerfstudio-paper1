# Efficient Gaussian Splatting for Monocular Dynamic Scene Rendering via Sparse Time-Variant Attribute Modeling

## 0. Metadata

* Title: Efficient Gaussian Splatting for Monocular Dynamic Scene Rendering via Sparse Time-Variant Attribute Modeling
* Authors: Hanyang Kong, Xingyi Yang, Xinchao Wang
* Year: 2025
* Venue: AAAI 2025
* PDF source: Zotero local PDF
* Zotero item key: VRJPK8II
* Zotero PDF attachment key: KC5JNY7E
* PDF path: `/Users/wangyibo/Zotero/storage/KC5JNY7E/Kong 等 - Efficient Gaussian Splatting for Monocular Dynamic Scene Rendering via Sparse Time-Variant Attribute.pdf`
* Note path: `notes/Efficient Gaussian Splatting for Monocular Dynamic Scene Rendering via Sparse Time-Variant Attribute Modeling.md`
* Code: Not specified
* Project page: Not specified
* Dataset link: Not specified
* Main task: monocular dynamic scene novel view rendering
* Domain: dynamic 3DGS, efficient rendering, sparse anchor-grid, time-varying attributes
* Input: monocular dynamic video frames and camera poses
* Output: compact dynamic 3DGS representation with faster rendering

## 1. One-Sentence Technical Summary

EDGS 将动态场景表示为 sparse anchor-grid 上的 time-invariant 与 time-variant attributes，用 unsupervised time-mask MLP 只让动态 anchors 查询时变属性，并用 RBF kernel 从 anchor motion 推导所属 Gaussian offsets 的运动，从而减少动态 3DGS 中冗余 Gaussians 和静态区域抖动。

## 2. Problem Formulation

Deformable 3DGS、4DGS 和 SCGS 等动态 3DGS 方法能重建 monocular dynamic scenes，但通常把大量 densified Gaussians 都送进 deformation network，在每个时间步查询位置、旋转、尺度等属性。真实场景中大部分区域是静态的，对这些区域反复查询时变属性会降低速度，还会引入静态区域 jittering。

本文的问题可以表述为：如何在不牺牲动态区域渲染质量的前提下，减少需要时变属性建模的 Gaussians，并将静态区域的属性固定，从而提升动态 3DGS 的渲染速度和稳定性。

## 3. Method Overview

EDGS 借鉴 Scaffold-GS 的 anchor-voxel 思路。首先用 COLMAP sparse points 初始化 voxelized sparse anchors，而不是直接维护大量 Gaussians。每个 anchor 拥有 feature、attribute scaling 和 $K$ 个 Gaussian offsets。time-invariant attributes 如 opacity 和 color 由 anchor feature 解码；time-variant attributes 如 location、scale、quaternion 只对动态 anchors 解码。

方法的两个关键模块是 time-mask MLP 和 RBF Gaussian offset derivation。time-mask MLP 无监督地判断哪些 anchors 属于动态区域，只有这些 anchors 才输入时变属性 MLP。对于动态 anchor，先用 deformation MLP 得到 anchor movement，再用 anchor feature 与 offset feature 的 RBF similarity 把 anchor motion 分配给对应 Gaussian offsets。

## 4. Method Details

### 4.1 Anchor-grid initialization

给定 COLMAP 点云 $P\in\mathbb{R}^{M\times3}$，EDGS 先按 voxel size $\Delta d$ 对点云体素化：

$$
A=\left\lfloor\frac{P}{\Delta d}\right\rfloor\cdot\Delta d
$$

得到 structured anchor-grid $A=\{a_0,a_1,\ldots,a_{N-1}\}$。floor operation 去掉冗余过密点，使 anchor 数量远小于 Gaussian 数量。训练时 anchor 位置保持冻结，优化的是 anchor feature、Gaussian offsets 和 MLP 参数。

### 4.2 Gaussian attribute derivation

每个 anchor $a$ 有 feature $f_a$，并关联 $K$ 个 Gaussian offsets。time-invariant attributes 如 opacity 和 color 由 $\Phi_\alpha(f_a)$ 与 $\Phi_c(f_a)$ 解码。scale、quaternion 和 Gaussian offset 的变化是 time-variant 的，输入为 anchor feature 与 time positional encoding $\gamma(t)$。例如第 $k$ 个 Gaussian 的 scale 为：

$$
s_o^{k,t}=s_a+s_o^k+\Delta s_o^{k,t}
$$

其中 $\Delta s_o^{k,t}=\Phi_s(\mathrm{cat}\{f_a,\gamma(t)\})$。quaternion 使用类似方式计算。

### 4.3 RBF kernel for Gaussian offsets motion

传统 deformable 3DGS 直接用 deformation MLP 对每个 Gaussian 查询 offsets：

$$
\Delta x,\Delta r,\Delta s=F(\gamma(x,t))
$$

EDGS 改为先查询 anchor movement：

$$
\Delta x_a^t=F(\gamma(x_a,t))
$$

再根据 anchor feature $f_a$ 与第 $k$ 个 offset feature $f_o^k$ 的 RBF similarity 分配运动：

$$
\Delta x_o^{k,t}=K(f_a,f_o^k)\cdot\Delta x_a^t
$$

$$
K(f_a,f_o^k)=\exp\left(-\frac{\|f_a-f_o^k\|^2}{2\sigma^2}\right)
$$

实验中 $\sigma=1$。最终第 $k$ 个 Gaussian 的位置为：

$$
x_o^{k,t}=x_a+x_o^k+\Delta x_o^{k,t}
$$

这样可以避免 rigid assumption 过强，也比 KNN 在物体碰撞或分离时更语义化。

### 4.4 Time mask

由于静态区域的 location、scale、quaternion 不应随时间变化，EDGS 引入 tiny binary classifier $\Phi_{mask}$ 判断 anchor 是否为 deformable。所有 anchor features 输入 $\Phi_{mask}$，只有输出 label 为 1 的 anchors 会进入 time-variant MLP。为鼓励稀疏动态 anchors，加入 time-mask regularization：

$$
L_{t-mask}=\sum_{n=0}^{N-1}\Phi_{mask}(f_a^n)/N
$$

该 mask 不需要 2D 或 3D motion labels，完全通过渲染 loss 和正则项共同学习。

## 5. Mathematical Objectives and Losses

3DGS 的基础 Gaussian 写作：

$$
G(x)=e^{-\frac{1}{2}(x-\mu)^T\Sigma^{-1}(x-\mu)}
$$

covariance 分解为：

$$
\Sigma=RSS^TR^T
$$

渲染使用 alpha blending：

$$
C=\sum_{i\in N}c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j)
$$

最终训练损失为：

$$
L=(1-\lambda)L_1+\lambda L_{SSIM}+\lambda_tL_{t-mask}
$$

所有实验中 $\lambda=0.2$、$\lambda_t=0.2$。监督来自 rendered RGB images 的 reconstruction loss，不需要额外 dynamic masks。

## 6. Training and Inference Procedure

模型训练 30000 iterations，主要超参数沿用 3DGS。每个 anchor 设置 $K=10$ 个 offset Gaussians，anchor feature 和 offset feature 维度为 8。Gaussian attribute MLPs 是两层 MLP，中间层维度 64；anchor deformation MLP 是 4 层 fully connected network，ReLU 激活，中间层维度 128。anchor 初始化 voxel size 为 0.6。实验硬件为 NVIDIA V100。

训练中还采用 anchor densification 和 pruning。每 100 iterations 统计 anchor gradients，超过阈值 $\epsilon$ 的 anchor voxel 被切分成 $m$ 个 sub-voxels，并复制 anchor feature、初始化 $K$ 个 offsets。对平均 opacity 低于阈值的 anchor 进行 pruning。推理时只对 time-mask 选出的动态 anchors 查询 time-variant attributes，从而减少 MLP 查询量并提升 FPS。

## 7. Experimental Setup and Results Summary

实验使用 NeRF-DS 和 HyperNeRF 两个真实动态数据集，指标包括 PSNR、SSIM / MS-SSIM、LPIPS、training time 和 FPS。对比方法包括 Nerfies、HyperNeRF、TiNeuVox、3D-GS、FFDNeRF、Deformable 3DGS、4DGS、SCGS。

NeRF-DS 上，EDGS 平均 PSNR 为 24.39，SSIM 为 0.8873，优于其他 baseline，并在 moving objects 上有更清晰结构。HyperNeRF VRIG 上，EDGS 达到 25.7 dB PSNR、0.860 MS-SSIM 和 117 FPS，同时只有约 7K Gaussians 需要查询 time-variant attributes。相比 Deformable 3DGS / 4DGS，EDGS 还减少了静态区域跨时间的 jittering。

消融表明，去掉 anchor-grid initialization 后速度下降到约 17-27 FPS，说明 Gaussian 数量仍是动态渲染瓶颈；去掉 time-mask 后速度仍高但质量略低，full model 在 As / Bell / Sieve 三个场景上分别达到 26.65 / 26.01 / 27.12 PSNR 和 152 / 147 / 151 FPS。offset derivation 消融中，rigid transformation 最差，KNN 和 cosine similarity 次之，RBF kernel 在三场景中整体最好或最均衡。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 sparse time-variant attribute modeling、unsupervised static-anchor filtering 和 RBF kernel motion flow。实际技术增量在于把动态 3DGS 的时变查询粒度从 dense Gaussians 降到 sparse anchors，并进一步用 learned mask 只保留动态 anchors 做时变查询。

相对 4DGS / Deformable 3DGS，EDGS 并不是设计更强的 deformation field，而是减少 deformation field 的调用对象。相对 SCGS 的 KNN control points，EDGS 用 feature-space RBF kernel 建立 anchor 与 Gaussian offsets 的运动关系，避免仅基于空间距离的近邻在复杂非刚体运动中失效。

## 9. Limitations and Hidden Assumptions

方法依赖 COLMAP sparse point cloud 初始化 anchor-grid；如果 monocular video 的相机位姿或 SfM 点云质量差，anchor layout 会影响后续动态建模。time-mask MLP 是无监督学习，虽然实验显示能区分静态和动态区域，但它可能在细微运动、反射、高频纹理变化或相机曝光变化下混淆。

EDGS 的目标主要是提升 dynamic 3DGS rendering efficiency，而不是解决 sparse-view coverage 或 pose-free reconstruction。虽然文件所在分组是 Sparse-View，但本文核心问题更接近 dynamic compact representation。数据集也集中在 NeRF-DS 和 HyperNeRF，户外大尺度、拓扑变化和长视频泛化未充分验证。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| 核心任务 | Monocular dynamic scene rendering |
| 输入 | monocular video frames, camera poses, COLMAP points |
| 表示 | voxelized sparse anchors + per-anchor Gaussian offsets |
| 关键模块 | anchor-grid initialization, time-mask MLP, RBF offset motion |
| 时变属性 | location, scale, quaternion for dynamic anchors only |
| 静态属性 | opacity, color decoded without time |
| 主要损失 | RGB $L_1$ + SSIM + time-mask sparsity regularization |
| 主要优势 | fewer time-variant queries, faster FPS, reduced static jitter |
| 主要风险 | SfM / pose dependence, unsupervised mask errors |

## 11. Reusable Components for My Research

1. time-mask MLP 可用于任何动态 3DGS，把静态区域从 deformation network 查询中排除。
2. anchor-level time-variant selection 适合与 pruning / dropout 结合，形成动态场景的 compute-aware rendering。
3. RBF kernel based offset motion 可替代 KNN control points，在非刚体或接触分离场景中减少错误邻域绑定。
4. static jittering 可作为动态 3DGS 的额外评估维度，不只看 PSNR / LPIPS。
5. anchor densification / opacity pruning 可作为动态版 Scaffold-GS 的基础组件。

## 12. Gap and Idea Seeds

1. 将 time-mask 与 optical-flow / motion segmentation weak prior 结合，提升细微动态区域的识别。
2. 在 sparse-view dynamic 任务中，用 MVSplat / DUSt3R 初始化 anchor-grid，降低 COLMAP 失败风险。
3. 将 time-mask regularization 改成预算约束：给定目标 FPS，自动调节动态 anchor 数量。
4. 将 RBF kernel 的 $\sigma$ 学成 per-anchor 或 per-object 参数，使刚体和非刚体区域有不同运动传播范围。
5. 把 static jittering loss 加入训练，在固定相机跨时间渲染时显式惩罚静态 mask 区域变化。

## 13. Human Check List

* NEED_HUMAN_CHECK: Table 1 的 per-scene 数值在 PDF 文本抽取中不完整，已记录论文给出的 mean 指标，精确矩阵需回看原表。
* NEED_HUMAN_CHECK: anchor densification 阈值 $\epsilon$、sub-voxel 数 $m$、opacity pruning 阈值未在抽取文本中给出。
* NEED_HUMAN_CHECK: 代码链接未在 PDF 主文中稳定抽取。
* 已确认：公式格式按仓库 inline / display dollar 规范书写。

## 14. Evidence Anchors

* Abstract: 提出 EDGS、sparse time-variant attribute modeling、unsupervised static anchor filtering 和 RBF motion flow。
* Figure 1: 展示 rendering speed 与 Gaussian 数量关系，并说明 EDGS 速度、质量和 time-variant Gaussian 数量优势。
* Figure 2: EDGS pipeline，包括 voxelized sparse anchors、time-mask MLP、static/time-variant attribute branches 和 RBF kernel。
* Section 4.1: anchor-grid initialization Eq. 5。
* Section 4.2-4.4: Gaussian attribute derivation、RBF motion Eq. 8-11、time-mask regularization Eq. 12。
* Section 4.5-4.6: anchor densification / pruning 和 final loss Eq. 13。
* Section 5.1: 数据集、指标、训练 30k iterations、MLP 结构、$K=10$、voxel size 0.6。
* Section 5.2: NeRF-DS mean PSNR / SSIM 和 HyperNeRF 25.7 dB / 117 FPS / 7K time-variant Gaussians。
* Section 5.4, Table 3-4: anchor-grid、time-mask、RBF kernel 的消融。
* Figure 5-6: static area jittering 对比和 time-mask 可视化。
