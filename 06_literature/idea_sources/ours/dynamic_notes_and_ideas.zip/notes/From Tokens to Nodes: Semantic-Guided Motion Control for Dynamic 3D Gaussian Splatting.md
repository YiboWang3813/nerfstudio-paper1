# From Tokens to Nodes: Semantic-Guided Motion Control for Dynamic 3D Gaussian Splatting

## 0. Metadata

- Title: From Tokens to Nodes: Semantic-Guided Motion Control for Dynamic 3D Gaussian Splatting
- Authors: Jianing Chen; Zehao Li; Yujun Cai; Hao Jiang; Shuqin Gao; Honglong Zhao; Tianlu Mao; Yucheng Zhang
- Venue/Year: ICLR 2026
- Zotero item key: `HTJ63C9C`
- Zotero PDF attachment key: `HL7ZEIFV`
- PDF path: `/Users/wangyibo/Zotero/storage/HL7ZEIFV/Chen 等 - 2026 - FROM TOKENS TO NODES SEMANTIC-GUIDED MO- TION CONTROL FOR DYNAMIC 3D GAUSSIAN SPLAT-.pdf`
- Local note path: `notes/From Tokens to Nodes: Semantic-Guided Motion Control for Dynamic 3D Gaussian Splatting.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

本文提出 MANI + spline node trajectories 的动态 3DGS 控制框架：先用 VFM patch tokens、foreground prior 和 depth 把图像 patch 反投影成候选 nodes，再按 motion tendency 自适应压缩静态冗余、保留动态区域节点，最后用 cubic Hermite spline 表达节点轨迹并通过 DQB 驱动 Gaussians。

## 2. Problem Formulation

输入是单目动态视频 $\{I_t\}$，目标是重建可实时渲染的 dynamic 3D Gaussian representation。论文关注 sparse control 类方法的资源分配问题：现有控制点通常由 FPS 或 voxelization 产生，只保证几何覆盖，却没有让控制点密度匹配 motion complexity。真实场景中静态背景占据大量空间但运动简单，动态物体区域小却需要更密集控制，因此会出现 static redundancy 和 dynamic insufficiency。

论文将每个 Gaussian 的运动交给少量 nodes 控制。每个 node 承载一个 $SE(3)$ 轨迹 $T_i(t)$ 和 RBF 半径 $\rho_i$，Gaussians 通过邻近 nodes 的权重插值获得时变刚体变换。核心问题因此变成：如何初始化更合理的 nodes，以及如何让 node trajectory 在单目弱监督下稳定优化。

## 3. Method Overview

方法包含三个主模块。第一，Motion-Adaptive Node Initialization (MANI)：从 keyframes 的 image patches 出发，用 frozen VFM 提取 token embedding，并结合深度和相机把 patch center 反投影到 3D，形成 patch-token-node correspondence。第二，dynamic motion-adaptive compression：在逐渐变粗的 voxel 尺度中，用 token similarity 和 foreground prior 计算 node pair similarity，再根据 voxel cluster 的 dynamic tendency 调整压缩比例，让静态区域更激进合并、动态区域少合并。第三，Spline-Parameterized Node Trajectories：用 cubic Hermite spline 参数化每个 node 的平移轨迹，并用 2D tracklets 反投影后的 3D 轨迹初始化 spline。

优化阶段中，节点 motion 通过 Dual Quaternion Blending 传播到 canonical Gaussians；渲染结果由 RGB、mask、depth、tracking 和 ARAP losses 联合监督。实现上使用 VGGT 提取 patch tokens，Track-Anything 提供 foreground masks，DepthCrafter 提供 temporally consistent depth，TAPIR 提供 dense 2D trajectories。

## 4. Method Details

### 4.1 Node-Based Deformation

节点集合 $N=\{N_i\}_{i=1}^{N_n}$ 远小于 Gaussian 数量 $N_g$。每个节点定义为 $N_i=\{T_i(t),\rho_i\}$，其中 $T_i(t)\in SE(3)$ 是跨时间轨迹，$\rho_i$ 是 RBF influence radius。

对 Gaussian $G_j$，方法选取邻域 $V(G_j)$ 中的 $K$ 个 nodes。节点 $N_i$ 到 Gaussian $G_j$ 的绑定权重是 normalized RBF：

$$
w_{ij}=\frac{\exp(-\|x_j-c_i\|^2/(2\rho_i^2))}{\sum_{k\in V(G_j)}\exp(-\|x_j-c_k\|^2/(2\rho_k^2))}.
$$

每个 node 的 $SE(3)$ 变换 $T_i(t)=[R_i(t)|t_i(t)]$ 被转为 dual quaternion $Q_i(t)$。Gaussian 的 blended transform 由邻近 nodes 的 weighted dual quaternions 归一化后再转回 $SE(3)$，即 $T_j(t)=\mathrm{DQ2SE3}(\hat Q_j(t))$。这一步沿用 DQB 来获得比 LBS 更稳定的刚体插值。

### 4.2 Patch-Token-Node Generation

MANI 不从 point cloud 均匀采样，而是把 keyframes 划分为固定大小 patches。对 frame $t$ 的 patch $p$，VFM 输出 token $z_{t,p}$，depth 提供反投影尺度，patch center $u_{t,p}$ 被反投影成 3D 点 $x_{t,p}$。候选 node 集合写作 $\{(x_{t,p},z_{t,p})\}$。这个设计的意义是把 2D semantic / motion prior 直接绑定到 3D control node，而不是在 3D 空间采样后再猜它属于什么语义或运动区域。

### 4.3 Motion-Adaptive Node Compression

候选 nodes 仍然过多，因此作者提出 iterative voxelization compression。算法从小 voxel size $v_{\mathrm{init}}$ 开始，在每个 voxel 内用 bipartite soft matching 找相似 node pairs，并合并 top $r\%$ 的高相似 pairs；每轮后 voxel size 增大 $\Delta v$，直到 node 数量低于目标阈值。

node pair similarity 同时考虑 token appearance 和 foreground prior：

$$
\mathrm{sim}(N_i,N_j)=\cos(z_i,z_j)-\eta\cdot \tilde M_{\mathrm{fg}}(N_i,N_j).
$$

静态区域跨帧 token 更一致，cosine similarity 高；动态区域 token 变化更强，同时 foreground prior 高，因此不应被过早合并。为此论文定义 cluster dynamic tendency $p_{\mathrm{dyn}}(C)$，由 cluster 内平均 foreground prior 与 pairwise similarity 组合而成，再设定 $r\%(C)=r_{\min}+(1-p_{\mathrm{dyn}}(C))(r_{\max}-r_{\min})$。所以低动态倾向区域合并比例高，高动态倾向区域合并比例低。

### 4.4 Spline-Parameterized Node Trajectories

每个 node 只在一组 keyframes $\{t_k\}$ 上学习位置 $\{P_k\}$，中间时刻用 cubic Hermite spline 插值：

$$
\xi(t)=h_{00}(\tau)P_k+h_{10}(\tau)(t_{k+1}-t_k)\dot P_k+h_{01}(\tau)P_{k+1}+h_{11}(\tau)(t_{k+1}-t_k)\dot P_{k+1}.
$$

其中 $\tau=(t-t_k)/(t_{k+1}-t_k)$，Hermite basis 保证位置和一阶导数连续。相比 MLP deformation，这种轨迹参数化把运动学习从 Gaussian attribute optimization 中部分解耦，参数更少、时间更平滑。

轨迹初始化来自 2D tracklets。给定 track pixel $u_t$、depth $D_t(u_t)$ 和相机外参，先反投影到 world coordinate $x_t$，再用 least squares 拟合 Hermite spline。旋转部分初始化为 $R_{\mathrm{node}}(t)=I_3$，留给联合优化阶段细化。

### 4.5 Optimization

总目标函数为：

$$
L_{\mathrm{total}}=\lambda_{\mathrm{rgb}}L_{\mathrm{rgb}}+\lambda_{\mathrm{mask}}L_{\mathrm{mask}}+\lambda_{\mathrm{depth}}L_{\mathrm{depth}}+\lambda_{\mathrm{track}}L_{\mathrm{track}}+\lambda_{\mathrm{arap}}L_{\mathrm{arap}}.
$$

$L_{\mathrm{rgb}}$ 使用 MSE 与 D-SSIM 的组合，appendix 中权重为 0.8 和 0.2。$L_{\mathrm{depth}}$ 对齐 monocular depth prediction，权重 1.0；$L_{\mathrm{mask}}$ 对齐 foreground segmentation mask，权重 1.0。$L_{\mathrm{track}}$ 包含 2D trajectory loss 和 depth reprojection loss，权重分别为 2.0 和 0.1。$L_{\mathrm{arap}}$ 约束邻域 Gaussian 的 pairwise distance 和 local-frame relative coordinates，避免退化形变。

## 5. Mathematical Objectives and Losses

本文真正的数学核心有三类。第一是 Gaussian-to-node RBF binding 和 DQB，把稀疏节点运动转为每个 Gaussian 的刚体变换。第二是 MANI 的 adaptive compression：$\mathrm{sim}(N_i,N_j)$ 和 $p_{\mathrm{dyn}}(C)$ 决定哪些 nodes 应该被合并，直接控制动态区域的控制点密度。第三是 cubic Hermite spline trajectory，它把逐帧自由运动约束成低维、光滑、可微的时间曲线。

loss 设计不是单纯 photometric fitting，而是把 VFM priors 转成训练监督：mask 约束 foreground，depth 约束几何结构，TAPIR tracklets 约束跨帧对应，ARAP 约束局部刚性。这样 sparse nodes 才不会只靠 RGB 在单目 setting 中漂移。

## 6. Training and Inference Procedure

训练前先运行外部 VFM：VGGT tokens、Track-Anything masks、DepthCrafter depth、TAPIR tracklets。随后从 keyframe patches 反投影生成候选 nodes，进行 MANI compression，得到 motion-adaptive node set。接着用反投影 3D tracklets 初始化 spline translations，rotation 初始化为 identity。

联合优化时 canonical Gaussians、node spline parameters、RBF radii 和 Gaussian attributes 一起更新。每次渲染先由 spline 得到 nodes 的 $T_i(t)$，再用 DQB 得到 Gaussian transform $T_j(t)$，最后执行 3DGS rasterization 并计算 composite loss。推理时不需要 MLP 查询 deformation field，只需 spline evaluation、DQB blending 和 Gaussian rasterization，因此 FPS 较高。

## 7. Experimental Setup and Results Summary

主实验使用 Hyper-NeRF(vrig) 和 Neural 3D Video (N3DV) 的单目设置。Hyper-NeRF 中用一个 Pixel 3 camera 序列训练，用另一相机 held-out views 测试；N3DV 按 MoDGS protocol 使用 cam0 训练、cam5 和 cam6 测试。指标为 PSNR、SSIM、LPIPS。

Hyper-NeRF 平均结果中，Ours 为 PSNR 25.78、SSIM 0.723、LPIPS 0.242，高于 Grid4D 的 25.46 / 0.715 / 0.261、MoSca 的 25.25 / 0.697 / 0.257、4DGS 的 25.05 / 0.681 / 0.346。把 MANI 加到 SC-GS 上，SC-GS 从 21.20 / 0.576 / 0.312 提升到 22.66 / 0.611 / 0.296，说明 node initialization 本身可迁移。

N3DV 单目结果中，Ours 平均 PSNR 23.31、SSIM 0.821，高于 MoDGS 的 22.63 / 0.804、Grid4D 的 22.51 / 0.805、4DGS 的 22.10 / 0.785。Appendix 的 N3DV 多视角表中，Ours 也达到 32.38 / 0.970。

消融表显示 baseline 为 22.35 / 0.613 / 0.335，加入 MANI 到 23.89 / 0.635 / 0.315，加入 spline motion stage 到 24.51 / 0.658 / 0.278，完整模型为 25.78 / 0.722 / 0.242。Node initialization 对比中，MANI 为 25.78 / 0.722 / 0.242，高于 FPS 24.49 / 0.678 / 0.280、Voxel 24.06 / 0.652 / 0.271、Tracklet 24.83 / 0.681 / 0.253。Node trajectory 对比中，MS 为 25.78 / 0.722 / 0.242，高于 MLP 23.95 / 0.633 / 0.317、Grid 24.28 / 0.649 / 0.271、Tracklet 24.59 / 0.671 / 0.263。

效率上，Hyper-NeRF 平均训练 39 分钟，渲染 69.5 FPS。与 4DGS 的 25.2 PSNR、30 分钟、34 FPS、61 MB 相比，Ours 为 25.8 PSNR、39 分钟、70 FPS、25 MB。Appendix 的 NVIDIA 表中，Ours 平均 PSNR 25.79，高于 MoSca 25.39、HiMoR 22.93、4DGS 22.87。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称的贡献是 motion-adaptive node initialization、spline-based node trajectory parameterization 和完整优化框架。实际技术增量集中在 sparse control 点的分配策略：不再让 FPS/voxelization 主导控制点布局，而是用 VFM token consistency 与 foreground prior 推断 motion tendency，使控制点预算更偏向动态区域。

第二个增量是把 node trajectory 从 MLP/grid/tracklet-cluster 形式换成 Hermite spline。这个改动本身并不新，但放在 sparse control dynamic 3DGS 中，可以减少逐帧自由度并提高优化稳定性。整体看，方法是一个较强的系统整合：VFM priors 用于 initialization 与 supervision，spline 用于 temporal basis，DQB 用于 node-to-Gaussian motion propagation。

## 9. Limitations / Assumptions

方法假设 VFM tokens 的跨帧 similarity 能可靠反映静态/动态差异。如果视频中存在强光照变化、重复纹理、透明反射物体或 token drift，MANI 的合并策略可能误判。

方法依赖外部 depth、mask 和 tracklets。虽然 appendix 表明去掉某个 VFM prior 后仍能稳定，但完整效果仍来自多个外部模型共同支撑；失败模式会随着这些 priors 的错误传播到 node initialization 和 training loss。

MANI 的动态倾向、compression bounds 和 spline keyframe interval 有超参数。论文报告它们较稳定，但它们仍可能随视频长度、分辨率、运动幅度和场景尺度变化。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | 单目动态视频；VFM tokens、depth、mask、2D tracklets |
| Output | Spline-controlled dynamic 3DGS |
| Core representation | Sparse nodes with $SE(3)$ trajectory and RBF radius |
| Node initialization | Patch-token-node generation + motion-adaptive compression |
| Motion model | Cubic Hermite spline node trajectories + DQB Gaussian deformation |
| Main supervision | RGB、mask、depth、tracking、ARAP |
| Main gain | 控制点密度匹配 motion complexity，减少静态冗余、补足动态区域 |
| Main risk | 依赖 VFM prior 质量和 token similarity 的动态判别能力 |

## 11. Reusable Components

- Patch-token-node correspondence：把 2D VFM token 直接附着到 3D control node。
- Dynamic tendency score：用 foreground prior 和 token similarity 控制 node compression ratio。
- Iterative voxelization compression：从细到粗逐步合并 nodes，适合控制点预算压缩。
- Cubic Hermite node trajectory：替代 MLP deformation 的低维、平滑时间参数化。
- VFM-supervised losses：RGB 之外加入 mask、depth、tracking 和 ARAP 来稳定单目动态重建。

## 12. Gap / Idea Seeds

- MANI 目前把 token similarity 作为 motion cue，可以进一步引入 uncertainty，让低置信 token 或遮挡区域降低合并决策权重。
- Dynamic tendency 只影响 node density，未来可以同时调节 RBF radius、KNN 规模或 per-node learning rate。
- Spline trajectory 默认 keyframe interval 固定，可研究基于 motion acceleration 的 adaptive knot placement。
- VFM priors 用于初始化和 loss，但没有端到端更新；可以探索轻量 adapter，让 token motion cue 与 3D reconstruction residual 互相校准。

## 13. Human Check List

- NEED_HUMAN_CHECK: PDF 文件名中标题断行为 `MO- TION` 和 `SPLAT-`，本笔记按论文首页完整标题归一化。
- NEED_HUMAN_CHECK: 项目页 / 代码链接在 Zotero metadata 和全文开头未明确出现，本笔记未填写 URL。
- NEED_HUMAN_CHECK: Appendix 中部分超参数表编号存在 `Table ??` 文本，说明 camera-ready PDF 可能仍有引用格式问题。

## 14. Evidence Anchors

- Section 4.2: node representation、RBF binding、DQB deformation。
- Section 4.3: patch-to-node generation、similarity score、dynamic tendency score、adaptive compression ratio。
- Section 4.4: cubic Hermite spline trajectory 与 2D tracklet-based initialization。
- Section 4.5 and Appendix A.2: composite loss、loss weights、ARAP formulation。
- Tables 1-3: Hyper-NeRF、N3DV 和核心消融。
- Tables 11-14: training time、FPS、storage、additional N3DV / NVIDIA results。
