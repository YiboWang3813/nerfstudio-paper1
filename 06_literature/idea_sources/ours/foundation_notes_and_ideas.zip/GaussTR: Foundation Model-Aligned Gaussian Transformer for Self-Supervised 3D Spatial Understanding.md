# GaussTR: Foundation Model-Aligned Gaussian Transformer for Self-Supervised 3D Spatial Understanding

## 0. Metadata

* Title: GaussTR: Foundation Model-Aligned Gaussian Transformer for Self-Supervised 3D Spatial Understanding
* Authors: Haoyi Jiang; Liu Liu; Tianheng Cheng; Xinjie Wang; Tianwei Lin; Zhizhong Su; Wenyu Liu; Xinggang Wang
* Year: 2025
* Venue: CVPR
* PDF source: `/Users/wangyibo/Zotero/storage/ZD6Q6ZLX/Jiang 等 - GaussTR Foundation Model-Aligned Gaussian Transformer for Self-Supervised 3D Spatial Understanding.pdf`
* Zotero item key: `N4SILIXL`
* Zotero PDF attachment key: `ZD6Q6ZLX`
* Code: `https://github.com/hustvl/GaussTR`
* Project page: Not specified
* Dataset link: Occ3D-nuScenes
* Main task: self-supervised 3D semantic occupancy prediction / open-vocabulary occupancy prediction
* Domain: autonomous driving, embodied spatial understanding
* Input: 6-camera multi-view images, camera parameters, VFM features, metric depth estimates
* Output: sparse Gaussian scene representation and voxelized open-vocabulary occupancy predictions
* Main representation: feed-forward predicted sparse 3D Gaussians with feature vectors
* Supervision type: self-supervised VFM feature alignment, depth alignment, optional Grounded SAM segmentation pseudo-labels
* Core contribution in one sentence: 用 Transformer 直接预测稀疏 3D Gaussian，并通过 differentiable splatting 把 3D 表示渲染回 2D VFM feature/depth 空间，从而做无需 3D 标注的开放词表 occupancy 预测。
* Note status: `complete`

## 1. 一句话技术摘要

This paper addresses self-supervised 3D semantic occupancy prediction by using feed-forward Transformer-predicted sparse Gaussian scene representations to transform multi-view images into open-vocabulary occupancy logits, with the key technical novelty being VFM-aligned Gaussian splatting supervision that bridges 2D foundation model features and 3D spatial representations.

## 2. 问题形式化

论文要解决的是在缺少 voxel-wise 3D 标注时，从多视角车载图像学习 3D occupancy 和语义。传统监督 occupancy 方法依赖昂贵 3D 标签；已有自监督方法多使用 dense voxel 或 radiance field，训练开销大，并且通常依赖预计算 2D pseudo-label。

GaussTR 把场景表示为一组稀疏高斯 $G = \{\mu_{3D}, S, R, \alpha, f_G\}$。训练时，高斯被 splat 到输入视角，渲染出 feature map $\hat{F}$ 和 depth map $\hat{D}$，分别对齐 foundation model 特征 $F$ 和深度 $D$。推理时，高斯特征 $f_G$ 与文本类别 embedding $f_T$ 做相似度，得到类别 logits 并 voxelize 成 occupancy volume。

## 3. 方法概览

整体结构见 Fig. 2。流程分三步：

1. 从多视角图像中用 CLIP/FeatUp/Talk2DINO 提取 VFM feature maps，用 Metric3D V2 提取 depth maps。
2. 初始化 learnable Gaussian queries $q_G$ 和 2D positions $\mu_{2D}$，通过 deformable cross-attention 聚合多尺度 2D 特征，再通过 self-attention 在高斯查询之间做全局 3D 关系建模。
3. Gaussian head 预测 $\Delta \mu_{3D}$、$\Delta R$、$\Delta S$、$\alpha$ 和 $f_G$；训练时用 feature/depth/segmentation rendering losses，推理时用 CLIP text embedding 做开放词表分类。

方法本质上不是为单个场景优化 3DGS，而是学习一个 feed-forward 3D scene representation predictor。

## 4. 方法细节

### 4.1 Gaussian 初始化与 Transformer 解码

3D 位置由 2D query 位置和预测深度反投影得到：

$$
\mu_{3D} = E^{-1}K^{-1}(d_G \cdot \mu_{2D})
$$

其中 $d_G$ 从 depth map $D$ 在 $\mu_{2D}$ 处采样。初始 scale $S_0$ 与 $d_G$ 成比例，初始 rotation $R_0$ 由相机外参决定，使高斯朝向相机视角。

每层 GaussTR 使用 deformable attention 从多视角 feature maps 聚合局部信息：

$$
q_G = \mathrm{DeformAttn}(q_G, \mu_{2D}, F)
$$

随后在高斯查询之间加入 3D positional encoding 做 self-attention：

$$
q_G = \mathrm{Attn}(q_G + \mathrm{PE}(\mu_{3D}), q_G + \mathrm{PE}(\mu_{3D}), q_G)
$$

Gaussian head 用 MLP 输出 $\{\Delta \mu_{3D}, \Delta R, \Delta S, \alpha, f_G\}$，并逐层 refine $\mu_{3D}$、$R$、$S$。

### 4.2 VFM-aligned 自监督学习

为了降低 feature splatting 维度，论文对 VFM feature $F$ 做 PCA，得到主成分 $V_k$，再把 $F$ 和高斯特征 $f_G$ 投影到低维空间：

$$
F' = F V_k^\mathsf{T}, \quad f'_G = f_G V_k^\mathsf{T}
$$

渲染 feature map 使用标准 alpha blending，只是把颜色换成 feature：

$$
\hat{F} = \sum_{i=1}^{N} f'_i \alpha_i \prod_{j=1}^{i-1}(1-\alpha_j)
$$

feature loss 为 cosine loss：$\mathcal{L}_{feat} = 1 - \mathrm{cos}(F', \hat{F})$。depth loss 由 SILog 和 L1 组成：$\mathcal{L}_{depth} = \mathcal{L}_{SILog}(D,\hat{D}) + \beta \mathcal{L}_{L1}(D,\hat{D})$，其中 $\beta = 0.2$。可选 segmentation loss 用 Grounded SAM 2 生成分割监督，由 auxiliary segmentation head 从 $\hat{F}$ 预测 $\hat{S}$，使用 cross entropy。

总损失为 $\mathcal{L} = \mathcal{L}_{feat} + \mathcal{L}_{depth} + \mathcal{L}_{seg}$，其中 $\mathcal{L}_{seg}$ 可选。

### 4.3 开放词表 occupancy 推理

推理阶段不使用 segmentation head。文本类别例如 “car”、“road”、“vegetation” 通过 text encoder 得到 $f_T$，每个高斯的类别 logits 为：

$$
l_G = \mathrm{Softmax}(f_G \cdot f_T^\mathsf{T})
$$

最后将带语义 logits 的高斯 voxelize 成 3D occupancy volume。这个设计让训练类别和推理类别可以解耦，是开放词表能力的来源。

## 5. 数学目标和损失

核心损失包括：

* feature alignment: $\mathcal{L}_{feat} = 1 - \mathrm{cos}(F', \hat{F})$；
* depth alignment: $\mathcal{L}_{depth} = \mathcal{L}_{SILog} + \beta \mathcal{L}_{L1}$；
* optional segmentation: $\mathcal{L}_{seg} = \mathcal{L}_{CE}(S,\hat{S})$。

注意论文的符号有冲突：$S$ 既可表示 scale，也可表示 segmentation map。实现复现时建议在代码和笔记中把 scale 写为 `scale` 或 $s$，把 segmentation 写为 $S_{seg}$。

## 6. 训练和推理流程

训练流程：

1. 输入 6-camera 图像，提取 VFM feature、Metric3D depth 和可选 Grounded SAM segmentation。
2. 初始化每个视角 300 个 Gaussian queries，总计 1800 个高斯表示一个场景。
3. 经过 3 层 GaussTR layer 预测高斯属性。
4. 把高斯 splat 回输入视角，计算 feature/depth/segmentation losses。
5. 训练 20 epochs，batch size 8，learning rate $2 \times 10^{-4}$，8 张 A800 上约 12 小时。

推理流程：

1. 从图像 feed-forward 预测 sparse Gaussians。
2. 对任意文本类别生成 text embeddings。
3. 高斯 feature 与文本 embedding 做 similarity。
4. voxelize 得到 3D semantic occupancy。

## 7. 实验设置与结果摘要

数据集为 Occ3D-nuScenes，约 1000 个 driving scenes 和 40,000 frames，6-camera 输入，目标空间为 $80m \times 80m \times 6.4m$，voxel resolution 为 $0.4m$，18 类语义。

主结果见 Table 1 和 Fig. 1。GaussTR(Talk2DINO) 达到 12.27 mIoU，相比 GaussianOcc 的 9.94 mIoU 提升 2.33 mIoU，并减少约 40% 训练时间。FeatUp 版本达到 11.70 mIoU。

消融结论：

* Table 2: 只有 feature alignment 不收敛；Metric3D depth alignment 是几何收敛的关键。
* Table 3: FeatUp 提升 MaskCLIP 的空间细粒度；Talk2DINO 不加 auxiliary segmentation 时最好。
* Table 4: query 数增加通常有帮助，但 FeatUp 在 300 queries 后可能因 attention dilution 下降；Talk2DINO 可继续受益于 400 queries。

## 8. 声称贡献 vs 实际技术增量

论文声称贡献是 sparse Gaussian scene representation、foundation model alignment、自监督开放词表 occupancy。实际技术增量主要是把 3DGS 的 rendering target 从 RGB 改成 VFM feature/depth，并用 Transformer feed-forward 预测高斯集合。

真正有用的部分是 “splat-to-feature-space” 的训练接口：它允许 2D foundation model 的知识通过 differentiable rendering 进入 3D occupancy。相对弱的部分是组件拼接较多，依赖外部 Metric3D、CLIP/FeatUp/Talk2DINO、Grounded SAM，系统收益中哪些来自高斯、哪些来自 foundation models，需要谨慎拆分。

## 9. 局限性和隐藏假设

* 依赖强 VFM/depth model，若 foundation model 对目标域失效，3D 表示会被错误监督牵引。
* sparse Gaussian 对小物体和大平面不友好，论文也指出 traffic cone、road、sidewalk 等类别较弱。
* 训练需要多外部模型预处理，复现复杂度不低。
* feature alignment 单独不收敛，说明几何先验仍是必要条件。
* 只在 Occ3D-nuScenes 上验证，跨数据集泛化能力仍需 human check。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 任务 | self-supervised 3D semantic occupancy, open-vocabulary occupancy |
| 输入 | 多视角车载图像 + 相机 + VFM features + depth |
| 输出 | sparse Gaussians + voxelized semantic occupancy |
| 表示 | feed-forward predicted 3D Gaussians |
| 关键模块 | deformable cross-attention, Gaussian self-attention, feature splatting, text-Gaussian similarity |
| 关键损失 | feature cosine, SILog+L1 depth, optional CE segmentation |
| 主要优点 | 不需要 3D semantic labels，训练快于 dense voxel/radiance-field 方法 |
| 主要风险 | 依赖 VFM/depth/SAM，稀疏高斯对小物体和平面较弱 |

## 11. 可复用组件

* 把 Gaussian rendering target 从 RGB 替换为任意 dense feature map。
* PCA 压缩高维 VFM feature 后进行 feature splatting。
* 通过 Gaussian feature 与 text embedding 相似度实现开放词表 3D 分类。
* 用 depth alignment 作为 feature-space 3D learning 的收敛支架。

## 12. Gap 和 idea seeds

* 可以研究 uncertainty-aware query allocation：小物体和平面区域自适应增加 Gaussian queries。
* 可以把 GaussTR 的 VFM alignment 和 Dynamic 4DGS 的 motion node 结合，做开放词表动态 occupancy。
* 可以用 DINO/SAM 边界一致性直接 regularize 高斯 scale/opacity，减少 segmentation head 依赖。
* 可以做跨 foundation model 的 teacher ensemble，但最终蒸馏成单一轻量 Gaussian feature field。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: 检查 supplementary 是否有更详细的 architecture hyperparameters。
* `NEED_HUMAN_CHECK`: 确认代码发布状态和具体 checkpoint 配置。
* `NEED_HUMAN_CHECK`: Table 4 中 400 queries 的 Talk2DINO 是否作为最终配置，主文实现细节需对代码确认。

## 14. Evidence Anchors

* Abstract: sparse Gaussians, VFM alignment, 12.27 mIoU, 40% training-time reduction。
* Fig. 1: 与 SelfOcc、OccNeRF、DistillNeRF、GaussianOcc 的性能/训练时间比较。
* Fig. 2: GaussTR architecture。
* Sec. 3.1: feedforward Gaussian splatting, Eq. (1)-(6)。
* Sec. 3.2: VFM-aligned self-supervised learning, Eq. (11)-(17)。
* Sec. 3.3: open-vocabulary occupancy prediction, Eq. (18)。
* Sec. 4.1-4.4: Occ3D-nuScenes 设置、实现细节、主结果、消融。
