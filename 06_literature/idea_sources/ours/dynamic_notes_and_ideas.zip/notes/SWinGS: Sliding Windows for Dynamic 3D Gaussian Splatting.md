# SWinGS: Sliding Windows for Dynamic 3D Gaussian Splatting

## 0. Metadata

* Title: SWinGS: Sliding Windows for Dynamic 3D Gaussian Splatting
* Authors: Richard Shaw; Michal Nazarczuk; Jifei Song; Arthur Moreau; Sibi Catley-Chandar; Helisa Dhamo; Eduardo Pérez-Pellitero
* Year: 2024
* Venue: ECCV 2024 / LNCS 15113
* Publisher: Springer Nature Switzerland
* DOI: 10.1007/978-3-031-73001-6_3
* URL: https://link.springer.com/10.1007/978-3-031-73001-6_3
* PDF source: `/Users/wangyibo/Zotero/storage/BQVBU78U/Shaw 等 - 2025 - SWinGS Sliding Windows for Dynamic 3D Gaussian Splatting.pdf`
* Local note path: `notes/SWinGS: Sliding Windows for Dynamic 3D Gaussian Splatting.md`
* Zotero item key: `R86HQRBD`
* Zotero PDF attachment key: `BQVBU78U`
* Duplicate PDF attachment key: `G9VMCTX9`
* Code: Not specified in extracted PDF text
* Project page: Not specified
* Dataset link: Not specified
* Main task: dynamic novel-view synthesis from synchronized multi-view videos
* Domain: dynamic 3D Gaussian Splatting; sliding-window canonical spaces; temporal consistency
* Input: calibrated synchronized multi-view dynamic sequence
* Output: per-frame Gaussian renderings from window-local dynamic 3DGS models; dynamic interactive viewer
* Main representation: per-window canonical 3D Gaussians plus tuneable dynamic MLP deformation fields
* Supervision type: photometric reconstruction with self-supervised inter-window consistency fine-tuning
* Core contribution in one sentence: 用 optical-flow adaptive sliding windows 把长动态序列切成局部 canonical spaces，每个窗口训练独立 dynamic 3DGS，并用 per-Gaussian tunable MLP blending 参数分离静态/动态 motion modes，最后在重叠帧上做自监督 temporal consistency fine-tuning。
* Note status: `complete`

## 1. 一句话技术摘要

这篇论文处理一般动态场景的新视角合成，通过把长序列切成带重叠帧的 adaptive sliding windows，并在每个窗口内训练局部 canonical 3DGS + dynamic MLP deformation field；关键技术差异是允许 canonical representation 随窗口变化，以降低长序列/大运动的形变难度，并用 overlap consistency loss 抑制跨窗口闪烁。

## 2. 问题形式化

### 2.1 任务

给定多机位同步动态视频和相机位姿，重建一个可以实时交互渲染的动态 3D 表示。目标不仅是单帧 novel view quality，还包括长序列中时间一致性和复杂拓扑变化下的稳定性。

### 2.2 长序列难点

单个 canonical representation 覆盖全序列时，形变场必须解释所有时间的运动和拓扑变化，长序列会出现：

* deformation magnitude 过大；
* canonical capacity 不足；
* render 变糊；
* temporal flickering；
* 训练和显存不易扩展。

SWinGS 的核心思路是用多个 temporally-local canonical spaces 分摊复杂度。

### 2.3 表示拆分

每个 window 有一个独立 dynamic 3DGS model：

* canonical 3D Gaussians: 当前窗口局部共享；
* dynamic MLP: 从 canonical Gaussians 和 normalized time 映射到每帧变形；
* tunable blending $\alpha$: per-Gaussian 学习静态/动态 motion mode；
* overlap frame: 相邻窗口共享一帧，用于 temporal consistency fine-tuning。

## 3. 方法概览

SWinGS 有三步。

第一步，Sliding-window processing。用 optical flow magnitude 估计每段视频运动量，贪心选择不同长度的 windows。高运动区域用短 windows，低运动区域用长 windows。相邻 windows 重叠一帧。

第二步，Dynamic 3DGS per window。每个 window 训练独立 canonical 3D Gaussians 和 temporally-local dynamic MLP。MLP 输入 Gaussian position 和时间，输出 $\Delta x,\Delta r,\Delta s$。

第三步，Temporal consistency fine-tuning。所有 windows 独立训练后，按顺序 fine-tune 当前 window，使它在 overlap frame 的 novel-view render 与前一个 window 一致。fine-tuning 时冻结 dynamic MLP，只更新 canonical static representation，并交替使用 consistency loss 和正常重建训练。

## 4. 方法细节

### 4.1 3DGS 基础

SWinGS 建立在 3DGS 上。3D Gaussian 由 covariance $\Sigma$ 和 mean $\mu$ 定义。Eq. 1 写作 $G(x)=e^{-\frac{1}{2}(x)^T\Sigma^{-1}(x)}$，这里省略了标准形式中的 $(x-\mu)$，应按 3DGS 语境理解为以 $\mu$ 为中心的 Gaussian。

Covariance 分解为 $\Sigma=RSS^TR^T$。优化变量包括 Gaussian positions $x$、scaling $S$、rotation $R$、opacity $o$ 和 SH colors。

渲染损失 Eq. 2: $L=(1-\lambda)L_1(I_r,I_{gt})+\lambda L_{SSIM}(I_r,I_{gt})$。

### 4.2 Sliding-window processing

SWinGS 不用单个模型拟合全序列，而是切分为多个重叠 windows。每个 window 是独立 dynamic 3DGS model，允许以下全部参数跨窗口变化：

* Gaussian 数量；
* positions；
* rotations；
* scales；
* colors；
* opacities；
* deformation MLP。

优势是各窗口可并行训练，且局部 canonical space 只需解释较短时间内的运动。

### 4.3 Adaptive window sampling

窗口大小由 motion amount 决定。论文使用预训练 RAFT 估计每个 camera view $j\in V$ 和相邻帧 $i,i+1$ 的 2D optical flow。

Eq. 3 的意图是对所有视角计算 per-frame mean flow magnitude $\hat{v}_i$。提取文本中的求和上下标排版有错位，但可理解为对 views 求平均，对 optical flow magnitude $\|f(I_i^j,I_{i+1}^j)\|_2^2$ 求统计。

贪心算法遍历时间帧，累计 $\hat{v}_i$；当累计 flow 超过预设 threshold，就生成一个新 window。这样每个 window 包含相近总运动量。每个 window 与下一个 window 重叠一帧，用于后续 consistency。

阈值具体值未在主文抽取文本中给出，标为 `NEED_HUMAN_CHECK`。

### 4.4 Dynamic 3D Gaussians

每个 window 有一个动态 MLP $F_\theta$，输入 normalized frame time $t\in[0,1]$ 和 Gaussian means $x$，输出 position、rotation、scale displacement。Eq. 4: $\Delta x(t),\Delta r(t),\Delta s(t)=F_\theta(\gamma(x),\gamma(t))$。

输入 $x$ 会按 scene mean 和 standard deviation 归一化，再做 sinusoidal positional encoding。位置编码形式为 $\gamma(x)=(x,\ldots,\sin(2^k\pi x),\cos(2^k\pi x),\ldots)$。

MLP 很小：

* frequency components $m=6$；
* depth $D=4$；
* width $W=16$；
* two skip connections。

小 MLP 旨在减少 overfitting，并让每个 window 的局部形变场轻量。

### 4.5 Tunable Dynamic MLPs

普通 time-dependent MLP 在静态区域占多数、动态区域较少的 imbalanced scenes 中，容易学不好动态 deformation。SWinGS 引入 tunable MLP：MLP 有 $M$ 套 weights，由每个 Gaussian 的 learnable blending parameters $\alpha$ 加权。

当 $M=2$ 时，MLP 可以学习两个 motion modes，直观对应 static 和 dynamic。对第 $i$ 个 Gaussian 的某一层输出，Eq. 5 写作 $y_i=\phi(\sum_{m=1}^{M}(\alpha_{i,m}w_m^T x_i+\alpha_{i,m}b_m))$。

因此 dynamic MLP 变为 Eq. 6: $\Delta x(t),\Delta r(t),\Delta s(t)=F_\theta^{dyn}(\gamma(x),\gamma(t),\alpha)$。

实现上，$\alpha$ 用 single batch matrix multiplication 实现加权，不需要分别跑多个 MLP，因此额外推理成本很小。

### 4.6 $\alpha$ 初始化

对一个 sliding window，SWinGS 将所有 3D Gaussians 投影到每个 camera view，得到 2D coordinates $u=\Pi_j(x)$。然后计算从 central frame 到 window 内其他 frames 的 $L_1$ pixel difference。如果差异大于阈值，标为 dynamic，否则 static。

为了对 occlusion 和 mislabeling 鲁棒，label 会在所有 views 和 frames 上平均；平均值大于 0.5 则初始化为 dynamic，否则 static。初始化后，$\alpha$ 作为 learnable parameter 与系统一起优化。

论文假设 $\alpha$ 在一个 sliding window 内对所有 frames 恒定；由于 adaptive window sampling 限制了每个窗口运动量，这个假设相对合理。

### 4.7 Temporal consistency fine-tuning

独立训练每个 window 会造成跨窗口 flickering，尤其在 novel views 中明显。SWinGS 在所有 windows 训练完成后进行 sequential fine-tuning。

fine-tuning 以第一个 window 开始顺序推进。对当前 window $w$ 的第一帧和前一 window $w-1$ 的最后一帧，即共享 overlap frame，从随机 novel viewpoint 渲染两张图：$I^w_{t=0}$ 与 $I^{w-1}_{t=N_w-1}$。

Eq. 8: $L_{consistency}=|I^w_{t=0}-I^{w-1}_{t=N_w-1}|_1$。

随机 novel viewpoint 由训练 cameras 的 pose 插值得到。提取文本显示使用 matrix exponential / logarithm 组合 camera poses，公式编号 Eq. 7；具体是对 sampled training poses $P_j$ 使用 $\exp_M(\sum_j\beta_j\log_M(P_j))$，其中 $\beta_j\in[0,1]$ 且 $\sum_j\beta_j=1$。

fine-tuning 时冻结 time-dependent dynamic MLP，只允许 canonical static representation 变化。为避免只优化 overlap frame 损害窗口内其他 frames，训练交替进行：

* 75% step 用 temporal consistency on overlap frame；
* 25% step 用 normal training views and frames。

### 4.8 训练实现

实现基于 PyTorch 和 3DGS differentiable rasterizer。每个 window model 用 COLMAP point cloud 初始化。

训练设置：

* 每个 sampled window 训练 15K iterations；
* 前 2K iterations 是 warm-up，只训练 central window frame，并冻结 MLP；
* warm-up 后解冻 MLP 和 $\alpha$；
* Gaussians densify 8K iterations，之后 Gaussian 数量固定；
* MLP 输入在 warm-up 后用 canonical point cloud mean/std normalization；
* Adam optimizer；
* 3DGS 参数学习率沿用 3DGS implementation；
* MLP 和 $\alpha$ learning rate 为 $1e-4$；
* MLP LR 在 20K iterations 内指数衰减 $1e-2$；
* 初始各 window 独立训练可在 8 张 32GB Tesla V100 上并行；
* temporal fine-tuning 每个 model 顺序单 GPU 训练 3K iterations。

## 5. 数学目标与损失

### 5.1 Per-window reconstruction loss

每个 window 的主损失是 3DGS reconstruction loss：$L=(1-\lambda)L_1+\lambda L_{SSIM}$。这优化 canonical Gaussian attributes、deformation MLP 和 $\alpha$。

### 5.2 Dynamic deformation function

形变目标不是独立监督的 scene flow，而是通过 photometric rendering loss 学到。MLP 输出 $\Delta x,\Delta r,\Delta s$，用来把 window-local canonical Gaussians 映射到每帧 Gaussians。

### 5.3 Tunable MLP mode mixing

$\alpha$ 的目标是让 MLP weights 根据 Gaussian 动静态属性软切换。它不是外部 mask，而是可学习参数。初始化只提供 static/dynamic prior，后续由 photometric loss 更新。

### 5.4 Temporal consistency loss

Consistency loss 是 overlap frame 上两个相邻 window models 的 render L1 difference。它不需要 GT novel view，属于 self-supervised loss。

关键限制：只约束 overlapping frame，不直接约束所有边界附近 frames；但由于 canonical representation 在整个 window 共享，更新会影响窗口内部。

## 6. 训练与推理流程

### 6.1 训练流程

1. 对完整序列计算 RAFT optical flow。
2. 用 greedy adaptive sampling 生成 overlapping sliding windows。
3. 对每个 window 并行训练 dynamic 3DGS：
   * COLMAP point cloud 初始化；
   * 2K warm-up；
   * 15K total training；
   * 8K densification；
   * 学习 MLP 和 $\alpha$。
4. 所有 windows 独立训练完后，按时间顺序 fine-tune。
5. 对每个 window，在 overlap frame 上从随机 novel views 渲染当前/前一 window，施加 $L_{consistency}$。
6. fine-tune 3K iterations，75% consistency，25% normal reconstruction。

### 6.2 推理流程

推理时每个 frame 由其所属 window model 渲染：

1. 取当前 frame 的 normalized time；
2. 对该 window canonical Gaussians 查询 dynamic MLP；
3. 得到 per-frame deformed Gaussians；
4. 用 3DGS rasterizer 实时渲染。

### 6.3 存储与并行

每个 window 是独立模型，因此存储随 window 数增加。Adaptive sampling 通过更少但合适的 windows 平衡质量、训练时间和模型数量。训练时 windows 之间独立，可多 GPU 并行；fine-tuning 因顺序依赖而串行。

## 7. 实验设置与结果

### 7.1 数据集

Neural 3D Video:

* 多视角动态真实场景；
* 原始分辨率 $2028\times2704$；
* 30 FPS；
* 评估 central test view；
* 300 frames；
* half resolution $1014\times1352$。

Technicolor:

* synchronized $4\times4$ camera array；
* full resolution $2048\times1088$；
* 评估 second row second column camera；
* 五个 scenes: Birthday, Fabien, Painter, Theater, Trains。

### 7.2 Neural 3D Video 主结果

Table 1 平均结果：

* MixVoxels: PSNR 30.42，SSIM 0.923，LPIPS 0.124，FPS 4.30；
* K-Planes: 30.63，0.922，0.117，0.33；
* HyperReel: 30.78，0.931，0.101，3.60；
* 4DGS: 27.61，0.916，0.135，30.00；
* Ours: 31.10，0.940，0.096，71.51。

SWinGS 平均 PSNR、SSIM、LPIPS 最好，并保持实时 FPS。

### 7.3 Technicolor 主结果

Table 2 平均结果：

* DyNeRF: PSNR 31.80，SSIM 0.911，LPIPS 0.142，FPS 0.02；
* HyperReel: 32.50，0.902，0.113，0.45；
* Dynamic3DG: 27.02，0.832，0.228，86.96；
* Ours: 33.65，0.934，0.117，23.79。

SWinGS 在 PSNR 和 SSIM 上最好，LPIPS 略弱于 HyperReel，但速度显著更快。

### 7.4 Temporal consistency 消融

Table 5 显示 temporal consistency fine-tuning：

* w/o temporal consistency: PSNR 32.01，SSIM 0.956，LPIPS 0.085，t-LPIPS 0.0129，VQA 0.666；
* w/ temporal consistency: PSNR 32.05，SSIM 0.949，LPIPS 0.093，t-LPIPS 0.0102，VQA 0.726；
* ground truth VQA: 0.763。

结论：per-frame SSIM/LPIPS 略降，但 temporal consistency 和 video perceptual quality 明显提高。

### 7.5 Window size / adaptive sampling 消融

Table 6 在 Technicolor Birthday 上比较 fixed window size：

* window 3: 24 windows，16 GPU hours，PSNR 33.12；
* window 9: 6 windows，4 GPU hours，PSNR 33.38；
* window 49: 1 window，0.7 GPU hours，PSNR 32.73；
* adaptive: 5 windows，3.3 GPU hours，PSNR 33.44，SSIM 0.959，LPIPS 0.042，t-LPIPS 0.0051；
* adaptive w/o dynamic MLP: PSNR 32.76，LPIPS 0.045，t-LPIPS 0.0062。

Adaptive sampling 匹配或超过最佳 fixed size，同时减少 window 数。Dynamic MLP / tunable $\alpha$ 明显提升质量。

## 8. 声称贡献 vs 实际技术增量

### 8.1 论文声称

SWinGS 声称贡献：

* adaptive sliding windows 支持任意长度序列；
* temporally-local dynamic MLPs 建模 window-local deformation；
* learnable MLP tuning parameters 分离 static/dynamic regions；
* fine-tuning 保证跨 window temporal consistency。

### 8.2 实际技术增量

实际增量是把“一个全局 canonical dynamic GS”改成“多个局部 canonical dynamic GS”。每个 window 的 canonical representation 和 deformation field 都能变化，因此降低大运动和拓扑变化难度。

Tunable MLP 是第二个关键增量：它不是在输入上加 mask，而是在 MLP weight level 给每个 Gaussian 做 motion-mode mixing，适合静态背景占多数的 imbalanced scenes。

### 8.3 证据强度

证据强的部分：

* 两个真实多视角数据集；
* N3DV / Technicolor 都给主表和 per-scene 表；
* temporal consistency、window size、adaptive sampling、dynamic MLP 都有消融；
* FPS 明确报告；
* 可视化展示 window consistency 和复杂 motion。

证据较弱的部分：

* 训练成本以 GPU hours 表示，但完整 per-sequence 存储和模型数量没有像 streaming 方法那样重点量化；
* adaptive threshold 未在抽取文本中明确；
* 每个 window 独立模型，长序列 storage 随 window 数增长；
* fine-tuning 串行，可能成为很长序列的瓶颈。

## 9. 局限与隐藏假设

论文没有单独 limitations section，但可归纳：

* 需要多视角同步视频和 COLMAP point cloud，不是 monocular casual video 方法。
* Sliding windows 牺牲全局一致 canonical identity，跨窗口同一 object / Gaussian identity 不连续。
* 每个 window 单独训练，长序列可能有较多模型存储。
* Temporal consistency 只在重叠帧上通过 render-level L1 约束，不能保证 3D geometry 或 motion field 一致。
* Adaptive window 依赖 RAFT optical flow；光流错误可能导致窗口划分不合理。
* Tuneable $\alpha$ 假设一个 window 内 Gaussian 动静态属性相对恒定。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法名称 | SWinGS |
| 输入类型 | calibrated synchronized multi-view video |
| 核心策略 | adaptive overlapping sliding windows |
| 每窗口表示 | canonical 3DGS + dynamic MLP |
| 形变输出 | $\Delta x,\Delta r,\Delta s$ |
| 动静态处理 | per-Gaussian tunable MLP blending $\alpha$ |
| Window 采样 | RAFT optical flow + greedy threshold |
| Consistency | overlap frame self-supervised render L1 |
| Fine-tuning | 3K iterations; freeze dynamic MLP; 75% consistency / 25% normal |
| MLP | $m=6$, depth 4, width 16, two skip connections |
| Training | 15K per window; 2K warm-up; densify 8K |
| 数据集 | Neural 3D Video; Technicolor |
| 主优势 | 长序列/大运动下质量高，实时渲染，窗口并行训练 |
| 主短板 | 多模型存储，跨窗口 identity 不连续，依赖 optical flow 划窗 |

## 11. 对我的研究可复用组件

1. Local canonical windows：动态 GS 矩阵中可作为“temporal segmentation / local canonical space”类别。
2. Optical-flow adaptive windowing：用 2D motion budget 控制 4D representation 的时间跨度。
3. Tunable MLP weights：per-Gaussian $\alpha$ 在 weight level 混合多个 motion modes，比简单输入 mask 更柔性。
4. Overlap-frame consistency：用 self-supervised novel-view render consistency 对齐相邻局部模型。
5. Static/dynamic imbalance handling：SWinGS 的 $\alpha$ 可和 SC-GS control points、DeGauss foreground/background 对比。

## 12. Gap and Idea Seeds

### 12.1 Gap: 多 window 模型存储随长度增长

SWinGS 支持 arbitrary length，但每个 window 独立模型。可以研究 window model compression、shared base canonical + local residual、或 LoRA-style dynamic MLP adapters。

### 12.2 Gap: 跨窗口 3D identity 不连续

Render consistency 不保证 Gaussian correspondence。可加入 Gaussian matching / transport loss，保持 object-level continuity。

### 12.3 Gap: Optical flow 只用 2D signal

RAFT flow 对遮挡、反光和多视角不一致敏感。可以结合 3D motion residual 或 depth-aware flow 来划窗。

### 12.4 Gap: $\alpha$ 时间恒定

一个 window 内同一 Gaussian 的 dynamic/static mode 恒定。对局部出现/消失或短暂接触，time-dependent $\alpha(t)$ 可能更准确，但会增加复杂度。

### 12.5 Gap: Fine-tuning 只约束 overlap frame

可扩展为 overlap interval、多帧 cross-window distillation 或 feature-level consistency，减少边界附近 flicker。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: adaptive window sampling 的 flow threshold 值和具体 greedy 伪代码需看 supplementary / code。
* `NEED_HUMAN_CHECK`: Eq. 3 光流公式在 PDF 抽取中上下标错位，note 中按文字解释重构。
* `NEED_HUMAN_CHECK`: $\Delta r$ 的旋转表示和 normalization 需要代码确认。
* `NEED_HUMAN_CHECK`: tuneable MLP 的 $M$ 默认是否总为 2，以及 $\alpha$ 是否归一化 / sigmoid，需要代码确认。
* `NEED_HUMAN_CHECK`: code URL 未在正文抽取文本中出现；可能在 supplementary 或项目页。
* `NEED_HUMAN_CHECK`: Springer 元数据 Year/Proceedings 为 2025，但会议是 ECCV 2024，引用时需按场景选择。

## 14. Evidence Anchors

* Abstract: sliding-window training, adaptive sampling, tuneable MLPs, temporal consistency fine-tuning。
* Figure 1: sharper dynamic reconstruction and dynamic real-time viewer。
* Section 1 Introduction: 单一 canonical representation 长序列退化；local canonical windows 的动机。
* Figure 2: pipeline: partition by optical flow, train dynamic 3DGS per window, fine-tune overlap consistency。
* Section 3.1: three-step overview and per-window independent canonical representation。
* Section 3.2 / Eq. 1-2: 3DGS preliminaries and reconstruction loss。
* Section 3.3 / Eq. 3: RAFT optical-flow adaptive window sampling。
* Section 3.4 / Eq. 4: dynamic MLP outputs $\Delta x,\Delta r,\Delta s$。
* Section 3.5 / Eq. 5-6: tunable MLP weight blending and $\alpha$ initialization。
* Figure 3: $\alpha$ highlights dynamic regions and normalized $\Delta x$ visualizations。
* Section 3.6 / Eq. 7-8: novel-view pose sampling and overlap consistency loss。
* Section 3.7: implementation details, 15K iterations, 2K warm-up, 8K densification, LR, V100 GPUs。
* Table 1: Neural 3D Video average metrics and FPS。
* Table 2: Technicolor average metrics and FPS。
* Table 5 / Figure 8: temporal consistency fine-tuning ablation。
* Table 6 / Figure 7: adaptive window size and dynamic MLP ablation。
* Section 5 Conclusion: sliding windows reduce scene flow magnitude and variability; $\alpha$ essential for imbalanced scenes。
