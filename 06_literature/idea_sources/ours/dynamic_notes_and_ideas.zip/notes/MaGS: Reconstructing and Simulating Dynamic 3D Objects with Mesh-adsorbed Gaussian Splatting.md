# MaGS: Reconstructing and Simulating Dynamic 3D Objects with Mesh-adsorbed Gaussian Splatting

## 0. Metadata

- Title: MaGS: Reconstructing and Simulating Dynamic 3D Objects with Mesh-adsorbed Gaussian Splatting
- Authors: Shaojie Ma; Yawei Luo; Wei Yang; Yi Yang
- Venue/Year: ICCV 2025
- Project page: https://wcwac.github.io/MaGS-page/
- Zotero item key: `XPNTRBFE`
- Zotero PDF attachment key: `XNUN8UF3`
- PDF path: `/Users/wangyibo/Zotero/storage/XNUN8UF3/Ma 等 - MaGS Reconstructing and Simulating Dynamic 3D Objects with Mesh-adsorbed Gaussian Splatting.pdf`
- Local note path: `notes/MaGS: Reconstructing and Simulating Dynamic 3D Objects with Mesh-adsorbed Gaussian Splatting.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

MaGS 将 3D Gaussians 约束为“吸附”在时序一致 mesh facet 附近，用 barycentric coordinates、normal offset 和 MeshId 表示 Gaussian 与 mesh 的相对关系，并通过 MPE-Net / RMD-Net / RGD-Net 学习 mesh deformation 和 Gaussian relative displacement，从而统一动态重建与 ARAP、SMPL、软体碰撞等 mesh-guided simulation。

## 2. Problem Formulation

动态 3D reconstruction 需要灵活表示外观和几何，而 simulation / editing 需要结构化、可施加物理或骨架先验的表示。纯 3DGS 渲染质量高但缺少 surface / topology / mesh priors；纯 mesh 适合 simulation 但渲染质量和重建速度弱。固定把 Gaussians anchor 到 mesh 的方法又面临 tradeoff：mesh 变形合理时渲染不够灵活，Gaussians 自由时 simulation 不够结构化。

MaGS 的目标是从单目视频重建一个既能高质量渲染、又能继承 mesh deformation priors 做 novel simulation 的动态对象表示。关键是让 Gaussians 不是固定在 mesh 顶点/面上，而是在 mesh facet 附近以可学习相对位移“roam”。

## 3. Method Overview

pipeline 先训练一个 deformation-field dynamic 3DGS，用其在 $t=0$ 的多视角 depth 通过 TSDF integration 得到初始 mesh，再用 deformation field 让 mesh 在各帧保持 facet-ID correspondence。这个 temporally consistent coarse mesh 被称为 guide mesh。

重建阶段中，MPE-Net 从 guide mesh 的 handle vertices 中提取 pose embedding；RMD-Net 根据 pose embedding 预测 relative mesh deformation，细化 guide mesh；RGD-Net 预测每个 Mesh-adsorbed Gaussian 的 barycentric coordinates 和 normal offset 的变化，使 Gaussians 在 mesh 上相对移动。最终 Gaussians 由 refined mesh 和 relative Gaussian displacement 共同确定，并通过 3DGS rasterization 与图像监督联合优化。

simulation 阶段中，用户可用 ARAP、SMPL、soft-body simulation 等方法生成新的 guide mesh deformation。MaGS 复用训练好的 MPE/RMD/RGD networks，把新 guide mesh 转成 refined mesh 和 final Gaussians，从而渲染未在输入视频中出现的 deformation。

## 4. Method Details

### 4.1 Mesh-Adsorbed Gaussian Representation

Mesh 部分是三角网格，包含 vertices、facets 和 normals。Gaussian 部分在标准 3D Gaussian attributes 之外增加 $b$、$h$ 和 MeshId。$b=(b_1,b_2,b_3)$ 是所在 facet 上的 barycentric coordinates，满足 $b_1+b_2+b_3=1$ 且 $b_k\ge 0$；$h\in[0,1]$ 是沿 facet normal 的 offset；MeshId 记录该 Gaussian 所属 facet。

对 facet $j$，三顶点为 $v_{j1},v_{j2},v_{j3}$，法线为 $n_j$，尺度因子为 $l_j$。Gaussian $i$ 的空间位置为：

$$
\mu_i=b_{i1}v_{j1}+b_{i2}v_{j2}+b_{i3}v_{j3}+h_in_jl_j.
$$

当 $h_i\ne 0$ 时，Gaussian 不在 mesh surface 上，而是沿 normal 悬浮。这种 Gaussian Hover 提供了额外自由度，使 mesh 不必完全承担所有渲染细节。

### 4.2 Mesh Pose Embedding Network

simulation 阶段没有视频 timestamp，因此 MaGS 不用 time embedding 指导 deformation，而是从 mesh 自身提取 pose embedding。MPE-Net 输入 handle vertices $H$ 及其 normals $N$，输出 global mesh pose embedding $E_M$ 和 vertex-specific embedding $E_V$：

$$
E_M,E_V=\mathrm{MPE}(H,N).
$$

handle vertices 通过 Poisson disk sampling 在 mesh 上均匀取点，再用 KNN 映射到 mesh vertices，以便覆盖整体 pose 信息。

### 4.3 Relative Mesh Deformation Network

RMD-Net 学习从 guide mesh 到 refined mesh 的相对变形。它输入 $E_M$ 和每个顶点的 $E_{V_i}$，输出顶点 displacement 以及与 Gaussian rendering 相关的属性调整：

$$
(\Delta v,\Delta q,\Delta s,\Delta\sigma,\Delta c)_i=\mathrm{RMD}(E_M,E_{V_i}).
$$

其中 $\Delta v$ 用于 refine mesh vertices，$\Delta q,\Delta s,\Delta\sigma,\Delta c$ 后续通过 barycentric interpolation 影响 Mesh-adsorbed Gaussians 的 rotation、scale、opacity 和 color。

### 4.4 Relative Gaussian Deformation Network

RGD-Net 允许 Gaussians 在 mesh deformation 时沿 facet 相对移动，而不是固定 anchor。对 Gaussian $i$，RGD-Net 输入 global pose embedding、该 Gaussian 所在 facet 三个顶点的 vertex embeddings，以及原始 $(b_i,h_i)$，输出相对变化：

$$
(\Delta b_i,\Delta h_i)=\mathrm{RGD}(E_M,E_{V_1},E_{V_2},E_{V_3},b_i,h_i).
$$

这个设计绕开了固定 mesh-Gaussian binding 的刚性限制：mesh 提供结构和 simulation prior，Gaussians 保留渲染所需的局部自由度。

### 4.5 Final Gaussian Computation

mesh deformation 后，facet area 和 normal 变化会影响 Gaussian position、scale 和 orientation。先更新 $b'_i=b_i+\Delta b_i$、$h'_i=h_i+\Delta h_i$、$v'_{jk}=v_{jk}+\Delta v_{jk}$。Final Gaussian mean 为：

$$
\mu'_i=b'_{i1}v'_{j1}+b'_{i2}v'_{j2}+b'_{i3}v'_{j3}+h'_in'_jl'_j.
$$

其他属性由三顶点的 RMD outputs 按 $b'_i$ 插值后作用到原始 Gaussian attributes。完整过程可概括为 $(b_{gs}+\Delta b,h_{gs}+\Delta h)\times(v_{mesh}+\Delta v)\rightarrow$ Final Gaussians。Final Gaussians 用标准 differentiable 3DGS rasterizer 渲染。

### 4.6 Mesh-Guided Simulation

simulation 阶段，用户先用 mesh-based methods 生成新的 guide mesh，例如 ARAP editing、SMPL motion editing、soft-body / cloth simulation。由于 MaGS 保留 vertex-facet correspondence，训练中学到的 Mesh-adsorbed Gaussians 可以继承到新 mesh 上。MPE-Net 从新 guide mesh 提取 pose embedding，RMD-Net refine mesh，RGD-Net 调整 Gaussian relative displacement，最后渲染 simulated image。

## 5. Mathematical Objectives and Losses

MaGS 的 reconstruction loss 是 3DGS 常见的 photometric loss：

$$
L=L_{L1}(1-\lambda_{\mathrm{ssim}})+L_{\mathrm{SSIM}}\lambda_{\mathrm{ssim}}.
$$

由于从 guide mesh、MPE/RMD/RGD、Mesh-adsorbed Gaussian 到 final rasterization 全部可微，rendering loss 可反向优化 Mesh-adsorbed Gaussian parameters 和三个 networks。方法没有显式物理 loss；物理/结构先验来自 mesh representation 和 simulation-time guide mesh。

## 6. Training and Inference Procedure

预处理先训练 dynamic 3DGS deformation field，并在 $t=0$ 从 100 个 viewpoints 渲染 median depths，经 TSDF fusion 得到初始 mesh。再把 mesh vertices 输入 deformation field 得到每帧 mesh deformation，因为只改变 vertex positions，所以 facet-ID correspondence 保持不变。

训练阶段使用视频 guide meshes 和 ground-truth frames 联合优化 Gaussians、MPE-Net、RMD-Net、RGD-Net。推理重建时给定视频时间对应 guide mesh，输出 refined mesh 和 final Gaussians；simulation 时给定用户编辑/物理模拟 mesh，输出相应 final Gaussians 和渲染图像。

## 7. Experimental Setup and Results Summary

评测数据包括 D-NeRF、DG-Mesh、PeopleSnapshot 和 Nerfies。D-NeRF 和 DG-Mesh 以 400x400 评估，PeopleSnapshot 以 1080x1080 评估。指标包括 PSNR、SSIM、MS-SSIM、LPIPS，以及 DG-Mesh 上的 EMD 和 CD。所有实验在 RTX 4090 上完成。

D-NeRF 上，MaGS 在多数场景的 PSNR、SSIM、LPIPS 上超过 prior methods，相比第二好的 SC-GS 平均 PSNR 提升约 0.7 dB。PeopleSnapshot 上，MaGS 在所有场景取得最高 PSNR 和 SSIM，相比 SplattingAvatar 平均 PSNR 提升约 2 dB。

DG-Mesh 表中，MaGS PSNR 为 40.76，优于 Dynamic 2D Gaussians 的 36.40、DynaSurfGS 的 33.18、DG-Mesh 的 31.43；EMD 为 0.1106 最优。CD 为 0.6662，略弱于 Dynamic 2D Gaussians 的 0.5254 和 DG-Mesh 的 0.6022，但 MaGS 只使用约 981 mesh faces，而 DG-Mesh 为 170,232 faces，Dynamic 2D Gaussians 为 1,419,454 faces。优化时间 47.6 分钟，也低于 DG-Mesh 的 89.3 和 Dynamic 2D Gaussians 的 72.7。

Nerfies 上，MaGS 在 Tobysit、Broom、Curls、Tail 的 PSNR 分别为 22.1、21.3、18.7、24.2，在三项上最高，平均优于 D-3DGS、SC-GS 和 Grid4D。消融表显示 full MaGS 为 44.06 / 0.9985 / 0.0040；去掉 RGD-Net 降到 42.98；去掉 Gaussian Hover 降到 41.87；同时去掉 RMD-Net 和 RGD-Net 降到 41.14，说明 mesh refinement、Gaussian relative displacement 和 hover freedom 都有贡献。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是统一 reconstruction and simulation 的 Mesh-adsorbed Gaussian Splatting、RMD/RGD/MPE 网络设计，以及对多种 deformation priors 的兼容性。实际技术增量在于把 Gaussian 与 mesh 的关系从固定绑定改成 facet-local coordinate + normal offset + learnable relative displacement。

与 DG-Mesh / SplattingAvatar 这类 mesh-embedded Gaussians 相比，MaGS 的关键是允许 Gaussian roam near mesh surface，缓解渲染精度与 deformation 合理性之间的冲突。与 SC-GS / sparse control point 方法相比，mesh 提供了连续 surface、facet correspondence 和更自然的 simulation interface。

## 9. Limitations / Assumptions

MaGS 依赖 temporally consistent mesh with facet-ID correspondence。初始 dynamic 3DGS 和 TSDF mesh extraction 如果失败，会影响后续吸附关系和 simulation。

方法不支持 topology-changing deformations，例如 fluid dynamics、断裂、融合或强拓扑变化。论文明确指出它与其他 mesh-based methods 一样受限于固定拓扑。

mesh face number 是超参数，论文设置约 1K 以提高效率。虽然 Gaussian Hover 降低了对复杂 mesh 的依赖，但过粗 mesh 在极端几何细节或复杂接触下可能不足。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Monocular dynamic object video; preprocessed temporally consistent guide meshes |
| Output | Mesh-adsorbed Gaussians for reconstruction and simulation |
| Core representation | Gaussian local facet coordinates $b$, normal offset $h$, MeshId |
| Mesh network | MPE-Net extracts pose from handle vertices; RMD-Net refines mesh |
| Gaussian network | RGD-Net updates barycentric coordinates and normal offset |
| Simulation priors | ARAP, SMPL, soft-body / cloth simulation through guide mesh |
| Strength | High-quality rendering plus mesh-compatible deformation simulation |
| Weakness | Needs consistent mesh topology; cannot handle topology-changing dynamics |

## 11. Reusable Components

- barycentric + normal-offset Gaussian parameterization on mesh facets。
- Gaussian Hover to relax strict mesh anchoring。
- MPE-Net replacing timestamp input with mesh pose embedding for simulation generalization。
- RMD-Net for video-learned mesh deformation refinement。
- RGD-Net for local Gaussian roaming under mesh deformation。
- reconstruction-trained networks reused for user-defined mesh-guided simulation。

## 12. Gap / Idea Seeds

- Add topology-change support by allowing Gaussian reassignment across facets or dynamic remeshing。
- Learn confidence for guide mesh quality so unreliable mesh regions permit larger Gaussian hover freedom。
- Combine MaGS with physically explicit particle/elastic losses for soft-body simulation rather than relying only on external guide mesh。
- Use semantic/part segmentation to constrain RMD/RGD for articulated objects.

## 13. Human Check List

- NEED_HUMAN_CHECK: Full D-NeRF Table 1 and PeopleSnapshot Table 2 are partially truncated in extracted text; note records paper-stated average conclusions and fully visible DG-Mesh/Nerfies/ablation tables.
- NEED_HUMAN_CHECK: Simulation section after Eq. 10 is partly truncated; note summarizes from visible text, figures and conclusion.
- NEED_HUMAN_CHECK: Mesh face count around 1K is a design choice from the paper; exact TSDF/decimation settings are in appendix.

## 14. Evidence Anchors

- Section 3.3: temporally consistent mesh extraction from dynamic 3DGS and TSDF。
- Section 4.1: Mesh-adsorbed Gaussian representation with $b$, $h$, MeshId and Gaussian Hover。
- Section 4.2: MPE-Net, RMD-Net, RGD-Net definitions。
- Section 4.3: final Gaussian computation and rendering loss。
- Section 4.4 / Figure 5: mesh-guided simulation with ARAP, soft body and SMPL。
- Tables 3-5: DG-Mesh, Nerfies and ablation results。
