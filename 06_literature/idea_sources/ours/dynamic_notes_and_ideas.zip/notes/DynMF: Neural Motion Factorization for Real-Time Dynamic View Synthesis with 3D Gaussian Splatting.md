# DynMF: Neural Motion Factorization for Real-Time Dynamic View Synthesis with 3D Gaussian Splatting

## 0. Metadata

- Title: DynMF: Neural Motion Factorization for Real-Time Dynamic View Synthesis with 3D Gaussian Splatting
- Authors: Agelos Kratimenos; Jiahui Lei; Kostas Daniilidis
- Venue/Year: ECCV 2024, LNCS / Springer version published 2025
- DOI: `10.1007/978-3-031-72986-7_15`
- URL: https://link.springer.com/10.1007/978-3-031-72986-7_15
- Zotero item key: `RCEN3HNP`
- Zotero PDF attachment key: `ZEVQI2CF`
- Duplicate PDF attachment key: `EH85AH6G`
- PDF path: `/Users/wangyibo/Zotero/storage/ZEVQI2CF/Kratimenos 等 - 2025 - DynMF Neural Motion Factorization for Real-Time Dynamic View Synthesis with 3D Gaussian Splatting.pdf`
- Local note path: `notes/DynMF: Neural Motion Factorization for Real-Time Dynamic View Synthesis with 3D Gaussian Splatting.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

DynMF 将动态 3DGS 的每个 Gaussian 运动分解为少量全局共享的 learned basis trajectories 与 per-Gaussian motion coefficients 的线性组合，用 time-only MLP 只按时间查询 basis，从而在保持 3DGS 级渲染速度的同时获得可解释、可稀疏控制的动态场景表示。

## 2. Problem Formulation

动态 NVS 的难点在于每个 3D 点的运动在单目或稀疏多视角下高度欠约束。逐点 deformation MLP 表达力强但需要对每个 Gaussian 查询网络，训练和渲染都慢；纯显式逐点轨迹又容易过拟合，且需要大量 correspondences。DynMF 的假设是：一个动态场景的复杂运动可以由很少的 basis trajectories 组合出来，每个 Gaussian 只需要学习它对这些 basis 的 motion coefficients。

因此问题从学习一个 dense deformation field 变为低秩 motion factorization。给定 canonical points 或 Gaussians，方法学习全局共享 basis $b_j(t)$，并为每个 Gaussian 学习系数 $c_j$。场景中静止区域应选择接近 0 的 motion coefficients，动态区域应稀疏选择少数 basis，从而天然形成 motion decomposition。

## 3. Method Overview

DynMF 的 pipeline 很直接：先以 3DGS 表示 canonical scene，再把 Gaussian mean 和 rotation 都替换成时间相关量。时间相关量不由 per-Gaussian MLP 预测，而由少量共享 basis trajectories 与 per-Gaussian coefficients 线性混合得到。basis 可用 Fourier series 显式定义，也可由一个很小的 MLP 学习；主方法采用 learned basis，因为它更平滑、更有表达力。

训练目标仍以 3DGS photometric reconstruction 为主，但额外加入 coefficient $L_1$ 和 sparsity losses。$L_1$ 抑制不必要运动，sparsity loss 强迫每个 Gaussian 只选择少量 trajectories，从而提高可解释性和可控性。作者还讨论了 rigidity loss，但实验上认为低数量共享 trajectories 已经天然鼓励局部刚性。

## 4. Method Details

### 4.1 Motion Factorization Field

设动态场景由 $N$ 个点 $x\in\mathbb{R}^{N\times 3}$ 表示，时间为 $t\in[0,T]$，canonical space 为 $x_c$。DynMF 定义 $B$ 个轨迹 basis $b_j(t):[0,T]\rightarrow\mathbb{R}^3$，每个点的运动写成：

$$
x(t)=x_c+\sum_{j=1}^{B}c_jb_j(t).
$$

如果把时间离散为 $T$ 个 timestamps，只看一个坐标维度，就得到矩阵形式 $X=X_c+C\cdot B$，其中 $C\in\mathbb{R}^{N\times B}$，$B\in\mathbb{R}^{B\times T}$，且 $B$ 远小于 $N$ 或 $T$。这使 motion field 成为一个低秩分解问题。

### 4.2 Learned Basis vs Fourier Basis

论文先给出显式 Fourier basis 的可能形式，例如奇数 basis 用 cosine、偶数 basis 用 sine。但主方法使用 learned basis：$b_j(t)=\mathrm{MLP}(t/T;w_j)$。这个 MLP 只输入时间，不输入空间坐标，因此一次 forward 就能得到所有 basis 在当前时间的值，随后对所有 Gaussians 做 coefficient blending。

这种设计与 D-NeRF 类 coordinate deformation MLP 的关键差异是：DynMF 的网络查询次数与 Gaussian 数量几乎无关。动态渲染时不需要为每个 Gaussian 单独跑 MLP，只需按时间查询 basis，然后进行矩阵/向量混合。

### 4.3 Dynamic 3D Gaussian Parameterization

DynMF 绑定在 3DGS 上。静态 3DGS 中每个 Gaussian 有 mean $\mu$、covariance $\Sigma$、rotation $R$、scale $s$、opacity $\alpha$ 和 spherical harmonics color coefficients。动态版本中，mean 和 rotation quaternion 随时间变化：

$$
\mu(t)=\mu_c+\sum_{j=1}^{B}c_jb_j^\mu(t),\quad q(t)=q_c+\sum_{j=1}^{B}c_jb_j^R(t).
$$

$\mu_c$、$q_c$ 和 coefficients $c$ 是 per-Gaussian learned parameters。translation 和 rotation 共享同一组 motion coefficients，但有不同的 basis outputs $b_j^\mu(t)$ 与 $b_j^R(t)$。density、opacity 和 color coefficients 在时间上保持固定。这个选择降低了动态自由度，也意味着 appearance change 主要通过几何运动解释。

### 4.4 Regularization and Sparsity

第一类正则是 motion coefficients 的 $L_1$ loss：

$$
L_1=\frac{1}{NB}\sum_{i=1}^{N}\sum_{j=1}^{B}|c_{ij}|.
$$

它用于惩罚背景或静态 Gaussians 的不必要移动。但作者发现 $L_1$ 不足以让运动真正稀疏，moving Gaussians 仍会以较小权重混合多个 basis。因此引入更强的 sparsity loss：

$$
L_s=\frac{1}{N}\sum_{i=1}^{N}\frac{\|c_i\|_1}{\|c_i\|_\infty}.
$$

当权重足够大时，该项会鼓励每个 Gaussian 只选择极少数 basis。这样可以把场景运动拆成可单独开关的分量，支持 novel motion synthesis 和 motion editing。

### 4.5 Rigidity Bias

DynMF 的 rigidity 不是主要靠显式 ARAP，而是来自 representation bias：少量全局 basis 会迫使相邻点选择相同或相近轨迹；Gaussian split / densification 时，新 Gaussian 会复制父 Gaussian 的 motion coefficients，也强化了局部一致性。论文也测试了邻近 Gaussians coefficients 的 rigidity loss $L_r$，但认为它没有进一步提升渲染质量。

## 5. Mathematical Objectives and Losses

DynMF 的核心目标仍是 3DGS photometric reconstruction，只是把 Gaussian 的 $\mu(t)$ 和 $q(t)$ 由 motion factorization 提供。完整优化还包含 coefficient $L_1$ 和 sparsity regularization。可概括为：photo loss 保证渲染拟合，$L_1$ 抑制静态漂移，$L_s$ 强制 basis selection 变稀疏，representation 本身提供低秩 motion prior。

这个数学设计的关键在于它没有显式学习一个高维时空场，而是学习一个低维 motion subspace。basis 数 $B$ 是最重要的超参数：太小会欠拟合复杂 motion，太大则可能削弱稀疏分解和刚性先验。

## 6. Training and Inference Procedure

实现使用 PyTorch 训练 motion representation，保留 3DGS 的 differentiable rasterization。basis MLP 由 8 个宽度 256 的 linear layers 构成，并有两个输出头，分别输出 $(B,3)$ 的 displacement basis 和 $(B,4)$ 的 quaternion correction basis。时间输入使用 positional encoding，默认 32 个 frequencies。

D-NeRF 上使用 $B=10$，HyperNeRF 和 N3DV 上使用 $B=32$。训练总共 30k iterations，前 3k iterations 不训练 basis functions 和 motion coefficients。basis learning rate 从 $8e^{-4}$ 指数衰减到 $8e^{-6}$，coefficients learning rate 为 $8e^{-3}$。所有数据集从场景中心附近随机初始化 2k Gaussians。

推理时，对任意 timestamp 只需查询一次 time-only MLP 得到 basis，然后为所有 Gaussians 线性组合得到 $\mu(t)$ 和 $q(t)$，再按标准 3DGS rasterization 渲染。这就是其 FPS 高的直接原因。

## 7. Experimental Setup and Results Summary

实验覆盖三个 setting：synthetic monocular D-NeRF、real monocular HyperNeRF、real multi-view N3DV。D-NeRF 分辨率为 400x400，DynMF 达到 PSNR 36.89、SSIM 0.983、LPIPS 0.02、训练 20 分钟、300 FPS，高于 4DGS 的 34.05 / 0.98 / 0.02 / 20 分钟 / 82 FPS 和 GauFRe 的 34.80 / 0.982 / 0.02 / 25 分钟 / 50 FPS。

HyperNeRF 的 4 个场景中，DynMF 在 PSNR 上大致与 4DGS 接近：3D Printer 22.4、Chicken 28.5、Broom 22.1、Peel Banana 28.1。SSIM 则不总是领先，例如 Chicken 为 0.81，低于 HyperNeRF / TiNeuVox / 4DGS 的 0.94 / 0.95 / 0.93。说明它在真实单目场景中优势更偏效率和可控分解，不是每个感知指标都绝对领先。

N3DV multi-view 上，DynMF 为 PSNR 31.70、SSIM 0.946、LPIPS 0.18、训练 40 分钟、135 FPS。它接近 K-Planes 的 31.63 / 0.964，但低于 HexPlane 的 32.22 PSNR；速度高于大多数 NeRF/grid baselines，但 LPIPS 不如 DyNeRF 或 4DGS。

Ablation 表明，D-NeRF Mutant 和 N3DV Flame-steak 上，$(B,F)=(10,32)$ 表现最好或接近最好，分别为 40.79 和 31.57 PSNR。$B=1$ 明显欠拟合，$B=20$ 或 $50$ 没有继续提升。Fourier basis 可用但弱于 learned basis：Mutant 上 learned basis 40.79，而 Fourier 10 / 20 / 50 / 100 分别为 33.17 / 35.21 / 33.87 / 21.12。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称的贡献是通过少量 neural trajectories 对动态场景运动进行 factorization，实现快速训练、实时渲染和可控 motion decomposition。实际技术增量在于把 trajectory basis factorization 与 3DGS 的 Gaussian attributes 结合，并把 basis MLP 的查询维度降到只依赖时间。

与 deformation-field methods 相比，它避免 per-Gaussian MLP query；与 explicit 4D primitives 相比，它更强调低秩共享 basis 和 motion coefficients；与 tracker/point-based dynamic Gaussian 方法相比，它不需要 dense correspondences。它的代价是 appearance 被固定，复杂拓扑变化和非几何变化只能通过有限 motion basis 间接表达。

## 9. Limitations / Assumptions

DynMF 假设场景运动可以由少量全局 basis 解释。对于多个局部独立、高频、非周期或突发运动，固定数量 basis 可能需要增大，进而削弱稀疏性与可解释性。

方法保持 density 和 spherical harmonics color coefficients 随时间固定，因此对真实场景中的强光照变化、显著非刚体外观变化、遮挡导致的 appearance change 表达有限。

HyperNeRF 和 N3DV 结果显示它并非所有指标都优于其他方法。真实数据上它的主要优势是效率、compactness 和 motion controllability，而不是无条件的画质最优。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Monocular or multi-view dynamic videos with known/estimated cameras |
| Output | Dynamic 3DGS with factorized Gaussian mean and rotation trajectories |
| Core representation | Shared learned motion basis + per-Gaussian coefficients |
| Network query | Time-only MLP, queried once per timestamp |
| Main losses | 3DGS photometric loss + coefficient $L_1$ + sparsity loss |
| Motion control | Enable/disable sparse basis components to synthesize new motion combinations |
| Strength | Fast training, high FPS, compact and interpretable motion factorization |
| Weakness | Limited by low-rank global basis and time-fixed appearance attributes |

## 11. Reusable Components

- time-only basis MLP for dynamic Gaussian deformation。
- shared motion coefficients for translation and rotation basis selection。
- coefficient sparsity loss $\|c_i\|_1/\|c_i\|_\infty$ for motion disentanglement。
- Gaussian densification with copied motion coefficients for implicit rigidity。
- learned-basis vs Fourier-basis ablation as a template for studying motion priors。

## 12. Gap / Idea Seeds

- $B$ 是全局固定的，可以改成 region-adaptive 或 object-adaptive basis count。
- appearance 固定限制真实动态光照，可加入 low-rank appearance basis，与 motion basis 分离。
- 当前 basis 是全局共享，可能难以表达多物体独立运动；可以引入 hierarchical basis 或 mixture-of-basis gating。
- sparsity loss 支持开关 motion，但缺少语义命名；可用 segmentation / language grounding 给 basis motion 自动标注。

## 13. Human Check List

- NEED_HUMAN_CHECK: Zotero metadata 的 authors 混入了 ECCV editors；本笔记按论文首页实际作者写为 Agelos Kratimenos、Jiahui Lei、Kostas Daniilidis。
- NEED_HUMAN_CHECK: Zotero 有两个 PDF 附件，主记录使用 `ZEVQI2CF`，另一个 `EH85AH6G` 作为重复附件记录。
- NEED_HUMAN_CHECK: Springer 版本页面显示 ECCV 2024 章节、copyright 2025，本笔记按 `ECCV 2024, Springer 2025` 处理。

## 14. Evidence Anchors

- Section 3.1: motion factorization field, low-rank matrix form, Fourier and learned basis definitions。
- Section 3.2: dynamic 3DGS parameterization for mean and rotation quaternion。
- Section 3.3: $L_1$ regularization、sparsity loss、rigidity discussion。
- Section 4.2: implementation details, MLP architecture, $B$ values, training schedule。
- Tables 1-3: D-NeRF、HyperNeRF、N3DV quantitative results。
- Tables 4-5: trajectory count / time encoding and learned-vs-Fourier basis ablations。
