# Spike4DGS: Towards High-Speed Dynamic Scene Rendering with 4D Gaussian Splatting via a Spike Camera Array

## 0. Metadata

- Paper title: Spike4DGS: Towards High-Speed Dynamic Scene Rendering with 4D Gaussian Splatting via a Spike Camera Array
- Authors: Qinghong Ye; Yiqian Chang; Jianing Li; Haoran Xu; Xuan Wang; Wei Zhang; Yonghong Tian; Peixi Peng
- Venue / year: NeurIPS 2025
- Project / code: `https://github.com/Qinghongye/Spike4DGS`
- Zotero item key: `LG4TIGXN`
- Zotero PDF attachment key: `CED3UWDI`
- Zotero PDF path: `/Users/wangyibo/Zotero/storage/CED3UWDI/Ye 等 - 2025 - Spike4DGS Towards High-Speed Dynamic Scene Rendering with 4D Gaussian Splatting via a Spike Camera.pdf`
- Local note path: `notes/Spike4DGS: Towards High-Speed Dynamic Scene Rendering with 4D Gaussian Splatting via a Spike Camera Array.md`

## 1. One-Sentence Technical Summary

Spike4DGS 用多视角 spike camera array 捕获高速动态场景，通过 multi-view spike-based dense initialization 得到点云和相机位姿，再用 pixel loss 与 spike variation loss 联合监督 4DGS，从而在高速运动中保留比 RGB/event 输入更细的动态纹理。

## 2. Problem Formulation

输入是来自 $N-1$ 个 spike cameras 的连续 spike streams，以及目标 novel view $V_N$ 和时间 $t$。输出是目标视角目标时间的渲染图像 $\hat{I}_t$：

$$
\mathrm{Spike4DGS}:\{(S_1,S_2,\ldots,S_{N-1}),V_N,t\}\to \hat{I}_t.
$$

核心问题是高速动态场景下普通 RGB 相机低帧率和曝光时间导致 motion blur，而 event camera 只记录亮度变化、不记录绝对亮度。Spike camera 以最高 20k Hz 的频率把 absolute light intensity 编码为 spike streams，更适合保留高速纹理，但此前多集中于单目或静态重建。本文把 spike camera array 和 4DGS 结合，解决多视角高速动态 NVS。

## 3. Method Overview

框架分两部分。第一部分是 Multi-view Spike-based Dense Initialization (MSDI)：直接从多视角 spike streams 估计 dense point cloud、camera poses 和由 spike 生成的监督图像，避免先 spike-to-image 再 COLMAP/DUSt3R 的两阶段误差传递。第二部分是 4DGS with Spike-Pixel Synergy Supervision (SPSS)：用 MSDI 的点云和位姿初始化 4DGS，渲染图像既与 spike-generated image 对齐，也被转换成 spike stream 与真实 spike stream 的动态统计对齐。

该设计的关键不是重写 4DGS，而是让 4DGS 能直接受益于 spike stream 的高时间分辨率。Pixel loss 约束可见图像质量，spike variation loss 约束短时间窗口内的动态变化。

## 4. Method Details

### 4.1 Spike Camera Model

Spike camera 的像素通过光电累积电压记录 absolute light intensity。当累积电压 $V$ 到达阈值 $\Theta$ 时触发 spike，并将 $V$ 重置。论文给出模型：

$$
V(t)=\int_{t_s}^{t}\sigma\cdot L(t)\,dt \bmod \Theta,
$$

其中 $L(t)$ 是瞬时光强，$t_s$ 是上一次 spike 触发时间，$\sigma$ 是光电转换系数。与 event camera 的 brightness-change trigger 不同，spike camera 能保留绝对亮度信息，因此对精细纹理重建更直接。

### 4.2 Multi-view Spike-based Dense Initialization

MSDI 的目标是从多视角 spike streams 中直接估计点云、相机位姿和图像：

$$
\mathrm{MSDI}:(S_1,\ldots,S_N)\to \{PC,([R|T]_1,\ldots,[R|T]_N),(I_1,\ldots,I_N)\}.
$$

MSDI 包含 spike feature extractor、point cloud and pose estimator、image generator。对时间窗口 $\Gamma_t$ 内第 $i$ 个视角 spike stream $S_i(\Gamma_t)$，先做四个方向旋转并拼接，以补全方向感受野：

$$
R(S_i(\Gamma_t))=\operatorname{CAT}\{\operatorname{Rot}(S_i(\Gamma_t),\theta)\mid \theta\in\{0^\circ,90^\circ,180^\circ,270^\circ\}\}.
$$

随后用 shift-based $3\times 3$ convolution 提取 spike features：

$$
\hat{f}_i(\Gamma_t)=M(R(S_i(\Gamma_t))).
$$

每个视角的 feature 进入共享权重 ViT encoder：

$$
\hat{F}_i(\Gamma_t)=\operatorname{ViT}_i(\hat{f}_i(\Gamma_t)),\qquad i\in(1,\ldots,N).
$$

多视角 features 由 24-layer fusion transformer 聚合：

$$
G_1(\Gamma_t),\ldots,G_N(\Gamma_t)=\operatorname{FusionTF}(\hat{F}_1(\Gamma_t),\ldots,\hat{F}_N(\Gamma_t)).
$$

DPT head 解码全局点云及置信度：

$$
(PC,\Sigma_{PC})=\operatorname{DPT}(G_1(\Gamma_t),\ldots,G_N(\Gamma_t)).
$$

最后通过 RANSAC-PnP 从全局点云估计每个视角的 $[R|T]$。

### 4.3 Spike Image Generator

MSDI 同时从 spike features 生成离散图像，用于后续 pixel supervision。对第 $i$ 个视角：

$$
\bar{I}_i(t)=\operatorname{BCONV}(\hat{f}_i(\Gamma_t)),
$$

其中 BCONV 是三层 $1\times 1$ convolution。这样 4DGS 的 pixel loss 不依赖外部 RGB frame，而是来自 spike stream 自身的图像化结果。

### 4.4 4DGS Backbone

本文使用 4DGS 作为动态场景表示。给定初始 3D Gaussian $G$ 和时间 $t$，spatial-temporal encoder $H$ 与 multi-head deformation decoder $D$ 预测 Gaussian deformation：

$$
\Delta G = D(H(G,t)).
$$

经过 MSDI 初始化后，Spike4DGS 在第 $i$ 个视角 $p_i$ 渲染：

$$
\hat{I}_i(t)=\operatorname{Render}(\operatorname{4DGS}(G,t),p_i).
$$

因此，Spike4DGS 的表示部分基本继承 4DGS，主要新增在初始化和监督。

### 4.5 Spike-Pixel Synergy Supervision

pixel loss 直接约束渲染图像与 MSDI 生成图像：

$$
L_{\mathrm{pixel}}^t=\left\lVert \hat{I}_i(t)-\bar{I}_i(t)\right\rVert_1.
$$

但高速运动中的纹理和 motion detail 仍存在于 spike stream 的时间变化里，所以作者把渲染图像再翻译为 spike。对像素 $(x,y)$ 的渲染强度 $\hat{I}_i(x,y,t)$，用 Integrate-and-Fire 机制生成预测 spike：

$$
\hat{S}_i(x,y,t)=\operatorname{IF}(\hat{I}_i(x,y,t)\cdot n(x,y)).
$$

其中 $n(x,y)$ 是响应非均匀噪声 deviation matrix，通过拍摄均匀光场获得。然后用一层 MLP $\phi_s$ 将单个时刻 spike 映射为时间窗口 $\Gamma_t$ 内 spike sequence：

$$
\hat{S}_i(\Gamma_t)=\phi_s(\hat{S}_i(t)).
$$

spike variation loss 对预测 spike sequence 和真实 spike sequence 的均值与标准差做 $L_1$：

$$
L_{\mathrm{spikeV}}^t=
\left\lVert \operatorname{avg}(\hat{S}_i(\Gamma_t))-\operatorname{avg}(S_i^{gt}(\Gamma_t))\right\rVert_1+
\left\lVert \operatorname{std}(\hat{S}_i(\Gamma_t))-\operatorname{std}(S_i^{gt}(\Gamma_t))\right\rVert_1.
$$

总监督为：

$$
L_{\mathrm{total}}^t=L_{\mathrm{spikeV}}^t+L_{\mathrm{pixel}}^t.
$$

## 5. Mathematical Objectives and Losses

本文的优化目标可分为初始化网络和 4DGS 两部分。MSDI 在 CARLA multi-view spike streams 上 fine-tune，用于估计点云、位姿和生成图像；主 4DGS 优化则使用 SPSS。关键目标为 $L_{\mathrm{pixel}}^t$ 与 $L_{\mathrm{spikeV}}^t$ 的和。

从损失设计看，$L_{\mathrm{pixel}}^t$ 是传统 image reconstruction loss，保证视觉外观；$L_{\mathrm{spikeV}}^t$ 是动态统计约束，用短时间窗口 spike sequence 的 average 和 standard deviation 逼近真实 spike dynamics。它不逐 spike 做精确二值匹配，而是用统计量表达高速运动变化，降低优化难度。

## 6. Training and Inference Procedure

训练前，作者搭建 9 个 spike cameras 的 real-world array，空间分辨率 250 x 400，时间分辨率 20k Hz；同时在 CARLA 中生成 synthetic outdoor spike dataset。MSDI 先用 synthetic multi-view spike streams fine-tune，得到对 spike stream 到点云/位姿/图像的端到端初始化能力。

训练 Spike4DGS 时，对输入 spike streams 用 MSDI 得到 initial point cloud 和 camera poses，并初始化 3D Gaussians；4DGS 根据时间 deform Gaussians 并渲染图像；渲染图像一方面与 MSDI 图像计算 $L_{\mathrm{pixel}}^t$，另一方面经 IF 转成 spike sequence，与真实 spike streams 计算 $L_{\mathrm{spikeV}}^t$。

推理时，使用学到的 4DGS 表示在目标视角和时间渲染动态图像。MSDI 主要服务于初始化和训练数据转换，SPSS 主要服务于训练监督。

## 7. Experimental Setup and Results Summary

实验数据包括作者自建 real-world object dataset 和 CARLA synthetic outdoor dataset。真实设备为 9-camera spike array，论文目标是验证高速度动态场景下 spike camera array 对 4DGS 的优势。比较对象包括 RGB/event/spike 相关的 NeRF/GS 方法，以及动态 4DGS baselines。

主要结论包括：Spike4DGS 在 synthetic 和 real-world datasets 上的 novel view rendering quality 优于 state-of-the-art methods；spike camera 在高速场景中优于 event camera 和 RGB camera；随着 spike camera 数量增加，渲染质量提升。论文还强调多视角 spike array 能在相机静止或弱纹理区域提供更多空间覆盖，弥补 monocular spike reconstruction 的不足。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是首个 spike camera array + 4DGS 的高速动态场景渲染框架。实际技术增量有三块：硬件/数据层面的多视角 spike array 和 synthetic/real datasets；初始化层面的 MSDI，直接从 spike streams 估计 point cloud 和 camera poses；监督层面的 SPSS，把渲染图像重新映射到 spike domain，用 spike temporal variation 约束高速动态细节。

4DGS backbone 本身不是新设计，本文更像是“把 4DGS 接入 spike sensing pipeline”。因此它对 Dynamic GS 的贡献在于传感器和训练信号，而不是 Gaussian 参数化本身。

## 9. Limitations / Assumptions

方法依赖专用 spike camera array，真实部署门槛高。与普通 RGB 视频相比，采集硬件、同步、标定和数据处理都更复杂。

MSDI 的训练依赖 CARLA synthetic spike data，跨域到真实 spike camera 的泛化质量会影响点云、位姿和后续 4DGS 初始化。若 synthetic-to-real gap 较大，端到端初始化可能不稳定。

spike variation loss 使用 average/std 统计量，而非完整 spike sequence likelihood。它能捕捉动态变化趋势，但可能无法约束所有精细时间结构。论文 checklist 中提到 limitations 在 supplementary，但当前抽取文本未显示具体 supplementary limitation 内容。

## 10. Matrix-Ready Summary

| Dimension | Entry |
|---|---|
| Input | Multi-view spike streams from spike camera array |
| Output | High-speed dynamic novel-view rendering |
| Sensor | Spike cameras, absolute intensity, up to 20k Hz |
| Initialization | MSDI estimates point cloud, camera poses and spike-generated images |
| Representation | 4D Gaussian Splatting |
| Supervision | Pixel loss plus spike variation loss |
| Spike modeling | Rendered intensity to spike via IF mechanism |
| Dynamic loss | Average/std matching over spike sequence window $\Gamma_t$ |
| Datasets | Real-world 9-camera spike dataset and CARLA synthetic dataset |
| Main advantage | Captures high-speed texture/motion details beyond RGB/event input |
| Main limitation | Requires specialized synchronized spike camera array |

## 11. Reusable Components

- Spike-to-geometry initialization: direct dense point cloud and pose estimation from multi-view spike streams.
- Rotation-augmented spike feature extraction: four-direction rotated spike tensors plus shift-based convolution.
- Spike-pixel synergy loss: combine image-domain reconstruction with spike-domain temporal variation matching.
- IF-based differentiable spike proxy: translate rendered intensity into spike representation for supervision.
- Multi-view neuromorphic dataset pipeline: useful for benchmarking high-speed dynamic reconstruction.

## 12. Gap / Idea Seeds

- Replace average/std spike variation with a probabilistic spike likelihood or differentiable integrate-and-fire sequence loss.
- Learn camera calibration and synchronization jointly with MSDI for less controlled spike arrays.
- Distill spike-supervised 4DGS into an RGB-only model for deployment without spike hardware.
- Add uncertainty to MSDI point clouds and pass it to Gaussian initialization as covariance/opacity priors.
- Combine spike supervision with event supervision: spike for absolute intensity, event for brightness change.

## 13. Human Check List

- NEED_HUMAN_CHECK: Verify final NeurIPS 2025 metadata and title spelling; extracted full text has “Recontruction” typo while Zotero title says “Rendering”.
- NEED_HUMAN_CHECK: Check supplementary for exact limitations, dataset splits, and numeric tables; extraction truncates the experiment section.
- NEED_HUMAN_CHECK: Confirm whether released code/dataset URLs are active and whether synthetic/real datasets are publicly available.

## 14. Evidence Anchors

- Abstract: spike camera array, synthetic/real datasets, MSDI, spike-pixel synergy supervision.
- Section 3.1: spike camera integrate-and-fire model and 4DGS deformation formulation.
- Section 3.2: problem formulation mapping spike streams and novel view/time to rendered image.
- Section 3.3: MSDI, spike feature extractor, ViT/fusion transformer, DPT point cloud and RANSAC-PnP pose estimation.
- Section 3.4: 4DGS rendering, pixel loss, IF spike translation, spike variation loss and total loss.
- Section 4: real-world spike array and CARLA synthetic outdoor dataset setup.
