# Dynamic Gaussian Splatting Idea Report

本文基于 `0-Gaussian Splatting/2-Classification/Dynamic` 下已经转换过的 53 篇论文笔记整理。报告先逐篇回顾每篇工作的主要创新点和应用场景，再综合这些工作中反复出现的技术路线，提出 10 个可以尝试的新 idea。这里的 idea 都刻意采用“组合、改造、优化”的方式组织，不直接复刻单篇论文的方案。

## 1. 53 篇论文逐篇回顾

| # | 论文 | 主要创新点 | 典型应用场景 |
|---:|---|---|---|
| 1 | 4D Gaussian Splatting for Real-Time Dynamic Scene Rendering | 将 3D Gaussian Splatting 扩展到动态场景，用 HexPlane/4D voxel 编码和形变解码器描述随时间变化的位置、旋转、尺度等属性，在保持显式高斯渲染效率的同时支持动态新视角合成。 | 通用动态场景重建、实时动态新视角渲染、动态内容编辑。 |
| 2 | Uncertainty Matters in Dynamic Gaussian Splatting for Monocular 4D Reconstruction | 引入逐高斯不确定性，用不确定性选择关键节点、调节运动图边权和重建损失权重，使单目 4D 重建在遮挡、外推和几何歧义下更稳健。 | 单目动态重建、极端新视角合成、遮挡严重场景恢复。 |
| 3 | 3D Geometry-aware Deformable Gaussian Splatting for Dynamic View Synthesis | 将高斯中心体素化，用 sparse 3D U-Net 提取局部几何特征，再由 MLP 预测形变，使动态形变受到 3D 几何结构约束。 | 几何一致性更强的动态新视角合成，尤其适合局部结构复杂的动态场景。 |
| 4 | Fully Explicit Dynamic Gaussian Splatting | 强调显式动态参数化，尽量减少或取消重型隐式形变网络，用可插值的时序高斯属性直接表示动态变化。 | 对延迟、可控性和可压缩性要求较高的实时动态渲染。 |
| 5 | SC-GS: Sparse-Controlled Gaussian Splatting for Editable Dynamic Scenes | 用稀疏控制点或控制节点驱动动态高斯，使用户可以通过少量控制信号编辑场景运动，而不是直接操作大量高斯。 | 可编辑动态场景、交互式运动控制、内容创作。 |
| 6 | DeGauss: Dynamic-Static Decomposition with Gaussian Splatting for Distractor-free 3D Reconstruction | 将场景拆成动态干扰物和静态主体，利用动态-静态分解去除 transient distractors，使静态 3D 重建更干净。 | 带行人、车辆等干扰物的静态场景重建，户外采集清理。 |
| 7 | Deformable 3D Gaussians for High-Fidelity Monocular Dynamic Scene Reconstruction | 在规范空间中维护 3D Gaussians，通过形变网络从单目视频恢复动态场景，在高斯渲染速度和单目高保真重建之间取得平衡。 | 单目动态视频的新视角合成、人物或物体运动重建。 |
| 8 | HiCoM: Hierarchical Coherent Motion for Dynamic Streamable Scenes with 3D Gaussian Splatting | 用层次化一致运动建模动态场景，把运动组织成更适合压缩和流式传输的结构，减少逐高斯独立运动带来的冗余。 | 可流式传输的自由视点视频、远程动态场景播放。 |
| 9 | SWinGS: Sliding Windows for Dynamic 3D Gaussian Splatting | 用滑动窗口处理长动态序列，在局部时间窗口内优化和维护高斯，缓解长视频训练显存和累积误差压力。 | 长时序动态视频重建、内存受限训练、在线/准在线处理。 |
| 10 | Real-time Photorealistic Dynamic Scene Representation and Rendering with 4D Gaussian Splatting | 以 4DGS 为核心实现高质量、实时的动态场景表示和渲染，强调 photorealistic 质量与实时速度的结合。 | 实时动态新视角渲染、VR/AR 动态内容、交互式观看。 |
| 11 | SplineGS: Robust Motion-Adaptive Spline for Real-Time Dynamic 3D Gaussians from Monocular Video | 用运动自适应样条描述高斯轨迹，让动态形变在时间上更平滑、更稳健，特别面向单目视频。 | 单目动态场景重建、平滑轨迹恢复、实时动态渲染。 |
| 12 | 3DGStream: On-the-Fly Training of 3D Gaussians for Efficient Streaming of Photo-Realistic Free-Viewpoint Videos | 提出边训练边流式更新的动态高斯框架，包括 Neural Transformation Cache 和自适应高斯生成，让自由视点视频可在线传输和播放。 | 在线 FVV、直播式动态重建、低延迟远程观看。 |
| 13 | Template-free Articulated Gaussian Splatting for Real-time Reposable Dynamic View Synthesis | 从视频中自动学习 superpoints 和骨架树，不依赖模板模型，支持 articulated object 的重摆姿动态新视角合成。 | 动物、人体、机械臂等铰接对象的重建、重姿态和动画。 |
| 14 | Vidu4D: Single Generated Video to High-Fidelity 4D Reconstruction with Dynamic Gaussian Surfels | 从单个生成视频恢复高质量 4D 资产，结合 neural SDF 初始化、表面对齐的 Gaussian surfels 和 warped-state normal regularization。 | 文生视频/图生视频结果转 4D 资产、生成式 3D/4D 内容制作。 |
| 15 | Gaussian-Flow: 4D Reconstruction with Dynamic 3D Gaussian Particle | 将高斯看作动态粒子，用 Dual-Domain Deformation Model 同时描述位置、旋转和辐射残差，增强动态 4D 重建能力。 | 单目或多视角 4D 重建、动态编辑、粒子式运动表示。 |
| 16 | Dynamic Gaussians Mesh: Consistent Mesh Reconstruction from Dynamic Scenes | 用 Gaussian-Mesh anchoring 和 cycle-consistent deformation 从动态高斯中提取时间一致的动态网格。 | 动态网格导出、纹理编辑、碰撞检测、传统图形管线渲染。 |
| 17 | MoDGS: Dynamic Gaussian Splatting from Casually-captured Monocular Videos with Depth Priors | 利用深度先验、3D-aware 初始化和 ordinal depth loss 改善随手拍单目视频中的动态高斯重建。 | 手机单目视频、in-the-wild 动态场景、低成本采集重建。 |
| 18 | MoSca: Dynamic Gaussian Fusion from Casual Videos via 4D Motion Scaffolds | 从深度、tracks、flow 中恢复稀疏 6-DoF 轨迹节点，构建 4D motion scaffold，再将高斯锚定到 scaffold 上。 | 随手拍视频重建、可编辑动态场景、运动结构分析。 |
| 19 | From Tokens to Nodes: Semantic-Guided Motion Control for Dynamic 3D Gaussian Splatting | 利用视觉基础模型 token 指导节点初始化和运动自适应节点分配，并用 Hermite spline 与 dual quaternion blending 表示运动。 | 语义引导的动态控制、对象级运动编辑、复杂运动场景重建。 |
| 20 | ProDyG: Progressive Dynamic Scene Reconstruction via Gaussian Splatting from Monocular Videos | 将 Splat-SLAM、MoSca、残差光流和 SAM2 masks 结合，做渐进式单目动态场景重建。 | 在线或增量式单目动态重建、动态 SLAM、长视频处理。 |
| 21 | DynMF: Neural Motion Factorization for Real-Time Dynamic View Synthesis with 3D Gaussian Splatting | 用低秩全局运动基和逐高斯系数分解动态运动，只需轻量 time-only MLP，提升可解释性与实时性。 | 实时动态新视角合成、运动模式分析、可控动态编辑。 |
| 22 | Learnable Infinite Taylor Gaussian for Dynamic View Rendering | 用可学习 Taylor 展开描述主导时间变化，并用残差项补充高阶动态，提供更可解释的时序建模。 | 动态视图渲染、连续时间插值、可解释运动表示。 |
| 23 | MoDec-GS: Global-to-Local Motion Decomposition and Temporal Interval Adjustment for Compact Dynamic 3D Gaussian Splatting | 用 anchor-based Scaffold-GS、全局到局部运动分解和时间区间自适应调整来压缩动态表示。 | 紧凑动态场景重建、长视频压缩、移动端播放。 |
| 24 | DGD: Dynamic 3D Gaussians Distillation | 从基础模型蒸馏逐高斯语义特征，使动态高斯拥有对象级、文本级或点击级选择和编辑能力。 | 动态场景语义编辑、目标跟踪、语言交互式选择。 |
| 25 | TRACE: Learning 3D Gaussian Physical Dynamics from Multi-view Videos | 将高斯建模为具有刚体粒子动力学的实体，并用数值积分预测未来运动，让高斯具备物理外推能力。 | 物理可预测动态场景、运动分割、未来帧预测。 |
| 26 | Time of the Flight of the Gaussians: Optimizing Depth Indirectly in Dynamic Radiance Fields | 用 C-ToF 原始测量建模动态辐射场，考虑低反射率、occupancy bias 和局部线性运动，间接优化深度。 | ToF 传感器动态重建、低纹理/弱光几何恢复。 |
| 27 | StreamGS: Online Generalizable Gaussian Splatting Reconstruction for Unposed Image Streams | 面向未定姿图像流做在线、可泛化的高斯重建，同时处理相机位姿估计和场景更新。 | 无位姿在线重建、机器人/AR 实时建图、图像流输入。 |
| 28 | BARD-GS: Blur-Aware Reconstruction of Dynamic Scenes via Gaussian Splatting | 显式考虑模糊形成过程，让动态高斯在模糊输入下恢复更清晰的几何和外观。 | 运动模糊视频、低快门动态拍摄、清晰新视角合成。 |
| 29 | MaGS: Reconstructing and Simulating Dynamic 3D Objects with Mesh-adsorbed Gaussian Splatting | 将高斯吸附到 mesh 上，把高质量渲染表示和可仿真的网格结构结合起来。 | 可仿真的动态物体、物理动画、网格资产生成。 |
| 30 | Mango-GS: Enhancing Spatio-Temporal Consistency in Dynamic Scenes Reconstruction using Multi-Frame Node-Guided 4D Gaussian Splatting | 用多帧节点引导来增强动态重建中的空间-时间一致性，减少逐帧漂移和局部不稳定。 | 稳定动态重建、长序列一致性优化、多帧约束场景。 |
| 31 | Frequency-aware Dynamic Gaussian Splatting | 通过频率感知分解或正则化区分低频主体运动和高频细节变化，兼顾稳定性和细节保真。 | 细节丰富的动态场景、纹理/运动频率复杂的视频重建。 |
| 32 | ODE-GS: Latent ODEs for Dynamic Scene Extrapolation with 3D Gaussian Splatting | 用 latent ODE 建模高斯动态，使模型不仅能插值，还能向未来时间外推。 | 动态场景预测、未来视角合成、连续时间模拟。 |
| 33 | FreeTimeGS: Free Gaussian Primitives at Anytime Anywhere for Dynamic Scene Reconstruction | 强调高斯 primitive 在时间和空间上的自由度，减少固定时间网格或固定拓扑约束。 | 自由时间插值、非规则动态、复杂出现/消失行为建模。 |
| 34 | Fracture-GS: Dynamic Fracture Simulation with Physics-Integrated Gaussian Splatting | 将物理断裂模拟与 Gaussian Splatting 结合，让高斯表示可表达破裂、碎裂等拓扑变化。 | 断裂仿真、破坏效果、物理动画渲染。 |
| 35 | Swift4D: Adaptive divide-and-conquer Gaussian Splatting for compact and efficient reconstruction of dynamic scene | 用自适应 divide-and-conquer 策略拆解动态场景，减少训练和表示负担。 | 高效动态重建、大规模动态场景、紧凑表示。 |
| 36 | PhysGaussian: Physics-Integrated 3D Gaussians for Generative Dynamics | 将 3DGS 粒子和 MPM 等物理模拟结合，使生成的高斯场景能产生符合物理的动态。 | 生成式物理动画、材质动态模拟、交互式物理内容。 |
| 37 | Grid4D: 4D Decomposed Hash Encoding for High-Fidelity Dynamic Gaussian Splatting | 用空间和时间分解的 3D hash encoding 加 directional attention 表达 4D 形变，提高动态细节和高保真重建能力。 | 高保真动态重建、复杂局部形变、动态细节恢复。 |
| 38 | Event-boosted Deformable 3D Gaussians for Dynamic Scene Reconstruction | 融合 event camera 和可形变 3DGS，联合建模 GS-threshold，并通过动态-静态分解增强高速运动恢复。 | 高速运动、低延迟动态重建、事件相机辅助重建。 |
| 39 | Instant Gaussian Stream | 用 feed-forward Anchor-driven Gaussian Motion Network 和关键帧细化实现快速、可泛化的流式动态重建。 | 快速在线重建、低延迟自由视点视频、泛化式动态场景处理。 |
| 40 | SplineGS: Learning Smooth Trajectories in Gaussian Splatting for Dynamic Scene Reconstruction | 用 NURBS 代表轨迹和 hash-MLP 权重学习平滑高斯轨迹，在不依赖额外平滑损失的情况下提升时序连续性。 | 长时序平滑动态重建、轨迹可控的动态场景。 |
| 41 | 1000+ FPS 4D Gaussian Splatting for Dynamic Scene Rendering | 通过空间-时间变化剪枝和关键帧时间滤波压缩动态表示，实现超高帧率 4DGS 渲染。 | 极高速动态渲染、实时交互、资源受限设备播放。 |
| 42 | MEGA: Memory-Efficient 4D Gaussian Splatting for Dynamic Scenes | 通过 DC-AC 颜色建模、时间-视角形变、熵约束 opacity、FP16/zip 等手段降低 4DGS 内存占用。 | 内存受限动态场景渲染、移动端/浏览器端部署。 |
| 43 | Dynamic Gaussian Splatting from Defocused and Motion-blurred Monocular Videos | 用 BP-Net 预测逐像素模糊核和强度，结合 blur-aware 稀疏化、densification 和 unseen-view supervision，从失焦和运动模糊单目视频恢复动态高斯。 | 失焦/运动模糊视频修复、单目动态新视角合成。 |
| 44 | STD-GS: Exploring Frame-Event Interaction for SpatioTemporal-Disentangled Gaussian Splatting to Reconstruct High-Dynamic Scene | 将 frame-event 交互、ClusterFormer 外观-运动聚类、对象级 4DGS 和事件亮度/光流一致性结合，处理高动态场景。 | 高动态范围和高速运动重建、事件+帧融合相机系统。 |
| 45 | VoxelSplat: Dynamic Gaussian Splatting as an Effective Loss for Occupancy and Flow Prediction | 不把高斯作为最终渲染资产，而是作为 occupancy 和 flow 预测的动态语义渲染损失，增强自动驾驶感知学习。 | 自动驾驶 3D occupancy、scene flow、BEV 感知训练监督。 |
| 46 | Superpoint Gaussian Splatting for Real-Time High-Fidelity Dynamic Scene Reconstruction | 将运动相似的高斯组成 superpoints，用关联矩阵和属性重建减少自由度，提升实时高保真动态重建。 | 实时动态重建、对象/部件级编辑、运动分组分析。 |
| 47 | Spike4DGS: Towards High-Speed Dynamic Scene Rendering with 4D Gaussian Splatting via a Spike Camera Array | 使用 spike camera array 和 MSDI 初始化，并通过 spike-pixel 协同监督恢复高速动态 4DGS。 | 超高速动态场景、传统相机难以捕获的快速运动。 |
| 48 | QUEEN: QUantized Efficient ENcoding of Dynamic Gaussians for Streaming Free-viewpoint Videos | 面向 FVV 流式传输设计全属性残差、量化 latent decoder、位置 gating 和梯度差动态 mask，降低码率。 | 低码率自由视点视频传输、网络端动态场景播放。 |
| 49 | MoE-GS: Mixture of Experts for Dynamic Gaussian Splatting | 用 mixture of experts 表示不同运动/形变模式，并通过 Volume-aware Pixel Router 或 weight splatting 做专家路由。 | 异质运动场景、高复杂动态新视角合成。 |
| 50 | Learning Physics-Grounded 4D Dynamics with Neural Gaussian Force Fields | 结合对象感知 3DGS、神经力场、ODE 积分和 Gaussian collision，学习可交互、物理扎根的 4D 动态。 | 物理视频预测、交互式 4D 场景、对象级力学建模。 |
| 51 | OmniPhysGS: 3D Constitutive Gaussians for General Physics-Based Dynamics Generation | 提出 Constitutive Gaussians 和多专家材质模型，并结合 MPM 与 text-to-video SDS 生成多材料物理动态。 | 文本引导物理动态生成、多材料仿真、生成式 4D 资产。 |
| 52 | Optimizing 4D Gaussians for Dynamic Scene Video from Single Landscape Images | 从单张风景图出发，通过深度提升、伪多视角、2D Eulerian flows 和 3D motion consistency 训练 4DGS。 | 单图动态化、风景 cinemagraph、图像到动态视频/4D 场景。 |
| 53 | A Compact Dynamic 3D Gaussian Representation for Real-Time Dynamic View Synthesis | 用 Fourier position approximation、linear quaternion approximation、光流损失和静态/动态分阶段训练，构建紧凑实时动态 3DGS。 | 紧凑动态表示、实时单目/少视角动态新视角合成。 |

## 2. 综合观察

这 53 篇工作大致可以分成五条主线。

第一条是运动表示：从早期的 canonical Gaussians + deformation MLP，逐步发展出 spline、NURBS、Taylor、ODE、low-rank basis、superpoint、motion scaffold、MoE experts 等结构。核心问题是如何用更少参数、更强先验表达复杂运动，同时避免逐高斯自由形变造成漂移。

第二条是输入先验：单目视频通常引入深度、光流、tracks、SAM/基础模型 mask；高速动态场景引入 event 或 spike；ToF 工作利用原始飞行时间测量。趋势是把传感器或基础模型的强先验转成节点、损失、初始化或不确定性，而不是只用 RGB photometric loss。

第三条是时序一致性与在线处理：SWinGS、ProDyG、3DGStream、StreamGS、Instant Gaussian Stream、QUEEN 等都在解决长序列、流式训练、在线传输问题。它们说明动态 3DGS 不只是一个离线重建问题，也逐渐变成可部署的 FVV/AR/机器人感知系统问题。

第四条是压缩和实时部署：MEGA、1000+ FPS 4DGS、QUEEN、MoDec-GS、Compact Dynamic 3DGS 等从时间滤波、残差编码、量化、basis 分解、属性近似等角度压缩模型。一个明显机会是把“训练时高容量”和“部署时低容量”分开设计。

第五条是物理、语义和可编辑性：PhysGaussian、TRACE、NGFF、OmniPhysGS、Fracture-GS 把高斯推进到物理仿真；DGD、From Tokens to Nodes、SC-GS、Template-free Articulated GS 则强调语义、节点和可控编辑。这些方向可以和基础动态重建结合，形成从“看起来对”到“可控制、可交互、可预测”的升级。

## 3. 10 个可以尝试的组合型 Idea

### Idea 1: Uncertainty-aware MoE Dynamic Gaussian Splatting

组合来源：USPLAT4D 的逐高斯不确定性，MoE-GS 的专家路由，Grid4D/SplineGS 的高容量形变专家。

要做的是把不确定性从一个 regularization/weighting 信号升级为专家路由信号。低不确定性区域使用轻量 motion basis 或 spline expert，高不确定性区域使用更强的 Grid4D/hash expert 或局部 MoE expert；同时在训练中用不确定性调节 photometric、depth、flow 和 temporal consistency loss。这样可以避免所有区域都走高容量网络，也避免遮挡边界和快速运动区域被低容量模型欠拟合。

预期适合单目动态重建和复杂异质运动场景。它不是直接复刻 MoE-GS，而是让“不确定性估计”参与专家选择、专家容量分配和损失调度。

### Idea 2: Basis-residual Streaming for Compact Free-viewpoint Video

组合来源：DynMF 的低秩运动基，QUEEN 的量化残差传输，MEGA/1000+ FPS 4DGS 的属性压缩和时序剪枝。

要做的是把动态 FVV 流式传输拆成“慢更新全局运动基 + 快更新稀疏残差包”。服务端先传一个共享 motion basis 和静态/低频 Gaussian 属性，随后每个时间段只传逐高斯 basis coefficient 残差、少量新增/删除高斯和高频颜色残差。接收端用轻量 decoder 解码残差，并用时序剪枝过滤对当前视角贡献低的高斯。

这个方向的目标是低码率、低延迟动态 FVV。它结合了 basis 表示和 residual streaming，而不是单纯压缩所有逐帧高斯属性。

### Idea 3: Event/Spike-guided Blur-aware Dynamic Reconstruction

组合来源：Event-boosted D3DGS、STD-GS、Spike4DGS 的高时间分辨率信号，BARD-GS 和 defocused/motion-blurred DGS 的 blur-aware 建模。

要做的是让 event/spike 信号不只是补充高速运动监督，也直接参与估计 RGB 帧的空间变化模糊核和时间曝光轨迹。模型可以用 event/spike 恢复曝光窗口内的亚帧轨迹，再把这些轨迹用于 blur rendering loss；RGB 提供颜色和低频外观，event/spike 提供边缘、速度和高频时间结构。

适合高速、低光照、运动模糊明显的动态场景。相比单独做 event 4DGS 或 blur-aware RGB 4DGS，这个组合把“去模糊”和“动态重建”的物理过程统一起来。

### Idea 4: Semantic Physical Editing for Dynamic Gaussian Assets

组合来源：DGD 的逐高斯语义蒸馏，Template-free Articulated GS / SP-GS 的部件级运动分组，NGFF/OmniPhysGS/PhysGaussian 的物理动态建模。

要做的是先把动态高斯分成语义对象和运动部件，再给每个对象/部件分配可学习或可选择的物理属性。用户可以用文本或点击选择“这块布”“这个轮子”“这团水”，然后施加力、改变材质或重设关节约束。渲染仍然用高斯，控制层则是语义部件 + 物理模型。

应用目标是可编辑 4D 资产，而不是只做重建。这个 idea 的关键在于把语义选择、部件化 motion representation 和物理仿真放在一个可交互系统里。

### Idea 5: Casual Monocular Dynamic Reconstruction with Scaffold-SLAM

组合来源：ProDyG 的渐进式单目动态重建，MoSca 的 4D motion scaffold，MoDGS 的深度/ordinal depth 先验，StreamGS 的无位姿在线处理。

要做的是构建一个面向随手拍视频的在线 pipeline：先用 SLAM/pose tracking 维护相机和静态背景，再用 depth、tracks、flow 估计动态 motion scaffold；对于 pose 不稳定或遮挡严重的片段，用 ordinal depth 和不确定性降低几何崩坏风险。模型应该边看视频边更新，而不是等全序列离线优化。

目标是手机视频、手持相机、旅游/街景动态场景。它组合的是在线 SLAM、motion scaffold 和单目深度先验，比单篇方法更偏完整系统。

### Idea 6: Lifetime-aware Compact 4D Gaussian Primitives

组合来源：FreeTimeGS 的自由时间高斯，Compact Dynamic 3DGS 的 Fourier/linear quaternion 近似，1000+ FPS 4DGS 的时空剪枝，QUEEN 的 position gating。

要做的是给每个动态高斯显式建模生命周期，包括 birth time、death time、活跃区间和区间内的低阶时间函数。静态或缓慢区域用低阶 Fourier/linear 近似；短暂出现、快速运动或拓扑变化区域允许更短生命周期和更高阶 basis；部署时只加载当前时间附近活跃的高斯。

这个方向适合长视频和有出现/消失行为的动态场景。它不是只压缩属性，而是把“什么时候存在”作为动态高斯的第一等属性。

### Idea 7: Mesh-Gaussian-Physics Bridge for Exportable Dynamic Scenes

组合来源：DG-Mesh 的时间一致网格提取，MaGS 的 mesh-adsorbed Gaussians，TRACE/PhysGaussian/NGFF 的物理动态。

要做的是建立双层表示：外层是时间一致 mesh，用于碰撞、拓扑约束、资产导出和传统图形工具兼容；内层或表面吸附层是 Gaussians，用于高保真外观渲染。训练时高斯提供 photometric supervision，mesh 提供几何一致性和物理约束；编辑或仿真时由 mesh 驱动大运动，高斯补充细节和外观。

应用场景是“重建后还要拿去用”的动态资产，包括游戏、动画、AR 和物理交互。它补足纯高斯难以导出、纯 mesh 难以高保真的缺口。

### Idea 8: Foundation-prior Adaptive Node Allocation

组合来源：From Tokens to Nodes 的 VFM token 节点初始化，DGD 的语义蒸馏，USPLAT4D 的不确定性，SplineGS/NURBS SplineGS 的平滑轨迹。

要做的是用基础视觉模型特征、语义边界、motion tracks 和不确定性共同决定 motion node 的数量、位置和轨迹阶数。语义边界附近、运动不连续处、高不确定性区域分配更多节点和更高阶 spline；刚性背景或低频运动区域只保留少量低阶节点。节点本身带语义标签，后续可以用于对象级控制。

这个 idea 主要优化 motion scaffold 或 node-based dynamic GS 的容量分配问题。它的价值在于把节点生成从启发式采样改成 foundation-prior + uncertainty-aware 的自适应过程。

### Idea 9: Occlusion-aware Deblurring Dynamic GS with Static-Dynamic Decomposition

组合来源：Dynamic DGS from defocused/motion-blurred videos 的 BP-Net blur kernel，DeGauss 的动态-静态分解，MoDGS 的 depth priors，VoxelSplat 中把渲染作为监督信号的思路。

要做的是在模糊单目视频中同时估计静态背景、动态前景、遮挡层次和模糊核。静态背景和动态物体使用不同的 blur model；深度和遮挡关系决定曝光窗口内哪些高斯对某像素可见；未见视角的 weak rendering loss 用来防止去模糊后几何过拟合到训练视角。

适合遮挡多、运动模糊重的单目视频。它不是单纯 deblur，而是把 deblur、层分解、深度和动态高斯可见性放在一起优化。

### Idea 10: Train-heavy, Deploy-light Dynamic Gaussian Distillation

组合来源：MoE-GS 的多专家高容量训练，Swift4D 的 divide-and-conquer，SP-GS 的 superpoint 表示，MEGA/Compact Dynamic 3DGS 的轻量属性近似。

要做的是训练阶段使用高容量 MoE、hash deformation、局部窗口和多种先验，把动态场景拟合到尽量好；部署阶段再把结果蒸馏成 superpoint/basis/compact function 形式。蒸馏目标不仅包括 RGB，还包括 flow、depth、motion grouping、uncertainty 和 temporal smoothness，使轻量模型继承高容量模型的运动结构。

目标是把研究型高质量 dynamic GS 变成可部署资产。它承认“最佳训练表示”和“最佳部署表示”未必相同，把复杂模型当 teacher，把 compact dynamic GS 当 student。

## 4. 优先级建议

如果目的是较快做出可验证原型，优先尝试 Idea 1、Idea 6 和 Idea 10：它们多数可以在现有 dynamic GS 代码上改 motion representation、routing 或 distillation，不强依赖特殊传感器。

如果目的是做有差异化的系统论文，优先尝试 Idea 3、Idea 4 和 Idea 7：它们跨 RGB/event/spike、语义编辑、物理和 mesh 资产，应用场景更鲜明，但工程成本也更高。

如果目的是面向真实用户或产品化，优先尝试 Idea 2 和 Idea 5：一个面向 FVV 传输，一个面向手机随手拍动态重建，都更接近部署问题。
