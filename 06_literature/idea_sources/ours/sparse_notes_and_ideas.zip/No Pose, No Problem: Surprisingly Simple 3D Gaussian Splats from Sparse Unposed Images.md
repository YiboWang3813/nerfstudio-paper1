---
title: "No Pose, No Problem: Surprisingly Simple 3D Gaussian Splats from Sparse Unposed Images"
authors: "Botao Ye, Sifei Liu, Haofei Xu, Xueting Li, Marc Pollefeys, Ming-Hsuan Yang, Songyou Peng"
year: 2025
venue: "ICLR 2025"
zotero_item_key: "8XZKQTXW"
pdf_attachment_key: "FTLNPFPV"
pdf_path: "/Users/wangyibo/Zotero/storage/FTLNPFPV/Ye 等 - 2025 - NO POSE, NO PROBLEM SURPRISINGLY SIMPLE 3D GAUSSIAN SPLATS FROM SPARSE UNPOSED IMAGES.pdf"
note_path: "notes/No Pose, No Problem: Surprisingly Simple 3D Gaussian Splats from Sparse Unposed Images.md"
tags: ["3D Gaussian Splatting", "pose-free reconstruction", "sparse-view synthesis", "generalizable reconstruction", "canonical space"]
---

## 0. 一句话总结

NoPoSplat 是一个 pose-free feed-forward 3DGS 方法：给定未标定的 sparse multi-view images 和相机内参，它把第一张输入图的局部相机坐标系设为 canonical space，直接预测所有输入视图对应的 Gaussian 到这个统一空间中，只用 photometric loss 训练，并可进一步用预测出的 Gaussian centers 做两阶段相对位姿估计。

## 1. 问题与动机

现有高质量 generalizable sparse-view 3DGS 方法如 pixelSplat、MVSplat 通常需要准确输入相机位姿。这些位姿往往来自 dense video 的 COLMAP/SfM，但真实应用中只有两三张图时 SfM 容易失败，尤其在低纹理或低重叠场景。

已有 pose-free NVS 方法常先估 pose 再重建，pose 错误会污染重建，重建错误又反过来影响 pose，形成误差累积。NoPoSplat 的动机是避开“先估姿态”的环节，直接在一个 canonical Gaussian space 中预测可渲染 3D 表示，让网络自己学习多视图融合。

## 2. 适用场景

该方法适合 unposed sparse-view scene reconstruction，输入可以少到两张图，输出用于 novel view synthesis、relative pose estimation 和下游 3D 表示。它可用于 RealEstate10K/ACID 这类视频数据，也可 zero-shot 泛化到 DTU、ScanNet++，还可处理手机随拍图和 Sora 生成视频帧。

它仍需要相机内参，论文假设内参通常可从现代设备获得；对于生成图像则可用经验焦距。方法当前只处理静态场景。

## 3. 方法定位

NoPoSplat 属于 generalizable pose-free 3D Gaussian reconstruction。它和 FreeSplatter 都处理未标定 sparse views，但 NoPoSplat 强调一个 surprisingly simple 的 canonical-space Gaussian prediction，并且只用 RGB photometric loss 训练，不需要 ground-truth depth 或 explicit matching loss。

相对 pose-required local-to-global Gaussian 方法，NoPoSplat 不在每个视图局部坐标系中先预测 Gaussian 再用 pose transform and fuse，而是直接输出所有视图的 Gaussian 到第一视图 canonical coordinate 中。

## 4. 核心创新

第一，提出 canonical Gaussian space。第一张输入图的相机坐标系被固定为全局参考系，所有输入视图的 Gaussian 参数都直接预测到该空间中，从而消除对输入 pose 的依赖。

第二，使用纯 ViT encoder-decoder，不注入 epipolar constraint、cost volume 等几何先验。作者发现，在低 overlap 场景中，依赖 overlap 的几何操作反而受限，简单 ViT 更鲁棒。

第三，系统研究 camera intrinsic embedding 对 scale ambiguity 的影响。由于仅从图像外观预测 3D 场景存在尺度不确定性，作者将内参转成 token 与 image tokens 拼接，显著改善尺度和重建质量。

第四，提出两阶段 pose estimation。先用 predicted Gaussian centers 通过 PnP-RANSAC 得到粗相对位姿，再固定 Gaussian、用 photometric loss 优化相机位姿。

## 5. 方法细节

输入是 $V$ 张未标定位姿图像及其内参 $\{(I^v,k^v)\}_{v=1}^{V}$。网络输出每个像素对应的 Gaussian 参数集合，包括 center $\mu\in\mathbb{R}^3$、opacity $\alpha$、quaternion rotation $r\in\mathbb{R}^4$、scale $s\in\mathbb{R}^3$ 和 SH color $c$：

$$
f_\theta:\{(I^v,k^v)\}_{v=1}^{V}\mapsto \{\mu_j^v,\alpha_j^v,r_j^v,s_j^v,c_j^v\}_{v,j}
$$

pipeline 包括 ViT encoder、ViT decoder 和 Gaussian parameter heads。RGB 图像被 patchify 成 image tokens，与 intrinsic token 拼接后分别进入共享权重的 ViT encoder。decoder 中，不同视图特征通过 cross-attention 交互。

Gaussian heads 使用 DPT-style architecture。center head 只使用 transformer decoder features；其余 Gaussian parameter head 除 decoder features 外还输入 RGB image shortcut，以保留纹理细节，因为 ViT decoder 特征下采样 16 倍，偏语义而缺少局部结构。

canonical space 定义为第一张输入图坐标系。第一视图 pose 为 $[U|0]$，其中 $U$ 是 identity rotation。对于第 $v$ 个输入视图，网络直接预测位于第一视图坐标系中的 Gaussian 参数，记作 $\mu_j^{v\to 1},r_j^{v\to 1},c_j^{v\to 1},\alpha_j,s_j$。

内参编码比较了三种方式：global intrinsic addition、global intrinsic concat 和 dense intrinsic embedding。默认使用 global intrinsic concat：将 $k=[f_x,f_y,c_x,c_y]$ 经过线性层得到 intrinsic token，并与 image tokens 拼接。没有内参时会出现尺度 misalignment 和模糊。

训练时，预测出的 3D Gaussians 用 ground-truth target camera poses 渲染 novel views，监督为 MSE 和 LPIPS 组合，权重分别为 1 和 0.05：

$$
L=L_{MSE}+0.05L_{LPIPS}
$$

relative pose estimation 分两步。第一步用 Gaussian centers 和像素对应关系做 PnP-RANSAC 得到初始 pose。第二步固定 Gaussian 参数，优化相机 pose，使渲染图与输入 view 在 photometric loss 和 SSIM structural part 下对齐。附录中 refinement 为 200 steps、学习率 $5\times 10^{-3}$，约 2 秒。

## 6. 实验设置

NVS 主实验在 RealEstate10K 和 ACID 上分别训练和评估。输入图像对按 overlap ratio 分为 small（5%-30%）、medium（30%-55%）和 large（55%-80%），overlap 由 RoMA dense matching 估计。

zero-shot 泛化测试包括 DTU、ScanNet 和 ScanNet++。pose estimation 在 RE10K、ACID、ScanNet-1500 上评估，指标为 AUC@5、AUC@10、AUC@20。NVS 指标为 PSNR、SSIM、LPIPS。

实现中 encoder 是 ViT-large、patch size 16，decoder 是 ViT-base。encoder/decoder 和 Gaussian center head 以 MASt3R 权重初始化，其余层随机初始化；论文也报告不用 MASt3R 预训练、仅 RGB 监督也能训练到接近性能。

## 7. 主要结果

RE10K 上，NoPoSplat 平均达到 25.033 PSNR、0.838 SSIM、0.160 LPIPS，显著超过 pose-free CoPoNeRF 的 18.938 PSNR 和 Splatt3R 的 15.318 PSNR，也略高于 pose-required MVSplat 的 23.977 PSNR。small overlap 下优势更明显：NoPoSplat 为 22.514 PSNR，高于 MVSplat 的 20.353。

ACID 上，NoPoSplat 平均达到 25.961 PSNR、0.781 SSIM、0.189 LPIPS，超过 pose-free CoPoNeRF 的 20.950 PSNR，也略高于 pose-required pixelSplat 和 MVSplat 的平均 PSNR。

zero-shot 泛化中，只在 RE10K 训练后，DTU 上 NoPoSplat 达到 17.899 PSNR、0.629 SSIM、0.279 LPIPS，高于 MVSplat 的 13.929 PSNR；ScanNet++ 上达到 22.136 PSNR、0.798 SSIM、0.232 LPIPS，高于 pixelSplat、MVSplat 和 Splatt3R。

pose estimation 中，RE10K 上 Ours* 达到 AUC@5/10/20 为 0.691/0.806/0.877，优于 RoMA 的 0.546/0.698/0.797。ACID 上 Ours* 为 0.486/0.617/0.728，优于 RoMA 的 0.463/0.588/0.689。ScanNet-1500 上 Ours* 的 AUC@20 为 0.717，也优于 RoMA 的 0.655。

效率方面，NoPoSplat 在 RTX 4090 上用两张 256 x 256 图预测 3D Gaussians 只需 0.015 秒，约 66 FPS，快于 pixelSplat 的 0.081 秒和 MVSplat 的 0.028 秒。

## 8. 消融与分析

canonical space 消融显示，在相同 backbone/head 下，pose-required transform-then-fuse 得到 24.632 PSNR、0.834 SSIM、0.167 LPIPS，而 canonical pose-free prediction 得到 25.033 PSNR、0.838 SSIM、0.160 LPIPS。说明绕开 local-to-global transform/fuse 不仅让方法 pose-free，还提升了融合质量。

内参编码消融显示，无 intrinsic embedding 时性能降到 23.543 PSNR、0.780 SSIM、0.186 LPIPS，并出现尺度错位和模糊。dense embedding 为 24.809 PSNR，global addition 为 24.952 PSNR，global concat token 最好。

去掉 RGB shortcut 后性能为 24.279 PSNR、0.810 SSIM、0.183 LPIPS，纹理丰富区域更模糊。加入第三个输入视图后性能提升到 26.619 PSNR、0.872 SSIM、0.127 LPIPS，说明模型能自然受益于更多 unposed input views。

## 9. 与相关工作的关系

相对 pixelSplat/MVSplat，NoPoSplat 不需要 input pose，也不使用 epipolar geometry 或 cost volume；低 overlap 场景下反而更强，因为这些几何 prior 依赖足够重叠。

相对 DUSt3R/MASt3R/Splatt3R，NoPoSplat 不依赖 per-pixel depth loss 或 frozen pointmap 模块，而是直接训练可渲染 Gaussian field。Splatt3R 继承 MASt3R 的点云尺度和融合问题，NoPoSplat 通过 canonical Gaussian prediction 更一致。

相对 FreeSplatter，NoPoSplat 同样从 unposed images 直接预测 Gaussian 和 pose，但 NoPoSplat 的训练目标更简洁，强调只用 photometric loss 和 intrinsic token 解决 scale ambiguity。

## 10. 优点

最大优点是 pipeline 简洁：不先估 pose、不做 local-to-global transform、不建 cost volume，只用 ViT 和 photometric supervision 就能实现 pose-free Gaussian reconstruction。

第二个优点是 canonical space 带来一致融合。所有视图的 Gaussian 直接位于同一参考空间中，减少了 transform-then-fuse 的 misalignment 和 ghosting。

第三个优点是应用范围广。它既能做 NVS，也能从 reconstructed Gaussian centers 估计 relative pose，还能处理手机照片和视频生成模型输出的 unposed frames。

## 11. 局限

论文指出当前方法只适用于静态场景，动态场景扩展仍是未来方向。方法还需要相机内参；虽然手机 EXIF 或启发式焦距可用，但内参错误会影响尺度和渲染。

另一个限制是 evaluation-time pose alignment。为了公平比较 NVS，论文对 target camera pose 做优化，这在真实应用中不是必需，但会让和 pose-required 方法的指标比较更复杂。

## 12. 可复现要点

复现时要严格使用第一输入视图作为 canonical coordinate。所有 view 的 Gaussian center 都直接输出到第一视图坐标系，而不是先输出各自 local depth 再用 pose 转换。

intrinsic token 很关键。将 $[f_x,f_y,c_x,c_y]$ 线性映射为 token 并与 image tokens concat 是默认最佳设置。Gaussian parameter head 中保留 RGB shortcut，否则 texture-rich 区域会明显变糊。

pose estimation 复现时，先 PnP-RANSAC 得到粗 pose，再固定 Gaussian 做 200 步 photometric refinement。若不做 refinement，速度更快但精度下降。

## 13. 可能扩展

一个扩展是把 NoPoSplat 的 canonical space 与动态场景表示结合，例如为不同时间帧预测 shared canonical Gaussian 加 deformation field，实现 unposed dynamic sparse-view reconstruction。

第二个扩展是用不确定性处理 scale 和 pose ambiguity，对内参不准或 overlap 很低的输入输出 confidence，指导 downstream pose refinement 或 view selection。

第三个扩展是和生成模型结合：先用 text/video diffusion 生成 sparse frames，再用 NoPoSplat 建 Gaussian，并用生成模型反向补不确定区域，形成 pose-free text/image-to-3D pipeline。

## 14. 个人理解

NoPoSplat 的关键启发是：pose-free 3DGS 不一定要“先求 pose 再重建”。如果网络直接在一个 canonical space 中预测多视图一致的 Gaussian，pose 可以成为重建后的副产品，而不是重建前的必要输入。

这篇文章也说明，很多看似必要的几何模块在低 overlap sparse-view 场景下可能成为限制。纯 ViT 没有显式 epipolar/cost volume 假设，反而能更灵活地从外观学习跨视图关系；内参 token 则提供了最小但关键的尺度信息。
