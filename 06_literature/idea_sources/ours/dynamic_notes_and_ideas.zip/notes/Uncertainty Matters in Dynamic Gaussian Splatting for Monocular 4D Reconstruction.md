# Uncertainty Matters in Dynamic Gaussian Splatting for Monocular 4D Reconstruction

## 0. Metadata

* Title: Uncertainty Matters in Dynamic Gaussian Splatting for Monocular 4D Reconstruction
* Authors: Fengzhi Guo; Chih-Chuan Hsu; Sihao Ding; Cheng Zhang
* Year: 2026
* Venue: ICLR 2026
* PDF source: `/Users/wangyibo/Zotero/storage/YUWWNKKI/Guo 等 - 2026 - UNCERTAINTY MATTERS IN DYNAMIC GAUSSIAN SPLATTING FOR MONOCULAR 4D RECONSTRUCTION.pdf`
* Zotero item key: RDECX89N
* Zotero PDF attachment key: YUWWNKKI
* Local note path: `/Users/wangyibo/Documents/ZoteroLocalNotes/notes/Uncertainty Matters in Dynamic Gaussian Splatting for Monocular 4D Reconstruction.md`
* Code: project page reports code, `https://tamu-visual-ai.github.io/usplat4d/`
* Project page: `https://tamu-visual-ai.github.io/usplat4d/`
* Dataset link: Not specified
* Main task: monocular 4D reconstruction and dynamic novel view synthesis under occlusion / extreme novel views
* Domain: dynamic Gaussian Splatting, monocular 4D reconstruction, uncertainty modeling, graph optimization
* Input: monocular dynamic video, camera poses, an initial dynamic Gaussian Splatting prior from a base model such as SoM or MoSca
* Output: uncertainty-aware 4D Gaussian representation and novel-view renderings
* Main representation: time-varying 3D Gaussians plus uncertainty-weighted spatio-temporal graph
* Supervision type: image reconstruction supervision, inherited 2D priors from base models, graph / motion regularization
* Core contribution in one sentence: 把逐 Gaussian 的时变不确定性估计引入 monocular dynamic Gaussian Splatting，并用它选择 key nodes、构建 uncertainty-aware graph、重加权优化损失，从而让可靠 Gaussian 作为 anchor 传播运动信息到遮挡或弱观测区域。
* Note status: `partial`

`partial` 的原因：论文给出了核心公式、graph 构建和 appendix loss，但具体 base-model 训练配置依赖 SoM / MoSca 集成细节，部分实现超参仍需要项目代码确认。

## 1. One-Sentence Technical Summary

这篇论文处理 monocular 4D reconstruction 中遮挡和 extreme novel view 下的运动漂移问题，通过估计每个 3D Gaussian 在每个时间帧的可靠性 / 不确定性，将低不确定性的 Gaussian 选作 key nodes，并构建 uncertainty-aware spatio-temporal graph 来约束 non-key Gaussians 的 DQB 插值和训练损失，关键技术增量是把 uncertainty 从辅助标量提升为 node selection、edge construction、loss weighting 的核心控制信号。

Evidence: Abstract, Sec. 1, Sec. 4, Fig. 2, PDF p.1-4.

## 2. Problem Formulation

### 2.1 Task Definition

* 任务：从 monocular dynamic video 重建可在任意时间和视角渲染的 4D Gaussian scene。
* 输入：单目视频、相机轨迹、由 SoM / MoSca 等 base dynamic GS 方法给出的 per-Gaussian motion prior。
* 输出：优化后的 dynamic Gaussians、per-Gaussian uncertainty、key/non-key graph，以及 novel-view rendering。
* 关键假设：被反复清楚观测到的 Gaussian 更可靠，可作为 anchor；遮挡、弱观测或 extreme view 区域的 Gaussian 应被低置信度处理。
* 优化目标：在 photometric / perception loss 基础上，增加 uncertainty-aware key node loss 和 non-key interpolation loss，使可靠节点约束不可靠节点。

Evidence: Sec. 3, Sec. 4, PDF p.3-7.

### 2.2 Formal Notation

| Symbol | Meaning | Evidence |
| ------ | ------- | -------- |
| $G_t=(p_t,q_t,s,\alpha,c)$ | time-varying Gaussian state | Eq. 1, Sec. 3 |
| $p_t \in \mathbb{R}^3$ | Gaussian position at time $t$ | Eq. 1 |
| $q_t \in \mathbb{R}^4$ | quaternion rotation at time $t$ | Eq. 1 |
| $s,\alpha,c$ | scale, opacity, color coefficients | Eq. 1 |
| $u_{i,t}$ | scalar uncertainty of Gaussian $i$ at frame $t$ | Eq. 5, Sec. 4.1 |
| $U_{i,t}$ | depth-aware anisotropic uncertainty matrix | Eq. 6 |
| $V_k,V_n$ | key node set and non-key node set | Sec. 4.2 |
| $E_i$ | graph edges of node $i$ | Eq. 7-8 |
| $U_{w,t,i}$ | uncertainty weight used in graph distances / losses | Sec. 4.2-4.3 |
| $p^o_{i,t}$ | pretrained / initial Gaussian position from base model | Eq. 9, Eq. 11 |
| $p^{DQB}_{i,t},q^{DQB}_{i,t}$ | non-key node position / rotation from Dual Quaternion Blending | Eq. 10 |

### 2.3 Why This Problem Is Hard

| Claimed difficulty | Technical reason | Evidence |
| ------------------ | ---------------- | -------- |
| Monocular dynamic reconstruction is underconstrained | occlusion and extreme novel views leave many surfaces weakly observed | Abstract, Sec. 1 |
| Uniform optimization causes drift | vanilla dynamic GS updates all primitives with similar strength regardless of observation reliability | Sec. 1, Sec. 4.1 |
| 2D priors are unstable under occlusion | depth, optical flow, photometric consistency may fail behind occluders or far from input trajectory | Sec. 3 |
| Local distance graph is insufficient | local kNN / global min-max distances can connect unreliable primitives or miss long-range coherent motion | Sec. 4.2 |
| Base models may already have flawed priors | the method inherits limits from visual foundation model tracks and initial 4D Gaussian priors | Sec. 6, Appendix E |

## 3. Method Overview

### 3.1 High-Level Pipeline

Step 1:
Input: monocular video and an initial dynamic Gaussian prior from a base method.
Operation: represent each Gaussian over time as $G_t=(p_t,q_t,s,\alpha,c)$ and render with standard dynamic GS objectives.
Output: initial trajectories and rendering residuals.
Purpose: provide a prior motion field before uncertainty-aware refinement.
Evidence: Sec. 3, Sec. 4 overview.

Step 2:
Input: rendered colors, ground-truth colors, Gaussian blending weights.
Operation: derive per-Gaussian scalar uncertainty from the photometric loss variance and convergence indicator.
Output: $u_{i,t}$ for each Gaussian and frame.
Purpose: distinguish reliable / well-observed primitives from ambiguous ones.
Evidence: Sec. 4.1, Eq. 2-5; Appendix A.1.

Step 3:
Input: scalar uncertainty and camera orientation.
Operation: lift scalar uncertainty to anisotropic depth-aware 3D uncertainty matrix $U_{i,t}=R_{wc}U_cR_{wc}^T$.
Output: uncertainty ellipsoid / matrix per Gaussian per frame.
Purpose: reflect monocular depth ambiguity and avoid over-confidence along camera axis.
Evidence: Sec. 4.1, Eq. 6.

Step 4:
Input: per-Gaussian uncertainty over time.
Operation: select key nodes by voxelized spatial sampling plus significant-period threshold, then assign remaining Gaussians as non-key nodes.
Output: $V_k$ and $V_n$.
Purpose: use reliable, repeatedly observed Gaussians as motion anchors.
Evidence: Sec. 4.2, Fig. 2.

Step 5:
Input: key / non-key nodes and uncertainty matrices.
Operation: construct uncertainty-aware kNN edges for key nodes and assign non-key nodes to closest key nodes over the sequence.
Output: uncertainty-encoded graph $G=(V,E)$.
Purpose: propagate stable motion cues across space and time.
Evidence: Sec. 4.2, Eq. 7-8.

Step 6:
Input: graph, initial Gaussian states, rendered images.
Operation: optimize key node loss, non-key DQB interpolation loss, motion losses, and photometric / perception loss.
Output: refined USPLAT4D representation.
Purpose: stabilize motion under occlusion and improve extreme-view rendering.
Evidence: Sec. 4.3, Eq. 9-12; Appendix A.2.

### 3.2 Core Idea

* Representation-level idea: dynamic 3D Gaussians remain the primitive, but each Gaussian gets a time-varying reliability estimate.
* Graph-level idea: uncertainty determines which Gaussians are anchors, which edges are trustworthy, and how non-key nodes inherit motion.
* Optimization-level idea: key nodes stay close to reliable prior trajectories; non-key nodes are softly regularized to initialization and DQB-interpolated key-node motion.
* Training-level idea: total loss combines base photometric / perception losses with uncertainty-aware graph losses.
* Generalization idea: the framework is model-agnostic and can wrap SoM, MoSca, or other per-Gaussian motion models.

Evidence: Sec. 4 overview, Sec. 5.1.

### 3.3 Method Diagram Reconstruction

Figure 2 shows:
* input: vanilla dynamic GS output / initialization from monocular video.
* uncertainty estimation: compute low/high uncertainty per Gaussian over time.
* key node selection: keep stable low-uncertainty Gaussians as key nodes.
* graph construction: key graph plus non-key graph interpolation; edges carry confidence.
* optimization: key node and non-key node losses plus perception losses.
* output: spatio-temporally consistent 4DGS with improved extreme novel view rendering.

Evidence: Fig. 2, PDF p.4.

## 4. Method Details

### 4.1 Dynamic Uncertainty Estimation

* Module purpose: estimate how reliably each Gaussian is constrained at each frame.
* Input: pixel reconstruction residuals, blending weights $T^h_{i,t}\alpha_i$, contributed pixel set $\Omega_{i,t}$.
* Output: scalar uncertainty $u_{i,t}$ and depth-aware uncertainty $U_{i,t}$.
* Internal operations: derive color variance from L2 photometric loss, gate it by convergence indicator, then transform into 3D covariance-like uncertainty.
* Architecture details: no new neural architecture; this is an analytic uncertainty estimator inserted into dynamic GS optimization.
* Mathematical formulation: Eq. 2-6.
* Trainable parameters: none directly; depends on current Gaussian rendering parameters.
* Hyperparameters: color threshold $\eta_c$, large uncertainty constant $\phi$, depth scaling factors $r_x,r_y,r_z$.
* Why this module is needed: uniform optimization cannot distinguish stable anchors from weakly observed drifting primitives.
* What would happen without it: ablation w/o key node uncertainty reduces DyCheck performance from 19.63 / 0.716 / 0.25 to 18.86 / 0.688 / 0.28.
* Evidence anchor: Sec. 4.1, Tab. 3, Appendix D.2/D.4.

Implementation-level reconstruction:
* For each frame, render current dynamic Gaussians and record per-pixel residuals.
* For each Gaussian, collect pixels it contributes to and compute variance inversely proportional to squared blending weights.
* If any covered pixel has L1 color error above $\eta_c$, assign large uncertainty $\phi$.
* Use camera-to-world rotation only, not translation, to transform axis-aligned uncertainty into world coordinates.
* Appendix reports default $[r_x,r_y,r_z]=[1,1,0.01]$ for experiments, but exact $\phi$ is Not specified in extracted text.

Relation to prior work:
* Unlike uncertainty used only for auxiliary smoothing / gradient reweighting, this method directly uses uncertainty for graph topology and loss weighting.

### 4.2 Key Node Selection

* Module purpose: choose stable Gaussians as graph anchors.
* Input: per-Gaussian uncertainty over frames.
* Output: key node set $V_k$ and non-key node set $V_n$.
* Internal operations: 3D gridization per frame, discard voxels containing only high-uncertainty Gaussians, sample one low-uncertainty candidate per remaining voxel, then keep candidates whose uncertainty remains below threshold for enough frames.
* Architecture details: discrete graph construction step.
* Mathematical formulation: significant period is a frame count where uncertainty is below a threshold.
* Trainable parameters: none.
* Hyperparameters: top 2% confident Gaussians / around 1000-th threshold, key/non-key ratio around 1:49, significant period threshold 5 frames.
* Why this module is needed: ensures spatial coverage and temporal stability of anchors.
* What would happen without it: random / non-grid selection degrades performance; removing key node uncertainty has the largest ablation drop.
* Evidence anchor: Sec. 4.2, Tab. 3, Appendix D.1/D.3.

Implementation-level reconstruction:
* Maintain per-frame voxel grid over 3D Gaussian positions.
* In each occupied reliable voxel, sample one low-uncertainty candidate.
* Retain candidate if it has at least 5 reliable frames.
* Label all other Gaussians non-key and handle them by interpolation from key graph.

Relation to prior work:
* More structured than random keypoint selection or soft motion score; it explicitly ties key selection to reliability and spatial coverage.

### 4.3 Uncertainty-Aware Graph Construction

* Module purpose: connect reliable key nodes and assign uncertain non-key nodes to stable anchors.
* Input: $V_k,V_n$, positions $p_{i,t}$, uncertainties $U_{w,t,i}$.
* Output: directed graph $G=(V,E)$.
* Internal operations: use UA-kNN for key nodes at their most reliable frame; for non-key nodes, choose closest key node across the whole sequence and inherit its neighborhood.
* Architecture details: graph over Gaussians, not a neural GNN.
* Mathematical formulation: Eq. 7-8.
* Trainable parameters: none in construction; graph then guides trainable Gaussian motion.
* Hyperparameters: kNN count $k$ Not specified in extracted text.
* Why this module is needed: local Euclidean kNN can connect unreliable or geometrically close but motion-incoherent nodes.
* What would happen without it: w/o UA-kNN reduces Table 3 metrics to 19.50 / 0.711 / 0.26.
* Evidence anchor: Sec. 4.2, Tab. 3.

Implementation-level reconstruction:
* For key node $i$, choose $\hat{t}=\arg\min_t u_{i,t}$.
* Build neighbors among $V_k \setminus \{i\}$ using an uncertainty-weighted Mahalanobis-like metric.
* For non-key node $i$, find key node minimizing accumulated uncertainty-weighted distance over all frames.
* Set non-key edges to that key node and the key node's edge set.

Relation to prior work:
* Extends graph-based motion modeling from distance-only kNN / scaffold interpolation toward uncertainty-aware topology.

### 4.4 Uncertainty-Aware Optimization

* Module purpose: refine motion and rendering by weighting reliable and unreliable Gaussians differently.
* Input: graph, initialized Gaussian states, image observations, base-model priors.
* Output: optimized USPLAT4D dynamic Gaussians.
* Internal operations: key node loss keeps anchors close to initialized states with uncertainty weights; non-key node loss balances initialization and DQB-interpolated trajectory; total loss includes photometric / perception loss.
* Architecture details: optimization objective rather than network module.
* Mathematical formulation: Eq. 9-12 and Appendix Eq. S7-S13.
* Trainable parameters: Gaussian positions / rotations / motion parameters inherited from base model; trainable motion parameters for local deviation are mentioned in appendix analysis.
* Hyperparameters: $\lambda_{iso}=1$, $\lambda_{rigid}=1$, $\lambda_{rot}=0.01$, $\lambda_{vel}=0.01$, $\lambda_{acc}=0.01$ in appendix; other base-model loss weights Not specified.
* Why this module is needed: prevents unreliable primitives from being updated as aggressively as reliable ones.
* What would happen without it: w/o loss weighting reduces PSNR / SSIM relative to full model.
* Evidence anchor: Sec. 4.3, Tab. 3, Appendix A.2.

Implementation-level reconstruction:
* First compute key graph and non-key assignment.
* For key nodes, optimize against initial positions and motion locality terms.
* For non-key nodes, compute DQB from neighbor transforms $T_{j,t}$ and normalized edge weights $w_{ij}$.
* Optimize total loss $L_{total}=L_{rgb}+L_{key}+L_{non-key}$.
* $L_{rgb}$ includes RGB L1 + SSIM and base-model priors such as mask, depth, depth gradient, and tracking losses.

Relation to prior work:
* Uses classic DQB for smooth non-key motion interpolation, but relaxes hard interpolation by uncertainty-weighted optimization.

## 5. Mathematical Objectives and Losses

| Loss / objective | Formula | Used for | Inputs | Weight | Evidence |
| ---------------- | ------- | -------- | ------ | ------ | -------- |
| Dynamic Gaussian state | $G_t=(p_t,q_t,s,\alpha,c)$ | define time-varying primitive | Gaussian parameters | Not applicable | Eq. 1 |
| Photometric L2 loss | $L_{2,t}=\sum_{h\in\Omega}\|\bar{C}^h_t-C^h_t\|_2^2$ | derive uncertainty | rendered / GT color | Not specified | Eq. 2 |
| Rendered color | $C^h_t=\sum_{i=1}^{N_g}T^h_{i,t}\alpha_i c_i$ | alpha blending contribution | blending weights and color | Not specified | Eq. 2 |
| Scalar variance | $\sigma^2_{i,t}=(\sum_{h\in\Omega_{i,t}}(T^h_{i,t}\alpha_i)^2)^{-1}$ | per-Gaussian reliability | contributed pixels | Not applicable | Eq. 3 |
| Convergence indicator | $\mathbf{1}_t(h)=1$ if $\|\bar{C}^h_t-C^h_t\|_1<\eta_c$, else 0 | detect unconverged pixels | color error | threshold $\eta_c$ | Eq. 4 |
| Final scalar uncertainty | $u_{i,t}=\mathbf{1}_{i,t}\sigma^2_{i,t}+(1-\mathbf{1}_{i,t})\phi$ | high uncertainty for unconverged Gaussians | variance and indicator | $\phi$ Not specified | Eq. 5 |
| Depth-aware uncertainty | $U_{i,t}=R_{wc}U_cR_{wc}^T$, $U_c=\mathrm{diag}(r_xu_{i,t},r_yu_{i,t},r_zu_{i,t})$ | anisotropic 3D uncertainty | camera rotation, scaling factors | $[1,1,0.01]$ in appendix | Eq. 6, Appendix D.4 |
| Key UA-kNN | $E_i=kNN_{j\in V_k\setminus\{i\}}\|p_{i,\hat{t}}-p_{j,\hat{t}}\|_{(U_{w,\hat{t},i}+U_{w,\hat{t},j})}$ | key graph edges | positions and uncertainty | $k$ Not specified | Eq. 7 |
| Non-key assignment | $j=\arg\min_{l\in V_k}\sum_{t=0}^{T-1}\|p_{i,t}-p_{l,t}\|_{(U_{w,t,i}+U_{w,t,l})}$ | assign non-key node to anchor | trajectories and uncertainty | Not specified | Eq. 8 |
| Key node loss | $L_{key}=\sum_{t=0}^{T-1}\sum_{i\in V_k}\|p_{i,t}-p^o_{i,t}\|_{U^{-1}_{w,t,i}}+L_{motion,key}$ | anchor stability | key node positions | uncertainty-weighted | Eq. 9 |
| DQB interpolation | $(p^{DQB}_{i,t},q^{DQB}_{i,t})=DQB(\{(w_{ij},T_{j,t})\}_{j\in E_i})$ | non-key target trajectory | neighbor transforms | Not specified | Eq. 10 |
| Non-key loss | $L_{non-key}=\sum\|p_{i,t}-p^o_{i,t}\|_{U^{-1}_{w,i}}+\sum\|p_{i,t}-p^{DQB}_{i,t}\|_{U^{-1}_{w,i}}+L_{motion,non-key}$ | stabilize non-key nodes | prior and DQB target | uncertainty-weighted | Eq. 11 |
| Total loss | $L_{total}=L_{rgb}+L_{key}+L_{non-key}$ | final optimization | rendering and graph terms | component weights Not specified | Eq. 12 |
| Motion locality loss | $L_{motion}=\lambda_{iso}L_{iso}+\lambda_{rigid}L_{rigid}+\lambda_{rot}L_{rot}+\lambda_{vel}L_{vel}+\lambda_{acc}L_{acc}$ | temporal / geometric regularization | Gaussian graph trajectories | $1,1,0.01,0.01,0.01$ | Eq. S13 |

For each loss:
* Uncertainty terms decide which residuals are trusted and how strongly motion updates propagate.
* Key node loss keeps reliable anchors close to initialized priors and motion-locality constraints.
* Non-key loss lets uncertain regions borrow key-node motion through DQB, but still remain near initialized states.
* Table 3 supports uncertainty usage by ablating key node uncertainty, UA-kNN, and loss weighting.

## 6. Training and Inference Procedure

### 6.1 Training Pipeline

| Item | Value | Evidence |
| ---- | ----- | -------- |
| Dataset | DyCheck, DAVIS, Objaverse, plus appendix results on NVIDIA and HyperNeRF | Sec. 5.1, Appendix C |
| Data split | DyCheck follows prior protocols; Objaverse uses one monocular video as input and remaining views for evaluation | Sec. 5.1, Appendix C.4 |
| Input resolution | DyCheck 1x / 2x protocols; exact image sizes Not specified | Tab. 1 |
| Preprocessing | initialize from base models SoM / MoSca; Objaverse rendered via Blender | Sec. 5.1, Appendix C.4 |
| Data augmentation | Not specified | Sec. 5 |
| Batch size | Not specified | Appendix B needed |
| Optimizer | Not specified in extracted text | Appendix B reference |
| Learning rate | Not specified in extracted text | Appendix B reference |
| LR schedule | Not specified | Appendix B reference |
| Epochs / iterations | runtime described as graph init plus training; exact iteration count Not specified | Appendix D.5 |
| Loss weights | motion locality weights partly specified: $\lambda_{iso}=\lambda_{rigid}=1$, others 0.01 | Appendix A.2 |
| Initialization | base model dynamic GS motion parameters from SoM / MoSca | Sec. 5.1, Appendix B |
| Hardware | runtime analysis on single NVIDIA H100 GPU | Appendix D.5 |
| Training time | uncertainty estimation negligible; graph construction about 3 sec/image; training about 4 sec/image; 200-frame DyCheck graph construction about 10 min and training about 13 min | Appendix D.5 |
| Code availability | project page provided | Abstract |

### 6.2 Inference Pipeline

| Item | Value | Evidence |
| ---- | ----- | -------- |
| Inference input | optimized dynamic Gaussians and target camera/time | Sec. 4-5 |
| Inference output | novel-view rendering and 4D reconstruction | Fig. 1, Fig. 3-6 |
| Test-time optimization | Not specified | Sec. 5 |
| Runtime | rendering speed for uncertainty estimation is described as fast, >60 FPS | Appendix D.5 |
| Memory | Not specified | Sec. 5 |
| Postprocessing | graph community detection only for analysis / segmentation visualization, not core rendering | Sec. 5.3, Fig. 7 |
| Failure cases | textureless regions, fast motion artifacts, highly deformable objects with poor priors | Appendix E |

### 6.3 Reproduction Checklist

Clearly specified:
* Compute scalar uncertainty from Eq. 3-5.
* Convert to depth-aware uncertainty with Eq. 6.
* Select key nodes by 3D gridization and significant period threshold.
* Build key graph with UA-kNN and non-key assignment.
* Optimize $L_{total}=L_{rgb}+L_{key}+L_{non-key}$.
* Use motion locality losses from Appendix A.2.

Not specified but inferable:
* Base model provides initial per-Gaussian trajectories and rendering pipeline.
* DQB implementation follows standard dual quaternion blending.
* Objaverse benchmark uses 121 frames and 12 circular camera views.

Missing / need human check:
* Exact optimizer, learning rate, iteration counts, and base model training configuration.
* Exact kNN value and edge weight normalization formula.
* Exact large uncertainty constant $\phi$.
* Whether all base-model 2D prior losses use identical weights to original implementations.

## 7. Experimental Setup and Results Summary

### 7.1 Datasets

| Dataset | Role | Size | Split | Modality | Preprocessing | Evidence |
| ------- | ---- | ---- | ----- | -------- | ------------- | -------- |
| DyCheck | main real-world benchmark | 5 scenes at 1x, 7 scenes at 2x in reported protocols | follows prior work | monocular dynamic video | validation views near input; extra extreme views sampled qualitatively | Sec. 5.1, Tab. 1 |
| DAVIS | qualitative generalization | selected challenging videos | Not specified | monocular videos with non-rigid motion / occlusion | qualitative extreme view evaluation | Sec. 5.1, Fig. 5 |
| Objaverse | synthetic extreme-view benchmark | 6 articulated objects; 121 frames; 12 circular cameras | one monocular video input, other 11 views evaluation | rendered RGB/depth/masks | Blender rendering, 30-degree horizontal evaluation ranges | Sec. 5.1, Appendix C.4 |
| NVIDIA | additional appendix evaluation | Not specified | follows RoDynRF pipeline | dynamic scene video | compare MoSca vs MoSca+USPLAT4D | Appendix C.6 |
| HyperNeRF | qualitative appendix evaluation | Not specified | Not specified | dynamic real-world scenes | compare to 4DGS | Appendix C.7 |

### 7.2 Baselines

| Baseline | Category | Why compared | Fairness concern | Evidence |
| -------- | -------- | ------------ | ---------------- | -------- |
| SoM | strong monocular 4D reconstruction base model | common base model and input prior | USPLAT4D wraps it, so gains depend on base prior quality | Sec. 5.1 |
| MoSca | state-of-the-art dynamic Gaussian fusion / scaffold method | strongest base model and comparison | same dependency on initialization and prior settings | Sec. 5.1 |
| SC-GS, Deformable 3DGS, 4DGS, MoDec-GS, MoBlender, Dynamic Gaussians, Gaussian Marbles | dynamic GS baselines | broad comparison on DyCheck | not all evaluated under exactly identical protocols | Tab. 1 |

### 7.3 Metrics

| Metric | Measures what | Used in which experiment | Higher/lower better | Evidence |
| ------ | ------------- | ------------------------ | ------------------- | -------- |
| PSNR / mPSNR | pixel reconstruction fidelity | DyCheck, Objaverse, appendix datasets | higher better | Tab. 1-2 |
| SSIM / mSSIM | structural similarity | DyCheck, Objaverse | higher better | Tab. 1-2 |
| LPIPS / mLPIPS | perceptual distance | DyCheck, Objaverse | lower better | Tab. 1-2 |
| Runtime | practical overhead | appendix runtime analysis | lower better | Appendix D.5 |

### 7.4 Results as Evidence Units

| Experiment | Purpose | Compared methods | Metrics | Main conclusion | Evidence strength | Evidence |
| ---------- | ------- | ---------------- | ------- | --------------- | ----------------- | -------- |
| DyCheck quantitative | evaluate near-input validation views | SC-GS, Deformable 3DGS, 4DGS, MoDec-GS, MoBlender, SoM, MoSca, others | mPSNR, mSSIM, mLPIPS | USPLAT4D improves over strong GS baselines; at 2x resolution it improves MoSca from 19.32 / 0.706 / 0.26 to 19.63 / 0.716 / 0.25 | strong | Tab. 1 |
| DyCheck extreme views | test severe viewpoint shift without GT | SoM, MoSca | qualitative | USPLAT4D better preserves fine structures and occluded regions | medium | Fig. 4 |
| DAVIS qualitative | test fast motion, deformation, occlusion | SoM, MoSca | qualitative | outputs more plausible geometry under extreme novel views | medium | Fig. 5 |
| Objaverse quantitative | evaluate extreme novel views with GT | SoM, MoSca | PSNR, SSIM, LPIPS across angle ranges | gains are stronger at larger viewpoint shifts, especially LPIPS | strong | Tab. 2 |
| Uncertainty / graph ablation | isolate key design choices | full vs w/o key uncertainty, w/o UA-kNN, w/o loss weighting, w/o 3D gridization | PSNR, SSIM, LPIPS | key node uncertainty and loss weighting are important; full model best | strong | Tab. 3 |
| Hyperparameter ablations | test key ratio, $\eta_c$, SPT, $r_z$ | varied settings | relative metrics | settings show broad plateaus; chosen values are not highly sensitive | medium | Tab. S6-S9 |
| Runtime analysis | estimate overhead | MoSca baseline vs USPLAT4D variants | seconds/image, total time | graph construction and training add cost but under-trained USPLAT4D can still beat MoSca in comparable time | medium | Appendix D.5, Tab. S10 |

## 8. Claimed Contribution vs Actual Technical Delta

| Claimed contribution | Actual technical change | Evidence | Is it novel? | Is it important? | Is it well supported? |
| -------------------- | ----------------------- | -------- | ------------ | ---------------- | --------------------- |
| uncertainty-aware dynamic GS | analytic per-Gaussian uncertainty from rendering residuals and blending weights | Sec. 4.1 | medium-high | high | yes |
| uncertainty-encoded graph | key/non-key split and UA-kNN edges based on uncertainty | Sec. 4.2 | medium | high | yes, Tab. 3 |
| uncertainty-aware optimization | key / non-key losses with uncertainty weighting and DQB interpolation | Sec. 4.3 | medium | high | yes |
| model-agnostic wrapper | integration with SoM and MoSca priors | Sec. 5.1, Appendix B | medium | high | partially, because details require code |
| improved extreme-view synthesis | qualitative and Objaverse quantitative evaluation under large angle shifts | Fig. 4-6, Tab. 2 | not a method novelty | high | yes |

实际技术边界：这不是一个从零开始的 dynamic GS architecture，而是一个 uncertainty-guided refinement / graph optimization layer，依赖已有 base dynamic Gaussian prior 的质量。

## 9. Limitations and Hidden Assumptions

### 9.1 Explicit Limitations

| Limitation | Evidence | Impact |
| ---------- | -------- | ------ |
| 受底层 visual foundation model / initial 4D prior 影响 | Sec. 6, Appendix E | 如果初始轨迹完全错误，uncertainty graph 没有可靠信息可传播 |
| textureless regions 仍困难 | Appendix E.1, Fig. S4 | 跟踪和先验缺少可靠特征，局部 motion 仍会错 |
| fast motion 仍有 rolling-shutter / consistency artifacts | Appendix E.2 | 快速动态区域难保持多视角一致 |
| highly deformable structures remain challenging under sparse observations | Appendix E.3 | 细长结构、肢体、耳朵等可能失真 |
| graph construction has nontrivial overhead | Appendix D.5 | 大序列可能有额外分钟级预处理成本 |

### 9.2 Inferred Limitations

| Inferred limitation | Why it may exist | Missing experiment | Possible consequence |
| ------------------- | ---------------- | ------------------ | -------------------- |
| 依赖相机位姿和 base rendering convergence | uncertainty uses rendering residual and camera rotation | pose-noise ablation | pose drift may corrupt uncertainty |
| key-node graph hyperparameters may affect topology | kNN, voxel size, threshold details not fully extracted | exhaustive graph hyperparameter sweep | bad graph may propagate wrong motion |
| evaluation near input views may understate extreme-view benefit | authors note DyCheck validation views are near input | quantitative real extreme-view GT | some claims rely on synthetic Objaverse |
| method may smooth rare but correct fast motions | graph propagation prefers stable anchors | fast-motion quantitative benchmark | loss may suppress outlier dynamics |

### 9.3 Hidden Assumptions

| Assumption | Where it appears | Risk if violated |
| ---------- | ---------------- | ---------------- |
| Low rendering uncertainty means reliable 3D motion | Sec. 4.1 | textureless or repeated texture can be photometrically plausible but geometrically wrong |
| Key nodes have enough coverage and motion diversity | Sec. 4.2 | key graph can miss small independent motions |
| Non-key motion can be interpolated from nearby reliable key nodes | Eq. 10-11 | topology changes or independent local deformation may fail |
| Initial base model contains recoverable structure | Sec. 5.1, Appendix E | graph refinement cannot create missing priors from nothing |

## 10. Matrix-Ready Summary

| Field | Value |
| ----- | ----- |
| paper_id | guoUNCERTAINTYMATTERSDYNAMIC2026 / RDECX89N |
| task | monocular 4D reconstruction; dynamic novel view synthesis under occlusion and extreme views |
| domain | dynamic Gaussian Splatting; uncertainty modeling; graph optimization |
| input | monocular video, camera poses, base dynamic GS prior |
| output | refined uncertainty-aware dynamic Gaussians and novel-view renderings |
| representation | time-varying 3D Gaussians plus uncertainty-weighted key/non-key graph |
| backbone | SoM / MoSca or other per-Gaussian motion dynamic GS methods |
| key_modules | dynamic uncertainty estimation; depth-aware uncertainty; key node selection; UA-kNN graph; DQB non-key interpolation; uncertainty-weighted losses |
| supervision | RGB / SSIM / base prior losses plus graph motion regularization |
| losses | $L_{total}=L_{rgb}+L_{key}+L_{non-key}$; motion locality loss with isometry, rigidity, rotation, velocity, acceleration |
| training_data | DyCheck, DAVIS, Objaverse; appendix NVIDIA and HyperNeRF |
| evaluation_data | DyCheck validation and extreme views; Objaverse angular ranges; DAVIS qualitative |
| metrics | PSNR, SSIM, LPIPS, runtime |
| baselines | SoM, MoSca, SC-GS, Deformable 3DGS, 4DGS, MoDec-GS, MoBlender, Dynamic Gaussians, Gaussian Marbles |
| ablations | w/o key node uncertainty, w/o UA-kNN, w/o loss weighting, w/o 3D gridization, key ratio, color threshold, SPT, depth scale |
| main_claim | uncertainty should guide which Gaussians anchor motion and how uncertain regions are optimized |
| actual_method_delta | analytic uncertainty estimates drive graph construction and uncertainty-weighted key/non-key losses |
| main_limitation | depends on initial dynamic GS prior; hard cases remain textureless regions, fast motion, severe deformation |
| reusable_component | uncertainty-aware key/non-key graph for any per-Gaussian motion model |
| possible_gap | combine uncertainty graph with pose refinement, stronger priors for textureless regions, or learned uncertainty calibration |

## 11. Reusable Components for My Research

| Component | What it does | How to reuse | Required changes | Risk |
| --------- | ------------ | ------------ | ---------------- | ---- |
| Per-Gaussian uncertainty estimator | converts rendering support / residual into reliability | attach to any Gaussian renderer that exposes blending weights | need access to per-Gaussian pixel contributions | wrong uncertainty if renderer not converged |
| Depth-aware uncertainty matrix | models monocular depth ambiguity anisotropically | use for pose / motion weighting in 3D Gaussian optimization | tune $r_x,r_y,r_z$ to camera motion | too small depth weight may under-regularize depth |
| Key/non-key node graph | separates anchors from interpolated uncertain primitives | use for dynamic scene motion propagation or segmentation | choose key ratio, voxel size, SPT | bad key selection propagates bad motion |
| UA-kNN | builds edges using uncertainty-weighted distance | replace Euclidean kNN in graph-based 4DGS | need stable uncertainty metric | can over-penalize directions with high uncertainty |
| DQB non-key interpolation | generates smooth non-key motion from key transforms | reuse for scaffold-like dynamic Gaussian motion | define edge weights and SE(3) transforms | overly smooth for independent local deformation |

## 12. Gap and Idea Seeds

| Gap / weakness | Evidence from this paper | Possible research direction | Minimal test |
| -------------- | ------------------------ | --------------------------- | ------------ |
| Initial prior dependence | Appendix E says no reliable prior means no meaningful signal to propagate | jointly learn uncertainty and motion from raw observations, not only as refinement | compare from weak vs strong initial priors |
| Textureless failure | Appendix E.1 | add semantic/shape priors or multi-frame silhouette constraints | Objaverse textureless objects ablation |
| Pose sensitivity not isolated | method uses camera rotation in Eq. 6 | combine with pose uncertainty / joint pose refinement | add synthetic pose noise |
| Graph topology is hand-designed | key ratio, SPT, kNN are manual | learn graph edges or confidence calibration | compare learned edge weights vs UA-kNN |
| Fast motion artifacts remain | Appendix E.2 | add rolling-shutter / event / optical-flow uncertainty modeling | fast-motion benchmark with GT |

## 13. Human Check List

| Item | Why it matters | Location |
| ---- | -------------- | -------- |
| Exact optimizer / LR / iteration schedule | needed for reproduction | Appendix B / code |
| Exact kNN count and voxel size | graph topology depends on them | Sec. 4.2 / code |
| Large uncertainty constant $\phi$ | affects uncertainty gating | Eq. 5 / code |
| Full base-model loss weights | $L_{rgb}$ inherits mask/depth/tracking terms | Appendix A.2 / code |
| Whether `USPLAT4D` capitalization is `USplat4D` in repo | filename / search consistency | project page |
| Zotero has two PDF attachments | batch-linking / duplicate cleanup may need choosing YUWWNKKI | Zotero children |

## 14. Evidence Anchors

| Claim / detail | Evidence location |
| -------------- | ----------------- |
| Monocular dynamic reconstruction is underconstrained | Abstract, Sec. 1, PDF p.1-2 |
| Existing dynamic GS optimizes primitives uniformly | Sec. 1, Sec. 4.1 |
| Dynamic Gaussian state definition | Sec. 3, Eq. 1, PDF p.3 |
| Scalar uncertainty from photometric variance | Sec. 4.1, Eq. 2-5, PDF p.4-5 |
| Depth-aware uncertainty | Sec. 4.1, Eq. 6, PDF p.5 |
| Key node selection by gridization and significant period | Sec. 4.2, PDF p.5-6 |
| UA-kNN key graph | Sec. 4.2, Eq. 7, PDF p.6 |
| Non-key assignment | Sec. 4.2, Eq. 8, PDF p.6 |
| Key node loss | Sec. 4.3, Eq. 9, PDF p.6 |
| DQB interpolation | Sec. 4.3, Eq. 10, PDF p.6 |
| Non-key loss | Sec. 4.3, Eq. 11, PDF p.6 |
| Total loss | Sec. 4.3, Eq. 12, PDF p.7 |
| Dataset setup | Sec. 5.1, PDF p.7-8 |
| DyCheck quantitative result | Table 1, PDF p.8 |
| Objaverse quantitative result | Table 2, PDF p.9 |
| Main ablation | Table 3, PDF p.10 |
| Motion locality losses | Appendix A.2, Eq. S8-S13, PDF p.15-16 |
| Key ratio / threshold ablations | Appendix D.1-D.4, PDF p.21-23 |
| Runtime | Appendix D.5, PDF p.23 |
| Failure cases | Appendix E, PDF p.24-26 |

