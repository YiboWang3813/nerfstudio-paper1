# MAtCha Gaussians: Atlas of Charts for High-Quality Geometry and Photorealism From Sparse Views

## 0. 元数据

* Title: MAtCha Gaussians: Atlas of Charts for High-Quality Geometry and Photorealism From Sparse Views
* Authors: Antoine Guedon; Tomoki Ichikawa; Kohei Yamashita; Ko Nishino
* Year: 2025
* Venue: CVPR
* PDF source: `/Users/wangyibo/Zotero/storage/44HRW8GT/Guedon 等 - MAtCha Gaussians Atlas of Charts for High-Quality Geometry and Photorealism From Sparse Views.pdf`
* Zotero item key: `4KQ8T56B`
* Zotero PDF attachment key: `44HRW8GT`
* Code: Not specified
* Project page: `https://anttwo.github.io/matcha/`
* Dataset link: Not specified
* Main task: sparse-view surface mesh reconstruction and novel view synthesis
* Domain: sparse-view 3D reconstruction, unbounded scene reconstruction, Gaussian surfel rendering
* Input: sparse RGB images, camera poses/intrinsics from calibration or MASt3R-SfM, monocular depth estimates
* Output: explicit surface mesh, chart-based surface manifold, photorealistic novel-view renderings

## 1. 一句话技术摘要

MAtCha Gaussians 将场景表面建模为由输入视角深度图初始化的 2D chart atlas，通过低分辨率 chart encoding 与 depth encoding 驱动的轻量 MLP 对齐单目深度和 SfM 点，再在 chart 上临时附着 2D Gaussian surfels 做可微渲染 refinement，从少量视图同时得到清晰 mesh 和较高质量 NVS。

## 2. 问题形式化

目标是在 sparse RGB views 下同时完成显式 surface reconstruction 和 novel view synthesis。给定 $N$ 张图像 $I_i$、相机外参 $(R_i,t_i)\in SO(3)\times\mathbb{R}^3$ 和内参 $K_i\in\mathbb{R}^{3\times 3}$，方法优化一组 charts 来近似真实场景表面。实践中，即使输入图像 unposed，也可用 MASt3R-SfM 估计相机和稀疏/粗糙点图。

核心表示不是自由 3D Gaussian cloud，而是二维流形 atlas。每个 chart 是从 2D UV 域到 3D surface patch 的映射 $\psi_i:V_i\rightarrow U_i$。在 sparse-view 场景中通常设 $n=N$，即每个输入视角初始化一个 chart。

## 3. 方法概览

MAtCha 的 pipeline 分三段。

第一段是 chart initialization：使用 Depth Anything V2 等单目深度模型对每个输入视角估计深度，并将深度图反投影为初始 chart $\psi_i^{(0)}$。这一步提供高频局部几何，但存在跨视角尺度不一致。

第二段是 chart deformation/alignment：引入轻量 neural deformation model，对每个 chart 的 3D 点加一个可学习 deformation $\Delta_i(u)$，用 SfM 点监督对齐尺度和全局结构，同时通过结构损失保留单目深度中的法线和曲率细节。

第三段是 Gaussian surfel refinement：在 chart 三角形上以 barycentric coordinates 固定/约束 2D Gaussian surfels，用 photometric rendering loss 进一步优化外观和几何。最后通过改造 GOF 的 adaptive tetrahedralization，从 manifold 中提取单块 mesh，覆盖前景和背景。

## 4. 方法细节

**Chart 表示。** 对每个输入视角 $i$，单目深度图 $D_i$ 被反投影为初始逆映射 $\psi_i^{(0)}:V_i\rightarrow U_i^{(0)}$。$V_i\subset[0,1]^2$ 是 UV 域，$U_i^{(0)}\subset\mathbb{R}^3$ 是该视角深度图生成的初始 surface patch。单目深度的局部结构较细，但不同物体和不同视角的尺度可能不一致，因此不能直接拼成全局 mesh。

**Chart encoding。** 每个 chart 维护一个低分辨率 2D learnable feature grid $E_i\in\mathbb{R}^{rh\times rw\times d}$，其中 $r<1$。在 UV 坐标 $u$ 上双线性采样 $E_i(u)$，输入 tiny MLP $f_{\theta_i}$ 预测 3D deformation vector。低分辨率网格限制 MLP 主要调整低频结构，从而避免破坏单目深度里的高频细节。

**Depth encoding。** 由于物体边界处 deformation 需要不连续，仅靠 2D UV grid 不够。MAtCha 增加 depth-dependent feature $z_i(d(u))$，其中 $d(u)=(P_i\circ\psi_i^{(0)}(u))_z$ 是初始反投影点在深度相机坐标中的 z 分量。最终特征不是 concat，而是 $E_i(u)+z_i(d(u))$。作者声称加法形式达到最好结果，并能把可靠 SfM 监督传播到相近深度区域，同时在深度不连续处提供特征跳变。

**SfM fitting 与 confidence map。** 对每个 chart，将该图像可见的 SfM surface points 投影到 chart UV 域，用 $L_1$ 距离约束 deformed chart points 与 SfM points 对齐。为了处理 MASt3R-SfM 噪声和 outliers，方法为每个 chart 学一个 confidence map $C_i$，自动下调难以拟合区域的权重，同时用 log regularization 避免 confidence 崩塌。

**Structure-preserving losses。** 论文在摘要和 ablation 中强调 $L_{\text{struct}}$ 与 $L_{\text{align}}$：前者保持初始 depth derivatives 中的 normals/curvatures，后者促进 charts 之间形成统一 manifold。主文抽取中这些损失的完整公式缺失，需要查 appendix。

**Gaussian surfel refinement。** 初始 alignment 后，charts 仍可能有局部误差或分辨率不足。MAtCha 先做 charts refinement：将 Gaussians 通过 barycentric coordinates pinned within chart triangles，用可微 2D Gaussian rendering 和 photometric loss 细化 charts。随后做 free Gaussians refinement：冻结 charts，允许 Gaussians 移动和 densify，但用 depth、normal、curvature constraints 和 confidence maps 约束其贴近 refined charts。

## 5. 数学目标与损失

Chart deformation 的基本形式为：

$$
\Delta_i(u)=f_{\theta_i}[E_i(u)]
$$

更新后的 chart inverse map 为：

$$
\psi_i(u)=\psi_i^{(0)}(u)+\Delta_i(u)
$$

加入 depth encoding 后，deformation 为：

$$
\Delta_i(u)=f_{\theta_i}[E_i(u)+z_i(d(u))]
$$

基础 SfM fitting loss 为：

$$
L_{\text{fit}}=\sum_{i=0}^{n-1}\sum_{k=0}^{m_i-1}\|\psi_i(u_{ik})-p_{ik}\|_1
$$

其中 $u_{ik}$ 是第 $i$ 个 chart 中第 $k$ 个可见 SfM 点的 UV 坐标，$p_{ik}$ 是对应 3D SfM 点。

带 confidence map 的 revised fitting loss 为：

$$
L_{\text{fit}}=\frac{1}{n}\sum_{i=0}^{n-1}\sum_{k=0}^{m_i-1}C_i(u_{ik})\|\psi_i(u_{ik})-p_{ik}\|_1-\alpha\sum_{i=0}^{n-1}\log(C_i)
$$

confidence map 由 $C_i=1+\exp(\hat{C}_i)$ 参数化，保证 $C_i\in[1,+\infty)$。这里的写法来自 PDF 主文，$\log(C_i)$ 是否对全图求和/平均在抽取文本中不完整，标记 `NEED_HUMAN_CHECK`。

最终优化还包含 $L_{\text{struct}}$、$L_{\text{align}}$、photometric rendering loss、2DGS regularization，以及 free Gaussian refinement 中的 depth/normal/curvature constraints。主文未给出全部公式，需查 appendix。

## 6. 训练与推理流程

1. 输入 sparse RGB images；若未提供相机，用 MASt3R-SfM 估计 poses、intrinsics 和 surface points/pointmaps。
2. 对每个输入视角用 Depth Anything V2 估计 monocular depth。
3. 将每张深度图反投影成初始 chart，通常 $n=N$。
4. 为每个 chart 初始化低分辨率 chart encoding grid、depth encoding 和 tiny MLP。
5. 使用 SfM points、confidence-weighted fitting loss、structure loss 和 chart alignment loss 优化 chart deformation。
6. 在 charts 上实例化 2D Gaussian surfels，进行 chart refinement 与 photometric rendering optimization。
7. 冻结 refined charts 后进入 free Gaussians refinement，允许 Gaussian 移动和 densify，同时用 depth/normal/curvature 约束贴近 chart manifold。
8. 从最终 chart manifold 和 Gaussian surfel 表示渲染 novel views。
9. 使用改造后的 adaptive tetrahedralization 提取单块 mesh。

实现细节：PyTorch，单张 NVIDIA RTX A6000；chart alignment 少于 3 分钟，refinement 约 5 到 10 分钟。整体针对 3 到 10 输入视角。

## 7. 实验设置与结果摘要

实验覆盖两个任务：sparse-view surface mesh reconstruction 和 sparse-view novel view synthesis，并测试 bounded 与 unbounded scenes。

Surface reconstruction: DTU 使用 3 张输入图像，按 Spurfies 和 S-VolSDF 协议评估 Chamfer Distance；Tanks & Temples 使用 5 或 10 张稀疏图像，评估 F-Score。DTU 表 2 中 MAtCha 平均 CD 为 1.04 mm，优于 Spurfies 的 1.36 mm，约 24% 提升。T&T 表 3 中 MAtCha 在 5/10 training images 下 F-Score 为 0.072/0.156，高于 2DGS+MASt3R-SfM 和 GOF+MASt3R-SfM。

Novel view synthesis: 在 Mip-NeRF360、Tanks&Temples、DeepBlending 上用 5 或 10 输入图像训练，10 张测试图像评估 average PSNR 与 10% quantile PSNR。表 4 显示 MAtCha 在各数据集和两种训练视图数量下整体优于 2DGS+MASt3R-SfM 与 GOF+MASt3R-SfM。作者特别强调 10%Q PSNR 用于反映 sparse-view 下最难测试视角的泛化能力。

Ablation: 表 5 说明 chart encodings、depth encodings、confidence map、$L_{\text{struct}}$ 和 $L_{\text{align}}$ 都有贡献。完整模型 CD 为 1.04，PSNR/SSIM 为 17.59/0.443；去掉 chart encodings 时 CD 恶化到 2.693，说明 low-frequency chart deformation 是关键。

## 8. 声称贡献与实际技术增量

* 声称贡献 1: sparse-view 下同时实现高质量 mesh 和 photorealistic rendering。实际技术增量是用 chart atlas 作为主几何表示，而不是先学 volume/GS 再后处理抽 mesh。
* 声称贡献 2: 直接优化 explicit surface manifolds。实际实现是 monodepth chart initialization + neural low-frequency deformation + SfM fitting。
* 声称贡献 3: unbounded scenes 中快速重建。证据来自 T&T 和 Mip-NeRF360/DeepBlending，训练时间以分钟计。
* 与常规 sparse-view 3DGS 的差异: MAtCha 不是通过正则自由 3D Gaussians 防漂移，而是先构造 surface manifold，再让 Gaussian surfels 受 chart 约束。

## 9. 局限与隐含假设

* 依赖单目深度和 MASt3R-SfM；当两者都不可靠时会失败，论文提到强反光和透明物体是典型困难。
* 输入视角重叠过低时仍然困难；chart alignment 需要一定多视角约束。
* 主流程面向静态场景，结论中提到动态和可变形物体是未来工作。
* 2DGS rasterization 要求 centered principal point，DTU mesh extraction 中需要 crop 输入图像，可能导致部分场景重建不完整。
* 虽然 NVS 质量不错，但方法主要目标是 surface reconstruction；与专门 sparse-view NVS 方法的比较范围有限。
* 方法包含多个阶段和多个 loss，复现需要 appendix 中的权重、采样、tetrahedralization 与 Gaussian refinement 细节。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法类别 | Chart-atlas surface representation with Gaussian surfel rendering |
| 核心表示 | Mesh as Atlas of Charts; 2D Gaussian surfels attached to charts |
| 输入条件 | Sparse RGB images; poses from calibration or MASt3R-SfM |
| 外部先验 | Depth Anything V2; MASt3R-SfM |
| 关键模块 | Monodepth chart initialization; chart encoding; depth encoding; confidence-weighted SfM fitting; structure loss; Gaussian surfel refinement |
| 输出 | Explicit mesh and NVS renderings |
| 主要优势 | sparse-view、unbounded scenes、分钟级训练、清晰 surface geometry |
| 主要风险 | 依赖 monodepth/SfM，低重叠和非朗伯材质困难 |

## 11. 对我研究可复用的组件

* **Chart-constrained Gaussians**: 用显式 manifold 约束 Gaussian，适合减少 sparse-view 下 floating artifacts。
* **Depth encoding for discontinuity**: 在 2D feature grid 外增加 depth-axis feature，可用于处理前景/背景尺度不一致和边界不连续。
* **Confidence-weighted SfM supervision**: 对 learned SfM/pointmap 噪声显式建模，不把所有点都当可靠 GT。
* **Structure-preserving monodepth distillation**: 保留单目深度的 normals/curvatures，而不是直接相信其绝对尺度。
* **Surface-first sparse-view pipeline**: 先得到可解释 surface，再用 GS 做 appearance refinement，适合 robotics/编辑类任务。

## 12. 缺口与想法种子

* **Uncertainty-aware chart atlas**: 将 monodepth uncertainty 和 SfM confidence 合并进 chart deformation 与 Gaussian refinement，避免错误深度主导几何。
* **Dynamic MAtCha**: 给每个时间段维护 canonical chart atlas 和 deformation field，把 MAtCha 扩展到 sparse-view dynamic scenes。
* **Diffusion-assisted chart completion**: 在低重叠或缺失背景区域，用 diffusion/large reconstruction prior 生成候选 depth/chart，再由 multi-view consistency 筛选。
* **Hybrid free/fixed Gaussian policy**: 根据 chart confidence 决定 Gaussian 是 pinned、semi-free 还是 fully-free，兼顾几何稳定和外观表达能力。
* **Loop-consistent atlas merging**: 对重叠 charts 做 cycle consistency 和 seam reduction，减少多 chart 拼接处的几何断裂。

## 13. 人工检查清单

* `NEED_HUMAN_CHECK`: appendix 中 $L_{\text{struct}}$、$L_{\text{align}}$、photometric loss、free Gaussian refinement constraints 的完整公式和权重。
* `NEED_HUMAN_CHECK`: confidence loss 中 $\log(C_i)$ 的具体聚合方式。
* `NEED_HUMAN_CHECK`: adaptive tetrahedralization 改造 GOF 的具体实现。
* `NEED_HUMAN_CHECK`: project page 是否提供代码和复现实验配置。

## 14. 证据锚点

* Abstract: MAtCha 将 Mesh as Atlas of Charts 与 2D Gaussian surfels 结合，同时追求 mesh recovery 和 photorealistic NVS。
* Fig. 1: 展示 3 views 和 10 views 下的 surface 和 rendering 质量。
* Sec. 1 Introduction: 解释 volume/GS 表示 photorealistic 但几何模糊，提出 surface-first 表示。
* Table 1: 与 Gaussian Surfel、2DGS、GOF、SuGaR、InstantSplat、SparseNeus、VolRecon、Spurfies 等比较方法能力。
* Sec. 4 / Fig. 2: 总 pipeline，包括 monodepth 初始化、SfM alignment、chart/depth encodings、Gaussian rendering。
* Sec. 4.1: chart initialization with monodepth estimates。
* Sec. 4.2 / Eq. (1)-(3): chart encoding、depth encoding 和 deformation model。
* Sec. 4.3 / Eq. (4)-(5): SfM fitting loss 与 confidence map。
* Sec. 4.4: Gaussian surfel refinement 与 mesh extraction。
* Sec. 5: 实验任务、实现细节和训练时间。
* Table 2: DTU 3-view Chamfer Distance 结果。
* Table 3 / Fig. 5: Tanks&Temples unbounded sparse surface reconstruction。
* Table 4: Mip-NeRF360、T&T、DeepBlending sparse-view NVS PSNR。
* Table 5: deformation architecture 和 loss component ablation。
* Sec. 6 Conclusion: 限制包括 low overlap、specularities、transparency，以及未来动态/可变形扩展。
