# Horseshoe Splatting: Handling Structural Sparsity for Uncertainty-Aware Gaussian-Splatting Radiance Field Rendering

## 0. Metadata

* Title: Horseshoe Splatting: Handling Structural Sparsity for Uncertainty-Aware Gaussian-Splatting Radiance Field Rendering
* Authors: Feng Wu; Tsai Hor Chan; Yihang Chen; Lingting Zhu; Guosheng Yin; Lequan Yu
* Year: 2025
* Venue: ICLR
* PDF source: `/Users/wangyibo/Zotero/storage/M2HYXRBT/Wu 等 - 2025 - Horseshoe Splatting Handling Structural Sparsity for Uncertainty-Aware Gaussian-Splatting Radiance.pdf`
* Zotero item key: `UPIKII2E`
* Zotero PDF attachment key: `M2HYXRBT`
* Code: `https://github.com/HKU-MedAI/Horseshoe-Splatting`
* Project page: Not specified
* Dataset link: LF, LLFF
* Main task: Bayesian uncertainty-aware 3D Gaussian Splatting with structural sparsity
* Domain: Bayesian 3DGS, structured sparsity, calibrated uncertainty
* Input: posed multi-view images
* Output: high-fidelity 3DGS renderings and pixel-wise posterior uncertainty maps
* Main representation: 3DGS with global-local Horseshoe prior on covariance scales
* Supervision type: variational inference plus reconstruction likelihood
* Core contribution in one sentence: 在每个 Gaussian 的 covariance scale 上施加 global-local Horseshoe prior，通过 spike-at-zero 和 heavy-tail 同时收缩噪声方向、保留显著结构，并用 Monte Carlo rendering 输出 calibrated uncertainty。
* Note status: `complete`

## 1. 一句话技术摘要

This paper addresses calibrated uncertainty in 3DGS by using a global-local Horseshoe prior on per-splat covariance scales to transform deterministic Gaussian covariances into sparse posterior samples, with the key technical novelty being variational inference over scale shrinkage variables and Monte Carlo rendering for pixel-wise uncertainty.

## 2. 问题形式化

标准 3DGS 的 covariance 是确定性的，既不能表达 uncertainty，也不能显式鼓励 scale/correlation 中的结构稀疏。论文认为很多 Gaussian covariance 的轴向尺度包含噪声方向，应被 shrink；但真正的数据支撑结构不能被过度收缩。Horseshoe prior 的 spike-at-zero 和 heavy-tail 正好适合这种 sparse-but-heavy-tail 场景。

每个 Gaussian 的 scale matrix 为 $S_i=\mathrm{diag}(s_{i1},s_{i2},s_{i3})$，covariance 为 $\Sigma_i=R_iS_iS_i^\mathsf{T}R_i^\mathsf{T}$。Horseshoe Splatting 对每个 $s_{ij}$ 建 Bayesian hierarchy。

## 3. 方法概览

方法包含三层：

1. Prior: 对每个 covariance scale $s_{ij}$ 放 global-local Horseshoe prior，local shrinkage $\lambda_{ij}$ 控制单个 scale，global shrinkage $\theta_j$ 控制轴向整体。
2. Variational inference: 用 factorized mean-field variational family 近似 posterior，包括 Gaussian factor 和 inverse-Gamma factors。
3. Posterior rendering: 训练后从 shrinkage posterior 采样 scale，形成多个 covariance samples，渲染多次得到 predictive mean、variance 和 credible intervals。

## 4. 方法细节

### 4.1 Horseshoe prior on scale

对每个 splat $i$ 和 axis $j$，建模：

$$
s_{ij}|\lambda_{ij},\theta_j \sim N(\beta_{ij}, \sigma_{ij}^2\theta_j^2\lambda_{ij}^2)
$$

其中 $\sigma_{ij}=\mathrm{softplus}(\rho_{ij})$。local shrinkage $\lambda_{ij}\sim C^+(0,1)$，global shrinkage $\theta_j\sim C^+(0,b)$。半 Cauchy prior 用 inverse-Gamma augmentation 表示，便于 variational inference。

Horseshoe prior 的含义是：噪声主导的 scale 被强烈压向 0；大而可靠的 scale 因 heavy tails 保留，避免 Laplace/Gaussian prior 那种过度收缩。

### 4.2 Variational inference

变分族是 factorized 的：

$$
q(s,\lambda^2,\nu,\theta^2,\xi)=\prod_{i,j}q_N(s_{ij})q_{IG}(\lambda_{ij}^2)q_{IG}(\nu_{ij})\prod_j q_{IG}(\theta_j^2)q_{IG}(\xi_j)
$$

ELBO 包含 likelihood、Gaussian prior term、IG hierarchy prior terms 和 entropy。实现中对 $s_{ij}$ 用 reparameterization $s_{ij}=\beta_{ij}+\sigma_{ij}\epsilon$，$\epsilon\sim N(0,1)$；IG factors 使用 pathwise/implicit reparameterization，KL 部分有解析形式。

### 4.3 与 reconstruction loss 结合

reconstruction term 是 posterior expectation 下的 negative log-likelihood：

$$
\mathcal{L}_{rec} \approx -\frac{1}{M}\sum_{m=1}^{M}\sum_{u=1}^{U}\ln f_N(I_u|\hat{I}_u^{(m)},\sigma_u^2)
$$

总损失为：

$$
\mathcal{L}_{total} = \mathcal{L}_{rec} + \mathcal{L}_{KL}
$$

其中 $\mathcal{L}_{KL}=KL(q(s,\lambda^2,\theta^2)\|p(s,\lambda^2,\theta^2))$。实践中用 Monte Carlo 近似 likelihood 项，用 inverse-Gamma factors 的解析 KL。

### 4.4 Posterior uncertainty rendering

训练后对每个 axis 采样 $\theta_j^2$、$\lambda_{ij}^2$ 和 $\epsilon_{ij}$，得到：

$$
s_{ij}^{(m)}=\beta_{ij}+\sigma_{ij}\theta_j^{(m)}\lambda_{ij}^{(m)}\epsilon_{ij}^{(m)}
$$

然后构造 $\Sigma_i^{(m)}=R_i\mathrm{diag}(s_{i1}^{(m)},s_{i2}^{(m)},s_{i3}^{(m)})R_i^\mathsf{T}$，用 3DGS rasterizer 渲染 $M$ 次。像素均值、方差和 credible intervals 由多次 render samples 估计。

## 5. 数学目标和损失

核心目标是 Bayesian reconstruction objective：negative expected log-likelihood 加 posterior-prior KL。相比 Variational Multi-scale 3DGS，Horseshoe Splatting 直接把 posterior 放在 covariance scales 上，并用结构稀疏 prior 控制 scale 的 shrinkage。

论文还给出理论分析：在 sparse scale 假设、local identifiability、Horseshoe prior、增长条件和 renderer local Lipschitz 下，scale posterior 以近 minimax rate 收缩，并通过 renderer Lipschitz 性传递到 image space。

## 6. 训练和推理流程

训练：

1. 用标准 SfM 初始化并训练 3DGS 参数。
2. 对 covariance scale 加 Horseshoe variational parameters。
3. 采样 scale，渲染图像，计算 likelihood。
4. 加 KL regularizer，联合优化。

推理：

1. 采样 10 次 posterior scales。
2. 每次构造 covariance 并渲染。
3. 计算 predictive mean、variance、uncertainty map。

实现基于官方 3DGS PyTorch 框架；local/global variational scale learning rates 分别为 $1\times 10^{-4}$ 和 $1\times 10^{-5}$；实验使用单张 RTX 3090。

## 7. 实验设置与结果摘要

数据集：LF 的 torch、basket、africa、statue；LLFF 的 fern、flower、fortress、horns、leaves、orchids、room、trex。

指标：NVS 用 PSNR/SSIM/LPIPS；uncertainty 用 AUSE 和 NLL。

主要结果：

* Table 1: LF depth uncertainty 平均 AUSE 0.18，优于 Variational 3DGS 的 0.19 和 Ensemble GS 的 0.20。
* Table 2: LF 上 PSNR 30.05、SSIM 0.947、LPIPS 0.064，uncertainty AUSE 0.25、NLL -0.74，均很强；LLFF 上也在 NVS 质量和 NLL 上领先。
* Fig. 3: uncertainty map 与 error map 更一致，FisherRF 虽重建好但 RGB uncertainty 噪声大。
* Table 4: active view selection 中，用 uncertainty 选新视角明显优于 random、FisherRF、Variational 3DGS。
* Table 5: inference time 0.03s/view，快于 Ensemble GS、FisherRF、Variational 3DGS。
* Table 3: Horseshoe prior 与 Laplace/Gaussian prior 渲染质量接近，但 uncertainty 显著更好，尤其 NLL。

## 8. 声称贡献 vs 实际技术增量

论文声称 Bayesian extension with structural sparsity and theory。实际技术增量是把 Horseshoe prior 这个成熟稀疏 Bayesian prior 精准放在 3DGS covariance scales 上，使不确定性来源和 3DGS 几何形状参数直接绑定。

相较 Variational Multi-scale 3DGS，它不通过 spawn/offset table 构造局部多尺度样本，而是直接对 scale posterior 建模；相较 PUP，它不是 post-hoc pruning score，而是训练内的 posterior uncertainty。

## 9. 局限性和隐藏假设

* 理论依赖 sparse scale、local Lipschitz renderer 和 local identifiability，真实 3DGS 是否严格满足需谨慎。
* 只对 covariance scales 建 Bayesian posterior，不覆盖 pose、color、opacity 等全部不确定性。
* Monte Carlo rendering 虽快但仍比单次 deterministic render 多开销。
* 论文为 ICLR 2026 版本，当前日期下需确认最终录用/版本状态。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 任务 | uncertainty-aware 3DGS |
| 输入 | posed images |
| 输出 | NVS + uncertainty maps |
| 表示 | 3DGS covariance scales with Horseshoe posterior |
| 关键模块 | global-local shrinkage, variational IG hierarchy, MC rendering |
| 关键损失 | expected NLL + KL |
| 主要优点 | uncertainty calibration 强，渲染质量也提升 |
| 主要风险 | posterior 覆盖参数有限，理论假设较强 |

## 11. 可复用组件

* Horseshoe prior 可用于压缩/稀疏化 Gaussian scale。
* posterior variance 可用于 active view selection。
* scale posterior 可与 pruning/densification 结合，删除 near-zero/noise-dominated directions。

## 12. Gap 和 idea seeds

* 把 Horseshoe prior 扩展到 dynamic 4DGS 的 motion scale 或 deformation basis。
* 与 PUP 结合：训练时 Horseshoe posterior，部署时 Fisher + posterior 双条件 pruning。
* 对语义/开放词表 3DGS，可用 uncertainty map 标注文本查询不可靠区域。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: Appendix E 的完整 algorithm 需要复核。
* `NEED_HUMAN_CHECK`: OpenReview/ICLR 版本状态与代码仓库可运行性需要确认。

## 14. Evidence Anchors

* Sec. 3.1: Horseshoe prior on scaling matrix。
* Sec. 3.2: reconstruction loss integration。
* Sec. 3.3: posterior inference and uncertainty estimation。
* Sec. 4: theoretical analysis, Theorem 1-2。
* Sec. 5.1: datasets, metrics, baselines, implementation。
* Table 1-2: uncertainty and NVS main results。
* Fig. 3: uncertainty visualization。
* Table 3: prior ablation。
* Table 4-5: active view selection and inference time。
