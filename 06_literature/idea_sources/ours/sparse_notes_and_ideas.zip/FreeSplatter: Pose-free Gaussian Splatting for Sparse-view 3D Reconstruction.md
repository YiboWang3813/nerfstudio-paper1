---
title: "FreeSplatter: Pose-free Gaussian Splatting for Sparse-view 3D Reconstruction"
authors: "Jiale Xu, Shenghua Gao, Ying Shan"
year: 2025
venue: "ICCV 2025"
zotero_item_key: "8QCPDDMF"
pdf_attachment_key: "Z6APS9ND"
pdf_path: "/Users/wangyibo/Zotero/storage/Z6APS9ND/Xu 等 - FreeSplatter Pose-free Gaussian Splatting for Sparse-view 3D Reconstruction.pdf"
note_path: "notes/FreeSplatter: Pose-free Gaussian Splatting for Sparse-view 3D Reconstruction.md"
tags: ["3D Gaussian Splatting", "pose-free reconstruction", "sparse-view reconstruction", "generalizable reconstruction", "camera pose estimation"]
---

## 0. 一句话总结

FreeSplatter 是一个 pose-free 的 feed-forward sparse-view 3DGS 框架：输入未标定的少量图像，不需要相机内外参，transformer 直接在统一参考坐标系中预测 pixel-aligned Gaussian maps，再用这些 Gaussian 的 3D 位置和像素坐标通过 PnP-RANSAC 反推出相机位姿和焦距，同时完成高质量 novel view synthesis。

## 1. 问题与动机

大多数 sparse-view reconstruction 或 generalizable 3DGS 方法默认输入相机位姿准确，但真实 sparse-view 图像中 SfM 往往因为重叠不足而失败。pose-dependent LRM 也对相机误差敏感，限制了它们在随手拍、多视角生成图像和互联网图像中的可用性。

已有 pose-free 方法如 PF-LRM、LEAP 多用隐式 NeRF 表示，渲染慢、分辨率有限，并且从隐式表示中估计相机还需要额外组件。DUSt3R/MASt3R 可以回归点图并用 PnP/全局对齐估计位姿，但点云稀疏，不直接适合高质量 novel view synthesis。FreeSplatter 的动机是：能否直接预测 Gaussian maps，让同一个表示既能渲染又能估计相机。

## 2. 适用场景

FreeSplatter 适用于未标定 sparse-view 图像的快速 3D 重建，覆盖 object-centric 和 scene-level 两类任务。论文训练了 FreeSplatter-O 用于物体中心重建，以及 FreeSplatter-S 用于室内、室外和真实物体场景。

它还适合 text/image-to-3D pipeline：多视角 diffusion 生成的图像常存在相机配置难对齐的问题，pose-free 架构可以绕开严格相机管理，直接从生成图像估计 Gaussian 和相机。

## 3. 方法定位

FreeSplatter 属于 generalizable pose-free Gaussian reconstruction。它不是对单个场景做优化，也不是先用 DUSt3R/MASt3R 估计点云再训练 Gaussian head，而是端到端从多视图图像 token 预测 Gaussian maps。

与 pose-dependent Gaussian LRMs 的关键差异是：模型没有相机 pose、intrinsics，也不能通过已知深度沿相机射线 unproject。因此它直接预测参考坐标系中的 3D Gaussian location，并用 pixel-alignment loss 约束每个 Gaussian 落在对应像素的相机射线上。

## 4. 核心创新

第一，提出统一参考坐标系下的 pose-free Gaussian map prediction。模型把第一张图作为 reference view，所有输入视图的 Gaussian 都预测到这个参考相机坐标系中。

第二，使用极简 transformer 架构处理多视角图像 token。所有 view token 经过 self-attention 交换信息，不需要 epipolar line、cost volume 或已知相机投影。

第三，利用 predicted Gaussian maps 直接估计相机。因为每个像素对应一个预测 3D 点，给定像素坐标和焦距后可以用 PnP-RANSAC 求每个视图的相机 pose。

第四，提出两阶段训练和 pixel-alignment loss。先用位置监督让随机初始化模型学到大致正确的 Gaussian 位置，再通过 ray alignment 约束和渲染 loss 提高可渲染质量与位姿可解性。

## 5. 方法细节

给定 $N$ 张无相机参数输入图像 $\{I^n\}_{n=1}^N$，FreeSplatter 输出 Gaussian maps、每张图的相机 pose 和共享焦距：

$$
\mathcal{G}, P^1,\dots,P^N,f=\operatorname{FreeSplatter}(I^1,\dots,I^N)
$$

每张图被切成 $p\times p$ patch，默认 $p=8$，线性投影为 token。每个 token 加上位置 embedding 和 view embedding。第一张图使用 reference embedding $e_{ref}$，其余图使用 source embedding $e_{src}$，让模型知道哪个坐标系是输出参考系。

经过 $L$ 层 self-attention transformer 后，每个输出 token 被线性层解码成 $p^2$ 个 Gaussian 参数，并 unpatchify 成每个输入视图对应的 Gaussian map $G^n\in\mathbb{R}^{H\times W\times q}$。每个像素对应一个 q 维 Gaussian primitive，包括 3D location、rotation、scale、opacity 和 SH coefficients。

相机恢复时，取第 $n$ 个视图 Gaussian map 的 location map $X^n\in\mathbb{R}^{H\times W\times 3}$、像素坐标 map $Y^n\in\mathbb{R}^{H\times W\times 2}$ 和有效 mask $M^n$，用估计内参 $K$ 通过 PnP-RANSAC 求 pose：

$$
P^n=\operatorname{PnP}(X^n,Y^n,M^n,K)
$$

训练首先使用 position loss 监督 Gaussian 位置：

$$
L_{pos}=\sum_{n=1}^{N}\|M^n\odot\hat{X}^n-M^n\odot X^n\|
$$

其中 $X^n$ 来自 depth unprojection。该 loss 只在预训练阶段使用，因为深度可能有噪声，长期使用会损害渲染质量。

pixel-alignment loss 通过最大化预测 3D 点方向和真实相机射线方向的 cosine similarity，让每个 predicted Gaussian 与对应像素射线对齐：

$$
L_{align}=\sum_{n,i,j}\left(1-\frac{\hat{r}_{i,j}^n\cdot r_{i,j}^n}{\|\hat{r}_{i,j}^n\|\|r_{i,j}^n\|}\right)
$$

总 loss 为：

$$
L=L_{render}+\lambda_a L_{align}+\mathbf{1}_{t\le T_{max}}\lambda_p L_{pos}
$$

其中 $L_{render}$ 是 MSE 和 LPIPS 的组合，论文设 $\lambda_a=1.0$、$\lambda_p=10.0$、$T_{max}=10^5$。

## 6. 实验设置

FreeSplatter-O 在 Objaverse 上训练，使用白背景居中物体渲染，每个资产归一化到 $[-1,1]^3$，随机采样 32 个视角和对应深度，分辨率 512 x 512。FreeSplatter-S 使用 BlendedMVS、ScanNet++、CO3Dv2 的混合训练集，覆盖室外、室内和真实物体。

评估包括 sparse-view reconstruction 和 camera pose estimation。物体级评估使用 GSO、OmniObject3D 等；场景级评估使用 ScanNet++、CO3Dv2，并额外用 RealEstate10K 测试位姿泛化。重建指标为 PSNR、SSIM、LPIPS，位姿指标为 RRE、RRA@15、RRA@30 和 scale-invariant TE。

## 7. 主要结果

在 PF-LRM 的评估数据上，FreeSplatter-O 在 OmniObject3D 上优于 PF-LRM，尤其 predicted input poses 渲染时达到 26.49 PSNR、0.926 SSIM、0.050 LPIPS。PF-LRM 在其 GSO 设置中指标较高，但作者指出该评估图像与 PF-LRM 训练条件更接近，而 OmniObject3D 更客观。

在作者自建 object-centric 评估中，FreeSplatter-O 即使不使用 GT pose，也显著超过 pose-dependent LGM 和 InstantMesh。GSO 上 FreeSplatter-O 达到 30.443 PSNR、0.945 SSIM、0.055 LPIPS；OmniObject3D 上达到 31.929 PSNR、0.973 SSIM、0.027 LPIPS。

scene-level 重建中，FreeSplatter-S 在 ScanNet++ 多数指标上优于 pose-dependent pixelSplat、MVSplat，也优于 pose-free Splatt3R。作者认为 Splatt3R 受限于冻结 MASt3R 的固定 Gaussian 位置，而 FreeSplatter 端到端联合优化 Gaussian 参数，视觉质量更高。

位姿估计方面，FreeSplatter-O 在 OmniObject3D 上 RRE 为 3.446，RRA@15 为 0.982，RRA@30 为 0.996，TE 为 0.039，优于 PF-LRM。scene-level 中 FreeSplatter-S 在 ScanNet++、CO3Dv2 和 Re10K 上达到与 MASt3R 相当或更好的 RRA/TE，且 Re10K 不在其训练集内。

## 8. 消融与分析

模型架构消融显示，更多 transformer 层和更小 patch size 都提升质量。GSO 上，16 层且 patch size 16 为 25.417 PSNR；16 层 patch size 8 提升到 28.945；24 层 patch size 8 达到 30.443。说明模型容量和局部 token 粒度都很关键。

pixel-alignment loss 是关键组件。去掉 $L_{align}$ 时，GSO 从 30.443 PSNR 降到 26.684，ScanNet++ 从 25.807 降到 21.330，LPIPS 也明显变差。作者指出没有该损失会出现明显模糊伪影，因为 Gaussian 不再稳定贴合像素射线，位姿求解和渲染都会受损。

view embedding 的设计也重要。给第 j 个视图 token 加 $e_{ref}$、其他视图加 $e_{src}$ 可以让模型识别参考视图，并在对应相机框架中重建 Gaussian；替代 embedding 组合会降低重建质量。

## 9. 与相关工作的关系

相对 pose-dependent LRMs，如 LGM、InstantMesh、GS-LRM，FreeSplatter 不需要输入相机 pose，并且实验中在物体级重建上甚至超过一些使用 GT pose 的模型。

相对 PF-LRM、LEAP 等 pose-free NeRF/LRM，FreeSplatter 使用 3D Gaussian 表示，渲染更高效，且 Gaussian map 可直接提供 PnP 需要的 2D-3D 对应。

相对 DUSt3R/MASt3R，FreeSplatter 不只是预测点图用于位姿，而是直接预测可渲染的 Gaussian radiance representation。相对 Splatt3R，它不是冻结 MASt3R 后加 Gaussian head，而是端到端优化 Gaussian 参数。

## 10. 优点

FreeSplatter 的优点是把 pose estimation 和 novel view synthesis 放在同一个显式表示里解决。Gaussian map 既是渲染 primitive，又是相机求解的 3D 点集合，避免了 pose-free pipeline 中“先估点云再转表示”的割裂。

架构也比较简洁：patchify、self-attention、linear unpatchify，没有依赖已知相机几何的 epipolar/cost volume 结构，因此天然适合未知相机设置。object-centric 和 scene-level 共享同类架构，只调整训练数据和 mask 策略。

## 11. 局限

方法依赖大规模训练数据和深度/位置监督进行预训练。虽然推理时 pose-free，但训练时仍需要数据集中可用的相机/深度来构造 $L_{pos}$ 和 $L_{align}$。

直接预测 3D location 的自由度很高，若输入视角极少、外观重复或遮挡严重，Gaussian map 可能产生错误 2D-3D 对应，进而影响 PnP pose 和渲染结果。scene-level 中 target-view masking 和 occlusion 处理也比较关键，复杂遮挡下仍可能有不可见区域重建不足。

## 12. 可复现要点

复现时要先明确 reference view 机制：第一张或指定第 j 张输入图作为输出坐标系，使用 $e_{ref}$ 标识，其余图使用 $e_{src}$。相机焦距共享估计，pose 通过 PnP-RANSAC 从 Gaussian location map 和像素坐标 map 求解。

训练流程必须包含位置预训练。仅靠渲染 loss 很难让随机初始化的 pose-free Gaussian 位置收敛。预训练后继续用 $L_{align}$ 维持 pixel-ray alignment，同时渲染 loss 负责外观质量。object-centric 中 $L_{align}$ 只对前景 mask 使用，以允许前景外 Gaussian 表示遮挡区域；scene-level 中更强调完整 pixel alignment 和 target-view masking。

## 13. 可能扩展

一个扩展是把 PnP 求解放入可微闭环，让相机估计误差反向影响 Gaussian map，而不是只用 off-the-shelf solver 做后处理。

第二个扩展是结合 DUSt3R/MASt3R 的强几何先验，但不冻结点图位置，而是作为初始化或辅助监督，让 Gaussian map 仍可端到端调整。

第三个扩展是用于多视角 diffusion 生成图像的相机自校准。FreeSplatter 可以先估计生成图的相机和 Gaussian，再反过来筛选或重加权不一致视图，提高 text/image-to-3D 的稳定性。

## 14. 个人理解

FreeSplatter 的关键在于把“pose-free”问题转化为“预测一个能同时服务 PnP 和渲染的 pixel-aligned Gaussian map”。这比单纯预测点云更适合 NVS，比隐式 NeRF 更容易反推出相机。

这篇文章也说明，在未知相机下做 generalizable 3DGS，最难的不是颜色或 opacity，而是 Gaussian 位置的可解性。$L_{pos}$ 负责启动，$L_{align}$ 负责把 3D 点约束回像素射线，PnP 负责把这种约束转成相机参数；三者缺一都会让系统变得不稳定。
