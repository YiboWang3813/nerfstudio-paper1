# 4D Gaussian Splatting in the Wild with Uncertainty-Aware Regularization

## 0. Metadata

* Title: 4D Gaussian Splatting in the Wild with Uncertainty-Aware Regularization
* Authors: Mijeong Kim; Jongwoo Lim; Bohyung Han
* Year: 2024
* Venue: NeurIPS
* PDF source: `/Users/wangyibo/Zotero/storage/NCYGJMWI/Kim 等 - 2024 - 4D Gaussian Splatting in the Wild with Uncertainty-Aware Regularization.pdf`
* Zotero item key: `KZG92E5V`
* Zotero PDF attachment key: `NCYGJMWI`
* Code: Not specified
* Project page: Not specified
* Dataset link: DyCheck, LLFF
* Main task: dynamic novel view synthesis from casually recorded monocular videos
* Domain: 4D Gaussian Splatting, monocular dynamic reconstruction, uncertainty regularization
* Input: handheld monocular video, estimated depth, scene flow, optical flow
* Output: 4DGS dynamic scene representation and novel view/time renderings
* Main representation: canonical 3D Gaussians deformed over time with HexPlane-style deformation
* Supervision type: image reconstruction, depth/flow data-driven losses, uncertainty-aware diffusion and depth smoothness priors
* Core contribution in one sentence: 用每个 Gaussian 的可见贡献估计 uncertainty，只在训练约束不足的区域施加 diffusion prior 和 depth TV regularization，并用 dynamic region densification 修复 SfM 对快速运动区域的初始化失败。
* Note status: `complete`

## 1. 一句话技术摘要

This paper addresses in-the-wild monocular 4D Gaussian reconstruction by using uncertainty-aware regularization to transform poorly observed dynamic regions into better-constrained Gaussians, with the key technical novelty being visibility-based Gaussian uncertainty that gates diffusion and depth-smoothing priors.

## 2. 问题形式化

动态单目视频重建是高度病态问题：训练视角有限，动态区域 SfM 初始化失败，4DGS 容易过拟合训练图像并在 novel views 上崩坏。论文以 4DGS 为 baseline，新增 uncertainty-aware regularization 和 dynamic region densification。

每个高斯 $\gamma_k$ 有 canonical 参数 $(\mu_k,R_k,S_k,\alpha_k,f_k)$，通过 deformation functions 在时间 $t$ 变成 $(\mu_k^t,R_k^t,S_k^t)$。核心是估计每个高斯在训练视图中是否被充分观察，并只对高不确定区域施加强先验。

## 3. 方法概览

方法包含三部分：

1. Uncertainty-aware regularization: 根据高斯在训练图像中的 alpha-blending contribution 计算 uncertainty map，对高不确定区域施加 diffusion prior 和 depth smoothing。
2. Dynamic region densification: 用 scene flow 和 depth 在动态区域额外初始化高斯，弥补 SfM 对快速运动物体的缺失。
3. Data-driven losses: 用 depth map 和 RAFT optical flow 约束动态几何与运动。

## 4. 方法细节

### 4.1 4DGS deformation

4DGS 将 canonical Gaussian 随时间变形：

$$
(\mu_k^t,R_k^t,S_k^t) = (\mu_k + \phi_\mu(\mu_k,t), R_k+\phi_r(R_k,t), S_k+\phi_s(S_k,t))
$$

本文采用 HexPlane-style deformation，与 baseline 4DGS 类似。

### 4.2 Visibility-based uncertainty

每个 Gaussian 的 informativeness 用其在所有训练图像所有像素上的贡献 $C_k$ 表示：

$$
C_k = \sum_{I \in T}\sum_r \omega_k^\pi(r)
$$

uncertainty 定义为：

$$
U_k = 1 - \mathrm{Sigmoid}(C_k;c_0,c_1)
$$

贡献越大，说明训练视角支撑越充分，uncertainty 越低。对于任意 unseen view，2D uncertainty map 通过 alpha blending 得到：

$$
U(r) = \sum_{k=1}^{K}\omega_k^\pi(r)U_k
$$

### 4.3 Uncertainty-aware diffusion prior

论文用 BLIP 从训练帧生成 prompt，再用 DreamBooth fine-tune Stable Diffusion。对 novel view/time 渲染图 $\hat{I}$，先编码并加噪，再用 DDIM 生成 refined image $I_{DDIM}$。diffusion loss 只在 high uncertainty 区域强约束：

$$
\mathcal{L}_{UA-diff} = \frac{|U \cdot (\hat{I}-I_{DDIM})|^2}{|U|^2} + \frac{|U \cdot (\hat{I}-I_{DDIM})|^1}{|U|^1}
$$

为了降低开销，每 2000 iterations 开始时随机采样 200 张图，提前用 DDIM refine 并缓存，后续 2000 iterations 复用。

### 4.4 Uncertainty-aware depth TV

先渲染 depth map：

$$
\hat{D}(r) = \sum_{k=1}^{K}\omega_k^\pi(r)d_k
$$

然后只在 uncertainty 高的相邻像素之间施加更强 total variation，低 uncertainty 区域尽量不平滑，以保留细节。该 loss 是 $\mathcal{L}_{UA-TV}$。

### 4.5 Dynamic region densification

SfM 假设静态场景，快速运动区域往往没有点云初始化。论文用 scene flow 识别 dynamic pixels，随机采样一部分像素，通过 depth 反投影初始化高斯位置：

$$
\mu_k = \pi^{-1}(r,D(r))
$$

feature 的前三维设为像素 RGB $I(r)$，剩余 SH 维度补零。这样动态区域一开始就有合理高斯，不需要静态区域高斯反复 clone/split 去填补。

## 5. 数学目标和损失

data-driven losses 包括 depth 和 flow：

* $\mathcal{L}_{depth} = |\hat{D}-D|_1$；
* optical flow 通过高斯从帧 $\Pi$ 到 $\Pi'$ 的投影位移 alpha-blending 得到 $\hat{F}^{\Pi \to \Pi'}$，再与 RAFT flow 比较；
* $\mathcal{L}_{data} = \mathcal{L}_{depth} + \mathcal{L}_{flow}$。

总损失为：

$$
\mathcal{L} = \mathcal{L}_{recon} + \lambda_{grid}\mathcal{L}_{grid} + \lambda_{data}\mathcal{L}_{data} + \lambda_{UA-diff}\mathcal{L}_{UA-diff} + \lambda_{UA-TV}\mathcal{L}_{UA-TV}
$$

## 6. 训练和推理流程

训练：

1. 用 baseline 4DGS/HexPlane 初始化 canonical Gaussians。
2. 用 scene flow + depth 在动态区域 densify。
3. 计算每个 Gaussian 的 contribution $C_k$ 和 uncertainty $U_k$。
4. 在 unseen view/time 渲染 uncertainty map。
5. 缓存 DDIM-refined images，计算 uncertainty-aware diffusion loss。
6. 渲染 depth/flow，计算 data-driven losses。
7. 联合优化 4DGS。

实现基于 4DGS 官方代码，单张 RTX A5000 测试。uncertainty-aware regularization 从 20,000 iterations 后开始，40,000 iterations 训练设置在附录/文本中出现。

## 7. 实验设置与结果摘要

主数据集是 DyCheck，包含 handheld monocular videos，选择有 held-out views 的 7 个 scenes：apple、block、paper-windmill、teddy、space-out、spin、wheel。指标包括 PSNR、SSIM、LPIPS 及 masked versions。

Table 1 显示 UA-4DGS 在 4DGS 系方法中最佳：mPSNR 15.25，高于 4DGS 的 14.14；mLPIPS 0.390，优于 4DGS 的 0.430。但 MLP-based methods 在该 in-the-wild monocular setting 下仍整体强于 Gaussian Splatting，说明 4DGS 在随手拍动态视频中仍易过拟合。

Table 2 将 uncertainty-aware regularization 用到 static few-shot FSGS，在 LLFF 3-view 设置下 UA-3DGS 也优于 FSGS。Table 3/4 消融显示 dynamic region densification、$\mathcal{L}_{UA-diff}$ 和 $\mathcal{L}_{UA-TV}$ 都有贡献；不带 uncertainty gating 的 diffusion/TV 会提升 test 但损害 train reconstruction，导致 underfitting。

## 8. 声称贡献 vs 实际技术增量

论文声称解决 in-the-wild monocular 4DGS 的 overfitting 和 initialization 问题。实际增量是把“哪些区域训练视角支撑不足”量化成 visibility-based uncertainty，再用它 gate 外部 diffusion/depth priors。dynamic region densification 是另一个实用补丁，解决 SfM 不给动态区域种子的问题。

uncertainty 定义简单有效，但不是 posterior uncertainty；它更接近 observation support / visibility confidence。

## 9. 局限性和隐藏假设

* diffusion prior 可能生成与真实 3D scene 不一致的内容，因此必须 uncertainty-gated。
* 依赖 BLIP、DreamBooth、Stable Diffusion、scene flow、depth、RAFT，系统复杂。
* DDIM refine 缓存减少开销但仍增加训练工程复杂度。
* Gaussian Splatting 在 DyCheck 这类 handheld monocular setting 中仍落后于 MLP-based methods。
* uncertainty 基于训练视图贡献，可能无法捕捉错误几何但高可见的区域。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 任务 | monocular dynamic 4DGS in the wild |
| 输入 | handheld monocular video + depth/flow/scene flow |
| 输出 | dynamic 4D Gaussians |
| 表示 | HexPlane-deformed 4DGS |
| 关键模块 | visibility uncertainty, diffusion prior, depth TV, dynamic densification |
| 关键损失 | recon, grid, depth/flow, UA-diff, UA-TV |
| 主要优点 | 减少 novel-view overfitting，改善动态区域初始化 |
| 主要风险 | 依赖多个外部先验，Gaussian 方法仍弱于 MLP baseline |

## 11. 可复用组件

* 基于 alpha contribution 的 per-Gaussian uncertainty 可用于 gating 任意 prior。
* dynamic region densification 可直接加入其他 monocular 4DGS。
* uncertainty-aware TV 可以避免全局 depth smoothing 带来的细节损失。
* diffusion prior 缓存机制可用于其他 SDS/DDIM regularization pipeline。

## 12. Gap 和 idea seeds

* 把 visibility uncertainty 与 Bayesian/variational uncertainty 结合，区分“少观察”和“多解/冲突观察”。
* 对 diffusion prior 加 multi-view consistency，避免 $I_{DDIM}$ 逐视角不一致。
* 用 foundation model segmentation 把 dynamic region densification 从 pixel-level 升级到 object-level。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: 附录中 hyperparameters $c_0,c_1,\lambda$ 的具体值需复核。
* `NEED_HUMAN_CHECK`: scene flow/depth estimator [71] 的具体模型名需从 references 确认。

## 14. Evidence Anchors

* Sec. 3: 3DGS and 4DGS preliminaries, Eq. (1)-(6)。
* Sec. 4.1: uncertainty-aware regularization, Eq. (7)-(14)。
* Fig. 2: dynamic region densification visualization。
* Sec. 4.2: dynamic region densification, Eq. (15)。
* Sec. 4.3-4.4: data-driven losses and total loss, Eq. (16)-(20)。
* Table 1: DyCheck main results。
* Table 2-4: static few-shot and ablations。
