# MoDGS: Dynamic Gaussian Splatting from Casually-captured Monocular Videos with Depth Priors

## 0. Metadata

* Title: MoDGS: Dynamic Gaussian Splatting from Casually-captured Monocular Videos with Depth Priors
* Authors: Qingming Liu; Yuan Liu; Jiepeng Wang; Xianqiang Lyv; Peng Wang; Wenping Wang; Junhui Hou
* Venue/Year: ICLR 2025
* URL: `https://openreview.net/forum?id=2prShxdLkX`
* Project: `https://MoDGS.github.io`
* DOI: Not specified in Zotero metadata / extracted PDF
* Zotero item key: `KVNSR566`
* Zotero PDF attachment key: `P836FKXP`
* PDF path: `/Users/wangyibo/Zotero/storage/P836FKXP/Liu 等 - 2024 - MoDGS Dynamic Gaussian Splatting from Casually-captured Monocular Videos with Depth Priors.pdf`
* Local note path: `notes/MoDGS: Dynamic Gaussian Splatting from Casually-captured Monocular Videos with Depth Priors.md`
* Tags: Monocular Dynamic View Synthesis; Dynamic Gaussian Splatting; Depth Priors; Casual Videos; Ordinal Depth

## 1. One-Sentence Technical Summary

MoDGS 面向静止或慢速移动相机拍摄的 casual monocular dynamic videos，用 single-view depth priors 补足弱多视角约束，通过 3D-aware initialization 初始化 invertible deformation field 和 canonical Gaussians，再用 ordinal depth loss 替代 Pearson/scale-invariant depth loss 处理跨帧深度尺度不一致，从而显著提升动态场景 novel-view synthesis。

## 2. Problem Formulation

### 2.1 输入

* 一段 casual captured monocular video。
* camera poses 已知或通过预处理得到。
* 每帧图像 $I_t$。
* 单目深度估计器输出的 depth map $D_t$。
* RAFT 等方法估计的 inter-frame optical flow $F_{t_i\rightarrow t_j}$。

### 2.2 输出

* canonical space 中的一组 3D Gaussians。
* time-conditioned deformation field $T_t:\mathbb{R}^3\rightarrow\mathbb{R}^3$。
* 任意时间和 novel camera view 下的 rendered image 和 rendered depth。

### 2.3 任务难点

现有 monocular dynamic NeRF/GS 方法常依赖 “teleporting camera motion”：相机在不同时间大幅移动，提供伪多视角约束。casual videos 往往相机静止或缓慢移动，导致多视角几何约束弱，baseline 难以重建 dynamic 3D geometry。

### 2.4 基本假设

* 单目深度估计虽然尺度不稳定，但像素之间的 depth order 比绝对值更稳定。
* RAFT inter-frame flow 虽 noisy，但足以为 3D-aware deformation initialization 提供局部对应。
* canonical Gaussian field 能跨时间积累信息，比单帧 depth warping 更完整。

## 3. Method Overview

MoDGS 的 pipeline：

1. 对每帧用 GeoWizard 等 single-view depth estimator 估计 depth。
2. 用 RAFT 估计帧间 2D optical flow。
3. 在 static regions 上估计每帧 depth scale，粗略统一 depth 尺度。
4. 把 depth maps 和 2D flow lift 成 3D flow，训练 invertible deformation field 初始化。
5. 把所有时间的 depth points 通过 $T_t^{-1}$ 回投 canonical space，并 voxel downsample 初始化 canonical Gaussians。
6. 用 rendering loss 和 ordinal depth loss 联合优化 Gaussians 与 deformation field。

## 4. Method Details

### 4.1 Canonical Gaussians and deformation field

MoDGS 在 canonical space 中维护 Gaussians $\{G_i\}_{i=1}^N$。canonical space 不对应任一真实时间帧，只是所有 Gaussian canonical locations 的虚拟空间。

deformation field $T_t$ 将 canonical 3D point $x$ 映射到时间 $t$ 的 3D space：

$$
x_t=T_t(x).
$$

$T_t$ follow Omnimotion/CaDeX 设计，是 invertible MLP，因此 $T_t$ 和 $T_t^{-1}$ 都可直接计算。所有时间共享同一个 MLP，normalized time $t\in[0,1]$ 作为输入。

### 4.2 Depth scale initialization

单目 depth maps 在不同时间有不同尺度。MoDGS 先估计每帧 coarse scale：

* 找 static regions，可通过 2D flow threshold 或 SAM2 segmentation。
* 把某时间的 depth reproject 到第一帧。
* 在 static regions 上通过 least-squares fitting 求该帧 scale。
* 用求得 scale rectify depth maps。

这个步骤只能粗略对齐尺度，不能完全解决跨帧深度不一致，因此后续仍需要 ordinal depth loss。

### 4.3 3D-aware deformation initialization

给定 $D_{t_i}$、$D_{t_j}$ 和 2D flow $F_{t_i\rightarrow t_j}$：

1. 将两帧 depth maps lift 成 3D points。
2. 用 2D flow 建立两个 3D point sets 的对应，得到 3D flow $F^{3D}_{t_i\rightarrow t_j}$。
3. 对 $I_{t_i}$ 中 pixel 对应的 3D point $x_{t_i}$，找到目标时间 $t_j$ 的 target point $x_{t_j}$。
4. 训练 deformation field 使 canonical round trip 后的位置接近 target point：

$$
\ell_{init}=\sum ||T_{t_j}\circ T_{t_i}^{-1}(x_{t_i})-x_{t_j}||_2.
$$

这个初始化比 random/Kaiming/zero deformation 更能让后续 4D optimization 进入合理 basin。

### 4.4 Gaussian initialization

deformation field 初始化后：

1. 将所有帧的 depth maps 转为 3D points。
2. 用 $T_t^{-1}$ 把每帧 depth points 回投到 canonical space。
3. 合并所有时间的 canonical points，形成 dense points。
4. 用 predefined voxel size 均匀下采样。
5. 用下采样点的位置初始化 canonical Gaussians。

Appendix 中 voxel size 为 0.0043，scene normalized to $[-1,1]^3$。

### 4.5 Ordinal depth loss

Pearson / normalized depth loss 只能处理 scale ambiguity。MoDGS 指出，single-view depth maps 在不同帧之间不一定满足线性关系 $D_{t+1}=aD_t+b$，即使归一化后仍有 inconsistency。

观察：深度绝对值不稳定，但像素对的深度顺序更稳定。因此定义 depth order indicator：

$$
R(D_t(u_1),D_t(u_2))=
\begin{cases}
1, & D_t(u_1)>D_t(u_2)\\
-1, & D_t(u_1)<D_t(u_2)
\end{cases}.
$$

ordinal depth loss 让 rendered depth $\hat D_t$ 的顺序与 estimated depth $D_t$ 的顺序一致：

$$
\ell_{ordinal}=||\tanh(\alpha(\hat D_t(u_1)-\hat D_t(u_2)))-R(D_t(u_1),D_t(u_2))||.
$$

实现中随机采样 100k pixel pairs 计算该 loss。

## 5. Mathematical Objectives and Losses

### 5.1 Pearson correlation depth loss baseline

Pearson depth loss 最大化 rendered depth $\hat D_t$ 与 depth prior $D_t$ 的相关性：

$$
Corr(\hat D_t,D_t)=\frac{Cov(\hat D_t,D_t)}{\sqrt{Var(\hat D_t)Var(D_t)}}.
$$

Appendix 证明 Pearson depth loss 与 scale-shift invariant depth loss 等价。

### 5.2 MoDGS final loss

初始化之后，MoDGS 用 rendering loss 和 ordinal depth loss 联合训练：

$$
\ell=\lambda_{ordinal}\ell_{ordinal}+\lambda_{render}\ell_{render}.
$$

Appendix 中 depth order loss weight 为 0.1，$\alpha=100$。

### 5.3 Pair filtering

计算 ordinal depth loss 时：

* 先把 depth range normalize 到 $[0,1]$。
* 只考虑 depth difference 大于 0.02 的 pixel pairs。

这样减少近等深度点对的噪声监督。

## 6. Training and Inference Procedure

### 6.1 Training

* PyTorch implementation。
* deformation field initialization: 20k steps。
* joint optimization of Gaussians and deformation field: 20k steps。
* flow 在 evenly sampled key frames 上计算，例如每 1/5 frames。
* outer optimization loop 和 rendering loss follow original 3DGS。
* 使用 Gaussian centers render depth。
* optimizer: Adam。
* 3D Gaussian learning rate follow official 3DGS。
* deformation network LR: initialization 中从 $10^{-3}$ decay 到 $10^{-4}$；后续优化中从 $10^{-4}$ decay 到 $10^{-6}$。
* NVIDIA RTX A6000，约 14G memory。
* 总训练约 3.5 hours：2 hours initialization，1.5 hours optimization。
* rendering speed 约 75 FPS。

### 6.2 Inference

给定 novel camera 和 timestamp $t$：

1. 用 $T_t$ 将 canonical Gaussians deform 到时间 $t$。
2. 按 3DGS splatting 渲染 color。
3. 可同时用 Gaussian centers 渲染 depth。

## 7. Experimental Setup and Results Summary

### 7.1 Evaluation protocol

MoDGS 使用严格 monocular DVS 设置：只用一个 camera 的 video 训练，然后在另一个 camera 的 viewpoint 评估。这样避免 baseline 使用不同时间不同相机形成 pseudo-multiview video。

因为 casual/static input 可能导致重建尺度不一致，评估时手工标注 training images 与 ground-truth novel-view images 的 correspondences，并优化一个 scale factor 对齐 depth 后再计算 PSNR、SSIM、LPIPS。

### 7.2 Datasets

* DyNeRF: 6 scenes，18-20 synchronized cameras，10-30s videos；camera0 training，camera5/6 evaluation。
* Nvidia: 8 scenes，12 synchronized cameras；camera4 training，camera3/5 evaluation。
* MCV: 6 个 online in-the-wild casual videos，只定性。
* Davis: appendix 中使用 UniDepth + DROID-SLAM preprocessing。

### 7.3 Main results

DyNeRF / Nvidia average:

| Method | DyNeRF PSNR | DyNeRF SSIM | DyNeRF LPIPS | Nvidia PSNR | Nvidia SSIM | Nvidia LPIPS |
|---|---:|---:|---:|---:|---:|---:|
| HexPlane | 15.33 | 0.5593 | 0.4514 | 17.17 | 0.3675 | 0.4756 |
| SC-GS | 18.77 | 0.7359 | 0.2310 | 17.59 | 0.4679 | 0.3348 |
| D-GS | 19.55 | 0.7446 | 0.2171 | 18.07 | 0.4650 | 0.3422 |
| MoDGS | 22.64 | 0.8042 | 0.1545 | 19.27 | 0.5235 | 0.2581 |

MoDGS 在两套数据上三项指标均优于 baselines。

### 7.4 Ablation

3D-aware init and depth loss on DyNeRF:

| 3D-aware Init | Depth Loss | PSNR | SSIM | LPIPS |
|---|---|---:|---:|---:|
| no | Ordinal | 21.27 | 0.7655 | 0.1984 |
| yes | Pearson | 21.77 | 0.7938 | 0.1680 |
| yes | Ordinal | 22.96 | 0.8103 | 0.1518 |

different initialization on flame steak:

| Method | PSNR | SSIM | LPIPS |
|---|---:|---:|---:|
| ZeroDeformationInit | 22.34 | 0.7906 | 0.2151 |
| KaimingInit | 22.24 | 0.7744 | 0.2036 |
| 3D-AwareInit | 23.23 | 0.8083 | 0.1592 |

alpha ablation:

| $\alpha$ | PSNR | SSIM | LPIPS |
|---:|---:|---:|---:|
| 10 | 21.05 | 0.7575 | 0.2370 |
| 40 | 21.39 | 0.7813 | 0.1916 |
| 100 | 23.23 | 0.8083 | 0.1592 |
| 1000 | 23.16 | 0.8058 | 0.1715 |

depth ranking loss comparison:

| Loss | Sear Steak PSNR/SSIM/LPIPS | Cut Beef PSNR/SSIM/LPIPS | Coffee Martini PSNR/SSIM/LPIPS |
|---|---|---|---|
| DRL | 18.22 / 0.7390 / 0.2228 | 17.07 / 0.7162 / 0.2283 | 14.09 / 0.7465 / 0.1902 |
| Ordinal | 23.53 / 0.8126 / 0.1642 | 23.98 / 0.8221 / 0.1438 | 21.37 / 0.7962 / 0.1473 |

### 7.5 Robustness to depth estimator

Appendix Table 13 显示不同 depth estimators 性能相近：

| Depth estimator | PSNR | SSIM | LPIPS |
|---|---:|---:|---:|
| Marigold | 23.12 | 0.8057 | 0.1712 |
| ChronoDepth | 23.44 | 0.8105 | 0.1687 |
| DepthAnything | 23.35 | 0.8097 | 0.1621 |
| GeoWizard | 23.23 | 0.8083 | 0.1592 |

说明方法不强依赖某个特定 depth prior distribution。

## 8. Claimed Contribution vs Actual Technical Delta

### 8.1 Claimed contributions

* 针对 casually captured monocular videos 的 dynamic Gaussian splatting pipeline。
* 3D-aware initialization 学习合理 deformation field。
* ordinal depth loss 处理 depth prior 跨帧尺度/线性不一致。
* 在 DyNeRF、Nvidia、Davis 和 in-the-wild videos 上显著优于 baselines。

### 8.2 Actual technical delta

真正关键的是把 single-view depth priors 用得更适配 casual monocular DVS：

* 不把 depth prior 当作绝对 metric depth，而只信任 ordinal relation。
* 用 RAFT + depth lift 构造 3D flow，为 invertible deformation field 提供初始化。
* 用所有帧回投 canonical space 的 depth points 初始化 Gaussian cloud，避免只用第一帧 depth。
* 明确提出 “teleporting camera motion” 与 casual video setting 的评估差异。

### 8.3 与其他 depth-supervised 方法的区别

MoDGS 不是简单给 HexPlane/D-GS 加 depth loss。Appendix 显示 HexPlane+D 只略有提升，而 MoDGS 仍大幅领先；关键在 3D-aware initialization、canonical Gaussian accumulation 和 ordinal depth loss 的组合。

## 9. Limitations / Assumptions

* 只能重建输入视频中被观察到的 3D parts，不能想象 unseen parts；novel view 中不可见区域仍会有 artifacts。
* 当前最多处理约 10 秒视频；约 30 秒需要更大 deformation MLP 和更多 iterations。
* 复杂 motion 下如果 robust depth maps 难预测，方法仍可能失败。
* rapid motion 会导致 camera pose estimation 不准，MoDGS 和其他 dynamic Gaussian methods 都会受影响。
* heavy occlusions 中若遮挡区域从未被观察到，不能生成新内容。
* 对 specular objects 没有专门建模，会产生 artifacts。
* 需要 camera poses；DyCheck iPhone dataset 因 pose errors 被作者排除。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| Task | casual monocular dynamic novel view synthesis |
| Input | monocular video, camera poses, monocular depth, optical flow |
| Representation | canonical 3D Gaussians + invertible deformation MLP |
| Depth estimator | GeoWizard by default, robust to alternatives |
| Flow estimator | RAFT |
| Initialization | depth scale alignment + 3D flow + canonical point fusion |
| Key loss | ordinal depth loss |
| Final loss | rendering loss + ordinal depth loss |
| Training cost | about 3.5 hours on RTX A6000 |
| Rendering speed | about 75 FPS |
| Main datasets | DyNeRF, Nvidia, Davis, MCV |
| Main gain | works when camera is static or slow-moving |
| Main weakness | unseen regions, complex motion, pose/depth failures |

## 11. Reusable Components

* **3D-aware deformation initialization**: depth + flow lift 成 3D flow，初始化 dynamic deformation field。
* **All-frame canonical Gaussian initialization**: 把所有时间 depth points 回投 canonical 后下采样。
* **Ordinal depth supervision**: 用深度顺序替代绝对值/线性相关，适合 noisy monocular depth priors。
* **Strict monocular DVS protocol**: 单 camera 训练、其他 camera 评估，更贴近 casual capture。
* **Depth-prior distillation through 3DGS**: 用 3D representation 和 rendering loss 把 inconsistent monocular depth 蒸馏成 temporally consistent rendered depth。

## 12. Gap / Idea Seeds

* 将 ordinal depth loss 与 uncertainty-aware pair sampling 结合，过滤不可靠 depth/order pairs。
* 用 video tracking priors 替代短程 RAFT flow，增强 long-range deformation initialization。
* 在 unseen regions 引入 diffusion/inpainting prior，但用 geometry consistency 约束避免 hallucination。
* 对 specular regions 加 inverse rendering 或 view-dependent BRDF 分支。
* 设计 scalable deformation MLP 或 chunked canonical Gaussians，处理 30s+ videos。
* 将 ordinal depth supervision 应用于其他 dynamic GS 方法，验证其独立贡献。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: DOI 未在 Zotero metadata 或 PDF 抽取中出现。
* `NEED_HUMAN_CHECK`: Project URL 大小写 `https://MoDGS.github.io` 是否实际可访问需确认。
* `NEED_HUMAN_CHECK`: camera pose preprocessing 对不同数据集差异较大，尤其 Davis 使用 UniDepth + DROID-SLAM。
* `NEED_HUMAN_CHECK`: Evaluation 中 manual correspondences 和 scale factor alignment 的具体标注数量/流程需看代码。
* `NEED_HUMAN_CHECK`: invertible MLP architecture 细节未在主文摘要中完全展开，需查代码。
* `NEED_HUMAN_CHECK`: MCV dataset 只有定性结果，不能与主表直接比较。

## 14. Evidence Anchors

* Abstract: MoDGS targets casually captured monocular videos, adopts single-view depth estimation, 3D-aware initialization, and robust depth loss.
* Fig. 1: baseline fails on static monocular video; MoDGS improves invisible/novel-view regions and depth consistency.
* Fig. 2: pipeline with canonical Gaussians, deformation field, estimated depth, rendered depth, ordinal depth loss.
* Sec. 3.1: canonical Gaussians and invertible deformation field $T_t$.
* Sec. 3.2: depth scale initialization, 3D flow from depth + RAFT, deformation initialization loss, canonical Gaussian initialization.
* Eq. 1: $\ell_{init}$ for 3D-aware initialization.
* Sec. 3.3: Pearson correlation limitation and ordinal depth loss.
* Eq. 2-3: depth order indicator and ordinal loss.
* Eq. 4: final MoDGS loss.
* Table 1: DyNeRF and Nvidia main quantitative results.
* Table 2: ablation on 3D-aware initialization and depth loss.
* Appendix A.1: training steps, voxel size, learning rates, $\alpha=100$, depth pair threshold, memory, training time, FPS.
* Appendix A.6-A.13: Davis/SoM comparison, alpha, noise, per-scene results, depth ranking loss, video depth, HexPlane+D, initialization methods, depth estimators.
* Appendix A.14-A.20: video length, depth consistency, complex/rapid motion, occlusion, specular, robustness discussion.
