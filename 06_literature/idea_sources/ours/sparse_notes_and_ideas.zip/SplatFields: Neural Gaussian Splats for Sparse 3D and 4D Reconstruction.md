# SplatFields: Neural Gaussian Splats for Sparse 3D and 4D Reconstruction

## 0. 元数据

* Title: SplatFields: Neural Gaussian Splats for Sparse 3D and 4D Reconstruction
* Authors: Marko Mihajlovic; Sergey Prokudin; Siyu Tang; Robert Maier; Federica Bogo; Tony Tung; Edmond Boyer
* Year: 2025
* Venue: ECCV 2024 / Computer Vision - ECCV 2024
* PDF source: `/Users/wangyibo/Zotero/storage/I5ARGAX8/Mihajlovic 等 - 2025 - SplatFields Neural Gaussian Splats for Sparse 3D and 4D Reconstruction.pdf`
* Zotero item key: `JYHQP6YA`
* Zotero PDF attachment key: `I5ARGAX8`
* Code: `markomih.github.io/SplatFields`
* Project page: `http://markomih.github.io/SplatFields`
* Dataset link: Not specified
* Main task: sparse-view static 3D reconstruction and dynamic 4D reconstruction with Gaussian Splatting
* Domain: 3DGS regularization, neural fields, dynamic scene reconstruction
* Input: sparse calibrated multi-view images or monocular/multi-view dynamic sequences; initial point cloud such as SfM or visual hull
* Output: optimized Gaussian splats for real-time novel view rendering

## 1. 一句话技术摘要

SplatFields 认为 sparse-view 下 3DGS 过拟合的根源之一是 Gaussian attributes 缺少空间自相关，于是在训练期用 CNN-generated tri-plane features 和 compact neural fields 预测 splat 位置、颜色、尺度、旋转和 opacity，引入 neural field 的 spatial bias；训练完成后丢弃 generator，仅保留普通 Gaussians 以维持实时渲染。

## 2. 问题形式化

标准 3DGS 将场景表示为一组相互独立的 Gaussian primitives。每个 primitive 的位置、尺度、旋转、颜色、opacity 都直接优化。这种自由度在密集视角下很强，但在 sparse views 下容易把训练视角拟合得很好，却在 novel views 上产生不连贯结构和过拟合伪影。

本文将问题重新表述为：如何在不牺牲 3DGS 实时渲染优势的前提下，让 nearby splats 的 attributes 具有空间自相关和连续性。作者用 Moran's I 衡量局部邻域内 color、opacity、covariance 的 spatial autocorrelation，并观察到更高 Moran's I 往往对应更好的 novel-view reconstruction。

## 3. 方法概览

SplatFields 的核心是训练期 neural generator。它不直接把每个 Gaussian attribute 作为独立参数优化，而是通过“tri-plane CNN features + MLP neural fields”生成这些 attributes。

第一步，CNN generator $g_{\theta}$ 从随机噪声生成三个 axis-aligned tri-plane feature maps $F$，作为 deep structural prior。每个 Gaussian center $p_k$ 投影到三张 feature planes 上，通过 bilinear interpolation 采样并拼接成 feature $f_k$。

第二步，将 $p_k$、$f_k$ 和可选时间 $t$ 输入 deformation MLP $f_{\Theta}$，得到 refined center $\hat{p}_k$。

第三步，将 refined point location 和 feature 输入一组 compact neural fields，分别预测 Gaussian color、scale、opacity 和 rotation。预测出的 Gaussians 用标准 3DGS rasterizer 渲染，并用 photometric loss 优化所有 learnable modules。

第四步，训练结束后丢弃 CNN generator 和 MLPs，把最终 Gaussian attributes 固化下来，因此推理仍是普通 3DGS 渲染速度和兼容性。

## 4. 方法细节

**Spatial autocorrelation diagnosis。** 作者为每个 splat 选 5 个 nearest neighbors，计算 splat attributes 的 Moran's I。普通 3DGS 在 sparse views 下训练视角质量极高但 novel-view 质量低，且 color/opacity/covariance 的 Moran's I 较低；SplatFields 训练视角拟合略弱，但 novel-view 指标更好，Moran's I 更高。

**Deep structural prior。** 直接用 3D CNN 生成 3D feature field 太贵，因此 SplatFields 使用 2D CNN 生成 tri-plane representation。CNN 的输入是随机初始化噪声 $\epsilon\sim\mathcal{N}(0,I)$，输出三个 $H\times W$ feature planes。这个设计借鉴 Deep Image Prior/ZeroRF，利用 CNN 对局部结构和低频信号的优化偏置来正则化 splat features。

**Neural splat fields。** 每个 splat center $p_k$ 在三张 plane 上投影和采样，得到 $f_k\in\mathbb{R}^{3l}$。然后 deformation MLP 预测 refined point $\hat{p}_k$。随后多个小型 MLP neural fields 预测 splat attributes。论文说明这些 MLP 约 5-6 layers、64-128 neurons。

**Color 表示。** 与标准 3DGS 使用 spherical harmonics 不同，SplatFields 直接预测 view-dependent color。具体 view direction 如何输入 compact color field 在主文抽取中不完整，需查 supplementary。

**Static regularization。** 静态重建中额外加入 $\|\hat{p}_k\|_2$ norm regularization，使 splats 不显著偏离 origin/初始结构，类似 dynamic 3DGS 中的 floor loss 思路。

**4D extension。** 对动态场景，SplatFields 将 MLPs 条件化到时间 $t$，并增加 time-conditioned flow field $f_p$ 将 Gaussian centers warp 到目标时间步。为了增强复杂动态的表达能力，使用 ResFields MLP architecture。论文比较了 DCT、translation offset、SE(3)、scaled SE(3) 等 flow parameterizations，并发现 ResFields 能稳定提升质量。

## 5. 数学目标与损失

标准 3D Gaussian distribution 为：

$$
G_k(x)\propto\exp(-\frac{1}{2}(x-p_k)^T\Sigma_k^{-1}(x-p_k))
$$

协方差由 rotation 和 scale 构成：

$$
\Sigma_k=O_ks_ks_k^TO_k^T
$$

投影到 2D 后，image-space Gaussian 为：

$$
G_k^{2D}(x')\propto\exp(-\frac{1}{2}(x'-p'_k)^T(\Sigma_k^{2D})^{-1}(x'-p'_k))
$$

Alpha compositing 为：

$$
c(x')=\sum_{k=1}^{K}c_k\alpha_kG_k^{2D}(x')\prod_{j=1}^{k-1}(1-\alpha_jG_j^{2D}(x'))
$$

标准 3DGS photometric loss 为：

$$
L=(1-\lambda)L_1+\lambda L_{\text{D-SSIM}}
$$

Tri-plane generator 为：

$$
F=g_{\theta}(\epsilon)\in\mathbb{R}^{3\times H\times W\times l}
$$

Deformation MLP 为：

$$
\hat{p}_k=f_{\Theta}(p_k,f_k,t)
$$

其中 $t$ 在静态 3D reconstruction 中可省略，在 4D reconstruction 中作为时间条件输入。最终训练目标是在标准 photometric loss 上优化 $g_{\theta}$、$f_{\Theta}$ 和属性预测 fields；静态版本还加入 $\|\hat{p}_k\|_2$ norm regularization。主文未给出该 regularization 的权重。

## 6. 训练与推理流程

1. 用 SfM point cloud 或 visual hull 初始化 point locations。
2. 初始化随机噪声 $\epsilon$，由 CNN generator 生成 tri-plane features $F$。
3. 对每个 point $p_k$，在三张 plane 中采样并拼接 feature $f_k$。
4. 用 deformation MLP 预测 refined point $\hat{p}_k$。
5. 用 compact neural fields 预测 color、scale、opacity、rotation 等 Gaussian attributes。
6. 用 3DGS rasterizer 从训练相机视角渲染图像。
7. 用 $L_1+D$-SSIM photometric loss 训练 generator 和 neural fields，并沿用 3DGS adaptive density control 周期性 densify/prune point set。
8. 4D 场景中，MLPs 加入时间条件 $t$，并用 time-conditioned flow field warp Gaussians 到目标时间。
9. 训练完成后丢弃 neural generator/fields，保存最终 splats；推理时直接用普通 Gaussian rasterization。

## 7. 实验设置与结果摘要

静态实验包括 Owlii 首帧 toy analysis、Blender sparse static reconstruction、DTU 3-view reconstruction。Blender 设置包含 6 和 12 input views，主要比较 SparseNeRF、SuGaR、ScaffoldGS、Mip3DGS、3DGS、Light3DGS、2DGS、3DGS with local Moran regularization 等。

Table 1 显示 spatial autocorrelation 与泛化的关系：3DGS 在训练视角上 SSIM/PSNR 很高，但 novel-view SSIM/PSNR 较低；SplatFields 训练拟合略弱，但 novel-view PSNR 从 27.50 提升到 30.33，color/opacity/covariance 的 Moran's I 也更高。

Table 2 的 Blender sparse static reconstruction 中，SplatFields3D 在 12 views 和 6 views 下整体优于多数 splatting baselines。作者强调 views 越少，SplatFields 与 baseline 的差距越明显，支持 spatial bias 是 sparse setting 下有效 regularizer 的判断。

Table 3 消融显示：MLP-only basic pipeline 已可工作；加入 $L_2$ norm regularization 有小幅增益；加入 tri-CNN features 在较多视角下明显提升，但在 4/6 views 极端 sparse 下结果并非所有指标都单调提升，说明 tri-plane prior 与数据稀疏程度仍需调参。

动态实验包括 NeRF-DS monocular dynamic sequences 和 Owlii multi-view dynamic sequences。NeRF-DS 中 SplatFields4D 达到 23.84 PSNR、85.17 SSIM、17.86 LPIPS $\times10^2$，与 NeRF/3DGS dynamic baselines 竞争，同时保持 120+/30 FPS 和约 1 小时训练。Owlii 中，在 10/8/6/4 input views 下，SplatFields4D 基本优于 4D-GS、Deformable3DGS、4DGaussians 等 splatting methods，并接近或超过训练更慢的 dynamic NeRF variants。

## 8. 声称贡献与实际技术增量

* 声称贡献 1: 在 3DGS 优化中引入 spatial bias。实际增量是通过 tri-plane CNN features 和 neural fields 生成 splat attributes，而不是手工邻域平滑。
* 声称贡献 2: 适用于静态和动态 sparse reconstruction。实际增量是静态 SplatFields3D + time-conditioned SplatFields4D/flow field 的统一框架。
* 声称贡献 3: 训练期 neural regularization，推理期保持 3DGS。实际优势是 generator discarded after training，因此不牺牲现有 rasterization pipelines。
* 与直接 Moran regularization 的差异: 直接强制邻域相似效果不如 SplatFields，说明可学习 neural prior 比固定 local smoothness 更灵活。

## 9. 局限与隐含假设

* 极端 sparse 且高度动态场景中性能下降，例如 Owlii 4 views rapid motion，仍不如最佳 NeRF-based methods。
* 需要初始 point cloud 或 visual hull；初始化质量对最终结构仍重要。
* 训练比 vanilla 3DGS 更复杂，需要维护 CNN generator、tri-plane features 和多个 MLP fields。
* 虽然推理可丢弃 generator，但训练期显存/时间和 implementation complexity 增加。
* 不使用外部 data-driven priors，优点是通用，缺点是在极少视角下缺少语义/几何先验补充。
* 主文中部分 attribute fields、view-dependent color 输入和 regularization 权重细节需要 supplementary。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法类别 | Neural-field-regularized 3D/4D Gaussian Splatting |
| 核心假设 | Nearby splats should have spatially autocorrelated attributes |
| 核心模块 | Tri-plane CNN generator; deformation MLP; compact neural fields; time-conditioned flow field |
| 输入条件 | Sparse calibrated views; initial point cloud/visual hull |
| 输出 | Static/dynamic Gaussian splats for real-time rendering |
| 训练期额外成本 | CNN generator + MLP fields + optional ResFields flow |
| 推理期成本 | 与普通 3DGS 接近，generator 可丢弃 |
| 主要风险 | 极端 sparse/rapid motion 下仍弱于 NeRF priors |

## 11. 对我研究可复用的组件

* **Spatial autocorrelation metric**: Moran's I 可作为诊断 sparse-view 3DGS 是否过拟合/局部不连贯的指标。
* **Training-only neural generator**: 用 neural field 约束 Gaussian attributes，训练后 bake 回普通 Gaussians。
* **Tri-plane feature prior**: 可与其他 sparse-view GS 的 depth/covisibility/dropout regularizers 组合。
* **Time-conditioned flow field**: 可替代直接 per-Gaussian deformation，在动态 sparse-view 中加入时空连续性。
* **ResFields MLP upgrade**: 在不显著影响训练速度的情况下提升 dynamic modeling capacity。

## 12. 缺口与想法种子

* **Covisibility-aware SplatFields**: 将 CoMapGS 的 covisibility weighting 加到 SplatFields，使低共视区域获得更强 neural prior。
* **Uncertainty-gated neural fields**: 只在高不确定 Gaussians 上使用 neural-field-generated attributes，低不确定区域保持自由 3DGS。
* **Diffusion/depth prior + SplatFields**: 极端 sparse 下用单目深度或 diffusion pseudo-view 给 tri-plane prior 提供更强初始化。
* **Adaptive bake-out**: 训练后不是完全丢弃 generator，而是对动态或不稳定区域保留 lightweight field，静态可靠区域 bake 成 splats。
* **Moran-guided densification**: 低 spatial autocorrelation 区域触发 regularization 或重新 densify，替代纯 gradient-based densification。

## 13. 人工检查清单

* `NEED_HUMAN_CHECK`: supplementary 中 compact neural fields 的输入、输出 parameterization 和 view-dependent color 细节。
* `NEED_HUMAN_CHECK`: $\|\hat{p}_k\|_2$ norm regularization 的权重。
* `NEED_HUMAN_CHECK`: adaptive density control 与 neural generator 共同训练时，新增 Gaussians 如何初始化 feature。
* `NEED_HUMAN_CHECK`: 两个 Zotero PDF attachment `I5ARGAX8` 与 `HARV2J6B` 是否完全重复。

## 14. 证据锚点

* Abstract: 识别 splat features 缺少 spatial autocorrelation 是 sparse 3DGS 表现差的因素，并提出用 implicit neural field regularize。
* Fig. 1 / Table 1: Moran's I 与 novel-view quality 的关联。
* Sec. 4 Limitations of 3DGS / Key Insight: sparse views 下 independent point primitives 容易 overfit。
* Sec. 4 Deep Structural Prior / Eq. (8): CNN generator 生成 tri-plane representation。
* Fig. 2: SplatFields pipeline，从 point locations 采样 tri-plane features，经 deformation MLP 和 attribute fields 生成 Gaussians。
* Sec. 4 Neural Splat Fields / Eq. (9): deformation MLP $\hat{p}_k=f_{\Theta}(p_k,f_k,t)$。
* Sec. 4 Splat Norm Regularization: 静态重建中的 norm regularization。
* Sec. 4 4D Reconstruction: time-conditioned neural fields、flow field 和 ResFields。
* Table 2 / Fig. 3: Blender sparse static reconstruction。
* Fig. 5: DTU 3-view reconstruction。
* Table 3: tri-plane CNN generator ablation。
* Table 4 / Fig. 4: NeRF-DS monocular dynamic reconstruction。
* Table 5: Owlii multi-view dynamic sparse reconstruction。
* Table 6: flow model ablation。
* Sec. 6 Limitations: 极端 sparse 和快速动态下仍不如最佳 NeRF-based methods。
