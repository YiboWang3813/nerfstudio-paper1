# Vidu4D: Single Generated Video to High-Fidelity 4D Reconstruction with Dynamic Gaussian Surfels

## 0. Metadata

* Title: Vidu4D: Single Generated Video to High-Fidelity 4D Reconstruction with Dynamic Gaussian Surfels
* Authors: Yikai Wang; Xinzhou Wang; Zilong Chen; Zhengyi Wang; Fuchun Sun; Jun Zhu
* Venue/Year: NeurIPS 2024
* Project: `https://vidu4d-dgs.github.io`
* DOI: Not specified in Zotero metadata / extracted PDF
* Zotero item key: `3YYG9G4A`
* Zotero PDF attachment key: `6KYV8LJD`
* PDF path: `/Users/wangyibo/Zotero/storage/6KYV8LJD/Wang 等 - Vidu4D Single Generated Video to High-Fidelity 4D Reconstruction with Dynamic Gaussian Surfels.pdf`
* Local note path: `notes/Vidu4D: Single Generated Video to High-Fidelity 4D Reconstruction with Dynamic Gaussian Surfels.md`
* Tags: Generated Video; 4D Reconstruction; Gaussian Surfels; Dynamic Gaussian Surfels; Text-to-4D

## 1. One-Sentence Technical Summary

Vidu4D 面向单个生成视频的 4D 重建，先用 neural SDF 初始化 camera poses 和连续非刚性 warping field，再用 Dynamic Gaussian Surfels 将 surface-aligned Gaussian surfels 从 static state warp 到每个时间的 warped state，并通过 warped-state normal regularization 与 rotation/scale refinement 同时提升几何稳定性和纹理细节。

## 2. Problem Formulation

### 2.1 输入

* 单段 RGB video，通常来自 text-to-video generative model。
* 视频只有单视角时间序列，没有已知 camera trajectory。
* 生成视频可能有 frame distortion、非刚性形变、背景 flickering、illumination changes。

### 2.2 输出

* sequential 3D / 4D representation。
* 每个时间步可渲染 novel view color、normal 和 surfel feature。
* 在 text-to-video model 外接时，可形成 text-(to-video)-to-4D pipeline。

### 2.3 优化目标

给定时间 $t=1,\dots,T$ 的 3D 表示参数 $\theta_t$ 和 differentiable renderer $g$，使渲染颜色 $c(\bar x_t)$ 拟合观测颜色 $\hat c(\bar x_t)$。论文把这个任务写成跨时间和像素的 empirical reconstruction loss。

### 2.4 关键困难

* generated video 没有可靠 camera poses。
* 生成视频的 3D consistency 只是不完全的隐式一致性。
* 非刚性形变和 frame distortion 会破坏 static Gaussian surfels 的 surface alignment。
* 单纯 warp Gaussian primitives 容易出现 texture flickering。

## 3. Method Overview

Vidu4D 有两个主要阶段。

### 3.1 Field initialization stage

先训练一个 neural SDF，并使用与 DGS 类似的 bone-based warping structure。这个阶段做两件事：

* 初始化 camera poses。
* 初始化 DGS 后续需要的 continuous warping field。

SDF 阶段使用 backward warping，把 warped-state ray samples 映射回 static state；再通过 cycle loss 推出可用于 DGS 的 forward warping。

### 3.2 DGS stage

DGS 使用 Gaussian surfels 作为 surface-aligned primitives。每个 surfel 在 static state 中定义在局部 tangent plane 上，然后用 time-varying non-rigid warping function 变换到 warped state。

DGS 的三项关键设计：

* **Non-rigid warping for surfels**: 用 $B$ 个 bone transformations 经过 dual quaternion blend skinning 得到合法的 $SE(3)$ warp。
* **Warped-state normal regularization**: 不在 static state 直接正则 surfel normals，而在 warped state 估计 surface normal 并对齐，避免非刚性 warp 破坏结构。
* **Dual branch refinement**: 在共享中心点和 warping 的同时，额外学习 rotation/scale refinements，减少 texture flickering 并增强细节。

## 4. Method Details

### 4.1 Gaussian surfel in static state

第 $k$ 个 Gaussian surfel 由 center $p_k^*$、局部坐标系中的两个 tangent vectors $t_u^*,t_v^*$ 和 scaling factors $s_u^*,s_v^*$ 表示。对局部坐标 $u=(u,v)$，world coordinate 为：

$$
P_k^*(u)=p_k^*+s_u^*t_u^*u+s_v^*t_v^*v.
$$

它等价于一个定义在局部 tangent plane 上的 2D Gaussian primitive。这里 `*` 表示 static state。

### 4.2 Bone-based non-rigid warping

DGS 用 $B$ 个 bones 作为 deformation key points。第 $b$ 个 bone 在时间 $t$ 的 rigid transform 记为 $J_b^t\in SE(3)$。对某个 surfel point，先计算 skinning weights $w_b^t$，再用 dual quaternion blend skinning 组合骨骼变换：

$$
J^t=\mathcal{R}\left(\sum_{b=1}^B w_b^t \mathcal{Q}(J_b^t)\right).
$$

其中 $\mathcal{Q}$ 是 quaternion process，$\mathcal{R}$ 是 inverse quaternion process，保证组合后的 $J^t$ 仍在 $SE(3)$ 中。

把 $J^t$ 写成 rotation $\tilde R^t$ 和 translation $\tilde T^t$ 后，static surfel point 被 warp 到时间 $t$ 的 warped state：

$$
P_k^t(u)=J^tP_k^*(u).
$$

### 4.3 Continuous warping field

为了让 normal regularization 在 warped state 中稳定，论文把 $J_b^t$ 设计为连续场。MLP 以 bone latent code $\gamma_b^t$、局部坐标 $u$ 和时间 $t$ 为条件，输出 6D dual quaternion，再映射为 $SE(3)$：

$$
J_b^t=\mathcal{R}(MLP(\gamma_b^t;u,t)).
$$

这个设计让 warping 随空间局部坐标和时间连续变化，而不是对一个 surfel rigidly 使用离散 transform。

### 4.4 Warped-state normal regularization

普通 Gaussian surfels 方法会鼓励 surfels 与表面局部对齐。Vidu4D 认为动态场景中直接套用 static normal regularization 会被非刚性 warp 破坏，因此改为在 warped state 中做 normal consistency。

对 ray 与 surfels 的交点，计算 oriented surfel normal $n_k$，并用 nearby depth points 的 finite differences 得到 warped-state surface normal $N_t$。normal loss 形式是对交点按 alpha blending weight $\omega_k$ 加权的 $1-n_k^TN_t$。

直观上，它约束 warped 后的 surfels 仍贴合实际表面，而不是只在 canonical/static state 几何正确。

### 4.5 Dual branch refinement

为减少 warping 时的 texture flickering，DGS 对 static rotation matrix $R_k^*$ 和 scaling matrix $S_k^*$ 学习 refinement terms $\Delta R_k^*$ 和 $\Delta S_k^*$。refinement 不改变 center $p_k^*$ 和 warping $J^t$，只改变 rotation/scale。

训练时维护两个分支：

* no-refinement branch。
* refinement branch。

两个分支共享 Gaussian centers 和 warping functions，但有不同的 rotation/scale matrices。这样可以让 refined branch 捕获 appearance details，同时保持几何中心与 warp 一致。

### 4.6 Rasterization

对 pixel ray，按照 Gaussian surfels / Gaussian splatting 的交点与 alpha-weighted appearance accumulation 做 volume rendering：

$$
c(\bar x)=\sum_k c_k\alpha_kG_k(u(\bar x))\prod_{j=1}^{k-1}(1-\alpha_jG_j(u(\bar x))).
$$

实现中对 $G_k(u(\bar x))$ 进一步使用 low-pass filtering。

## 5. Mathematical Objectives and Losses

### 5.1 Reconstruction objective

核心目标是跨时间拟合每帧观测颜色：

$$
\min_\theta \frac{1}{T}\sum_{t=1}^{T}\sum_{\bar x_t} L(c(\bar x_t),\hat c(\bar x_t)).
$$

### 5.2 Normal loss

warped-state normal regularization 可概括为：

$$
L_n=\sum_k \omega_k(1-n_k^TN_t).
$$

其中 $\omega_k$ 是 ray 上 surfel intersection 的 blending weight，$N_t$ 是 warped state depth points finite difference 估计出的 surface normal。

### 5.3 Field initialization cycle loss

SDF 初始化阶段训练 backward warp，同时要求 forward-after-backward 近似 identity：

$$
L_{cyc}=||J^f(J^{f,-1}(X^f))-X^f||_2^2.
$$

$X^f$ 可以是 mesh surface point 或 camera ray sample point。该 loss 用来缓解 SDF sample distribution 和 DGS surface sample distribution 的 gap。

### 5.4 Skinning weights

Appendix 中说明，第 $b$ 个 bone 的 skinning weight 基于 normalized Mahalanobis distance，并经过 softmax 得到。bone 由 learnable Gaussian ellipsoid 表示，包含 center、orientation 和 precision/scaling matrix。

## 6. Training and Inference Procedure

### 6.1 Evaluation split

实验 follow dynamic reconstruction 标准 pipeline：

* 每 4 帧取 1 帧作为 training frame。
* 每对 training frames 中间的 frame 作为 validation frame。

### 6.2 Field initialization

1. 使用 8-layer NeRF-like volume rendering architecture。
2. SDF MLP 初始化为 approximate unit sphere。
3. 使用 NeuS-style scene representation。
4. 使用 DinoV2 features 做 unsupervised registration，并借鉴 RAC 训练 feature rendering channel。
5. 得到 neural SDF、warping field 和 camera poses。
6. 用 marching cubes 提取 canonical mesh。
7. 在 mesh sampled surface points 上初始化 Gaussian surfel centers。
8. SH 0th order 初始化为 nearest vertices 的 RGB。
9. 保留 learned camera poses 和 forward warping field 给 DGS stage。

### 6.3 DGS stage

* Gaussian surfel centers 来自 neural SDF surface samples。
* warping field 从 field initialization 的 forward field 初始化。
* bone latent code embedding dimension $\gamma_b^t$ 为 128。
* follow BANMo，使用 25 bones 优化 skinning weights。
* 每个 reconstruction 在 A800 GPU 上训练超过 1 小时。

### 6.4 Text-to-4D workflow

1. 输入 text prompt。
2. 用 Vidu video diffusion model 生成 single video。
3. 对生成视频运行 field initialization。
4. 运行 DGS 得到 4D representation。
5. 输出 novel-view color、normal 和 surfel feature renderings。

## 7. Experimental Setup and Results Summary

### 7.1 Baselines

论文比较了 NeRF-based 和 Gaussian-based dynamic reconstruction methods：

* BANMo。
* D-NeRF。
* Deformable-GS。
* SCGS。
* Deformable-GS + our field init。
* SCGS + our field init。

加入 `w. Poses` / `our field init` 变体是为了公平比较 camera pose 初始化对 baseline 的影响。

### 7.2 Quantitative results

Novel-view results on generated videos:

| Method | Average PSNR | Average SSIM | Average LPIPS |
|---|---:|---:|---:|
| BANMo | 13.62 +/- 2.99 | 0.6153 +/- 0.0714 | 0.3738 +/- 0.0665 |
| D-NeRF | 21.01 +/- 2.86 | 0.8519 +/- 0.0717 | 0.1522 +/- 0.0754 |
| Deformable-GS | 13.22 +/- 3.42 | 0.5934 +/- 0.0535 | 0.3749 +/- 0.0763 |
| SCGS | 21.17 +/- 2.69 | 0.8547 +/- 0.0691 | 0.1504 +/- 0.0737 |
| Deformable-GS + our field init | 22.63 +/- 2.14 | 0.8469 +/- 0.0438 | 0.1452 +/- 0.0354 |
| SCGS + our field init | 24.75 +/- 2.11 | 0.8680 +/- 0.0440 | 0.1201 +/- 0.0359 |
| Vidu4D / DGS | 27.30 +/- 2.66 | 0.9152 +/- 0.0602 | 0.0877 +/- 0.0564 |

论文强调 averaged results 上，DGS 比 SCGS + poses 高约 2.5 PSNR。

### 7.3 Single-video examples

三段示例中，Vidu4D full model 指标为：

| Video | PSNR | SSIM | LPIPS |
|---|---:|---:|---:|
| Cat | 24.63 | 0.8432 | 0.1559 |
| Cheetah | 25.68 | 0.8843 | 0.1117 |
| Dragon | 28.58 | 0.9392 | 0.0618 |

### 7.4 Ablation

Field initialization and refinement ablation:

| Variant | Cat PSNR/SSIM/LPIPS | Cheetah PSNR/SSIM/LPIPS | Dragon PSNR/SSIM/LPIPS |
|---|---|---|---|
| w.o. init | 20.15 / 0.7961 / 0.2393 | 20.96 / 0.8194 / 0.1940 | 25.33 / 0.9146 / 0.0938 |
| w.o. refinement | 24.19 / 0.8196 / 0.1797 | 24.10 / 0.8582 / 0.1242 | 27.71 / 0.9128 / 0.0687 |
| full | 24.63 / 0.8432 / 0.1559 | 25.68 / 0.8843 / 0.1117 | 28.58 / 0.9392 / 0.0618 |

Qualitative ablation:

* 去掉 warped-state normal regularization 会破坏 surface-aligned Gaussian surfels 的结构完整性，normal maps 更不一致。
* 去掉 refinement branch 会损失 fine-grained appearance details，并加重 texture flickering。
* 去掉 field initialization 后 camera poses 与 DGS performance 明显退化。

## 8. Claimed Contribution vs Actual Technical Delta

### 8.1 Claimed contributions

* 从 single generated video 重建 high-fidelity 4D representation。
* 提出 Dynamic Gaussian Surfels。
* warped-state geometric regularization 提升几何。
* rotation/scale refinement 缓解 flickering 并提升细节。
* field initialization 为 generated videos 提供 camera poses 和 warping initialization。

### 8.2 Actual technical delta

Vidu4D 的核心不是简单把 3DGS 换成 4DGS，而是把 surface-aware Gaussian surfels 和 generated-video 特有的 initialization 问题打包解决：

* DGS 把 Gaussian surfel 的 local tangent geometry 带入 dynamic warping。
* Continuous warping field 让 normal regularization 可以在 warped state 中有效工作。
* Dual branch refinement 保留 shared center/warp，同时允许 appearance geometry 的 rotation/scale 局部修正。
* Field initialization 对生成视频尤其关键；表中 baseline 加上其 initialization 后也明显变强，说明 camera/warp 初始化是主要瓶颈之一。

### 8.3 与一般 dynamic GS 的区别

一般 dynamic GS 多在真实视频或已知 camera setting 中拟合 dynamic radiance field。Vidu4D 面向 generated video，重点是：

* camera trajectory unknown。
* generated frames may be distorted。
* 需要 text-to-4D pipeline 中可用。
* 重建质量同时看 texture 与 geometry/normal。

## 9. Limitations / Assumptions

* 依赖输入生成视频质量；视频本身不一致会限制 4D 重建上限。
* 大场景 scalability 仍是挑战。
* 训练开销较高，每个 reconstruction 在 A800 上超过 1 小时，不适合实时应用。
* 与 generative models 结合时有 deceptive content / deepfake 风险。
* 只释放 reconstruction code，不释放可能增加伦理风险的生成组件。
* camera pose 和 warping field 初始化仍是复杂 pipeline，可能对不同视频质量敏感。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| Task | single generated video to 4D reconstruction |
| Input | RGB generated video, unknown camera trajectory |
| Output | dynamic Gaussian surfel 4D representation |
| Core primitive | Gaussian surfels |
| Motion model | bone-based continuous non-rigid warping field |
| Skinning | dual quaternion blend skinning |
| Geometry regularization | warped-state normal consistency |
| Appearance refinement | dual branch rotation/scale refinement |
| Initialization | neural SDF + backward/forward cycle + camera pose estimation |
| Bones | 25 in experiments |
| Training cost | over 1 hour per reconstruction on A800 |
| Main gain | 27.30 PSNR avg over 30 generated videos |
| Main weakness | video quality dependence and large-scene/real-time scalability |

## 11. Reusable Components

* **Warped-state normal regularization**: 对任何 dynamic surfel/mesh Gaussian 方法都有复用价值。
* **SDF-to-Gaussian-surfels initialization**: 先用 implicit surface 得到 camera/warp/mesh，再转 Gaussian surfels。
* **Dual branch refinement**: shared center and warp，separate rotation/scale refinement，可用于减少 dynamic primitive flickering。
* **Generated-video reconstruction protocol**: 每四帧训练、中间帧验证，适合评估 video-to-4D。
* **Baseline with shared pose initialization**: 将自家 field init 给 baseline 使用，能分离 pose initialization 与 representation 本身的贡献。

## 12. Gap / Idea Seeds

* 用 feed-forward video pose estimator 替代每例 1h+ 的 SDF initialization。
* 将 DGS 的 warped-state normal regularization 移植到 4DGS/SCGS，评估是否单独带来几何提升。
* 针对 generated video flickering，加入 temporal feature consistency loss 或 diffusion feature prior。
* 做 progressive large-scene DGS，把 object-centric assumptions 扩展到场景级生成视频。
* 加入 uncertainty mask，降低 generated frames 中不可信区域对 geometry 的污染。
* 让 video generation model 输出 camera/control metadata，减少 reconstruction 的 pose ambiguity。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: DOI 未在 Zotero metadata 或 PDF 抽取中出现。
* `NEED_HUMAN_CHECK`: Project page 是否已有可下载 code；PDF checklist 说 acceptance 后释放。
* `NEED_HUMAN_CHECK`: Eq. 4 和 Eq. 7 在 PDF 抽取中矩阵排版可能有轻微错位，精确实现需看源码。
* `NEED_HUMAN_CHECK`: DGS loss 的完整权重设置在主文没有完全展开，需看代码或 supplement。
* `NEED_HUMAN_CHECK`: 30 generated videos 的 prompt list、video generator settings、random seed 需查项目页/代码。
* `NEED_HUMAN_CHECK`: Baselines 使用 “our field init” 后是否完全公平，包括训练预算和 hyperparameters。

## 14. Evidence Anchors

* Abstract: DGS optimizes time-varying warping functions from static Gaussian surfels to dynamically warped states.
* Fig. 2: two-stage pipeline: field initialization stage and DGS stage.
* Fig. 3: DGS details: warping conditioned on time and coordinate, warped-state normal regularization, refinement branch.
* Sec. 3.1: formal problem definition for single-video 4D reconstruction.
* Sec. 3.2: Gaussian surfel definition, non-rigid warping, normal regularization, dual branch refinement, rasterization.
* Eq. 2: local tangent-plane Gaussian surfel coordinate.
* Eq. 3: dual quaternion blend skinning for valid $SE(3)$ warping.
* Eq. 5: continuous bone transform MLP conditioned on $\gamma_b^t$, $u$, and $t$.
* Eq. 6: warped-state normal consistency loss.
* Eq. 8: Gaussian primitive alpha compositing.
* Sec. 3.3: neural SDF field initialization, backward warping, cycle loss, marching cubes, surfel initialization.
* Sec. 4.1: training split, architecture, 25 bones, A800 training cost.
* Table 1: novel-view quantitative results; Vidu4D average 27.30 PSNR / 0.9152 SSIM / 0.0877 LPIPS.
* Table 3: field initialization and refinement ablations.
* Sec. 5: limitations on video quality, scalability, real-time applications, and deceptive content risk.
