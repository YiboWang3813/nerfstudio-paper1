---
title: "DropoutGS: Dropping Out Gaussians for Better Sparse-view Rendering"
authors: "Yexing Xu, Longguang Wang, Minglin Chen, Sheng Ao, Li Li, Yulan Guo"
year: 2025
venue: "CVPR 2025"
zotero_item_key: "3UQBR8EC"
pdf_attachment_key: "ZUGF4TDG"
pdf_path: "/Users/wangyibo/Zotero/storage/ZUGF4TDG/Xu 等 - DropoutGS Dropping Out Gaussians for Better Sparse-view Rendering.pdf"
note_path: "notes/DropoutGS: Dropping Out Gaussians for Better Sparse-view Rendering.md"
tags: ["3D Gaussian Splatting", "sparse-view synthesis", "dropout", "regularization", "edge-guided splitting"]
---

## 0. 一句话总结

DropoutGS 把 sparse-view 3DGS 的退化视为过参数化过拟合问题：训练时随机 dropout 一部分 Gaussian，让模型像多个低复杂度子模型集成一样减少空洞和漂浮伪影；再用 edge-guided splitting 把边缘区域的大 Gaussian 拆成小 Gaussian，补回 dropout 带来的高频细节损失。

## 1. 问题与动机

3DGS 在 sparse input 下训练 loss 会持续下降，但 test loss 可能在中后期上升，novel view 出现 hollow artifacts、floaters 和错误几何。作者观察到，当 Gaussian 数量较少时，过拟合现象减弱，结果更平滑；但 Gaussian 太少又会损失边缘和纹理细节。

因此 sparse-view 3DGS 的核心矛盾可以表述为：高复杂度模型容易过拟合少量训练视图，低复杂度模型泛化更好但表达细节不足。DropoutGS 用 RDR 降低有效复杂度，用 ESS 恢复高频表达。

## 2. 适用场景

DropoutGS 适合输入视角稀疏、3DGS 容易过拟合的 per-scene novel view synthesis，尤其是 LLFF/DTU 的 3-view 设置和 Blender 的 8-view 设置。

它是 3DGS 训练期插件，不强依赖额外深度模型；也可以和 DNGaussian、FSGS、CoR-GS 等已有 3DGS-based sparse-view 方法结合，作为额外 regularization。

## 3. 方法定位

DropoutGS 不是通过新的几何先验或生成模型来补信息，而是从 overfitting 角度 regularize 3DGS。它对渲染流程做轻量修改：训练时随机关闭 Gaussian primitives，并让 dropout 子模型的渲染接近完整模型的渲染；推理时所有 Gaussian 都打开。

相对 DNGaussian 等依赖单目深度的方法，DropoutGS 不需要额外 depth estimator。若与 DNGaussian 结合，则总 loss 中可同时包含 depth regularization 和 RDR loss。

## 4. 核心创新

第一，实验性地指出 sparse-view 3DGS 的退化与 Gaussian 数量和模型复杂度相关。10k Gaussians 比 1k Gaussians 更容易训练视图过拟合并在测试视角产生空洞，而 1k Gaussians 更平滑但细节差。

第二，提出 Random Dropout Regularization（RDR）。训练时以概率 $p$ 随机 deactivate Gaussians，得到一个低复杂度 sub-model，并用完整模型渲染作为 teacher 约束 dropout 子模型。

第三，提出 Edge-guided Splitting Strategy（ESS）。RDR 会鼓励 Gaussian 变大以获得稳定结构，但大 Gaussian 不擅长表达高频边缘，因此作者用 edge map 计算每个 Gaussian 的 edge score，只对大尺度且位于边缘区域的 Gaussian split。

第四，证明 DropoutGS 有较强兼容性，可插入 3DGS、DNGaussian、FSGS、CoR-GS 等不同 sparse-view 3DGS pipeline。

## 5. 方法细节

RDR 中，训练时对 Gaussian 随机 dropout。设 dropout probability 为 $p$，随机变量 $z\sim\operatorname{Uniform}(0,1)$，激活标记 $r=[z>p]$。dropout 后像素颜色为：

$$
\hat{C}=\sum_{i\in\mathcal{N}} r\alpha_i\prod_{j=1}^{i-1}(1-r\alpha_j)c_i
$$

完整模型渲染颜色记为 $C$。RDR loss 不直接用 ground-truth color 监督 dropout 渲染，而是让 dropout 子模型接近完整模型：

$$
L_{RDR}=\|C-\hat{C}\|_1+\operatorname{SSIM}(C,\hat{C})
$$

作者指出，如果用 ground-truth color 监督 dropout 子模型，梯度会分布到全局许多 Gaussian，可能互相抵消；用完整模型渲染监督时，梯度主要集中在被 dropout Gaussian 的邻域，更像局部修补。

ESS 中，先对输入图像做 edge detection 得到像素 edge probability $E(I)$。将 Gaussian 投影到 edge map 上，并按 Gaussian 对像素的 alpha blending contribution 聚合单视图 edge score：

$$
E_i'=\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j)\cdot\sum_p E(I)M^i(p)
$$

多视图下再按每个 Gaussian 覆盖像素数归一化并累积：

$$
E_i=\sum_{k=1}^{M}\frac{E_{i,k}'}{\sum_p M_k^i}
$$

最终对同时满足“大尺度”和“高边缘分数”的 Gaussian 做 split：

$$
M_{edge}=\{S_i\ge S_{thr}\}\cap\{E_i\ge E_{thr}\}
$$

如果结合深度正则方法，DropoutGS 总 loss 写为：

$$
L=L_{gs}+\lambda_{depth}L_{depth}+\lambda_{RDR}L_{RDR}
$$

其中 $L_{depth}$ 可来自 DNGaussian 等方法。

## 6. 实验设置

实验在 LLFF、DTU 和 Blender 上进行。LLFF/DTU 采用前人常用 3-view 设置；DTU 使用 object masks 评估目标物体而非背景；Blender 使用 8 个训练视图并在另外 25 个视图测试。

指标包括 PSNR、SSIM、LPIPS 和 AVGE。所有结果平均三次重复实验。实现基于 PyTorch，LLFF、DTU、Blender 都训练 6k iterations。按 DNGaussian 设置，3DGS 和 DropoutGS 使用随机点云初始化。

## 7. 主要结果

LLFF 3-view 上，DropoutGS 达到 19.35 PSNR、0.622 SSIM、0.282 LPIPS、0.128 AVGE，在 DNGaussian baseline 上进一步提升，并在感知质量上减少 hollow artifacts 和过拟合伪影。

DTU 3-view 上，DropoutGS 在多个指标上显著超过 baseline，定性结果显示其点云更密、更贴合物体表面，前景空洞和模糊更少。

Blender 8-view 上，DropoutGS 达到 24.476 PSNR、0.889 SSIM、0.085 LPIPS，优于 DNGaussian 的 24.305 PSNR、0.886 SSIM、0.088 LPIPS，也优于 vanilla 3DGS 的 22.226 PSNR。

在 LLFF 更多视图设置中，DropoutGS 也稳定优于 DNGaussian。6-view 时 DNGaussian 为 22.18 PSNR、0.755 SSIM、0.198 LPIPS，DropoutGS 为 23.35 PSNR、0.791 SSIM、0.177 LPIPS；9-view 时 DNGaussian 为 23.17 PSNR，DropoutGS 为 24.33 PSNR。

## 8. 消融与分析

LLFF 3-view 上，baseline DNGaussian 为 18.76 PSNR、0.582 SSIM、0.300 LPIPS、0.139 AVGE。只加 ESS 为 18.91 PSNR、0.592 SSIM、0.294 LPIPS；只加 RDR 为 19.26 PSNR、0.608 SSIM、0.317 LPIPS；完整 DropoutGS 为 19.35 PSNR、0.622 SSIM、0.282 LPIPS。

这说明 RDR 主要提升 PSNR/SSIM 和结构平滑，但会让 LPIPS 略差，因为 Gaussian 变大后高频细节弱；ESS 能把边缘区域的大 Gaussian 再拆细，改善 perceptual detail。

dropout rate 消融显示，$p=0.0,0.2,0.4,0.6,0.8$ 的 PSNR 分别为 18.76、19.20、19.35、19.37、19.44，SSIM 在 $p=0.4$ 到 $0.8$ 附近接近，但 LPIPS 在 dropout rate 过大时变差。作者选择较平衡的 $p=0.4$。edge threshold 消融显示，阈值降低能改善 LPIPS，但过低会导致过度 splitting。

## 9. 与相关工作的关系

相对 DNGaussian、DRGS 等 depth-prior 方法，DropoutGS 不把重点放在额外几何先验，而是把 sparse-view degradation 看作 overfitting。它可以独立使用，也可以叠加到 depth-prior 方法上。

相对普通 neural dropout，DropoutGS 的 dropout 对象不是神经元，而是空间中的 Gaussian primitives。由于每个 Gaussian 有明确几何和渲染贡献，dropout 的结果更像训练多个低复杂度 3D 子模型。

相对 D$^2$GS 这类后续深度/密度引导 dropout 方法，DropoutGS 更简单：随机 dropout + 边缘 split，不区分近远场和密度分布。

## 10. 优点

DropoutGS 的优点是简单、轻量、插件化。RDR 只需训练期随机 mask Gaussian 并加入一致性 loss，推理时无额外成本；ESS 基于 edge map 选择性 split，也不需要复杂网络。

另一个优点是解释性强。RDR 对应降低模型有效复杂度、缓解过拟合；ESS 对应恢复高频边缘细节。二者分别处理 sparse-view 3DGS 中平滑泛化和细节表达的矛盾。

## 11. 局限

RDR 随机 dropout 不区分哪些 Gaussian 更容易过拟合。对远场欠拟合、近场过拟合等空间不均衡问题，它没有显式建模，可能会误伤本来就缺少 Gaussian 的区域。

ESS 依赖 2D edge map，边缘检测错误或纹理噪声可能导致不必要 split。dropout rate 和 edge threshold 也需要调参；dropout 太大虽然减少伪影，但会让结果过度平滑、LPIPS 变差。

## 12. 可复现要点

复现 RDR 时，注意 dropout 渲染 $\hat{C}$ 的监督目标是完整模型渲染 $C$，而不是 ground-truth image。训练期间随机 deactivate Gaussians，推理时全部激活。

复现 ESS 时，需要先对训练图像生成 edge probability map，再把每个 Gaussian 投影到多个视图并按其 alpha contribution 累积 edge score。只 split 同时满足 scale threshold 和 edge threshold 的 Gaussian，以避免全局过度 densification。

## 13. 可能扩展

一个扩展是把 random dropout 改为 uncertainty-aware 或 density-aware dropout，对过密、近场、训练残差异常的 Gaussian 提高 dropout 概率，对欠拟合区域降低 dropout 概率。

第二个扩展是把 ESS 的 edge score 换成多信号融合，例如 image edge、depth discontinuity、normal discontinuity 和 view inconsistency，共同决定哪里需要 split。

第三个扩展是把 DropoutGS 和 MVPGS/SCGaussian 结合。几何 prior 负责把结构拉正确，dropout 负责控制过拟合复杂度，二者可能互补。

## 14. 个人理解

DropoutGS 的价值在于它给 sparse-view 3DGS 提供了一个很朴素但有效的视角：不是所有问题都要靠外部深度或生成先验，很多伪影来自模型容量相对数据量太大。训练期随机关闭 Gaussian，等价于强迫局部邻域学会互相补位。

不过它也暴露了随机 dropout 的局限。Gaussian 是空间结构单元，不同位置的过拟合风险不同；后续更合理的方向应该是让 dropout 概率和 densification 策略感知深度、密度、可见性和残差，而不是全局统一随机。
