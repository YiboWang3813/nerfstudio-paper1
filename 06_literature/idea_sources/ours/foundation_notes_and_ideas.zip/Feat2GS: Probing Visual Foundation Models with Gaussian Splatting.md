# Feat2GS: Probing Visual Foundation Models with Gaussian Splatting

## 0. Metadata

* Title: Feat2GS: Probing Visual Foundation Models with Gaussian Splatting
* Authors: Yue Chen; Xingyu Chen; Anpei Chen; Gerard Pons-Moll; Yuliang Xiu
* Year: 2025
* Venue: CVPR
* PDF source: `/Users/wangyibo/Zotero/storage/Y3EYUBL5/Chen 等 - 2025 - Feat2GS Probing Visual Foundation Models with Gaussian Splatting.pdf`
* Zotero item key: `TGJGNLXY`
* Zotero PDF attachment key: `Y3EYUBL5`
* Code: Not specified
* Project page: `fanegg.github.io/Feat2GS`
* Dataset link: LLFF, DTU, DL3DV, Casual, MipNeRF360, MVImgNet, Tanks and Temples
* Main task: probing 3D awareness of visual foundation models through novel view synthesis
* Domain: VFM evaluation, Gaussian Splatting, sparse-view casual NVS
* Input: sparse unposed or casually posed multi-view images, frozen VFM feature maps
* Output: 3DGS parameters decoded from features and NVS metrics for probing geometry/texture awareness
* Main representation: per-pixel 3D Gaussians read out from frozen VFM features
* Supervision type: photometric reconstruction loss, optional warm-start from DUSt3R point cloud
* Core contribution in one sentence: 用浅层 readout 从 VFM feature 解码 3DGS 参数，把 NVS 作为 dense multi-view proxy task 来评估不同 VFM 的 geometry 和 texture awareness。
* Note status: `complete`

## 1. 一句话技术摘要

This paper addresses evaluation of visual foundation models' 3D awareness by using a lightweight feature-to-Gaussian readout to transform frozen VFM features from sparse images into 3DGS parameters, with the key technical novelty being disentangled geometry/texture probing through novel view synthesis without 3D ground-truth labels.

## 2. 问题形式化

论文问的问题是：VFM 是否真正理解 3D？已有 probe 多用 depth/normal 或 sparse matching，主要测 geometry，且依赖 3D ground truth。Feat2GS 把 NVS 作为 proxy task：如果一个 VFM 的 feature 能被浅层 readout 解码成好的 3DGS geometry 或 texture，那么它包含对应的 3D-aware 信息。

输入为若干 casual images，经 VFM 得到 pixel-wise feature $f_i$。readout layer $g_\Theta$ 将每个像素 feature 转换为 Gaussian primitive $G_i$，然后用 photometric loss 优化并在 novel views 上评估 PSNR/SSIM/LPIPS。

## 3. 方法概览

Feat2GS 有两个用途：

1. 作为 VFM probe：用统一 shallow MLP readout 测不同 VFM feature 是否能支持 3DGS。
2. 作为 NVS baseline：根据 probe 结论，组合多种 VFM feature，得到比 InstantSplat 更强的 sparse casual NVS baseline。

核心是 GTA probing modes：

* Geometry mode: feature 只读出 geometry 参数 $\{x,\alpha,\Sigma\}$，texture $c$ 自由优化。
* Texture mode: feature 只读出 texture 参数 $c$，geometry 自由优化。
* All mode: feature 同时读出 $\{x,\alpha,\Sigma,c\}$。

## 4. 方法细节

### 4.1 Feature-to-Gaussian readout

不同 VFM feature 先经过 PCA 统一 channel 数，再双线性上采样到一致空间分辨率。对每个像素 $i$，readout layer 输出：

$$
G_i = g_\Theta(f_i)
$$

每个高斯包括位置 $x \in \mathbb{R}^3$、opacity $\alpha$、covariance $\Sigma \in \mathbb{R}^{3 \times 3}$ 和 SH texture coefficients $c_i \in \mathbb{R}^{48}$。readout 是浅层 MLP，设计目标是让它作为 information conduit，而不是大容量记忆模块。

### 4.2 GTA probing modes

Geometry mode:

$$
\{x_i,\alpha_i,\Sigma_i\} = g_\Theta^{(G)}(f_i), \quad \{c_i\} = O^{(G)}
$$

Texture mode:

$$
\{c_i\} = g_\Theta^{(T)}(f_i), \quad \{x_i,\alpha_i,\Sigma_i\} = O^{(T)}
$$

All mode:

$$
\{x_i,\alpha_i,\Sigma_i,c_i\} = g_\Theta^{(A)}(f_i)
$$

这里 $O$ 表示不由 feature 解码、而是自由优化的参数。这个拆分让作者能单独评价 VFM 中的 geometry 信息和 texture 信息。

### 4.3 Warm start 与 pose handling

直接从 2D feature 解码 3D structure 容易陷入局部最优。论文用 DUSt3R 初始化 point cloud $G_{init}$，通过 warm-start loss 让 readout 先接近初始化：

$$
\min_\Theta \|g_\Theta(f) - G_{init}\|
$$

对于 sparse/casual images，论文用 DUSt3R 估计训练和测试视角的 camera parameters，并在评估前用 photometric loss 做 test-time pose optimization。

## 5. 数学目标和损失

训练主要使用 multi-view photometric loss，主文未给出完整最终 loss 展开，核心监督是渲染图像和输入图像之间的 photometric reconstruction。Warm start 使用 Eq. (6) 的 point cloud regression。评价指标是 NVS 的 PSNR、SSIM、LPIPS；DTU 上还比较 reconstructed 3DGS positions 与 point cloud ground truth 的 accuracy、completeness、distance。

## 6. 训练和推理流程

训练/评估流程：

1. 对每个输入 view 提取 frozen VFM feature。
2. PCA 统一 channel，统一 feature spatial resolution。
3. 用 shallow readout 解码 Gaussian 参数。
4. 用 DUSt3R 估计相机并 warm start。
5. 优化 readout/自由参数以最小化 photometric loss。
6. 在 held-out views 上用 NVS 指标评价 VFM 的 geometry/texture/all awareness。

论文评估 10 个 VFM：DUSt3R、MASt3R、MiDaS、DINOv2、DINO、SAM、CLIP、RADIO、MAE、Stable Diffusion，并加入 IUVRGB baseline。

## 7. 实验设置与结果摘要

Tab. 4 表明 DTU 上 NVS 2D metrics 与 3D point cloud metrics 高相关，因此 NVS 可作为 3D awareness proxy。Tab. 5 跨七个 multi-view datasets 评估 GTA modes，说明小规模数据会产生偏置，必须用多样化数据集。

关键发现：

* Geometry mode 中 RADIO、MASt3R、DUSt3R 较强。
* Texture mode 中 MAE、SAM、MASt3R 较强，但整体 VFM texture awareness 偏弱。
* All mode 中 MASt3R 和 DUSt3R 最好，DINO 次之。
* Stable Diffusion feature 在 NVS probing 中表现很差，出现 color shift 和 geometry broken。
* 许多 VFM 的训练目标鼓励 texture-invariant feature，这有利于语义/几何稳健性，但会损害 texture reconstruction。

## 8. 声称贡献 vs 实际技术增量

论文声称贡献是提出统一 VFM 3D probe、系统分析 VFM、给出强 NVS baseline。实际技术增量不是新的 3DGS renderer，而是一个很干净的 probe protocol：把 VFM feature 限制在 shallow readout 的信息瓶颈中，再通过 3DGS 参数分组评价 feature 是否含有 geometry/texture 信息。

这篇对方法研究有价值的地方在于“评价设计”，而不是某个复杂网络模块。它能帮助判断哪些 VFM 适合作为 3DGS 初始化、geometry prior 或 texture prior。

## 9. 局限性和隐藏假设

* NVS 与 3D awareness 相关，但不是等价；强 NVS 可能来自 texture/pose optimization 补偿。
* DUSt3R warm start 和 pose optimization 会影响 probe 纯度。
* Feature channel PCA 可能丢掉部分 VFM 信息，但它保证了公平和可控。
* Texture mode 整体较弱，说明很多 VFM feature 不适合直接做 appearance reconstruction。
* 论文目标是 probing，不能简单把排名当成所有 3D 下游任务的最终结论。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 任务 | VFM 3D awareness probing, sparse-view NVS |
| 输入 | sparse multi-view images, frozen VFM features |
| 输出 | 3DGS parameters and NVS metrics |
| 表示 | per-pixel 3D Gaussians decoded by shallow MLP |
| 关键模块 | GTA modes, warm start, DUSt3R pose estimation |
| 关键损失 | photometric loss, warm-start point cloud regression |
| 主要优点 | 不需要 3D 标签，能分离 geometry/texture awareness |
| 主要风险 | probe 受 DUSt3R/pose optimization/数据集选择影响 |

## 11. 可复用组件

* GTA 参数分组可用于评价任意 3D foundation feature 是否适合 Gaussian initialization。
* “浅层 readout + NVS proxy” 可作为视觉表征的 dense multi-view benchmark。
* VFM feature 拼接可作为 sparse NVS 强 baseline 的简单策略。

## 12. Gap 和 idea seeds

* 可以把 Feat2GS 的 probe protocol 用于 dynamic 4DGS，分别测 VFM 对 motion geometry 和 dynamic texture 的支持。
* 可以设计 texture-aware VFM pretraining，让 feature 同时保留 semantic invariance 和 low-level appearance。
* 可以把 GTA 拆分扩展到 opacity、scale、rotation、SH 各子属性，做更细粒度 feature attribution。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: supplementary 中各数据集 sampling 细节和最终 baseline variants 需要复核。
* `NEED_HUMAN_CHECK`: code/data 是否已经公开，主文只写 will be made available。

## 14. Evidence Anchors

* Fig. 1: Feat2GS 作为 VFM probe 和 baseline 的整体图。
* Tab. 1: Geometry/Texture/All probing modes。
* Sec. 3.1: feature readout and Gaussian parameterization, Eq. (1)-(5)。
* Sec. 3.2: warm start, Eq. (6)。
* Sec. 3.3: NVS as evaluation protocol。
* Tab. 4: NVS metrics 与 3D metrics correlation。
* Tab. 5: 跨数据集 VFM probing 结果。
* Sec. 4.3: texture-unfriendly training strategies 分析。
