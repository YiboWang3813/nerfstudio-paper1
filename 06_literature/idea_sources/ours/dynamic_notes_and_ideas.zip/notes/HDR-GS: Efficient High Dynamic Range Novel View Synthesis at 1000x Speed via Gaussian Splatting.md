## 3 方法

图 3 展示了 HDR-GS 的整体框架。首先，作者使用结构从运动（Structure-from-Motion, SfM）算法 [17] 对场景的相机参数进行重新标定，并初始化高斯点云，如图 3(a) 所示。随后，作者提出 Dual Dynamic Range（DDR）高斯点云模型，用于联合拟合 HDR 与 LDR 颜色，如图 3(b) 所示。3D 高斯直接使用球谐函数（Spherical Harmonics, SH）建模 HDR 颜色；之后，三个独立的 MLP 分别学习 RGB 通道中的 tone-mapping 操作。该 tone-mapper 会根据对应的 HDR 颜色和可控曝光时间 $\Delta t$ 渲染 LDR 颜色。接着，LDR 与 HDR 颜色被送入两个并行可微光栅化（Parallel Differentiable Rasterization, PDR）流程，以渲染 HDR 和 LDR 图像，如图 3(c) 所示。本节先介绍 DDR 点云模型，再介绍 PDR 流程，最后说明 HDR-GS 的初始化与优化。

图 3：方法流程。（a）使用 SfM [17] 重新标定相机参数并初始化 3D 高斯。（b）Dual Dynamic Range 高斯点云使用球谐函数建模 HDR 颜色；三个 MLP 根据 HDR 颜色和用户输入的曝光时间 tone-map 出 LDR 颜色。（c）HDR 与 LDR 颜色分别送入两个并行可微光栅化流程，以渲染 HDR 与 LDR 视图。

### 3.1 Dual Dynamic Range 高斯点云模型

一个场景可以由作者提出的 Dual Dynamic Range（DDR）高斯点云集合 $G$ 表示：

$$
G = \{G_i(\mu_i, \Sigma_i, \alpha_i, c_i^l, c_i^h, \Delta t, \theta) \mid i = 1, 2, \ldots, N_p\},
\tag{1}
$$

其中，$N_p$ 是 3D 高斯的数量，$G_i$ 表示第 $i$ 个高斯。其中心位置、协方差、不透明度、LDR 颜色和 HDR 颜色分别记为 $\mu_i \in \mathbb{R}^3$、$\Sigma_i \in \mathbb{R}^{3 \times 3}$、$\alpha_i \in \mathbb{R}$、$c_i^l \in \mathbb{R}^3$ 和 $c_i^h \in \mathbb{R}^3$。除这些属性外，每个 $G_i$ 还包含一个曝光时间 $\Delta t \in \mathbb{R}$，用于控制 LDR 视图的光照强度；同时还包含三个全局共享的 MLP，其参数为 $\theta$。

$\Sigma_i$ 由旋转矩阵 $R_i \in \mathbb{R}^3$ 和缩放矩阵 $S_i \in \mathbb{R}^3$ 表示：

$$
\Sigma_i = R_i S_i S_i^\top R_i^\top.
\tag{2}
$$

$\mu_i$、$R_i$、$S_i$、$\alpha_i$ 和 $\theta$ 都是可学习参数。tone-mapping 操作 $f_{TM}(\cdot)$ 用于建模相机响应函数（Camera Response Function, CRF），该函数将 HDR 颜色 $c_i^h$ 非线性映射到 LDR 颜色 $c_i^l$：

$$
c_i^l = f_{TM}(c_i^h \cdot \Delta t),
\tag{3}
$$

其中，曝光时间 $\Delta t$ 可以从照片元数据中读取。作者使用 MLP 学习 tone-mapping 过程。这里有两种选择。第一种是直接建模 $f_{TM}(\cdot)$，但乘法操作可能带来数值溢出或下溢，从而导致梯度消失问题。此外，乘法也会使 MLP 的输入信号出现非线性与不连续性，进一步加剧训练不稳定。第二种做法是遵循 Debevec 和 Malik [16] 的传统非参数 CRF 标定方法，将 $f_{TM}(\cdot)$ 从线性域转换到对数域，以提升 MLP 训练稳定性。作者采用第二种做法。具体来说，先对式 (3) 中的 $f_{TM}(\cdot)$ 取反函数并转换为：

$$
\log f_{TM}^{-1}(c_i^l) = \log c_i^h + \log \Delta t,
\tag{4}
$$

其中，$\log(\cdot)$ 表示自然对数函数，其底数为 $e = 2.71828\cdots$。随后，对式 (4) 两侧取反函数，可重写为：

$$
c_i^l = (\log f_{TM}^{-1})^{-1}(\log c_i^h + \log \Delta t).
\tag{5}
$$

由于 RGB 颜色通常由不同的 CRF 进行 tone-mapping，作者使用三个 MLP $\theta$ 分别独立建模 RGB 通道中的函数 $(\log f_{TM}^{-1})^{-1}$。为简化表示，作者将 tone-mapper $\theta$ 的映射函数定义为 $g_\theta(x) \triangleq (\log f_{TM}^{-1})^{-1}(x)$。因此，式 (5) 可改写为：

$$
c_i^l = g_\theta(\log c_i^h + \log \Delta t),
\tag{6}
$$

其中，$\log c_i^h$ 由球谐函数（SH）建模，其系数集合为 $k = \{k_l^m \mid 0 \le l \le L, -l \le m \le l\} \in \mathbb{R}^{(L+1)^2 \times 3}$。每个 $k_l^m \in \mathbb{R}^3$ 是一组三个系数，分别对应 RGB 分量。$L$ 是 SH 的阶数。在视角方向 $d = (\theta, \phi)$ 下，$c_i^h$ 可表示为：

$$
c_i^h(d, k) =
\exp\left(
\sum_{l=0}^{L}
\sum_{m=-l}^{l}
k_l^m Y_l^m(\theta, \phi)
\right),
\tag{7}
$$

其中，$Y_l^m : S^2 \to \mathbb{R}$ 是球谐函数，将球面上的 3D 点映射为实数；$\exp(\cdot)$ 表示指数函数。将式 (7) 代入式 (6)，可得到 $c_i^l$：

$$
c_i^l(d, k, \Delta t) =
g_\theta\left(
\sum_{l=0}^{L}
\sum_{m=-l}^{l}
k_l^m Y_l^m(\theta, \phi)
+ \log \Delta t + b
\right),
\tag{8}
$$

这里加入了常数偏置 $b \in \mathbb{R}$，帮助 SH 函数更好地拟合数据。基于 MLP 的 tone-mapper $\theta$ 的具体结构见图 3(b)。$g_\theta(\cdot)$ 对应如下过程：$\log c_i^h$ 的 RGB 通道分别经过一个独立 MLP，每个 MLP 包含一个全连接（fc）层、一个 ReLU 激活、一个 fc 层和一个 sigmoid 激活，最终生成 LDR 颜色 $c_i^l$。

### 3.2 并行可微光栅化

式 (7) 中计算得到的 HDR 颜色 $c_i^h$，以及式 (8) 中计算得到的 LDR 颜色 $c_i^l$，会被送入两个并行可微光栅化流程，以联合渲染 HDR 与 LDR 视图，如图 3(c) 所示。HDR 光栅化 $F_{HDR}$ 和 LDR 光栅化 $F_{LDR}$ 可表示为：

$$
I^h = F_{HDR}(M_{int}, M_{ext}, \{\mu_i, \Sigma_i, \alpha_i, c_i^h\}_{i=1}^{N_p}),
$$

$$
I^l(\Delta t) = F_{LDR}(M_{int}, M_{ext}, \{\mu_i, \Sigma_i, \alpha_i, c_i^l(\Delta t)\}_{i=1}^{N_p}),
\tag{9}
$$

其中，$I^h$ 和 $I^l(\Delta t) \in \mathbb{R}^{H \times W \times 3}$ 分别表示渲染得到的 HDR 图像，以及曝光时间为 $\Delta t$ 的 LDR 图像；$H$ 和 $W$ 分别表示图像高度和宽度；$M_{ext} \in \mathbb{R}^{4 \times 4}$ 表示外参矩阵；$M_{int} \in \mathbb{R}^{3 \times 4}$ 表示内参矩阵。为简化符号，文中省略了 $c_i^h$ 和 $c_i^l$ 中的 $d$ 与 $k$。下面介绍并行光栅化流程的细节。

首先，作者计算第 $i$ 个 3D 高斯分布在点位置 $x \in \mathbb{R}^3$ 处的概率值：

$$
P(x \mid \mu_i, \Sigma_i) =
\exp\left(
-\frac{1}{2}(x - \mu_i)^\top \Sigma_i^{-1}(x - \mu_i)
\right).
\tag{10}
$$

随后，splatting 操作将 3D 高斯投影到 2D 成像平面。在该投影过程中，中心位置 $\mu_i$ 先从世界坐标系变换到相机坐标系，再投影到图像坐标系：

$$
\tilde{v}_i = [v_i, 1]^\top = M_{ext}\tilde{\mu}_i = M_{ext}[\mu_i, 1]^\top,
\quad
\tilde{u}_i = [u_i, 1]^\top = M_{int}\tilde{v}_i = M_{int}[v_i, 1]^\top,
\tag{11}
$$

其中，$u_i \in \mathbb{R}^2$ 和 $v_i \in \mathbb{R}^3$ 分别表示 $\mu_i$ 的图像坐标和相机坐标。$\tilde{u}_i$、$\tilde{v}_i$ 和 $\tilde{\mu}_i$ 分别是 $u_i$、$v_i$ 和 $\mu_i$ 的齐次形式。3D 协方差 $\Sigma_i$ 也会从世界坐标系变换到相机坐标系中的 $\Sigma_i' \in \mathbb{R}^{3 \times 3}$：

$$
\Sigma_i' = J_i W_i \Sigma_i W_i^\top J_i^\top,
\tag{12}
$$

其中，$J_i \in \mathbb{R}^{3 \times 3}$ 表示投影变换 $M_{int}M_{ext}$ 的仿射近似 Jacobian 矩阵。$W_i \in \mathbb{R}^{3 \times 3}$ 是从 $M_{ext}$ 的前三行前三列中取得的视角变换矩阵。与已有工作 [15, 66-68] 类似，2D 协方差矩阵 $\Sigma_i'' \in \mathbb{R}^{2 \times 2}$ 通过直接去掉 $\Sigma_i'$ 的第三行和第三列得到。

随后，2D 投影平面被划分为互不重叠的 tile。3D 高斯 $(\mu_i, \Sigma_i)$ 会被分配到其 2D 投影 $(u_i, \Sigma_i'')$ 所覆盖的 tile 中。对于每个 tile，被分配到该 tile 的 3D 高斯会按照视空间深度排序。然后，对于像素 $p$，其 RGB 值 $I^h(p)$ 和 $I^l(p \mid \Delta t) \in \mathbb{R}^3$ 由该 tile 中与像素 $p$ 重叠的 $N$ 个有序点混合得到：

$$
I^h(p) =
\sum_{j \in N}
c_j^h \sigma_j
\prod_{k=1}^{j-1}(1 - \sigma_k),
\quad
I^l(p \mid \Delta t) =
\sum_{j \in N}
c_j^l(\Delta t) \sigma_j
\prod_{k=1}^{j-1}(1 - \sigma_k),
\tag{13}
$$

其中，$\sigma_j = \alpha_j P(x_j \mid \mu_j, \Sigma_j)$；$x_j$ 是从相机光心出发并落在像素 $p$ 上的射线与 3D 空间中高斯点云相交得到的第 $j$ 个 3D 交点。$c_j^h$ 和 $c_j^l(\Delta t)$ 分别表示 $x_j$ 的 HDR 颜色，以及曝光时间为 $\Delta t$ 的 LDR 颜色。

### 3.3 初始化与优化

3DGS 方法应用于 3D HDR 成像的一个障碍是，原始多视角 HDR 数据集 [14] 只提供归一化设备坐标（Normalized Device Coordinate, NDC）系统下的相机位姿。该 NDC 系统并不适合 3DGS 方法，主要有两个原因。首先，NDC 侧重描述透视投影后 2D 屏幕上的位置，而 3D 高斯是一种显式 3D 表示；3DGS 需要在 3D 空间中对高斯点云进行变换和投影。其次，NDC 会将坐标缩放到 [-1, 1] 或 [0, 1] 范围内，体素分辨率受限，难以捕捉场景细节。此外，原始数据集 [14] 也没有提供用于初始化 3DGS 的 SfM [17] 点云。

为解决这些问题，并为 3D HDR 成像中的 3DGS 类算法研究建立数据基础，作者使用 SfM 算法 [17] 重新标定相机参数，并计算 3D 高斯的初始位置。SfM 的映射函数 $F_{SfM}$ 可概括为：

$$
M_{int}, \{M_{ext}^j\}_{j=1}^{N_v}, N_p, \{\mu_i\}_{i=1}^{N_p}
=
F_{SfM}(\{\hat{I}_j^l(t_s)\}_{j=1}^{N_v}),
\tag{14}
$$

其中，$N_v$ 表示视角数量；$\hat{I}_j^l(t_s) \in \mathbb{R}^{H \times W \times 3}$ 表示多视角 HDR 数据集 [14] 中第 $j$ 个视角、曝光时间为 $t_s$ 的 LDR 图像。内参矩阵 $M_{int}$ 不随视角变化。需要注意的是，作者使用相同曝光时间下的 HDR 视图作为 SfM 算法的输入，因为 SfM 依赖多视角特征检测和匹配；曝光条件变化可能降低 SfM 精度。随后，作者使用式 (14) 中得到的 $N_p$ 和 $\{\mu_i\}_{i=1}^{N_p}$ 初始化式 (1) 中的 $G$，而 $G$ 的其他可学习参数则随机初始化。

重新标定得到的相机位姿-图像数据对 $\{M_{ext}^j, \hat{I}_j^l(\Delta t)\}_{j=1}^{N_v}$ 用于训练 HDR-GS。训练目标为 L1 损失与 D-SSIM 损失的加权和：

$$
L_p =
\sum_{j=1}^{B}
L_1(I_j^l(\Delta t_j), \hat{I}_j^l(\Delta t_j))
+ \lambda \cdot
L_{D\text{-}SSIM}(I_j^l(\Delta t_j), \hat{I}_j^l(\Delta t_j)),
\tag{15}
$$

其中，$B$ 是训练 batch size，$\lambda$ 是超参数。类似 HDR-NeRF [14] 在合成场景中使用真实 CRF 校正系数 $C_0$ 约束 HDR 颜色，作者也在 $\mu$-law [14, 23, 69, 70] LDR 域中对渲染得到的 HDR 图像施加约束：

$$
L_c =
\sum_{j=1}^{B}
\left\|
\frac{\log(1 + \mu \cdot norm(I_j^h))}{\log(1+\mu)}
-
\frac{\log(1 + \mu \cdot norm(\hat{I}_j^h))}{\log(1+\mu)}
\right\|_2^2,
\tag{16}
$$

其中，$\mu$ 表示压缩量，$norm(\cdot)$ 表示 min-max 归一化。$I_j^h$ 和 $\hat{I}_j^h \in \mathbb{R}^{H \times W \times 3}$ 分别表示第 $j$ 个视角下渲染得到的 HDR 图像和真实 HDR 图像。整体训练损失为：

$$
L = L_p + \gamma \cdot L_c,
\tag{17}
$$

其中，$\gamma$ 是控制 $L_p$ 与 $L_c$ 相对重要性的超参数。由于真实场景数据集不提供真实 HDR 图像，作者在真实场景中不使用 $L_c$。因此，在合成数据集和真实数据集实验中，$\gamma$ 分别设置为 $0.6$ 和 $0$。
