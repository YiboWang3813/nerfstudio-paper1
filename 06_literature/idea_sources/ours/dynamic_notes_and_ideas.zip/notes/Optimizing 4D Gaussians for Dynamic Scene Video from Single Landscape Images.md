# Optimizing 4D Gaussians for Dynamic Scene Video from Single Landscape Images

## 0. Metadata

- Paper title: Optimizing 4D Gaussians for Dynamic Scene Video from Single Landscape Images
- Authors: In-Hwan Jin; Haesoo Choo; Seong-Hun Jeong; Heemoon Park; Junghwan Kim; Oh-joon Kwon; Kyeongbo Kong
- Venue / year: ICLR 2025
- Project / code: `https://cvsp-lab.github.io/ICLR2025_3D-MOM/`
- Zotero item key: `4JXAKBYJ`
- Zotero PDF attachment key: No local PDF attachment found; Zotero item is marked as in Trash.
- Zotero PDF path: No suitable attachment found in Zotero; method details recovered from arXiv source `2504.05458` in `/private/tmp/2504src`.
- Local note path: `notes/Optimizing 4D Gaussians for Dynamic Scene Video from Single Landscape Images.md`

## 1. One-Sentence Technical Summary

本文从单张 landscape image 出发，通过 depth lifting 生成多视角伪图、用单图动画模型估计多视角 2D motion，再用 3D Motion Optimization Module (3D-MOM) 将这些不一致的 2D motions 优化为一致 3D motion，并以此初始化和训练 4D Gaussians 来生成可变视角动态场景视频。

## 2. Problem Formulation

目标是把单张 landscape image 扩展为 dynamic scene video：场景中水、云、烟等 fluid-like 区域会运动，同时相机可以在 3D 空间中移动并看到具有深度感的新视角。传统 3D Cinemagraphy / Make-It-4D 多用 Layered Depth Images (LDIs) 隐式表示伪 3D 空间，容易因离散层划分导致深度感不足、camera movement 下扭曲，以及输出局限在 2D video domain。

论文提出用 explicit 4D Gaussians 表示完整 3D space + animation。难点在于单图没有真实多视角视频监督，因此需要从单图构造多视角图、估计 motion masks 和 2D motion maps，再把它们提升为跨视角一致的 3D motion 来训练 4DGS。

## 3. Method Overview

框架分三步。第一，Multi-view image generation for 3D Gaussians optimization：用 monocular depth estimator 从输入图像估计 depth map，将 RGB pixels unproject 成 point cloud，再沿预定义 camera trajectory 渲染多视角 RGB images，并用这些伪多视角图优化静态 3D Gaussians。第二，Consistent 3D motion estimation：输入 motion mask 被同样 lift/project 到各视角，单图动画模型在每个视角独立估计 2D Eulerian flow；3D-MOM 通过优化一个 3D motion field，使其投影到所有视角后匹配这些 2D motion maps，从而消除 multi-view motion ambiguity。第三，4D Gaussians optimization：采用 4D-GS/HexPlane-style deformation，以 3D-MOM 的 $\mathbf{F}_{3D}$ 初始化 position deformation，再用多视角图和伪视频进行两阶段训练。

该方法的核心贡献是 3D-MOM：它把现成 2D single-image animation 的 motion 结果提升为跨视角一致的 3D motion，使单图动画能进入 4D Gaussian 表示。

## 4. Method Details

### 4.1 Point Cloud Generation from a Single Image

给定输入图像 $\mathbf{I}\in\mathbb{R}^{3\times H\times W}$，先用 monocular depth estimation 得到 depth map $\mathbf{D}\in\mathbb{R}^{1\times H\times W}$。然后用 intrinsic matrix $\mathbf{K}$ 和输入视角 extrinsic $\mathbf{E}_0$ 将 RGB-D unproject 到点云：

$$
\mathcal{P}_{I}=\{(\mathbf{X}_i,\mathbf{C}_i)\}=\Phi_{2\rightarrow 3}(\mathbf{I},\mathbf{D};\mathbf{K},\mathbf{E}_0).
$$

其中 $\mathbf{X}_i$ 是 3D coordinate，$\mathbf{C}_i$ 是 RGB value。实现中用 ZoeDepth 估计 normalized depth；intrinsics 根据图像尺寸按常规设定，extrinsics 从 identity matrix 出发定义 camera trajectory。

### 4.2 Multi-View Image Rendering and 3DGS Optimization

点云被沿约 30 个 camera viewpoints 投影成伪多视角图：

$$
\tilde{\mathbf{I}}_i=\Phi_{3\rightarrow 2}(\mathcal{P}_I,\mathbf{K},\mathbf{E}_i).
$$

投影造成的 holes 用简单线性插值补全。这些生成的 multi-view images 被当作 multiview loss 的 ground truth，用于优化 3D Gaussians。3DGS 优化损失写为：

$$
L=L_1+\lambda(L_{\mathrm{SSIM}}-L_1).
$$

这一步本质上把单图提升出的相对 3D point cloud 转成更可渲染的 explicit Gaussian volume，为后续 motion 和 temporal modeling 做空间初始化。

### 4.3 Multi-View 2D Motion Estimation

用户或工具提供初始 motion mask $\mathbf{M}_0$。该 mask 通过同样的 lift/project 过程生成每个视角的 motion mask：

$$
\tilde{\mathbf{M}}_i=
\Phi_{3\rightarrow 2}(\Phi_{2\rightarrow 3}(\mathbf{M}_0,\mathbf{D};\mathbf{K},\mathbf{E}_0);\mathbf{K},\mathbf{E}_i).
$$

随后对每个视角的 image/mask 使用现成 single-image animation model 估计 Eulerian flow：

$$
\mathbf{F}_{t\rightarrow t+1}(\cdot)=EF(\cdot),
$$

$$
\mathbf{F}_i=EF(\tilde{\mathbf{I}}_i,\tilde{\mathbf{M}}_i).
$$

这些 $\mathbf{F}_i$ 是每个视角的 2D motion map。由于各视角独立估计，同一 3D 点投影到不同视角后可能对应不一致运动，即论文称的 Motion Ambiguity。

### 4.4 3D Motion Optimization Module

3D-MOM 直接参数化 3D 点从 $(x,y,z)$ 到 $(x',y',z')$ 的位移：

$$
\mathbf{F}_{3D}=(x',y',z')-(x,y,z).
$$

该 3D motion 投影到第 $i$ 个视角后得到 2D motion，并与该视角的估计 motion map $\mathbf{F}_i$ 做 $L_1$。优化目标为：

$$
\min_{x',y',z'}\sum_{i=0}^{N}\left\lVert \mathbf{F}_i-\Phi_{3\rightarrow 2}(\mathbf{F}_{3D};\mathbf{K},\mathbf{E}_i)\right\rVert_1.
$$

实现中用 SGD 训练约 200 iterations，batch size 30，初始学习率 0.5 并指数衰减。该模块牺牲一般 3D motion estimation 的最优性，优先保证多视角投影一致性。

### 4.5 4D Gaussian Optimization

论文采用 4D-GS 作为动态 Gaussian backbone，但声称框架不绑定某个 4DGS 模型。4D-GS 使用 Spatial-Temporal Structure Encoder、多分辨率 HexPlane 和 tiny MLP，再由 multi-head deformation decoder 输出 position、rotation、scale deformation：

$$
(\mathbf{x}',r',s')=(\mathbf{x}+\Delta\mathbf{x},r+\Delta r,s+\Delta s).
$$

由于 animation 最主要是 position deformation，作者用 3D-MOM 得到的 $\mathbf{F}_{3D}$ 初始化 position：

$$
(\mathbf{x}',r',s')=(\mathbf{x}+\mathbf{F}_{3D}+\Delta\mathbf{x}',r+\Delta r,s+\Delta s).
$$

剩余 deformation 用 weak supervision 学习，以减少 distortion。

### 4.6 Two-Stage Training

完整多视角视频全部动画化成本高且冗余。作者使用两阶段训练：第一阶段固定时间 $t=0$，用所有 viewpoints 训练 3D Gaussian，保证空间一致性；第二阶段只采样部分 viewpoints 的 pseudo-videos，在整个 temporal axis 上训练 4D Gaussians，学习 temporal deformation。

Pseudo-videos 来自多视角图、motion masks、3D motion 和 single-image animation/video generation 模型。论文与 rebuttal 中明确提到使用 Holynski et al. 和 SLR-SFS 这类模型生成 looping/temporally coherent animation。

## 5. Mathematical Objectives and Losses

主要损失包括 3DGS 空间重建 loss、3D-MOM 的多视角 motion consistency loss，以及 4DGS 的视频/图像重建 loss。关键可复用公式是：

$$
L_{\mathrm{3DGS}}=L_1+\lambda(L_{\mathrm{SSIM}}-L_1),
$$

$$
L_{\mathrm{3D\text{-}MOM}}=
\sum_{i=0}^{N}\left\lVert \mathbf{F}_i-\Phi_{3\rightarrow 2}(\mathbf{F}_{3D};\mathbf{K},\mathbf{E}_i)\right\rVert_1.
$$

4DGS 阶段以 motion-initialized deformation 为起点，通过多视角 first-frame images 和 sampled-view pseudo-videos 进行监督。抽取 tex 没有给出单独的 4DGS 总损失公式，推断应沿用 4D-GS 的 image reconstruction losses 与 deformation learning。

## 6. Training and Inference Procedure

训练流程：手动用 LabelMe 标注 input motion mask；ZoeDepth 估计 depth；按图像尺寸设 intrinsic，identity 起点设 extrinsic trajectory；从单图 lift 为 point cloud 并渲染约 30 个 views；用伪多视角图优化 3DGS；将 motion mask 投影到各 view；用 Holynski/SLR-SFS 类单图动画模型估计 2D flow；训练 3D-MOM 得到一致 3D motion；用 3D motion 初始化 4DGS position deformation；两阶段训练得到最终 4D Gaussians。

推理/生成时，用户给定 camera trajectory 和时间，4D Gaussians 根据 learned deformation 渲染 dynamic scene video。输出是 3D Gaussian domain 的动态表示，可再投影为 2D video。

## 7. Experimental Setup and Results Summary

评估使用 Holynski et al. validation set：27 个 scenes、162 个 ground-truth video clips，静态相机捕获；按照 3D-Cinemagraphy 的 4 条 camera trajectories 渲染 novel-view ground truth，每个样本 240 ground-truth frames。指标包括 PSNR、SSIM、LPIPS、PIQE；运动区域单独用 mask 评估；3D motion ablation 用 End-Point-Error (EPE)。

比较方法包括 3D-Cinemagraphy、Make-It-4D、DynamiCrafter、Motion-I2V。主表结果：本文方法 PSNR 20.57、SSIM 0.90、LPIPS 0.14、PIQE 7.80，优于 3D-Cinemagraphy 的 17.30/0.83/0.17/8.93 和 Make-It-4D 的 16.98/0.81/0.20/8.30。用户研究中，本文在 immersion、realism、structural consistency、quality 上分别为 56.25%、57.81%、62.81%、60.25%，高于 LDI baselines。

消融显示 3D-MOM 显著提高跨视角 motion consistency：不用 3D-MOM 时 EPE 为 0.152，使用后为 0.003。3D motion initialization 也能让 4DGS 更准确学习自然 motion，减少伪视频监督下的运动不稳定。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称这是首次从单张 landscape image 出发，在 complete 3D space 中考虑 animation 并优化 4D Gaussians。实际技术增量是一个 glue framework：把单图 depth lifting、多视角伪图生成、单图动画 2D flow、3D motion consistency optimization 和 4DGS training 串起来。

最核心的新模块是 3D-MOM。它不需要训练专门 3D motion network，而是把多视角 2D flow 当监督，通过投影一致性优化 3D motion。这使已有 2D animation 模型可以被“lift”到 3D Gaussian motion。

方法的生成质量很依赖外部模块：depth estimation、single-image animation/video generation、4DGS backbone。论文也把这种模块化描述为可扩展性优势。

## 9. Limitations / Assumptions

方法主要适合 fluid-like landscape motions，如 water、cloud、smoke、wind-like patterns。对于人、动物、强非刚体或复杂拓扑变化，2D Eulerian flow 和单图动画模型可能不足。

单图 depth 是 normalized/relative depth，camera intrinsics/extrinsics 也是按 convention 和预设 trajectory 构造，不是真实几何。因此生成的 3D space 是相对和伪多视角，不能等同真实重建。

伪多视角图由 point-cloud projection 和 linear interpolation 生成，遮挡区域、新显露区域和细节可能不真实。4DGS 学到的是这些伪监督下的一致表示，而非真实多视角视频约束。

## 10. Matrix-Ready Summary

| Dimension | Entry |
|---|---|
| Task | Dynamic scene video from a single landscape image |
| Input | Single image plus motion mask |
| Spatial representation | 3D Gaussians from depth-lifted point cloud |
| Multi-view supervision | Pseudo views rendered from point cloud |
| Motion source | Single-image animation / Eulerian flow models |
| Core module | 3D Motion Optimization Module (3D-MOM) |
| Motion objective | Match projected 3D motion to multi-view 2D flows |
| Dynamic representation | 4D-GS with motion-initialized position deformation |
| Main advantage | Complete 3D Gaussian space with animation, less LDI artifact |
| Main limitation | Pseudo geometry/motion from one image; best for fluid-like motions |

## 11. Reusable Components

- Depth-lifted pseudo multi-view supervision: generate views from single image for 3DGS optimization.
- Motion-mask projection: lift user mask into 3D and render masks for arbitrary views.
- 3D-MOM: optimize 3D motion by matching multi-view projected 2D flows.
- Motion-initialized 4DGS: initialize Gaussian position deformation with external 3D motion before learning residual deformation.
- Two-stage spatial/temporal training: train all views at $t=0$, then train temporal deformation on sampled pseudo-videos.

## 12. Gap / Idea Seeds

- Replace manual motion masks with SAM/semantic segmentation plus user editable controls.
- Use modern video diffusion or motion-aware image-to-video models as interchangeable 2D motion providers.
- Add geometry uncertainty from monocular depth to avoid overconfident 3D motion in poorly inferred regions.
- Extend 3D-MOM to non-Eulerian object motions by combining optical flow, segmentation and rigidity priors.
- Use generated 4D Gaussians as initialization for real video fine-tuning if later frames become available.

## 13. Human Check List

- NEED_HUMAN_CHECK: Zotero item has no PDF attachment and is marked in Trash; note was generated from arXiv source `2504.05458`.
- NEED_HUMAN_CHECK: Verify exact final publication metadata and whether ICLR 2025 version differs from arXiv source.
- NEED_HUMAN_CHECK: Check code/project page for exact 4DGS loss and video generator settings, since tex does not fully specify them.

## 14. Evidence Anchors

- Abstract and Introduction: single landscape image, explicit 4D Gaussians, multi-view image generation, consistent 3D motion.
- Section 3.1/3.2: depth lifting, point cloud generation, pseudo multi-view rendering and 3DGS optimization.
- Section 3.3: multi-view motion masks, Eulerian flow, motion ambiguity and 3D-MOM objective.
- Section 3.4: 4D-GS deformation, 3D motion initialization and two-stage training.
- Experimental Setup: ZoeDepth, LabelMe masks, Holynski/SLR-SFS, 30 views, SGD 200 iterations, RTX 3090.
- Results/Ablations: quantitative table, user study, EPE improvement from 0.152 to 0.003.
