# QUEEN: QUantized Efficient ENcoding of Dynamic Gaussians for Streaming Free-viewpoint Videos

## 0. Metadata

- Paper title: QUEEN: QUantized Efficient ENcoding of Dynamic Gaussians for Streaming Free-viewpoint Videos
- Authors: Sharath Girish; Tianye Li; Amrita Mazumdar; Abhinav Shrivastava; David Luebke; Shalini De Mello
- Venue / year: NeurIPS 2024
- Project / code: `https://research.nvidia.com/labs/amri/projects/queen`
- Zotero item key: `DP8L4WCJ`
- Zotero PDF attachment key: `YZWWNBRQ`
- Zotero PDF path: `/Users/wangyibo/Zotero/storage/YZWWNBRQ/Girish 等 - 2024 - QUEEN QUantized Efficient ENcoding of Dynamic Gaussians for Streaming Free-viewpoint Videos.pdf`
- Local note path: `notes/QUEEN: QUantized Efficient ENcoding of Dynamic Gaussians for Streaming Free-viewpoint Videos.md`

## 1. One-Sentence Technical Summary

QUEEN 面向在线 free-viewpoint video streaming，把每一帧的 3DGS 表示写成相邻帧 Gaussian attribute residual，并用整数 latent-decoder 量化非位置属性、用 learned gates 稀疏化位置残差，再借助 viewspace gradient difference 聚焦动态区域，实现低码率、低训练延迟和高 FPS 的动态 Gaussian 流式编码。

## 2. Problem Formulation

在线 FVV streaming 要求系统在每个时间步只使用当前局部输入，增量更新 3D/4D volumetric representation，同时满足三类约束：训练/编码要快，渲染/解码要快，逐帧传输包要小。离线 dynamic NeRF/4DGS 可以访问完整视频并长时间训练，不适合 3D video conferencing、live volumetric broadcast 等流式场景。

QUEEN 的问题设定是：第 0 帧训练一个标准 3DGS 表示 $A_0$，随后每个时间步 $t$ 只学习相对上一帧属性 $A_{t-1}$ 的残差 $R_t$，并在训练过程中同时压缩这些残差。它不强行把动态映射塞进固定 voxel grid、triplane 或 hash cache，而是允许所有 Gaussian attributes 自由更新，再通过 quantization-sparsity 降低码率。

## 3. Method Overview

QUEEN 由三部分组成。第一，attribute residual modeling：对每一帧，Gaussian attributes 满足 $A_t=A_{t-1}+R_t$，残差覆盖 position、rotation、scale、opacity 和 color。第二，quantization-sparsity framework：rotation/scale/opacity/color 等非位置残差用可训练整数 latents 和共享线性 decoder 表示，训练后 entropy coding；position residuals 对量化敏感，因此保持 full precision，但通过 learned gates 让大多数位置残差为 0，只存动态部分。第三，adaptive masked training：用相邻帧 viewspace Gaussian gradient difference 初始化/指导 gates，并只渲染动态局部区域，加速训练。

该框架把 dynamic Gaussian streaming 看作“残差学习 + 残差压缩 + 动态区域选择”。相较只更新部分属性或固定结构的 3DGStream，QUEEN 更新全部属性，表达能力更强；相较逐帧完整 3DGS，QUEEN 利用时间冗余大幅压缩。

## 4. Method Details

### 4.1 3DGS Base Representation

每个 Gaussian 的 attributes 为 $A=\{p_i,q_i,s_i,o_i,h_i\}_{i=1}^N$，包括位置、旋转 quaternion、scale、opacity 和 spherical harmonic coefficients。投影到 2D 后，像素颜色由 alpha blending 得到：

$$
\hat{c}(x)=\sum_{i=1}^{N}c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j),
\qquad
\alpha_i=o_i\cdot\exp\left(-\frac{1}{2}(x-p_i')^T\Sigma_i'^{-1}(x-p_i')\right).
$$

标准重建损失为：

$$
L=\lambda L_{\mathrm{D\text{-}SSIM}}+(1-\lambda)L_1.
$$

QUEEN 第 0 帧用 vanilla 3DGS 训练 $A_0$，之后进入逐帧残差模式。

### 4.2 Attribute Residual Formulation

对于多视角视频序列 $\{I_t\}_{t=0}^{T-1}$，时间步 $t$ 的属性由上一时间步加残差得到：

$$
A_t=A_{t-1}+R_t.
$$

$R_t$ 包括所有 Gaussian attributes 的 learnable residuals。这个选择与只学习几何 transform 或少量属性的在线方法不同，能表达 illumination changes、新纹理变化和复杂动态外观。代价是未压缩残差的内存很大，因此需要后续量化和稀疏化。

### 4.3 Quantized Latent-Decoder for Non-Position Residuals

对非位置属性残差，QUEEN 使用每个 Gaussian 的整数 latent $l_i\in\mathbb{Z}^L$ 和共享线性 decoder $D\in\mathbb{R}^{M\times L}$ 表示属性类别残差 $r_i\in\mathbb{R}^M$。训练时维护连续 latent $\hat{l}_i\in\mathbb{R}^L$，forward pass 通过 STE 近似取整：

$$
l_i=\operatorname{STE}(\hat{l}_i), \qquad r_i=D(l_i;D)=D\cdot\operatorname{float}(l_i).
$$

连续 latents 和 decoder 参数都参与端到端优化。训练后，整数 latents $L$ 用 entropy coding 存储，decoder $D$ 直接存储。论文报告 entropy coding 可在不降低质量的情况下把相关 residual storage 从 44 MB 降到 4 MB 量级。

### 4.4 Position Residual Gating

位置残差对量化更敏感，直接低比特量化会显著影响渲染质量。QUEEN 因此不量化 position residual，而是学习稀疏门控。对第 $i$ 个 Gaussian：

$$
\Delta p_i=g_i\cdot l_i^p,
$$

其中 $g_i$ 是 learnable scalar gate，$l_i^p\in\mathbb{R}^3$ 是 full-precision pre-gated position residual。训练后，大量 $g_i$ 被压到 0，对应静态 Gaussians 不存位置残差；非零动态 Gaussians 的 $\Delta p_i$ 以 sparse matrix format 存储。

该设计等价于把位置 residual compression 从“值量化”改成“动态点选择”：静态区域使用上一帧位置，动态区域保留精确运动。

### 4.5 Viewspace Gradient Difference

QUEEN 使用相邻帧 2D viewspace Gaussian gradients 的差异来分离静态/动态内容。直觉是：动态区域或外观显著变化区域的 viewspace gradient 会在相邻帧之间发生明显变化，而静态背景变化小。该 signal 用于初始化 learned gates，并指导 adaptive masked training。

在训练效率上，作者不总是渲染整张图像，而是根据 gradient difference 选择高度动态的局部 image regions，只对这些 masked regions 进行更集中的训练。这既减少计算，也避免静态区域主导优化。

## 5. Mathematical Objectives and Losses

核心重建目标仍是 3DGS 的 image reconstruction loss：

$$
L_{\mathrm{rec}}=\lambda L_{\mathrm{D\text{-}SSIM}}+(1-\lambda)L_1.
$$

QUEEN 在该目标上加入量化与稀疏机制：非位置残差通过 STE 量化 latents 反向传播，position residual 通过 gate sparsity 学习静态/动态分离。抽取文本未完整显示 gate sparsity 的具体正则项形式，但方法描述表明 gate 会被鼓励为稀疏，使大部分位置残差为 0。

逐帧优化可概括为：

$$
\min_{\hat{L}_t,D_t,g_t,l_t^p}\; L_{\mathrm{rec}}(R(A_{t-1}+R_t), I_t) + L_{\mathrm{sparse}}(g_t),
$$

其中 $R_t$ 由量化 decoder 输出的非位置残差和 gated full-precision 位置残差共同组成。该式是根据方法描述归纳的实现目标，具体权重和正则形式需查论文完整方法/代码。

## 6. Training and Inference Procedure

训练/编码时，第 0 帧训练 vanilla 3DGS。对每个后续帧 $t$，加载上一帧 attributes $A_{t-1}$；初始化量化 latents、decoder 和 position gates；用 viewspace gradient difference 识别动态区域并初始化 gates；在 masked dynamic regions 和必要全图监督下优化 residuals；训练完成后 entropy-code 整数 latents，存储小 decoder 和 sparse position residuals。

解码/渲染时，接收上一帧 attributes 和当前帧压缩 residual packet；解码 latents 得到非位置 residuals；恢复 sparse position residuals；计算 $A_t=A_{t-1}+R_t$；用标准 3DGS rasterizer 渲染任意视角。论文报告渲染约 350 FPS，解码 residual 是每步一次的操作，也可与下一帧训练并行。

## 7. Experimental Setup and Results Summary

论文在多个 FVV benchmarks 上评估，包括 N3DV 和 Immersive datasets。N3DV 使用 6 个动态场景；Immersive 使用 7 个场景，中央视角 hold out 测试，部分视频抽取前 300 帧，Truck 为 150 帧。评价维度包括 reconstruction quality、per-frame model size、training/encoding time 和 rendering FPS。

主结论是 QUEEN 在在线 FVV 方法中全面优于 3DGStream、TeTriRF 等 baselines。摘要报告在多个高动态场景上每帧模型大小可低至 0.7 MB，训练小于 5 秒，渲染约 350 FPS。论文强调相比固定结构或只更新部分属性的方法，QUEEN 同时提升质量、训练速度、渲染速度和内存效率。

消融显示各组件都有贡献：完整 attribute residual 比只更新子集更高质量；quantized latent-decoder 大幅降低非位置属性码率；position gating 比量化位置更稳；viewspace gradient difference 能改进 gate 初始化、加速训练，并帮助 adaptive masked rendering 聚焦动态区域。

## 8. Claimed Contribution vs Actual Technical Delta

QUEEN 的贡献不在于新的 Gaussian 渲染器，而在于 online dynamic Gaussian encoding。它把动态场景表示从“学习一个时间条件模型”转为“逐帧更新并压缩 residual packets”，更贴近 video codec 和 streaming 系统需求。

真实技术增量有三点。第一，所有 Gaussian attributes 都允许残差更新，减少结构假设带来的表达损失。第二，非位置属性与位置属性采用不同压缩策略：前者量化，后者稀疏。第三，viewspace gradient difference 把渲染优化中的梯度信息转化为动态区域选择信号，连接了训练效率和码率控制。

这篇对 Dynamic GS 分类的价值是补齐“流式传输/编码”方向：很多 dynamic GS 关注重建质量，QUEEN 关注在线约束下如何把每帧动态变化打包成可传输的 compact residual。

## 9. Limitations / Assumptions

论文附录明确指出，逐帧 residual encoding 对长序列或剧烈场景更新会遇到重建能力挑战。因为在线训练看不到未来帧，面对突然出现/消失的物体、拓扑变化或强烈外观变化时，难以及时分配、剪枝或 densify Gaussians。

方法仍依赖相干的多视角输入视频。若输入视角稀疏、缺帧或跨视角不同步，residual learning 和 viewspace gradient difference 的可靠性会下降。作者也指出 single/sparse-view streaming FVV 是未来方向。

虽然每帧训练可小于数秒，但仍不是零延迟编码；真实低带宽/高分辨率直播系统还需要与网络传输、packet loss、客户端缓存和关键帧策略结合。

## 10. Matrix-Ready Summary

| Dimension | Entry |
|---|---|
| Task | Online free-viewpoint video streaming |
| Representation | Per-frame 3D Gaussian attributes |
| Temporal model | Attribute residuals $A_t=A_{t-1}+R_t$ |
| Updated attributes | Position, rotation, scale, opacity, color |
| Compression | Quantized integer latents + shared decoder for non-position residuals |
| Position handling | Full-precision residuals with learned sparse gates |
| Dynamic signal | Viewspace Gaussian gradient difference |
| Efficiency trick | Adaptive masked training on dynamic regions |
| Output packet | Entropy-coded latents, decoder, sparse position residuals |
| Main advantage | High quality, low per-frame MB, fast training and ~350 FPS rendering |
| Main limitation | Hard sudden scene changes and long-term online drift |

## 11. Reusable Components

- Residual Gaussian streaming: encode dynamic scenes as per-frame updates from previous Gaussian attributes.
- Attribute-specific compression: quantize appearance/shape/orientation residuals but sparsify position residuals.
- STE integer latent decoder: train discrete residual codes end-to-end, entropy-code after training.
- Viewspace gradient difference: use renderer gradients to localize dynamic content and initialize motion gates.
- Adaptive masked training: render/train high-change image regions more often for low-latency updates.

## 12. Gap / Idea Seeds

- Add keyframe scheduling for sudden object appearance/disappearance and topology changes.
- Combine QUEEN residual packets with standard video-codec rate control ideas: bitrate budget, packet priority, temporal GOP.
- Learn predictive residual priors from previous frames to reduce per-frame optimization time.
- Extend position gating from scalar hard sparsity to uncertainty-aware motion clusters.
- Support sparse-view online FVV by adding generative dynamic-scene priors or cross-view hallucination constraints.

## 13. Human Check List

- NEED_HUMAN_CHECK: Extracted text truncates the exact position gate sparsity regularizer and its weights; verify from PDF/code.
- NEED_HUMAN_CHECK: Confirm code release status; paper checklist says code will be released in the future.
- NEED_HUMAN_CHECK: Check full numeric tables for exact per-dataset PSNR/SSIM/LPIPS/model-size/training-time values.

## 14. Evidence Anchors

- Abstract and Introduction: online FVV constraints, all-attribute residuals, quantization-sparsity, viewspace gradient difference, 0.7 MB/frame and ~350 FPS claim.
- Figure 1: residual update, quantization, gates, adaptive masked training overview.
- Section 3.1: 3DGS attributes, rendering equation and reconstruction loss.
- Section 3.2: $A_t=A_{t-1}+R_t$, STE integer latent-decoder, position residual gating.
- Section 3.3: viewspace gradient difference for dynamic/static separation and efficient masked training.
- Appendix C: limitations on long sequences, drastic scene updates, keyframing and sparse-view future directions.
