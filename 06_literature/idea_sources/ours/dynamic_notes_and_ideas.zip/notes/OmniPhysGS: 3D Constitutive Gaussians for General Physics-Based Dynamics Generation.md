# OmniPhysGS: 3D Constitutive Gaussians for General Physics-Based Dynamics Generation

## 0. Metadata

- Paper title: OmniPhysGS: 3D Constitutive Gaussians for General Physics-Based Dynamics Generation
- Authors: Yuchen Lin; Chenguo Lin; Jianjin Xu; Yadong Mu
- Venue / year: ICLR 2025
- Project / code: `https://wgsxm.github.io/projects/omniphysgs`
- Zotero item key: `2YJS24MS`
- Zotero PDF attachment key: `8MXKH922`
- Zotero PDF path: `/Users/wangyibo/Zotero/storage/8MXKH922/Lin 等 - 2024 - OmniPhysGS 3D Constitutive Gaussians for General Physics-Based Dynamics Generation.pdf`
- Local note path: `notes/OmniPhysGS: 3D Constitutive Gaussians for General Physics-Based Dynamics Generation.md`

## 1. One-Sentence Technical Summary

OmniPhysGS 将 3D Gaussians 扩展为 Constitutive Gaussians，为每个局部 Gaussian neighborhood 学习由 12 类专家本构模型组成的材料选择，并把 MPM 物理模拟渲染成视频后用 text-to-video diffusion SDS 优化，从而生成多材料、异质物体交互的物理 4D 动态。

## 2. Problem Formulation

输入是一个静态 3D Gaussian scene $S=\{x_p,\Sigma_p,sh_p,\alpha_p\}_{p\in P}$ 和用户文本提示 $y$，提示描述物体材料和运动，例如 “A rubber duck falls on a soft mud pile”。目标是生成与文本一致、同时符合物理规律的 3D dynamic scene。

已有 physics-based 3DGS 方法通常要求手动指定材料参数，或把所有物体限制在某一类材料模型中，例如纯弹性或粘弹性。这在真实场景中不够，因为一个场景可能同时包含橡胶、金属、泥、水、沙等不同材料。OmniPhysGS 的核心问题是自动估计每个 Gaussian 的物理材料模型，并支持多材料交互。

## 3. Method Overview

方法先从多视角图像获得静态 3D Gaussians，然后把每个 Gaussian particle 放入 differentiable MPM simulator。与 PhysGaussian 一类方法不同，OmniPhysGS 不手动设置固定 constitutive model，而是为局部 Gaussian neighborhoods 学习 material category logits，并从专家设计的 hyperelastic energy density functions 和 plasticity return functions 中选择组合。

动态过程由 MPM 推进，得到每个时间步的 particle positions 和 deformation gradients，再通过 MPM-compatible 3DGS renderer 渲染视频片段。视频片段输入 pretrained text-to-video diffusion model ModelScope，通过 Score Distillation Sampling (SDS) 对 Constitutive Gaussian 网络参数反向优化，使模拟动态符合文本提示和视频先验。

## 4. Method Details

### 4.1 Physical Background: Constitutive Models

连续介质力学中的守恒方程为：

$$
\frac{D\rho}{Dt}+\rho\nabla\cdot v=0,\qquad
\rho\frac{Dv}{Dt}=\nabla\cdot\sigma+f_{\mathrm{ext}}.
$$

Cauchy stress tensor 由 hyperelastic energy density function $\Psi$ 和 deformation gradient 的弹性部分 $F^E$ 给出：

$$
\sigma(x,t)=\frac{1}{\det(F)}\frac{\partial\Psi}{\partial F}(F^E)(F^E)^T.
$$

同时，plasticity return function $\psi$ 对 trial deformation gradient 做塑性约束修正：

$$
F=\psi(F^E).
$$

因此材料行为主要由 $\Psi(\cdot)$、$\psi(\cdot)$ 和物理参数 $\gamma$ 决定。OmniPhysGS 把这些从手工设置扩展为可学习选择。

### 4.2 Constitutive Gaussian

vanilla 3D Gaussian kernel 被扩展为 Constitutive Gaussian。每个 particle 的 constitutive components 被写为：

$$
\Psi\leftarrow \Psi_{\theta_{\mathrm{el}}},\qquad
\psi\leftarrow \psi_{\theta_{\mathrm{pl}}},\qquad
\gamma\leftarrow \gamma_{\theta_{\mathrm{phy}}}.
$$

训练目标为：

$$
\min_{\theta_{\mathrm{el}},\theta_{\mathrm{pl}},\theta_{\mathrm{phy}}} L(S,y;\Phi),
$$

其中 $\Phi$ 是 pretrained text-to-video diffusion model，$L$ 是 SDS guidance 产生的优化目标。论文也从概率角度写作：

$$
\theta^\ast=\arg\max_{\theta}\log P(V(\theta)\mid S,y;\Phi).
$$

### 4.3 Physics-Guided Constitutive Network

直接用普通 MLP 从 diffusion guidance 中学习本构模型会不稳定，因为 constitutive model 高度非线性，且中间模拟状态没有 ground truth。OmniPhysGS 因此采用 physics-guided network：3D feature encoder + physical-aware decoder。

Feature encoder 类似 PointBERT。首先用 FPS 和 kNN 将 Gaussian particles 划分为 local neighborhoods $N_i$，每个 neighborhood 包含 32 particles；mini-PointNet 编码 neighborhood 中 $\{x_p,\Sigma_p,sh_p,\alpha_p\}_{p\in N_i}$，得到 feature $f_i\in\mathbb{R}^d$。该 partition 只在初始位置上执行一次，避免未优化材料导致的动态噪声。

Physical-aware decoder 用 MLP 预测材料类别 logits，并通过 hardmax + straight-through estimator 为每个 neighborhood 选择专家 constitutive model。对 neighborhood $N_i$：

$$
\sigma_{p\in N_i}=\Psi_{j_i}(F_{p\in N_i}),\qquad
F_{p\in N_i}=\psi_{k_i}(F_{p\in N_i}^{\mathrm{trial}}),
$$

$$
j_i,k_i=\arg\max[\operatorname{MLP}_j(f_i),\operatorname{MLP}_k(f_i)].
$$

作者收集 12 种 constitutive model combinations，由 3 类 hyperelastic density functions 和 4 类 plasticity return functions 组合而成，覆盖 pure elasticity、viscoelasticity、plasticity 和 fluidity。

### 4.4 MPM Simulation and Rendering

MPM 的每个时间步跟踪 particle state：

$$
s_{t_n}=\{x_p^{t_n},v_p^{t_n},F_p^{t_n},C_p^{t_n}\}_{p\in P}.
$$

初始化时：

$$
x_p^{t_0}=x_p,\qquad v_p^{t_0}=0,\qquad F_p^{t_0}=I,\qquad C_p^{t_0}=0.
$$

MPM 每步包含 stress update、particle-to-grid、grid update、grid-to-particle 和 plasticity correction。用于渲染时，Gaussian center 和 covariance 根据 MPM 状态更新：

$$
x_{p,\mathrm{render}}^{t_n}\leftarrow x_p^{t_n},\qquad
\Sigma_{p,\mathrm{render}}^{t_n}\leftarrow F_p^{t_n}\Sigma_p(F_p^{t_n})^T.
$$

视角方向也按 deformation gradient 的 polar decomposition 更新：

$$
d_{p,\mathrm{render}}^{t_n}\leftarrow (R_p^{t_n})^Td_p.
$$

SH coefficients 和 opacity 在模拟中保持不变。

### 4.5 Diffusion Guidance

每次训练从初始状态 $s_{t_0}$ 开始，MPM 模拟 $N-1$ 步得到 states $[\hat{s}_{t_0},\hat{s}_{t_1},\ldots,\hat{s}_{t_{N-1}}]$。渲染器生成视频片段：

$$
\hat{V}=[\hat{I}_{t_0},\hat{I}_{t_1},\ldots,\hat{I}_{t_{N-1}}].
$$

ModelScope text-to-video diffusion model 以 prompt $y$ 监督 $\hat{V}$，SDS gradient 回传到 Constitutive Gaussian parameters。由于 MPM 和 renderer 可微，材料选择/参数能够被文本视频先验驱动优化。

## 5. Mathematical Objectives and Losses

主目标是最大化 diffusion model 对模拟视频的文本条件似然，实际训练通过 SDS 实现。抽象写为：

$$
L_{\mathrm{SDS}}(\theta;y,\Phi)=\left\langle \nabla_{\hat{V}}\log P_\Phi(\hat{V}\mid y),\frac{\partial \hat{V}}{\partial \theta}\right\rangle.
$$

该式是对 SDS 训练关系的概括；论文抽取文本在梯度公式处被截断，具体噪声时间步采样、权重和 ModelScope loss 细节需查 PDF/代码。

评估上，作者使用 CLIPSIM、DiffSSIM 和 DiffCLIP。CLIPSIM 为：

$$
\operatorname{CLIPSIM}=\frac{1}{N}\sum_{n=1}^{N}\operatorname{CLIP}(\hat{I}_n,y).
$$

DiffSSIM 和 DiffCLIP 定义为：

$$
\operatorname{DiffSSIM}=1-\frac{1}{N}\sum_{n=1}^{N}\operatorname{SSIM}(I_n',\hat{I}_n),\qquad
\operatorname{DiffCLIP}=\frac{\operatorname{CLIPSIM}}{\operatorname{CLIPSIM}'}.
$$

## 6. Training and Inference Procedure

训练设置：所有实验在单张 NVIDIA A6000 48GB 上进行。模拟时间步 $\Delta t=3\times 10^{-4}$，视频长度 150 frames、30 fps，共 5 秒。场景放入 $1\times 1\times 1$ bounding box，并划分为 $25\times25\times25$ grids；重力为 9.8 m/s²。训练 Adam 学习率 $5\times 10^{-5}$，每个场景 5 iterations。

训练策略把完整模拟分为 10 个 stages，每个 stage 渲染 15 frames，并对每个 stage 的 video clips 用 pretrained text-to-video diffusion model 优化 30 internal iterations，再进入下一 stage。Constitutive Gaussian 网络用 FPS 采样 8192 centers，每个 neighborhood 32 particles。

推理/生成时，给定静态 3DGS scene 和 prompt，Constitutive Gaussian 网络预测每个局部 neighborhood 的材料模型，MPM 模拟产生动态轨迹，Gaussian renderer 输出 4D video。用户也可通过边界条件、初始速度、外力等控制 motion generalization。

## 7. Experimental Setup and Results Summary

比较对象包括 PhysDreamer、Physics3D 和 DreamPhysics。实验覆盖单物体不同材料、多物体异质材料交互，以及 motion generalization。定量指标包括 visual quality 和 text alignment 相关指标，论文摘要称相较已有方法在这些指标上提升约 3% 到 16%。

定性结果展示了多种材料行为：crushed metal can、rubber duck falling、sand wolf collapsing、jelly bouncing、water flowing、mud pile collapsing、rubber duck on soft mud pile、hard duck denting breakable metal can、lego excavator digging soil 等。基线方法往往对不同 prompt 产生相似材料动态，因为它们只调少量物理参数且固定 constitutive family；OmniPhysGS 通过专家本构模型选择表现出更丰富材料差异。

消融强调 physical-aware decoder 的重要性：纯 neural network-only prediction 容易收敛不稳定；hardmax 选择专家本构模型给中间模拟施加强物理约束，提升训练稳定性和物理合理性。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称是首个为 physics-based 3D dynamic synthesis 引入 learnable constitutive models 的方法。实际增量在于把 Gaussian particle 的材料建模从“手动参数”提升到“可学习的本构专家选择”，并用 text-to-video diffusion prior 自动监督。

它不是简单学习 Young’s modulus 或 Poisson’s ratio，而是从 12 个 constitutive model combinations 中选择 hyperelastic/plastic response，因此能覆盖 elasticity、plasticity、viscoelasticity 和 fluidity。相比 PhysGaussian，自动化更强；相比纯 4D generation，物理约束更明确。

对 Dynamic GS 体系而言，OmniPhysGS 把 3DGS 的粒子性质用于 MPM simulation，强调“物理可模拟”而不是“数据驱动 deformation field”。

## 9. Limitations / Assumptions

材料在 local neighborhood 内被假设为 homogeneous，且 hardmax 只选择一个专家组合。这有助于物理可解释和稳定训练，但对连续混合材料或细粒度空间变化可能不够。

方法依赖 video diffusion model 的材料/运动先验。如果 prompt 对应的材料行为在 diffusion model 中学得不好，SDS 可能给出错误梯度。由于没有真实中间物理状态监督，优化仍可能受到 diffusion prior 偏差影响。

MPM simulation 和 SDS 多阶段训练成本较高；每个场景需要重复模拟和渲染，不是实时动态预测方法。SH 和 opacity 保持不变，也限制了颜色/外观随材料变形或流体混合的变化。

## 10. Matrix-Ready Summary

| Dimension | Entry |
|---|---|
| Task | Text-guided physics-based 3D/4D dynamic synthesis |
| Input | Static 3DGS scene and material/motion text prompt |
| Representation | Constitutive Gaussians |
| Physics engine | Differentiable MPM |
| Material model | Expert constitutive model ensemble |
| Experts | 3 hyperelastic functions x 4 plasticity return functions = 12 combinations |
| Learning signal | Text-to-video SDS via ModelScope |
| Key network | PointBERT-like feature encoder + physical-aware decoder |
| Rendering | MPM-compatible 3DGS renderer |
| Main advantage | Multi-material general dynamics without manual material tuning |
| Main limitation | Neighborhood-level hard material assignment and diffusion prior dependence |

## 11. Reusable Components

- Constitutive Gaussian abstraction: attach learnable material model selection to Gaussian particles.
- Physics-aware decoder: combine neural material inference with expert-designed constitutive functions.
- Hardmax + STE material routing: enforce discrete physically valid material families while keeping differentiability.
- MPM-compatible Gaussian rendering: update Gaussian covariance with deformation gradient.
- Stage-wise SDS over simulation clips: optimize long physical simulations in shorter video chunks.

## 12. Gap / Idea Seeds

- Replace hardmax expert selection with temperature-controlled mixture only where physical stability permits.
- Learn spatially continuous material fields over Gaussians while preserving local constitutive validity.
- Add real video/material supervision to reduce reliance on text-to-video diffusion priors.
- Extend appearance dynamics so SH/color/opacity can change with wetting, breaking, melting or fluid mixing.
- Use OmniPhysGS material inference as initialization for faster NGFF-style neural force prediction.

## 13. Human Check List

- NEED_HUMAN_CHECK: Extracted text truncates the exact SDS gradient formula; verify from PDF/code before implementation.
- NEED_HUMAN_CHECK: Confirm final code/data release status and exact list of 12 constitutive combinations.
- NEED_HUMAN_CHECK: Check whether all experiments use ModelScope or whether additional video diffusion priors are used in supplementary.

## 14. Evidence Anchors

- Abstract and Figure 1: general material dynamics, 12 domain experts, video diffusion supervision, comparison to fixed physical models.
- Section 3.1: problem statement with 3D Gaussian scene and prompt.
- Section 3.2.1: constitutive equations, learnable $\Psi$, $\psi$, $\gamma$ and training target.
- Section 3.2.2: PointBERT-like encoder, physical-aware decoder, hardmax expert selection.
- Section 3.2.3: MPM simulation, rendering and SDS guidance.
- Appendix A-B: MPM equations, Gaussian rendering updates, expert constitutive models, hyperparameters and training strategy.
