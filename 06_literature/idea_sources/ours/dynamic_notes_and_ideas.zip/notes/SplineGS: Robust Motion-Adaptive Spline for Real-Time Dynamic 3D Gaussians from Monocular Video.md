# SplineGS: Robust Motion-Adaptive Spline for Real-Time Dynamic 3D Gaussians from Monocular Video

## 0. Metadata

* Title: SplineGS: Robust Motion-Adaptive Spline for Real-Time Dynamic 3D Gaussians from Monocular Video
* Authors: Jongmin Park; Minh-Quan Viet Bui; Juan Luis Gonzalez Bello; Jaeho Moon; Jihyong Oh; Munchurl Kim
* Year: 2025
* Venue: CVPR 2025
* PDF source: `/Users/wangyibo/Zotero/storage/2T8TVARJ/Park 等 - SplineGS Robust Motion-Adaptive Spline for Real-Time Dynamic 3D Gaussians from Monocular Video.pdf`
* Local note path: `notes/SplineGS: Robust Motion-Adaptive Spline for Real-Time Dynamic 3D Gaussians from Monocular Video.md`
* Zotero item key: `9QPVVWGV`
* Zotero PDF attachment key: `2T8TVARJ`
* Project page: https://kaist-viclab.github.io/splinegs-site/
* Code: Not specified in extracted PDF text
* Dataset link: Not specified
* Main task: COLMAP-free dynamic 3DGS from in-the-wild monocular videos; novel view and time synthesis
* Domain: monocular dynamic Gaussian Splatting; spline trajectory; camera pose estimation
* Input: monocular video frames, metric depth prior, 2D long-range tracks, motion masks; no precomputed camera parameters
* Output: optimized camera intrinsics/extrinsics, static/dynamic 3D Gaussians, dynamic Gaussian spline trajectories, novel spatio-temporal renders
* Main representation: union of static 3D Gaussians and dynamic 3D Gaussians whose means follow motion-adaptive cubic Hermite splines
* Supervision type: photometric / geometric self-supervision with metric depth and tracking priors
* Core contribution in one sentence: 用 Motion-Adaptive Spline 将每个动态 Gaussian 的均值轨迹表示为带可学习控制点的 cubic Hermite spline，并用 MACP 为不同运动复杂度自适应剪枝控制点，同时联合估计 COLMAP-free camera parameters。
* Note status: `complete`

## 1. 一句话技术摘要

这篇论文处理 in-the-wild monocular videos 的动态新视角/新时间合成，通过将动态 3D Gaussians 的位置轨迹建模为 cubic Hermite spline，并用 motion-adaptive control point pruning 为每个 Gaussian 保留足够但不过量的控制点；关键技术差异是同时摆脱 COLMAP 预处理和 MLP/grid deformation 的渲染开销，在单目场景中实现高质量和约 400 FPS 渲染。

## 2. 问题形式化

### 2.1 任务

给定单目视频 $\{I_t\}_{t=0}^{N_f-1}$，没有可靠 COLMAP camera parameters。模型需要估计每帧 camera extrinsics $[\hat{R}_t|\hat{T}_t]$、共享 intrinsics $\hat{K}$，并学习静态背景与动态对象的 3D Gaussian representation，用于任意 novel view 和 unseen intermediate time 渲染。

### 2.2 核心难点

* 单目视频缺少多视角约束；
* COLMAP 在动态、in-the-wild 视频上常失败；
* MLP / grid deformation 速度慢或细节不足；
* 固定阶 polynomial trajectory 对不同 motion complexity 不够自适应；
* Novel view and time synthesis 要求模型能渲染训练中未见过的中间时间。

### 2.3 表示拆分

SplineGS 将场景表示为：

* static Gaussians $\{G_i^{st}\}$: 建模静态背景；
* dynamic Gaussians $\{G_i^{dy}\}$: 建模运动对象；
* dynamic Gaussian 的 mean $\mu(t)$ 由 spline function $S(t,P)$ 给出；
* camera parameters 由 shallow MLP / learnable focal length 估计，并与 Gaussians 联合优化。

## 3. 方法概览

SplineGS 由三部分组成。

第一，Motion-Adaptive Spline (MAS)。每个 dynamic Gaussian 持有一组可学习控制点 $P=\{p_k\}$。给定时间 $t$，使用 cubic Hermite spline 计算 Gaussian mean $\mu(t)$。控制点数量 $N_c$ 不必等于帧数 $N_f$。

第二，Motion-Adaptive Control Points Pruning (MACP)。训练中尝试把当前 $N_c$ 个控制点压缩成 $N_c-1$ 个；如果投影误差低于阈值 $\epsilon$，就接受剪枝。这样简单运动用少量控制点，复杂运动保留更多控制点。

第三，COLMAP-free camera parameter estimation。用 photometric consistency 和 geometric consistency 优化相机参数。warm-up 阶段先优化 camera，main stage 再联合优化 camera、static/dynamic Gaussians 和 MAS。

## 4. 方法细节

### 4.1 3DGS 预备

3DGS Gaussian Eq. 1: $G(x)=e^{-\frac{1}{2}(x-\mu)^\top\Sigma^{-1}(x-\mu)}$。Covariance 分解为 $\Sigma=RSS^\top R^\top$，其中 $S$ 来自 scale vector $s$，$R$ 由 unit quaternion $q$ 表示。

渲染颜色 Eq. 2: $C=\sum_{i\in N}c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j)$，其中 $\alpha_i$ 由投影后的 2D covariance $\Sigma'=JW\Sigma W^\top J^\top$ 计算。

论文沿用静态 + 动态 Gaussian union：static background 用 $G_i^{st}$，dynamic objects 用 $G_i^{dy}$。

### 4.2 Motion-Adaptive Spline

对每个 dynamic Gaussian，SplineGS 不用 MLP 或 grid 查询位置变形，而是把 mean 改成 spline trajectory。Eq. 3: $\mu(t)=S(t,P)$。

控制点集合 $P=\{p_k\in R^3,k=0,\ldots,N_c-1\}$ 是每个 dynamic Gaussian 的额外 learnable attribute。$N_c$ 可小于 $N_f$，并由 MACP 调整。

Eq. 4 定义 cubic Hermite spline。令 $t_n=t/(N_f-1)$，$t_s=t_n(N_c-1)$，$t_r=t_s-\lfloor t_s\rfloor$。Spline 在当前 segment 上由 $p_{\lfloor t_s\rfloor}$、$p_{\lfloor t_s\rfloor+1}$ 及其 tangents 计算。Tangent $m_k=(p_{k+1}-p_{k-1})/2$。

这个设计相当于为每个 Gaussian 学一条连续 3D 轨迹。相比固定三次/十次 polynomial，Hermite spline 是 piecewise 的，能局部表达不同速度和曲率；相比 MLP/grid，推理时只需 spline evaluation，延迟低。

### 4.3 Control points initialization

稳定优化 spline 需要合理初始化。SplineGS 使用 long-range 2D tracking CoTracker 和 metric depth UniDepth。

给定 2D track $T=\{\phi_t^{tr}\}$、metric depth $d_t$、当前估计 camera extrinsic $[\hat{R}_t|\hat{T}_t]$ 和 intrinsic $\hat{K}$，Eq. 5 将 2D track unproject 到世界坐标：

$W_t(\phi_t^{tr})=\hat{R}_t^\top\pi_{\hat{K}}^{-1}(\phi_t^{tr},d_t(\phi_t^{tr}))-\hat{R}_t^\top\hat{T}_t$。

然后通过 least-square fitting 初始化控制点。Eq. 6: $\min_P\sum_{t=0}^{N_f-1}\|W_t(\phi_t^{tr})-S(t,P)\|_2^2$。

注意 camera parameters 也是从视频估计出来的，不是 ground truth，也不是 COLMAP。

### 4.4 MACP

过多控制点会 overfit 并降低渲染速度；过少控制点表达不了复杂运动。MACP 在每次 3D Gaussian densification 后执行。

给定当前控制点集 $P$，构造少一个控制点的新集合 $P'$，通过 Eq. 7 最小化 $\sum_t\|S(t,P)-S(t,P')\|_2^2$。

然后计算投影误差 Eq. 8。若 $E<\epsilon$，则接受 $P'$；否则保留 $P$。误差 $E$ 是所有时间上 $S(t,P)$ 与 $S(t,P')$ 在当前相机下投影位置的平均 $L_2$ 差异。

这样每个 dynamic Gaussian 可以有不同 $N_c$。Fig. 8 显示简单人体运动用较少控制点，复杂 balloon 运动需要更多控制点。

### 4.5 Camera parameter estimation

每帧 extrinsic 由 shallow MLP $F_\theta$ 输入时间 encoding 预测。Eq. 9: $[\hat{R}_t|\hat{T}_t]=F_\theta(\gamma(t))$。Intrinsic 中 focal length $\hat{f}$ 是共享 learnable parameter。

为了估计 camera，SplineGS 使用 static background 的 photometric and geometric consistency。核心是用 metric depth 将 target pixel unproject 到 3D，再投影到 reference frame。

Eq. 10 给出 target pixel $\phi_t$ 到 reference frame 的对应像素 $\phi_{t\rightarrow t_{ref}}$。Eq. 11 定义 photometric consistency $L_{pc}$，比较 $I_t(\phi_t)$ 与 $I_{t_{ref}}(\phi_{t\rightarrow t_{ref}})$。

Eq. 12 使用 motion masks $M_t,M_{t_{ref}}$ 排除 dynamic regions。原文说 motion mask 的值为 dynamic 1 / static 0，但损失写成乘以 $M_{t,t_{ref}}$ 并称用于 static background；这里符号语义可能有反转或文字表述问题，需要 `NEED_HUMAN_CHECK`。

Eq. 13 定义 geometric consistency $L_{gc}$，比较两帧对应像素 unproject 后的 3D world locations。

### 4.6 两阶段优化

Warm-up stage: 只优化 camera parameters，loss Eq. 14: $L_{total}^{warm}=\lambda_{pc}L_{pc}+\lambda_{gc}L_{gc}$。

Main training stage: 用 warm-up 得到的 camera 初始化 dynamic Gaussian control points，然后联合优化 camera、static/dynamic Gaussians、MAS。Eq. 15:

$L_{total}^{main}=\lambda_{rgb}L_{rgb}+\lambda_dL_d+\lambda_ML_M+\lambda_{pc}L_{pc}+\lambda_{d-pc}L_{d-pc}+\lambda_{gc}L_{gc}$。

其中：

* $L_{rgb}$: rendered RGB vs GT frame；
* $L_d$: rendered depth vs metric depth；
* $L_M$: rendered dynamic mask vs precomputed motion mask，Eq. 16-17；
* $L_{pc}$: metric-depth-based photometric consistency；
* $L_{d-pc}$: rendered-depth-based photometric consistency；
* $L_{gc}$: geometric consistency。

## 5. 数学目标与损失

### 5.1 Spline trajectory objective

MAS 的主要优化来自 rendering loss 与 depth/mask/camera consistency，而不是直接 supervised trajectory loss。初始化时使用 CoTracker + UniDepth 的 least-square fit，训练后控制点由整体重建目标更新。

### 5.2 Camera objective

Camera estimation 依赖两个一致性：

* photometric: reprojected reference color 应匹配 target color；
* geometric: 两帧对应像素 unproject 到世界空间后应一致。

这两个损失只在 static background 区域可信，因此需要 motion mask 排除动态区域。

### 5.3 Mask objective

Eq. 16 使用 generalized Dice loss $L_M$ 约束 rendered motion mask $\hat{M}_t$ 与 precomputed motion mask $M_t$。Eq. 17 中 rendered mask 通过 alpha blending 聚合 Gaussian 的 static/dynamic label $m_i$，dynamic Gaussian $m_i=1$，static Gaussian $m_i=0$。

### 5.4 MACP objective

MACP 的准则不是直接保留控制点数最少，而是在 projection error 不超过阈值时递减控制点。它从渲染相关的 2D projection error 判断轨迹简化是否可接受，比单纯 3D trajectory error 更贴近图像质量。

## 6. 训练与推理流程

### 6.1 Warm-up

1. 输入单目视频、metric depth、motion masks、2D tracks。
2. 用 camera MLP 和 learnable focal length 表示 camera sequence。
3. 在 static background 上优化 $L_{pc}$ 和 $L_{gc}$。
4. 得到 coarse $\hat{K}$ 和 $\{[\hat{R}_t|\hat{T}_t]\}$。

### 6.2 Main training

1. 用估计 camera 和 2D tracks / metric depth 初始化 dynamic Gaussian control points。
2. 初始化 static/dynamic Gaussians。
3. 对每个 dynamic Gaussian，用 MAS 计算 $\mu(t)$。
4. 用 3DGS rasterizer 渲染 RGB、depth 和 motion mask。
5. 联合优化 $L_{total}^{main}$。
6. 在 densification 后执行 MACP，按 projection error 自适应减少控制点。

### 6.3 推理

推理时不需要 MLP deformation 或 grid lookup。给定时间 $t$：

* static Gaussians 直接渲染；
* dynamic Gaussians 用 spline evaluation 得到 $\mu(t)$；
* 其他 Gaussian 属性和 camera parameters 用优化结果；
* rasterizer 实时渲染。

论文报告在 NVIDIA dataset 上约 400 FPS。

## 7. 实验设置与结果

### 7.1 数据集

NVIDIA dataset:

* challenging monocular videos；
* 用于 novel view synthesis 和 novel view + time synthesis；
* 按 RoDynRF 设置评估。

DAVIS dataset:

* in-the-wild monocular videos；
* 平均 69.7 frames；
* COLMAP 通常无法提供合理 camera parameters。

### 7.2 Novel view synthesis

Table 1 在 NVIDIA dataset 上比较 SfM-based 和 SfM-free 方法。SplineGS 在 SfM-free setting 下平均 PSNR 27.21、LPIPS 0.053、FPS 400、training time 1.5 hours。相比：

* RoDynRF SfM-free: PSNR 25.38，LPIPS 0.079，FPS 0.45，train >24h；
* MoSca SfM-free: 26.61，0.069，FPS 40，train 1.0h；
* DynNeRF SfM-based: 26.53，0.068，FPS 0.8，train 0.5h；
* SplineGS with COLMAP poses: 26.90，0.060，FPS 400，train 0.5h。

论文强调 SplineGS 相比 RoDynRF 快 890 倍，相比 DynNeRF 快 8000 倍左右。

### 7.3 Novel view and time synthesis

Table 2 在更难 setting 中排除训练 odd frames 和测试 even frames，确保 test timestamps 未见过：

* DynNeRF: PSNR 23.36，LPIPS 0.219，tOF 0.921；
* 4DGS: 17.07，0.459，tOF 6.314；
* D3DGS: 19.63，0.343，tOF 3.225；
* STGS: 15.72，0.474，tOF 2.105；
* RoDynRF: 21.58，0.221，tOF 2.138；
* SplineGS: 25.92，0.098，tOF 0.703。

SplineGS 在 unseen intermediate times 上明显更稳，说明 MAS 连续轨迹比固定 polynomial / MLP / grid 更适合这个测试。

### 7.4 MAS 消融

Table 3(a) 比较 deformation model：

* MLP: PSNR 23.51，LPIPS 0.125，$g_{def}$ 149.41 ns；
* Grid: 25.48，0.090，98.89 ns；
* Poly 3rd: 25.14，0.111，1.80 ns；
* Poly 10th: 24.38，0.120，7.71 ns；
* Bézier: 27.19，0.060，8.78 ns；
* MAS: 27.21，0.053，5.63 ns。

MAS 的质量最高，速度仅慢于三次 polynomial，但显著快于 MLP/grid。

### 7.5 MACP 消融

Table 3(c):

* fixed $N_c=4$: PSNR 26.62，LPIPS 0.065，$g_{def}$ 5.34 ns；
* fixed $N_c=N_f$: 27.08，0.054，6.11 ns；
* MACP: 27.21，0.053，5.63 ns。

MACP 在质量和速度间取得更好平衡：简单运动不会保留过多控制点，复杂运动仍能保留足够表达力。

### 7.6 Loss 消融

Table 3(b):

* w/o $L_{pc}$: PSNR 17.49，LPIPS 0.853；
* w/o $L_{gc}$: 26.33，0.067；
* w/o $L_{d-pc}$: 26.18，0.066；
* w/o $L_M$: 26.34，0.088；
* full: 27.21，0.053。

$L_{pc}$ 对 camera estimation 最关键；去掉它相机无法一致收敛，质量崩溃。

## 8. 声称贡献 vs 实际技术增量

### 8.1 论文声称

SplineGS 声称：

* COLMAP-free；
* high quality；
* very fast rendering；
* MAS 可以连续表示 dynamic Gaussian trajectories；
* MACP 可以按 motion complexity 调整控制点数量。

### 8.2 实际技术增量

实际技术增量是把 dynamic Gaussian trajectory 从固定多项式或 neural deformation 改为 per-Gaussian adaptive Hermite spline。SplineGS 同时解决了单目设置下相机参数不可靠的问题，因此不仅是 deformation module 替换，也是一套 COLMAP-free dynamic GS pipeline。

与 STGS / Ex4DGS 的区别：

* STGS 使用 fixed-degree polynomial trajectory，SplineGS 用 piecewise cubic Hermite spline；
* Ex4DGS 用 keyframe interpolation 但依赖多视角 / 点云条件，SplineGS 面向 COLMAP-free monocular；
* SplineGS 的 $N_c$ per Gaussian 自适应，而不是全局固定。

### 8.3 证据强度

证据强：

* NVIDIA NVS 主表覆盖大量 baseline；
* novel view and time synthesis explicitly tests unseen timestamps；
* MAS / MACP / loss 全部有消融；
* latency per Gaussian $g_{def}$ 支持实时性分析；
* DAVIS qualitative 展示 COLMAP-free 价值。

证据弱或需复核：

* Implementation details 主要在 supplementary；
* 依赖 UniDepth、CoTracker、Track Anything motion mask 等预训练模块，不是完全无外部先验；
* motion mask 符号和 static/dynamic 区域说明在正文中可能有歧义；
* DAVIS 主要定性，缺少完整定量。

## 9. 局限与隐藏假设

* 依赖 metric depth prior、2D tracking 和 motion mask；虽然不需要 COLMAP，但仍需要多个强预训练视觉模块。
* 相机估计主要依赖 static background；如果视频中静态背景少或被长期遮挡，camera optimization 可能不稳。
* Spline trajectory 主要控制 Gaussian mean，其他 dynamic attributes 的时间变化没有同等复杂建模。
* MACP 阈值 $\epsilon$ 的选择会影响速度/质量平衡。
* Dynamic/static Gaussian 分离依赖 motion masks 和 rendered mask loss，mask 错误会传递到重建。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法名称 | SplineGS |
| 输入类型 | in-the-wild monocular video |
| 是否 COLMAP-free | 是 |
| 核心动态表示 | per-Gaussian cubic Hermite spline |
| 控制点 | learnable $P=\{p_k\}$ |
| 控制点数量 | per-Gaussian adaptive via MACP |
| 初始化先验 | CoTracker 2D tracks; UniDepth metric depth; motion masks |
| Camera | shallow MLP for extrinsics; learnable focal length |
| 训练阶段 | warm-up camera; main joint optimization |
| 主要损失 | $L_{rgb},L_d,L_M,L_{pc},L_{d-pc},L_{gc}$ |
| 主数据集 | NVIDIA; DAVIS |
| 主优势 | unseen time synthesis、400 FPS、COLMAP-free |
| 主短板 | 依赖多种预训练 priors，implementation details 在 supplement |

## 11. 对我的研究可复用组件

1. MAS spline trajectory：可作为 dynamic GS 中“spline trajectory”类别，与 Ex4DGS / SplineGS 2024 / STGS 对比。
2. MACP：per-Gaussian trajectory complexity adaptation，适合做压缩或速度/质量 trade-off。
3. COLMAP-free camera optimization：单目 dynamic GS 中非常关键，可独立复用。
4. Novel view + time evaluation split：排除训练 odd/test even，是检验 continuous trajectory 的好协议。
5. $g_{def}$ latency metric：比较 deformation module 的单 Gaussian 计算成本。

## 12. Gap and Idea Seeds

### 12.1 Gap: 外部 prior 依赖

SplineGS 不需要 COLMAP，但需要 depth、tracking、motion mask。可研究减少这些依赖，例如用 self-supervised tracking / mask refinement 与 Gaussian optimization 联合训练。

### 12.2 Gap: 只对 mean 用 spline

动态物体的 rotation、scale、opacity、appearance 也可能连续变化。可以扩展 MAS 到 $q(t),s(t),\sigma(t),c(t)$，但需控制过拟合。

### 12.3 Gap: MACP 阈值固定

$\epsilon$ 可能应随投影尺度、深度、motion magnitude 自适应。可设计 uncertainty-aware MACP。

### 12.4 Gap: Camera 与 dynamic separation 耦合

Camera estimation 依赖静态 mask；mask 错会影响 pose，pose 错又影响 mask。可加入 bundle-adjustment-style alternating schedule 或 confidence weighting。

### 12.5 Gap: 从单视频到多视频泛化

当前是 per-scene optimization。可研究可初始化的 spline control point prior，用于加速新视频训练。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: Supplementary 中的实现细节、loss 权重、训练轮数、MACP 阈值 $\epsilon$。
* `NEED_HUMAN_CHECK`: Motion mask $M_t$ 的 0/1 语义与 Eq. 11-13 中 static background weighting 是否在正文有符号歧义。
* `NEED_HUMAN_CHECK`: Eq. 8 接受剪枝时的 projection error 单位和阈值设置。
* `NEED_HUMAN_CHECK`: Dynamic 3D Gaussian 除 mean 外其他属性是否随时间变化，需看代码。
* `NEED_HUMAN_CHECK`: Project page 是否含 GitHub code；PDF 文本未抽出 repository URL。
* `NEED_HUMAN_CHECK`: DAVIS 定性实验中用 SplineGS camera parameters 训练其他方法的具体协议。

## 14. Evidence Anchors

* Abstract: COLMAP-free dynamic 3DGS, MAS, MACP, joint camera/GS optimization, fast rendering。
* Figure 1: DAVIS COLMAP failure and NVIDIA 400 FPS claim。
* Section 1 Introduction: MLP/grid/polynomial limitations and COLMAP dependency motivation。
* Section 3 / Eq. 1-2: 3DGS preliminaries and static/dynamic Gaussian union。
* Section 4.1 / Figure 2: two-stage optimization and full pipeline。
* Section 4.2 / Eq. 3-4: MAS cubic Hermite spline trajectory。
* Section 4.2 / Eq. 5-6: 2D track + depth unprojection and LS control point initialization。
* Section 4.2 / Eq. 7-8: MACP one-control-point pruning and projection error criterion。
* Section 4.3 / Eq. 9-13: camera MLP, photometric and geometric consistency。
* Section 4.4 / Eq. 14-17: warm-up loss, main loss, rendered mask。
* Table 1: NVIDIA novel view synthesis, SplineGS SfM-free PSNR 27.21 / LPIPS 0.053 / 400 FPS。
* Table 2: novel view and time synthesis, SplineGS PSNR 25.92 / LPIPS 0.098 / tOF 0.703。
* Figure 6: 2D motion tracking comparison with D3DGS and STGS。
* Table 3(a): deformation model ablation and $g_{def}$ latency。
* Table 3(b): loss function ablation, w/o $L_{pc}$ collapse。
* Table 3(c), Figure 7-8: MACP effectiveness and per-scene control point distributions。
