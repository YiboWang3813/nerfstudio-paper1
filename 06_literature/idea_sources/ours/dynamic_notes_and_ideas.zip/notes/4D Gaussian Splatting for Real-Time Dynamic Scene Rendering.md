# 4D Gaussian Splatting for Real-Time Dynamic Scene Rendering

## 0. Metadata

* Title: 4D Gaussian Splatting for Real-Time Dynamic Scene Rendering
* Authors: Guanjun Wu; Taoran Yi; Jiemin Fang; Lingxi Xie; Xiaopeng Zhang; Wei Wei; Wenyu Liu; Qi Tian; Xinggang Wang
* Year: 2024
* Venue: CVPR 2024
* PDF source: `/Users/wangyibo/Zotero/storage/ZH3L2R9U/Wu 等 - 2024 - 4D Gaussian Splatting for Real-Time Dynamic Scene Rendering.pdf`
* Zotero item key: PH49JNKV
* Zotero PDF attachment key: ZH3L2R9U
* Code: project page reports demos and code, `https://guanjunwu.github.io/4dgs/`
* Project page: `https://guanjunwu.github.io/4dgs/`
* Dataset link: Not specified
* Main task: dynamic novel view synthesis / real-time dynamic scene rendering
* Domain: 3D vision, neural rendering, Gaussian Splatting
* Input: posed images / video frames of a dynamic scene, camera view matrix, timestamp
* Output: novel-view image at a target viewpoint and timestamp
* Main representation: canonical 3D Gaussians plus 4D neural voxel / decomposed HexPlane-style spatial-temporal encoder
* Supervision type: image reconstruction supervision from target rendered images
* Core contribution in one sentence: 用一个紧凑的 Gaussian deformation field 将一组 canonical 3D Gaussians 按时间变形为动态 3D Gaussians，从而在动态场景中同时获得较快训练、较低存储和实时渲染。
* Note status: `partial`

`partial` 的原因：正文提到更多 hyperparameters 在 appendix 中，但当前 PDF 只有正文和 references，未包含 appendix；相关超参数需要人工检查项目代码或补充材料。

## 1. One-Sentence Technical Summary

这篇论文处理动态场景 novel view synthesis，通过一组 canonical 3D Gaussians 加上由 decomposed 4D neural voxel / HexPlane 编码驱动的 Gaussian deformation field，把输入视角和时间戳对应的动态场景渲染为目标图像，关键技术增量是用空间-时间结构编码器连接相邻 Gaussian，并用轻量多头 MLP 同时预测位置、旋转和尺度变形，而不是为每个时间帧显式存一套 Gaussian。

Evidence: Abstract, PDF p.1 / paper p.20310; Method, PDF p.4 / paper p.20313.

## 2. Problem Formulation

### 2.1 Task Definition

* 任务：给定动态场景的稀疏时空观测，在任意目标视角和时间戳合成图像。
* 输入：view matrix $M=[R,T]$、timestamp $t$、待变形的 3D Gaussians $G$，以及训练时的目标图像 $I$。
* 输出：渲染图像 $\hat{I}$，以及中间表示 deformed 3D Gaussians $G'$。
* 假设：训练数据具备相机位姿；动态场景可由 canonical Gaussian 集合加时间相关变形近似；相邻 Gaussians 共享一定空间和时间结构。
* 优化目标：最小化渲染图像和真实图像之间的颜色重建误差，并加入 grid-based total variation regularization。

Evidence: Sec. 4.1, PDF p.4 / paper p.20313; Sec. 4.3, PDF p.5 / paper p.20314.

### 2.2 Formal Notation

| Symbol | Meaning | Evidence |
| ------ | ------- | -------- |
| $G$ | canonical / original 3D Gaussians | Fig. 2, Fig. 3, Sec. 4.1 |
| $G'$ | timestamp $t$ 下变形后的 3D Gaussians | Fig. 2, Fig. 3, Sec. 4.1 |
| $F$ | Gaussian deformation field network | Sec. 4.1 |
| $H$ | spatial-temporal structure encoder | Sec. 4.1, Sec. 4.2 |
| $D$ | multi-head Gaussian deformation decoder | Sec. 4.2 |
| $M=[R,T]$ | view matrix | Sec. 4.1 |
| $X$ / $\mu=(x,y,z)$ | 3D Gaussian center / mean position | Sec. 3.1, Sec. 4.2 |
| $r, s, C, \alpha$ | rotation, scaling, SH color coefficients, opacity | Sec. 3.1 |
| $\Delta X, \Delta r, \Delta s$ | predicted position, rotation, scaling deformation | Sec. 4.2 |
| $R_l(i,j)$ | multi-resolution 2D voxel plane module | Sec. 4.2 |
| $f_h, f_d$ | queried plane feature and merged deformation feature | Eq. 7, Sec. 4.2 |

### 2.3 Why This Problem Is Hard

| Claimed difficulty | Technical reason | Evidence |
| ------------------ | ---------------- | -------- |
| 动态场景需要建模复杂运动 | sparse spatial-temporal input 下点运动难以准确估计 | Introduction, PDF p.2 / paper p.20311 |
| 直接按时间帧维护 3D Gaussians 存储开销大 | Dynamic3DGS 类方法显式存每个 timestamp 的 Gaussian 信息，复杂度接近 $O(tN)$ | Sec. 2.2, PDF p.3 / paper p.20312 |
| 动态 NeRF / voxel 方法难以实时渲染 | 即使训练加速，volume rendering 或 sampled-point 处理仍限制 FPS | Sec. 2.1, PDF p.2 / paper p.20311 |
| monocular / sparse input 下动态与静态部分难分 | 没有额外监督时 static/dynamic Gaussian 的 joint motion 分离困难 | Sec. 5.5, PDF p.8 / paper p.20317 |

## 3. Method Overview

### 3.1 High-Level Pipeline

Step 1:
Input: dynamic scene training frames, camera poses, timestamp.
Operation: 初始化一组 3D Gaussians，优先利用 SfM points；若没有合适初始化，训练更不稳定。
Output: canonical 3D Gaussian set $G$。
Purpose: 给 4D deformation field 一个可优化的静态几何基础。
Evidence: Sec. 4.3, Fig. 4, PDF p.5 / paper p.20314.

Step 2:
Input: Gaussian center $X=(x,y,z)$ and timestamp $t$。
Operation: 查询 6 个空间-时间 2D planes，包括 $(x,y),(x,z),(y,z),(x,t),(y,t),(z,t)$，并在多分辨率层级上进行 bilinear interpolation。
Output: plane feature $f_h$。
Purpose: 用 decomposed 4D neural voxel 低成本编码邻近 Gaussian 的空间和时间结构。
Evidence: Sec. 4.2, Eq. 7, PDF p.4-5 / paper p.20313-20314.

Step 3:
Input: plane feature $f_h$。
Operation: tiny MLP $\phi_d$ 合并 plane features。
Output: deformation feature $f_d$。
Purpose: 将多平面查询结果转为供 deformation decoder 使用的紧凑特征。
Evidence: Sec. 4.2, PDF p.5 / paper p.20314.

Step 4:
Input: deformation feature $f_d$。
Operation: multi-head decoder $D=\{\phi_x,\phi_r,\phi_s\}$ 分别预测 $\Delta X$、$\Delta r$、$\Delta s$。
Output: deformed Gaussian parameters $X'=X+\Delta X$、$r'=r+\Delta r$、$s'=s+\Delta s$。
Purpose: 同时建模 Gaussian motion 和 Gaussian shape changes。
Evidence: Sec. 4.2, Eq. 8, PDF p.5 / paper p.20314.

Step 5:
Input: deformed Gaussians $G'$ and view matrix $M$。
Operation: 使用 differential splatting 渲染。
Output: rendered image $\hat{I}=S(M,G')$。
Purpose: 保留 3D-GS 的实时 rasterization 优势。
Evidence: Sec. 4.1, Fig. 2, PDF p.4 / paper p.20313.

### 3.2 Core Idea

* Representation-level idea: 不为每个时间帧存一套 Gaussian，而是维护一组 canonical 3D Gaussians，加一个时间条件 deformation field。
* Architecture-level idea: 用 HexPlane / K-Planes 风格的 6 个 2D plane 分解 4D neural voxel，降低 4D voxel 的内存开销。
* Optimization-level idea: 先 warm-up 优化 3D Gaussians 3000 iterations，再联合优化 4D Gaussian deformation。
* Training-level idea: 用 L1 image reconstruction loss 加 grid-based TV regularization。
* Inference-level idea: 给定 timestamp 后直接把 canonical Gaussians 变形，再走 3D-GS splatting pipeline。

Evidence: Sec. 4.1-4.3, PDF p.4-5 / paper p.20313-20314.

### 3.3 Method Diagram Reconstruction

Figure 3 shows:
* input: 3D Gaussians $G$ 的中心坐标 $x,y,z$ 和 timestamp $t$。
* branch/module 1: spatial-temporal structure encoder 查询 $(x,t),(y,t),(z,t),(x,y),(y,z),(x,z)$ planes。
* branch/module 2: MLP 合并 plane features。
* decoder: position head $\phi_x$、rotation head $\phi_r$、scaling head $\phi_s$。
* output: deformed 3D Gaussians $G'$。
* loss/supervision: 图像重建损失和 TV loss 在渲染结果上监督。

Evidence: Fig. 3, PDF p.3 / paper p.20312; Sec. 4.2, PDF p.4-5 / paper p.20313-20314.

## 4. Method Details

### 4.1 Canonical 3D Gaussians

* Module purpose: 提供一个显式 3D 点状场景表示，供 deformation field 在不同时间戳下变形。
* Input: SfM points 或 random point cloud initialization；训练图像和相机。
* Output: 每个 Gaussian 的 $X,C,\alpha,r,s$ 等属性。
* Internal operations: 基于 3D-GS 的 covariance 分解和 differentiable splatting。
* Architecture details: 每个 Gaussian 包含 position、SH color coefficients、opacity、rotation、scaling。
* Mathematical formulation: 3D Gaussian 和 covariance 见 Eq. 1-3；alpha blending 见 Eq. 4。
* Trainable parameters: Gaussian center、color / SH、opacity、rotation、scaling。
* Hyperparameters: Not specified in current PDF.
* Why this module is needed: 继承 3D-GS 的实时 splatting 和显式可编辑性。
* What would happen without it: 方法退化为 NeRF/voxel 类 representation，难以保留 3D-GS 的实时渲染优势。
* Evidence anchor: Sec. 3.1, PDF p.3-4 / paper p.20312-20313.

Implementation-level reconstruction:
* 维护 Gaussian parameter tensors: position shape inferred as $N \times 3$，rotation $N \times 4$，scaling $N \times 3$，opacity $N \times 1$，SH coefficients $N \times k$。
* 每次训练采样相机和 timestamp，先生成对应时间的 $G'$，再调用 3D-GS rasterizer。
* tensor shape 除 Gaussian 属性维度外，具体 batch size、SH degree、optimizer details 当前 PDF 未给出。

Relation to prior work:
* 主要继承 3D-GS，技术改动在于不直接把 static Gaussians 用于所有帧，而是加时间条件 deformation。

### 4.2 Spatial-Temporal Structure Encoder

* Module purpose: 从 Gaussian center 和 timestamp 生成 deformation feature，连接相邻 Gaussians 的空间和时间信息。
* Input: $\mu=(x,y,z)$ and $t$。
* Output: deformation feature $f_d$。
* Internal operations: 查询 6 个 2D plane modules，多分辨率 bilinear interpolation，随后由 tiny MLP $\phi_d$ 合并。
* Architecture details: $H(G,t)=\{R_l(i,j),\phi_d | (i,j) \in \{(x,y),(x,z),(y,z),(x,t),(y,t),(z,t)\}, l \in \{1,2\}\}$。
* Mathematical formulation: Eq. 7。
* Trainable parameters: plane feature grids $R_l(i,j)$ and MLP $\phi_d$。
* Hyperparameters: hidden dim $h$、basic resolution $N$、upsampling scale $l$ 的概念给出，但具体数值 Not specified。
* Why this module is needed: 比 per-frame explicit Gaussian table 更省存储，同时比单个 shallow MLP 更能建模复杂形变。
* What would happen without it: w/o HexPlane 的 ablation PSNR 从 34.05 降到 27.05，说明复杂 deformation 建模不足。
* Evidence anchor: Sec. 4.2, Eq. 7, Tab. 4, PDF p.4-7 / paper p.20313-20317.

Implementation-level reconstruction:
* 对每个 Gaussian 的 normalized coordinate 和 timestamp 构造 6 个 plane query。
* 每个 plane 用 bilinear interpolation 从四个 grid vertices 取特征。
* 多分辨率特征合并方式正文公式排版不完全清晰，按 K-Planes / HexPlane 类方法可推断为跨 plane / level 的 feature composition，再输入 $\phi_d$；具体 production / aggregation details 需要查 [11] 或代码，标为 NEED_HUMAN_CHECK。

Relation to prior work:
* 明确受 HexPlane、K-Planes、TiNeuVox、Tensor4D 等 decomposed neural voxel 方法启发，但目标对象从 sampled points 改为 3D Gaussian centers。

### 4.3 Multi-Head Gaussian Deformation Decoder

* Module purpose: 将 encoder feature 解码为 Gaussian 参数变形。
* Input: $f_d$。
* Output: $\Delta X$、$\Delta r$、$\Delta s$。
* Internal operations: 三个 separate MLP heads，分别处理位置、旋转和尺度。
* Architecture details: $D=\{\phi_x,\phi_r,\phi_s\}$。
* Mathematical formulation: Eq. 8。
* Trainable parameters: three MLP heads。
* Hyperparameters: layer count, width, activation Not specified。
* Why this module is needed: 动态场景不仅需要点位置移动，也需要 Gaussian covariance / shape 随运动拉伸和扭转。
* What would happen without it: w/o $\phi_x$ PSNR 下降到 26.67；w/o $\phi_r$ 和 w/o $\phi_s$ 也有质量下降，说明位置最关键，旋转和尺度是辅助但有用。
* Evidence anchor: Sec. 4.2, Sec. 5.3, Tab. 4, PDF p.5-7 / paper p.20314-20317.

Implementation-level reconstruction:
* Position head 输出 $N \times 3$。
* Rotation head 输出 $N \times 4$，但正文没有说明 quaternion normalization 或 rotation parameterization 的后处理，NEED_HUMAN_CHECK。
* Scaling head 输出 $N \times 3$，正文没有说明是否在 log-scale 空间更新，NEED_HUMAN_CHECK。
* Deformed attributes为 $G'=\{X',s',r',\sigma,C\}$；颜色和 opacity 在 Eq. 8 后的描述中没有被 deformation decoder 改写。

Relation to prior work:
* 属于对 3D-GS 的动态扩展，和 Dynamic3DGS 的 per-timestamp explicit tracking 不同；也不同于 4D temporal Gaussian 分布只关注局部时间空间。

### 4.4 3D Gaussian Initialization and Warm-Up

* Module purpose: 稳定 4D-GS 的早期优化，让 Gaussian 先形成合理静态几何。
* Input: initial point cloud / SfM points。
* Output: warm-up 后的 3D Gaussians。
* Internal operations: 前 3000 iterations 只用 $\hat{I}=S(M,G)$ 训练 3D Gaussians，不使用 $G'$。
* Architecture details: training schedule rather than network module。
* Mathematical formulation: warm-up rendering $\hat{I}=S(M,G)$，joint stage rendering $\hat{I}=S(M,G')$。
* Trainable parameters: warm-up 阶段主要是 Gaussian parameters。
* Hyperparameters: warm-up 3000 iterations；总训练 iteration 从 Fig. 4 可见到 20000，但完整 schedule Not specified。
* Why this module is needed: 减小大 deformation 学习压力，让 deformation field 更关注动态部分，并避免数值错误。
* What would happen without it: w/o initialization 的 PSNR 从 34.05 降到 31.91。
* Evidence anchor: Sec. 4.3, Fig. 4, Sec. 5.3, Tab. 4, PDF p.5-7 / paper p.20314-20317.

## 5. Mathematical Objectives and Losses

| Loss / objective | Formula | Used for | Inputs | Weight | Evidence |
| ---------------- | ------- | -------- | ------ | ------ | -------- |
| 3D Gaussian density | $G(X)=e^{-\frac{1}{2}X^T\Sigma^{-1}X}$ | 定义 Gaussian primitive | center / covariance | Not specified | Eq. 1, Sec. 3.1 |
| Covariance decomposition | $\Sigma=RSS^TR^T$ | 可微优化 covariance | rotation $R$, scaling $S$ | Not specified | Eq. 2, Sec. 3.1 |
| Camera-space covariance | $\Sigma'=JW\Sigma W^TJ^T$ | splatting projection | view transform $W$, Jacobian $J$ | Not specified | Eq. 3, Sec. 3.1 |
| Alpha blending | $C=\sum_{i \in N} c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_i)$ | pixel color rendering | ordered overlapping Gaussians | Not specified | Eq. 4, Sec. 3.1 |
| Dynamic NeRF formulation baseline | $c,\sigma=M(x,d,t,\lambda)$ | 对比动态 NeRF mapping | position, direction, time, latent code | Not specified | Eq. 5, Sec. 3.2 |
| Deformation NeRF baseline | $c,\sigma=NeRF(x+\Delta x,d,\lambda)$ | 对比 world-to-canonical deformation | deformed point, direction, code | Not specified | Eq. 6, Sec. 3.2 |
| Plane feature query | $f_h=[\prod_l interp(R_l(i,j))], (i,j)\in\{(x,y),(x,z),(y,z),(x,t),(y,t),(z,t)\}$ | spatial-temporal feature encoding | coordinate and timestamp | Not specified | Eq. 7, Sec. 4.2 |
| Gaussian deformation | $(X',r',s')=(X+\Delta X,r+\Delta r,s+\Delta s)$ | produce deformed Gaussians | decoder outputs | Not specified | Eq. 8, Sec. 4.2 |
| Training loss | $L=|\hat{I}-I|+L_{tv}$ | supervise image reconstruction and grid regularity | rendered image, GT image, grid | TV weight Not specified | Eq. 9, Sec. 4.3 |

注：alpha blending 的乘积项在正文 Eq. 4 中是 $\prod_{j=1}^{i-1}(1-\alpha_i)$，按常见 3D-GS / volume compositing 通常应为 previous samples 的 opacity；这里保留论文抽取公式，不自行更正。

For each loss:
* L1 color loss 鼓励渲染图像匹配目标图像，是主监督。
* $L_{tv}$ 鼓励 grid / voxel plane 的平滑或正则性，是辅助正则。
* 是否有 loss-specific ablation: 当前正文没有单独消融 $L_{tv}$，Not specified。

## 6. Training and Inference Procedure

### 6.1 Training Pipeline

| Item | Value | Evidence |
| ---- | ----- | -------- |
| Dataset | D-NeRF synthetic, HyperNeRF / Nerfies, Neu3D | Sec. 5.1 |
| Data split | Not specified | Sec. 5.1 |
| Input resolution | synthetic 800x800; HyperNeRF 960x540; Neu3D 1352x1014 | Tab. 1-3 |
| Preprocessing | Neu3D 使用 first frame 的 SfM points；HyperNeRF 随机选择 200 frames | Sec. 5.1 |
| Data augmentation | Not specified | Sec. 5.1 |
| Batch size | Not specified | Sec. 5.1 |
| Optimizer | fine-tuned from 3D-GS config, exact optimizer Not specified | Sec. 5.1 |
| Learning rate | Not specified | Sec. 5.1 |
| LR schedule | Not specified | Sec. 5.1 |
| Epochs / iterations | warm-up 3000 iterations; Fig. 4 shows 20000 iterations endpoint | Sec. 4.3, Fig. 4 |
| Loss weights | TV weight Not specified | Eq. 9 |
| Initialization | SfM points where available; static 3D Gaussian warm-up | Sec. 4.3, Sec. 5.1 |
| Hardware | single RTX 3090 GPU | Sec. 5.1 |
| Training time | synthetic 8 mins; HyperNeRF 30 mins; Neu3D 40 mins | Tab. 1-3 |
| Code availability | project page reports demos and code | Abstract |

### 6.2 Inference Pipeline

| Item | Value | Evidence |
| ---- | ----- | -------- |
| Inference input | canonical Gaussians $G$, target timestamp $t$, view matrix $M$ | Sec. 4.1 |
| Inference output | rendered image $\hat{I}$ and deformed Gaussians $G'$ | Sec. 4.1 |
| Test-time optimization | Not specified; inference described as direct deformation plus splatting | Sec. 4.1 |
| Runtime | 82 FPS at 800x800 synthetic; 34 FPS at 960x540 HyperNeRF; 30 FPS at 1352x1014 Neu3D | Tab. 1-3 |
| Memory / storage | 18 MB synthetic; 61 MB HyperNeRF; 90 MB Neu3D | Tab. 1-3 |
| Postprocessing | Not specified | Sec. 4-5 |
| Failure cases | large motions, missing background points, inaccurate camera pose, static/dynamic joint motion separation | Sec. 5.5 |

### 6.3 Reproduction Checklist

Clearly specified:
* Representation: canonical 3D Gaussians plus deformation field.
* Encoder planes: $(x,y),(x,z),(y,z),(x,t),(y,t),(z,t)$ with multi-resolution levels $l \in \{1,2\}$。
* Decoder heads: position, rotation, scaling。
* Warm-up: first 3000 iterations optimize static 3D Gaussians。
* Loss: L1 color loss plus grid-based TV loss。
* Main datasets and headline evaluation metrics。

Not specified but inferable:
* Gaussian tensor shapes for position / rotation / scaling follow 3D-GS conventions。
* Rendering backend likely follows 3D-GS differential splatting。
* Feature querying likely follows K-Planes / HexPlane style interpolation。

Missing / need human check:
* Full hyperparameter table referenced as appendix but absent in current PDF。
* Exact plane resolutions, hidden dimension $h$, MLP widths/depths, activation functions。
* Optimizer, learning rates, densification schedule, pruning thresholds。
* Rotation update normalization and scale update parameterization。
* Dataset splits and exact per-scene settings。

## 7. Experimental Setup and Results Summary

### 7.1 Datasets

| Dataset | Role | Size | Split | Modality | Preprocessing | Evidence |
| ------- | ---- | ---- | ----- | -------- | ------------- | -------- |
| D-NeRF synthetic | synthetic monocular benchmark | each scene 50-200 dynamic frames | Not specified | synthetic dynamic scenes | camera poses close to randomly generated | Sec. 5.1 |
| HyperNeRF / Nerfies vrig | real-world benchmark | Not specified | Not specified | one or two camera capture | 200 frames randomly selected for HyperNeRF | Sec. 5.1, Tab. 2 |
| Neu3D | real-world multi-view benchmark | 15-20 static cameras | Not specified | multi-view dynamic video | SfM points from first video frame | Sec. 5.1, Tab. 3 |

### 7.2 Baselines

| Baseline | Category | Why compared | Fairness concern | Evidence |
| -------- | -------- | ------------ | ---------------- | -------- |
| 3D-GS | static explicit Gaussian splatting | shows static Gaussian failure on dynamic scenes and FPS/storage reference | static method not designed for dynamic scenes | Tab. 1-3 |
| TiNeuVox-B | dynamic voxel / NeRF | fast dynamic radiance field baseline | slower rendering than splatting | Tab. 1-2 |
| K-Planes / HexPlane | decomposed 4D feature field | closest representation inspiration | sampled point rendering differs from Gaussian deformation | Tab. 1, Tab. 3 |
| V4D | voxel for 4D NVS | high-quality dynamic representation | much slower training / rendering | Tab. 1-2 |
| FFDNeRF / MSTH / NeRFPlayer / HyperReel / Im4D | dynamic NVS methods | broad SOTA comparison | some methods assume multi-view or fixed-view settings | Sec. 5.2, Tab. 1-3 |

### 7.3 Metrics

| Metric | Measures what | Used in which experiment | Higher/lower better | Evidence |
| ------ | ------------- | ------------------------ | ------------------- | -------- |
| PSNR | reconstruction fidelity | all main quantitative tables | higher better | Tab. 1-3 |
| SSIM / MS-SSIM / D-SSIM | structural similarity / dissimilarity | synthetic, HyperNeRF, Neu3D | SSIM higher; D-SSIM lower | Tab. 1-3 |
| LPIPS | perceptual error | synthetic, Neu3D | lower better | Tab. 1, Tab. 3 |
| FPS | rendering speed | all main tables | higher better | Tab. 1-3 |
| Time | training time | all main tables | lower better | Tab. 1-3 |
| Storage | model storage | all main tables | lower better | Tab. 1-3 |

### 7.4 Results as Evidence Units

| Experiment | Purpose | Compared methods | Metrics | Main conclusion | Evidence strength | Evidence |
| ---------- | ------- | ---------------- | ------- | --------------- | ----------------- | -------- |
| Synthetic D-NeRF | 验证 monocular synthetic dynamic scenes 上的质量、速度、存储 | TiNeuVox-B, KPlanes, HexPlane-Slim, 3D-GS, FFDNeRF, MSTH, V4D | PSNR, SSIM, LPIPS, Time, FPS, Storage | 4D-GS 达到 34.05 PSNR、82 FPS、18 MB，在质量和实时性之间最均衡 | strong | Tab. 1 |
| HyperNeRF vrig | 验证 real-world one/two-camera dynamic scenes | Nerfies, HyperNeRF, TiNeuVox-B, 3D-GS, FFDNeRF, V4D | PSNR, MS-SSIM, Time, FPS, Storage | 4D-GS 达到最高 PSNR / MS-SSIM，并保持 34 FPS | strong | Tab. 2 |
| Neu3D | 验证 multi-view high-resolution dynamic scenes | NeRFPlayer, HyperReel, HexPlane, KPlanes, Im4D, MSTH | PSNR, D-SSIM, LPIPS, Time, FPS, Storage | 4D-GS 不是最高 PSNR，但 LPIPS 最低且 30 FPS，速度明显优于多数方法 | medium | Tab. 3 |
| Encoder ablation | 验证 HexPlane-style encoder 的必要性 | w/o HexPlane vs full | PSNR, SSIM, LPIPS, Time, FPS, Storage | 去掉 encoder 后 PSNR 从 34.05 降到 27.05，说明只靠 shallow MLP 不足以建模复杂变形 | strong | Tab. 4 |
| Decoder head ablation | 验证 position / rotation / scaling deformation | w/o $\phi_x$, w/o $\phi_r$, w/o $\phi_s$ | same | 位置变形最关键；旋转和尺度变形也提升质量 | strong | Tab. 4 |
| Warm-up ablation | 验证 3D Gaussian initialization | w/o initialization vs full | same | 无 warm-up 时 PSNR 下降，训练质量受损 | medium | Tab. 4 |

## 8. Claimed Contribution vs Actual Technical Delta

| Claimed contribution | Actual technical change | Evidence | Is it novel? | Is it important? | Is it well supported? |
| -------------------- | ----------------------- | -------- | ------------ | ---------------- | --------------------- |
| efficient 4D Gaussian splatting framework | 一组 canonical 3D Gaussians 加 timestamp-conditioned deformation field | Introduction, Sec. 4.1 | medium: 3D-GS 动态扩展方向已有，但该组合明确有效 | high | yes |
| multi-resolution encoding connects nearby 3D Gaussians | 将 K-Planes / HexPlane 式 6-plane decomposition 用于 Gaussian center 的 deformation feature | Sec. 4.2, Eq. 7 | medium | high | yes, Tab. 4 支持 |
| real-time dynamic rendering with good quality | 通过 deformation field 加 splatting 达到 82 FPS synthetic、30 FPS Neu3D | Tab. 1-3 | medium | high | yes, 但依赖硬件和 scene complexity |
| tracking and editing potential | 显式 Gaussians 轨迹和 composition 可视化 | Sec. 5.4, Fig. 7-8 | low-to-medium | medium | weak: 主要是 qualitative demonstration |

技术增量的实际边界：核心不是提出全新的 splatting renderer，而是把 3D-GS 的 explicit primitive 与轻量 4D deformation encoding 结合，避免 per-frame Gaussian table 的存储增长，同时保持 splatting 的实时性。

## 9. Limitations and Hidden Assumptions

### 9.1 Explicit Limitations

| Limitation | Evidence | Impact |
| ---------- | -------- | ------ |
| large motions 会导致优化困难 | Sec. 5.5 | 大幅非刚性运动或快速运动场景可能失败 |
| 缺少 background points 会影响优化 | Sec. 5.5 | 背景建模不足会影响 novel view quality |
| inaccurate camera pose 会导致 struggle | Sec. 5.5 | 位姿噪声下鲁棒性有限 |
| monocular setting 下 static/dynamic joint motion 难以分离 | Sec. 5.5 | 动静态解耦需要额外监督或先验 |
| urban-scale reconstruction 仍需更紧凑算法 | Sec. 5.5 | 大量 Gaussians 查询 deformation field 会带来开销 |

### 9.2 Inferred Limitations

| Inferred limitation | Why it may exist | Missing experiment | Possible consequence |
| ------------------- | ---------------- | ------------------ | -------------------- |
| 对相机位姿质量敏感 | 方法依赖 posed frames，正文直接提到 inaccurate pose | pose noise ablation | 实际手持视频可能质量下降 |
| 对 deformation field capacity 有速度-质量 tradeoff | Fig. 9 讨论 points / FPS，正文提到 deformation field scale 影响速度 | encoder/MLP capacity sweep | 场景复杂时 FPS 下降或欠拟合 |
| 颜色 / opacity 不随时间显式变形 | Eq. 8 只更新 position, rotation, scaling | dynamic appearance ablation | 拓扑变化、光照变化或非 Lambertian 外观可能受限 |
| appendix 缺失影响复现 | 正文说 hyperparameters in appendix，但当前 PDF 不含 appendix | full config table | 难以无代码复现 |

### 9.3 Hidden Assumptions

| Assumption | Where it appears | Risk if violated |
| ---------- | ---------------- | ---------------- |
| Gaussian motion 可由相邻空间-时间 plane feature 推断 | Sec. 4.2 | 离散、遮挡严重或非局部运动可能建模不足 |
| canonical Gaussians 足以覆盖动态物体所有时刻 | Sec. 4.1, Sec. 4.3 | 大形变或新出现区域会缺 primitive |
| SfM / initialization 提供合理几何起点 | Sec. 4.3, Sec. 5.1 | 初始化差会导致 convergence difficulty |
| 训练和测试视角/时间分布相近 | experiment setup | 时间外推或视角外推能力不明 |

## 10. Matrix-Ready Summary

| Field | Value |
| ----- | ----- |
| paper_id | wu4DGaussianSplatting2024 / PH49JNKV |
| task | dynamic novel view synthesis; real-time dynamic scene rendering |
| domain | 3D vision; neural rendering; Gaussian Splatting |
| input | posed dynamic scene images/video, camera view matrix, timestamp |
| output | rendered novel-view image and deformed 3D Gaussians |
| representation | canonical 3D Gaussians plus decomposed 4D neural voxel deformation field |
| backbone | 3D-GS rasterization; HexPlane / K-Planes-style 6-plane encoder; tiny MLP heads |
| key_modules | spatial-temporal structure encoder; multi-head Gaussian deformation decoder; 3D Gaussian warm-up |
| supervision | image reconstruction with L1 color loss plus grid TV regularization |
| losses | $L=|\hat{I}-I|+L_{tv}$ |
| training_data | D-NeRF synthetic; HyperNeRF / Nerfies; Neu3D |
| evaluation_data | synthetic 800x800; HyperNeRF 960x540; Neu3D 1352x1014 |
| metrics | PSNR, SSIM, MS-SSIM, D-SSIM, LPIPS, training time, FPS, storage |
| baselines | TiNeuVox, KPlanes, HexPlane, 3D-GS, FFDNeRF, MSTH, V4D, Nerfies, HyperNeRF, NeRFPlayer, HyperReel, Im4D |
| ablations | w/o HexPlane, w/o initialization, w/o $\phi_x$, w/o $\phi_r$, w/o $\phi_s$ |
| main_claim | real-time dynamic rendering with compact storage and competitive quality |
| actual_method_delta | apply compact spatial-temporal plane encoding and MLP deformation heads to canonical 3D Gaussians |
| main_limitation | large motions, missing background points, inaccurate pose, dynamic/static separation, urban-scale scaling |
| reusable_component | Gaussian deformation field: plane encoder plus position/rotation/scale heads |
| possible_gap | pose-robust 4D-GS, dynamic/static disentanglement, appearance-changing Gaussians, larger-scale efficient deformation querying |

## 11. Reusable Components for My Research

| Component | What it does | How to reuse | Required changes | Risk |
| --------- | ------------ | ------------ | ---------------- | ---- |
| Spatial-temporal 6-plane encoder | 用低维 plane decomposition 编码 4D space-time features | 可用于任何 point / Gaussian / voxel primitive 的 time-conditioned deformation | 需要定义 coordinate normalization、plane resolution、feature fusion | 过低容量会欠拟合复杂运动 |
| Multi-head Gaussian deformation decoder | 分别预测 position、rotation、scale deformation | 可插入 3D-GS pipeline，把 static primitives 扩展为 dynamic primitives | 需要明确 rotation normalization 和 scale domain | 参数更新不稳定可能导致 Gaussian collapse |
| Static warm-up then joint optimization | 先形成 canonical geometry，再学习 deformation | 适用于动态重建和稀疏输入设置 | 需要调 warm-up length 和 densification schedule | warm-up 过强可能把动态区域学成静态平均 |
| Explicit Gaussian trajectories | 可用于 tracking / editing / composition | 用 $G'$ 的时间序列作为可视化或交互编辑对象 | 需要稳定 ID correspondence | 遮挡和拓扑变化下 trajectory 可能不可靠 |

## 12. Gap and Idea Seeds

| Gap / weakness | Evidence from this paper | Possible research direction | Minimal test |
| -------------- | ------------------------ | --------------------------- | ------------ |
| 相机位姿不准会影响 4D-GS | Sec. 5.5 明确列出 inaccurate camera pose | pose-robust deformation field 或 joint pose refinement | 在 D-NeRF / HyperNeRF 上加入可控 pose noise |
| monocular 下 static/dynamic 难分 | Sec. 5.5 明确提出 joint motion separation 困难 | 加入 motion segmentation prior 或 static-background constraint | 比较是否减少背景漂移和动态 artifact |
| 颜色 / opacity 未显式随时间变化 | Eq. 8 只更新 position、rotation、scale | 增加 appearance / opacity deformation head | 在有光照变化或拓扑变化场景做 ablation |
| deformation field 查询在大规模场景开销大 | Sec. 5.5 提到 urban-scale 需要更紧凑算法 | hierarchical / sparse / cached deformation query | 统计 Gaussians 数量、FPS、质量随场景尺度变化 |
| hyperparameters 不完整 | Sec. 5.1 说 appendix 有更多超参数但当前 PDF 缺失 | 用代码配置补全 reproducibility matrix | 对照 repo config 重建训练设置 |

## 13. Human Check List

| Item | Why it matters | Location |
| ---- | -------------- | -------- |
| Appendix / supplementary hyperparameters | 复现需要 plane resolution、MLP config、learning rates、loss weights | Sec. 5.1 mentions appendix; current PDF missing |
| Code repository exact URL | Abstract 只给 project page，未在正文列 repo URL | Abstract, PDF p.1 |
| Eq. 7 feature aggregation details | 公式抽取不清，production / concatenation / multiplication 需要确认 | Sec. 4.2, Eq. 7 |
| Rotation and scale update implementation | 直接相加可能需要 normalization / log scale handling | Sec. 4.2, Eq. 8 |
| Dataset split and per-scene config | 表格给均值，未给完整 split | Sec. 5.1 |
| Duplicate Zotero PDF attachment | Zotero item 有两个 PDF 附件，需确认是否完全重复 | Zotero children: ZH3L2R9U, CK5996GE |

## 14. Evidence Anchors

| Claim / detail | Evidence location |
| -------------- | ----------------- |
| 4D-GS combines 3D Gaussians and 4D neural voxels | Abstract, PDF p.1 / paper p.20310 |
| Target real-time rendering: 82 FPS at 800x800 on RTX 3090 | Abstract; Tab. 1, PDF p.1 and p.6 |
| 3D-GS static limitation and dynamic extension motivation | Introduction, PDF p.2 / paper p.20311 |
| Per-frame explicit Gaussian storage has $O(tN)$ cost | Sec. 2.2, PDF p.3 / paper p.20312 |
| Proposed memory complexity $O(N+F)$ | Sec. 2.2, PDF p.3 / paper p.20312 |
| Overall pipeline: query planes, decode deformations, splat | Fig. 3, PDF p.3 / paper p.20312 |
| Rendering equation $\hat{I}=S(M,G')$ and $G'=\Delta G+G$ | Sec. 4.1, PDF p.4 / paper p.20313 |
| Encoder plane set and multi-resolution levels | Sec. 4.2, PDF p.4 / paper p.20313 |
| Deformation heads $\phi_x,\phi_r,\phi_s$ | Sec. 4.2, PDF p.5 / paper p.20314 |
| Warm-up first 3000 iterations | Sec. 4.3, PDF p.5 / paper p.20314 |
| Loss $L=|\hat{I}-I|+L_{tv}$ | Sec. 4.3, Eq. 9, PDF p.5 / paper p.20314 |
| D-NeRF synthetic dataset details | Sec. 5.1, PDF p.5 / paper p.20314 |
| HyperNeRF and Neu3D setup | Sec. 5.1, PDF p.5-6 / paper p.20314-20315 |
| Synthetic quantitative comparison | Tab. 1, PDF p.6 / paper p.20315 |
| HyperNeRF quantitative comparison | Tab. 2, PDF p.7 / paper p.20316 |
| Neu3D quantitative comparison | Tab. 3, PDF p.7 / paper p.20316 |
| Ablation studies | Tab. 4, PDF p.8 / paper p.20317 |
| Tracking and composition discussion | Sec. 5.4, Fig. 7-8, PDF p.7-8 / paper p.20316-20317 |
| Explicit limitations | Sec. 5.5, PDF p.8 / paper p.20317 |
