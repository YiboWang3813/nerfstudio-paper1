# Speedy-Splat: Fast 3D Gaussian Splatting with Sparse Pixels and Sparse Primitives

## 0. 元数据

* Title: Speedy-Splat: Fast 3D Gaussian Splatting with Sparse Pixels and Sparse Primitives
* Authors: Alex Hanson; Allen Tu; Geng Lin; Vasu Singla; Matthias Zwicker; Tom Goldstein
* Year: 2025
* Venue: CVPR
* PDF source: `/Users/wangyibo/Zotero/storage/ZIAUSPX2/Hanson 等 - Speedy-Splat Fast 3D Gaussian Splatting with Sparse Pixels and Sparse Primitives.pdf`
* Zotero item key: `NA82FLDP`
* Zotero PDF attachment key: `ZIAUSPX2`
* Code: `https://speedysplat.github.io/`
* Project page: `https://speedysplat.github.io/`
* Dataset link: Not specified
* Main task: accelerate 3D Gaussian Splatting rendering, reduce model size and training time
* Domain: 3DGS acceleration, model pruning, tile-based rasterization optimization
* Input: standard posed-image 3DGS training data, COLMAP poses and sparse point clouds
* Output: faster and smaller 3DGS model with near-baseline rendering quality

## 1. 一句话技术摘要

Speedy-Splat 发现 3DGS 的渲染开销同时浪费在过大的 Gaussian tile extent 和过多冗余 Gaussians 上，因此用 SnugBox/AccuTile 精确计算 Gaussian- tile intersections，并用训练期 Soft/Hard Pruning 基于高效 Hessian-inspired score 删除大量 primitives，实现约 $6.71\times$ FPS 加速和 $10.6\times$ Gaussian 数量压缩。

## 2. 问题形式化

论文处理的是已训练或训练中的 3DGS 的效率问题，而不是 sparse-view reconstruction 的欠约束问题。标准 3DGS 用 $N$ 个 Gaussian primitives 表示场景，每个 $G_i$ 包含 mean $\mu_i$、scale $s_i$、rotation $r_i$、spherical harmonics $h_i$ 和 opacity $\sigma_i$。渲染开销近似由两部分决定：需要处理的 Gaussian 数量，以及每个 Gaussian 被分配到多少 image tiles/pixels。

作者的目标是在保持图像质量接近 3DGS baseline 的前提下，同时减少每个 Gaussian 覆盖的 tile 数量和总 Gaussian 数量，从而提高 FPS、降低模型大小和缩短训练时间。

## 3. 方法概览

Speedy-Splat 包含四个可累加组件。

第一，SnugBox：用 Gaussian 真实 alpha threshold 推导 image-space ellipse extent，再计算紧致 axis-aligned bounding box，替换 3DGS 原始的保守圆形半径框。

第二，AccuTile：在 SnugBox 的 tile rectangle 内进一步逐行或逐列求 ellipse 与 tile 的精确交集，只保留真正被 Gaussian ellipse touched 的 tiles。

第三，Soft Pruning：在 densification 阶段、opacity reset 前，按高效 pruning score 删除低敏感度 Gaussians，实验中每次可删除 80%。

第四，Hard Pruning：densification 结束后，每 3000 iterations 删除 30% Gaussians，并继续 fine-tune，使模型进一步压缩。

## 4. 方法细节

**3DGS 原始 tile 分配的问题。** 3DGS 将 image plane 切成 $16\times16$ tiles。每个 Gaussian 先投影到 2D，再根据 projected covariance 的最大特征值 $\lambda_{\max}$ 取半径 $r=\lceil3\sqrt{\lambda_{\max}}\rceil$，将与该圆外接方形相交的 tiles 都分配给该 Gaussian。该规则不考虑 opacity $\sigma_i$，因此通常显著高估实际贡献范围。

**SnugBox。** Speedy-Splat 以实际渲染 threshold $\alpha_i(p)>1/255$ 定义 Gaussian 的有效像素范围。由于 $\alpha_i(p)=\sigma_i g_i(p)$，可得到一个由 projected 2D covariance 决定的 ellipse。SnugBox 对这个 ellipse 求 $x/y$ 方向的 axis-aligned extrema，得到更紧的 bounding box。它只在 preprocess 和 duplicateWithKeys 两处调用，额外开销很小，但能减少后续 prefix sum、sort、tile range 和 render 的工作量。

**AccuTile。** SnugBox 仍保留 ellipse bounding box 内的部分空 tiles。AccuTile 在 SnugBox rectangle 中沿较短方向迭代，对每一行或列求 ellipse 的最小/最大 extent，并把这段区间转换为 tile range。关键是每次迭代只需计算两个边界交点，复杂度与 tile rectangle 的短边长度及真实 touched tiles 数量相关。

**高效 pruning score。** PUP 3D-GS 用 Hessian sensitivity 做 pruning，但每个 Gaussian 需要存储与 6 个几何参数相关的 $36$ 维 Hessian block，且需要从 pixel gradients 反传到 $\mu$ 和 $s$，训练期使用成本太高。Speedy-Splat 将 Hessian 近似改写到 2D projected Gaussian scalar value $g_i(p)$ 上。由于 $\nabla_{g_i}I_G$ 已在 render backward pass 中计算，只需平方并跨 pixels 聚合，存储从 $N\times36$ 降为 $N$。

**Soft/Hard Pruning schedule。** 作者观察到 iteration 6000 后 $L_1$ residual 已较小，除 opacity reset 后外 Hessian approximation 较稳。因此在 6000、9000、12000 这三次 opacity reset 前做 Soft Pruning。densification 在 15000 iterations 后结束，之后每 3000 iterations 做 Hard Pruning，每次删 30%。

## 5. 数学目标与损失

标准 3DGS 参数集合为：

$$
\mathcal{G}=\{G_i=\{\mu_i,s_i,r_i,h_i,\sigma_i\}\}_{i=1}^{N}
$$

标准训练损失为：

$$
L(\mathcal{G}\mid\phi,I_{\text{gt}})=\|I_{\mathcal{G}}(\phi)-I_{\text{gt}}\|_1+L_{\text{D-SSIM}}(I_{\mathcal{G}}(\phi),I_{\text{gt}})
$$

3D covariance 为：

$$
\Sigma_i^{3D}=R_iS_iS_i^TR_i^T
$$

projected covariance 近似为：

$$
\hat{\Sigma}_i^{3D}=JW\Sigma_i^{3D}W^TJ^T
$$

渲染时 alpha 与 2D Gaussian 值为：

$$
\alpha_i(p)=\sigma_i g_i(p)
$$

$$
g_i=e^q,\quad q=-\frac{1}{2}(p-\mu_i^{2D})\Sigma_i^{2D^{-1}}(p-\mu_i^{2D})^T
$$

颜色 alpha compositing 为：

$$
C(p)=\sum_{i\in N}c_i\alpha_i(p)\prod_{j=1}^{i-1}(1-\alpha_j(p))
$$

SnugBox 的 ellipse threshold 来自 $\alpha_i(p)=1/255$：

$$
2\log(255\sigma_i)=(p-\mu_i^{2D})\Sigma_i^{2D^{-1}}(p-\mu_i^{2D})^T
$$

令 $\Sigma_i^{2D^{-1}}=\begin{bmatrix}a&b\\b&c\end{bmatrix}$、$x_d=p_x-\mu_x$、$y_d=p_y-\mu_y$，ellipse 方程为：

$$
t=ax_d^2+2bx_dy_d+cy_d^2,\quad t=2\log(255\sigma_i)
$$

PUP 3D-GS 的 Hessian approximation 为：

$$
H=\nabla_{\mathcal{G}}^2L_2=\sum_{\phi\in P_{\text{gt}}}\nabla_{\mathcal{G}}I_{\mathcal{G}}(\phi)\nabla_{\mathcal{G}}I_{\mathcal{G}}(\phi)^T
$$

Speedy-Splat 的高效 score 将 per-Gaussian sensitivity 写为：

$$
\tilde{U}_i=\log|\nabla_{g_i}I_{\mathcal{G}}\nabla_{g_i}I_{\mathcal{G}}^T|
$$

由于 $g_i$ 是 scalar 且 log 单调，可简化为：

$$
\tilde{U}_i=(\nabla_{g_i}I_{\mathcal{G}})^2
$$

## 6. 训练与推理流程

1. 以 standard 3DGS 初始化，使用 COLMAP poses 和 sparse point cloud。
2. 在 renderer 中替换原始 conservative tile allocation。
3. Preprocess 阶段用 SnugBox 计算每个 Gaussian 的紧 bounding box 和 tile count。
4. DuplicateWithKeys 阶段可进一步用 AccuTile 生成精确 Gaussian-to-tile keys。
5. 在正常 3DGS densification 期间训练；在 6000、9000、12000 iterations 的 opacity reset 前执行 Soft Pruning，按 $\tilde{U}_i$ 删除低分 Gaussians。
6. 15000 iterations 后 densification 结束，之后每 3000 iterations 执行 Hard Pruning，每次删 30%，并继续 fine-tune。
7. 推理时使用 SnugBox/AccuTile 的 tile intersection 和被 pruning 后的小模型渲染。

## 7. 实验设置与结果摘要

数据集沿用 3DGS 的 Mip-NeRF360、Tanks & Temples 的 train/truck，以及 Deep Blending 的 drjohnson/playroom。使用数据集作者提供的 COLMAP poses 和 sparse point clouds。实现基于 3DGS differentiable renderer，训练 pipeline 中修改 pruning schedules；计时用 CUDA events，GPU 为 RTX A5000。

表 1 展示逐模块累计的 renderer 函数耗时：SnugBox 将 overall render time 从 7.478 ms 降至 4.102 ms，约 $1.823\times$；AccuTile 进一步降至 3.748 ms，约 $1.995\times$；Soft Pruning 后为 2.381 ms；Hard Pruning 后为 1.114 ms，约 $6.712\times$。

表 2 汇总所有场景平均性能：baseline 为 2.93M Gaussians、134 FPS、23.2 min training time；完整 Speedy-Splat 为 0.28M Gaussians、898 FPS、15.7 min training time，对应 $10.6\times$ compression、$6.71\times$ FPS、$1.47\times$ training speed-up。

表 3 在 Mip-NeRF360 上对比剪枝/压缩方法。SnugBox 和 AccuTile 属于 lossless rendering acceleration，PSNR/SSIM/LPIPS 基本不变；完整 +Hard Pruning 达到 $10.6\times$ compression 和 $6.51\times$ FPS，但 PSNR 从 27.55 降到 26.94，SSIM 从 0.814 降到 0.782，LPIPS 从 0.222 增至 0.296。

表 4 比较 Speedy-Splat efficient pruning score 与 PUP score，在相同 PUP post-hoc pipeline 和 88.44% pruning 率下，Speedy-Splat PSNR 更高，但 SSIM/LPIPS 略有取舍。

## 8. 声称贡献与实际技术增量

* 声称贡献 1: SnugBox 精确计算 Gaussian-tile bounding box intersections。实际增量是把 opacity threshold 纳入 extent 计算，避免 $\lambda_{\max}$ 圆形半径过保守。
* 声称贡献 2: AccuTile 计算 exact Gaussian-tile intersections。实际增量是对 SnugBox rectangle 做行/列级 ellipse intersection，而不是简单使用 bounding box 内所有 tiles。
* 声称贡献 3: Soft Pruning 在 densification 期间剪枝。实际增量是把高效 sensitivity score 放入训练循环，而不是训练后 post-hoc pruning。
* 声称贡献 4: Hard Pruning 在 densification 后持续压缩。实际增量是 schedule 设计与 fine-tune 配合。
* 对 sparse-view 研究的相关性: 这里的 sparse 指 sparse pixels/primitives，不是 sparse input views；但 pruning 和 tile 精确化可以作为 sparse-view GS 的效率模块。

## 9. 局限与隐含假设

* 完整压缩会牺牲图像质量，尤其 LPIPS 有明显恶化。
* Pruning score 与 PUP score 仍有性能差距，作者承认未来可寻找更好的高效 score。
* 方法主要评估标准 3DGS 数据设置，未专门验证在 few-shot/sparse-view 训练下剪枝是否会加剧欠重建。
* SnugBox/AccuTile 假设现有 3DGS tile renderer 架构；对其他 rasterizer 或 mobile-specific pipeline 需要重新适配。
* Soft Pruning schedule 依赖 3DGS 的 opacity reset 和 densification 节奏，迁移到其他 GS variants 需要重调。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法类别 | 3DGS renderer acceleration and primitive pruning |
| 核心模块 | SnugBox; AccuTile; efficient pruning score; Soft Pruning; Hard Pruning |
| 输入条件 | 标准 posed 3DGS training data |
| sparse 含义 | sparse pixels/tile intersections; sparse primitives |
| 是否解决 sparse-view | 否，主要解决效率和压缩 |
| 输出 | 小型高速 3DGS model |
| 主要收益 | $6.71\times$ FPS, $10.6\times$ compression, $1.47\times$ training speed-up |
| 主要代价 | 高压缩下 image quality 下降 |

## 11. 对我研究可复用的组件

* **Lossless tile localization**: SnugBox/AccuTile 可直接用于 sparse-view GS 方法的渲染加速，且不会改变图像结果。
* **训练期 pruning**: 在 densification 中加入 Soft Pruning，可减少后续训练和渲染负担。
* **高效 sensitivity score**: 使用 $\nabla_{g_i}I_{\mathcal{G}}$ 聚合替代昂贵 Hessian block，适合需要频繁评估 primitive importance 的方法。
* **质量-速度分层配置**: SnugBox/AccuTile 可作为无损配置；Soft/Hard Pruning 可作为可调压缩配置。

## 12. 缺口与想法种子

* **Sparse-view aware pruning**: 将 pruning score 与 view coverage/uncertainty 结合，避免删除只被少数视角约束但对 novel view 重要的 Gaussians。
* **Geometry-safe pruning**: 在 DNGaussian、CoR-GS、MAtCha 类方法中加入 depth/normal preservation score，剪枝时同时保几何。
* **Adaptive pruning schedule**: 不固定 6000/9000/12000/15000，而是根据 validation PSNR、opacity reset 后稳定性或 Gaussian gradient statistics 触发。
* **Exact tile intersection for dynamic GS**: 将 SnugBox/AccuTile 扩展到 time-varying Gaussian attributes，减少动态场景每帧渲染开销。
* **Pruning as regularization**: 在 sparse-view 训练中将 soft pruning 作为 anti-coadaptation 手段，与 dropout-style Gaussian regularization 结合。

## 13. 人工检查清单

* `NEED_HUMAN_CHECK`: Appendix A.1 的 AccuTile correctness proof。
* `NEED_HUMAN_CHECK`: Appendix A.3 中 Tanks & Temples 和 Deep Blending 的完整结果。
* `NEED_HUMAN_CHECK`: Appendix A.4 与 StopThePop 的速度比较细节。
* `NEED_HUMAN_CHECK`: code 中 Soft/Hard Pruning 与 3DGS opacity reset 的具体执行顺序。

## 14. 证据锚点

* Abstract: 提出两类 inefficiencies：Gaussian localization 和 pruning，并报告平均 $6.71\times$ 渲染加速。
* Fig. 1: truck scene 中 Gaussian 数从 2.6M 减到 0.26M，FPS 从 184.87 到 1148.77。
* Sec. 1 Introduction: 四个贡献 SnugBox、AccuTile、Soft Pruning、Hard Pruning。
* Sec. 3.1 / Eq. (1)-(2): 3DGS 参数和训练损失。
* Sec. 3.2 / Table 1: tile-based rendering pipeline 的主要耗时函数。
* Sec. 4.1 / Eq. (8)-(16): 原始 extent、opacity threshold ellipse 和 SnugBox 推导。
* Algorithm 1: AccuTile 的 row/column exact intersection procedure。
* Sec. 4.2 / Eq. (17)-(21): PUP Hessian score 与 Speedy-Splat efficient score。
* Sec. 4.2.2-4.2.3: Soft Pruning 和 Hard Pruning schedule。
* Table 2: 平均 Gaussian count、FPS、training time。
* Table 3: Mip-NeRF360 与其他 pruning/compression 方法比较。
* Table 4: Speedy-Splat score 与 PUP score 的 post-hoc pruning 比较。
* Sec. 6 Limitations: 图像质量下降与 pruning score 差距。
