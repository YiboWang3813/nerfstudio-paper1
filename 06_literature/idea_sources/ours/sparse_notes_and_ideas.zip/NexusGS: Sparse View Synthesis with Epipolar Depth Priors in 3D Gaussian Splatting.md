---
title: "NexusGS: Sparse View Synthesis with Epipolar Depth Priors in 3D Gaussian Splatting"
authors: "Yulong Zheng, Zicheng Jiang, Shengfeng He, Yandu Sun, Junyu Dong, Huaidong Zhang, Yong Du"
year: 2025
venue: "CVPR 2025"
zotero_item_key: "S2FA6XEN"
pdf_attachment_key: "JGUI5GV7"
pdf_path: "/Users/wangyibo/Zotero/storage/JGUI5GV7/Zheng 等 - 2025 - NexusGS Sparse View Synthesis with Epipolar Depth Priors in 3D Gaussian Splatting.pdf"
note_path: "notes/NexusGS: Sparse View Synthesis with Epipolar Depth Priors in 3D Gaussian Splatting.md"
tags: ["3D Gaussian Splatting", "sparse-view synthesis", "epipolar geometry", "optical flow", "depth prior", "point cloud densification"]
---

## 0. 一句话总结

NexusGS 不用单目深度正则，而是用 optical flow 和相机位姿在 epipolar geometry 下显式计算 dense depth，把深度 prior 直接嵌入初始 dense point cloud；再通过 flow-resilient depth blending 和 flow-filtered pruning 降低光流误差影响，使 sparse-view 3DGS 从一开始就拥有更可靠、更密集的几何覆盖。

## 1. 问题与动机

sparse-view 3DGS 的关键瓶颈是初始点云稀疏且位置不准。标准 3DGS 依靠 adaptive density control 的 split 操作逐步补点，但在少视角下监督不足，split 的随机性会导致过平滑、过拟合和错误 geometry。

已有方法常用单目深度正则，但 monocular depth 有尺度歧义，手工正则通常只是重新分配尺度误差，不能真正消除。NexusGS 的动机是：利用已知相机位姿和 optical flow，在 epipolar 几何中显式求 metric depth，并把结果转成 dense point cloud 初始化。

## 2. 适用场景

NexusGS 适用于相机位姿已知的 sparse-view NVS，包括 LLFF、DTU、Mip-NeRF360、Blender 等。它尤其适合希望提升初始点云密度和深度准确性的 per-scene 3DGS 训练。

它依赖光流估计和相机参数。如果图像之间重叠极低、外观变化大或光流预测失败，epipolar depth 会受影响；因此论文设计了 depth blending 和 pruning 来缓解但不能完全消除该风险。

## 3. 方法定位

NexusGS 是一个 point-cloud densification/initialization 方法，而不是训练时深度正则方法。训练目标仍是 3DGS 的 RGB photometric loss，不额外使用 depth regularization。

相对 FSGS 的 Gaussian unpooling，NexusGS 不在 KNN edge 中心生成点，而是从每个输入像素通过 epipolar depth 直接投到 3D，形成 dense point cloud。相对 DNGaussian，它不用单目深度，而用 optical flow + camera pose 的几何约束。

## 4. 核心创新

第一，提出 Epipolar Depth Nexus。给定 source 像素和 optical flow 预测的 target 匹配点，先把匹配点投影到对应 epipolar line 上，再用两视图几何显式求 source 像素深度。

第二，提出 Flow-Resilient Depth Blending。一个 source 像素可以从多个 target views 得到多个 depth，作者不简单平均，而是选择对 flow error 最不敏感的深度。

第三，提出 Flow-Filtered Depth Pruning。用 optical-flow matched point 到 epipolar line 的距离衡量匹配可靠性，过滤偏离过大的点，减少错误点云。

第四，展示生成的 depth map 和 dense point cloud 可迁移到 SparseNeRF、DNGaussian、FSGS、CoR-GS 等方法中并提升性能，说明 prior 本身有通用价值。

## 5. 方法细节

对 source view $i$ 的像素 $p_i=(x_i,y_i)$，target view $j$ 中的 epipolar line 为：

$$
(a,b,c)^\top=F^{i\to j}(x_i,y_i,1)^\top,\quad ax+by+c=0
$$

先用预训练 optical flow estimator 得到 flow $M_{flow}^{i\to j}=f(I_i,I_j)$，预测匹配点：

$$
\hat{p}_j=p_i+M_{flow}^{i\to j}(p_i)
$$

由于 $\hat{p}_j$ 可能不在 epipolar line 上，NexusGS 取其到 epipolar line 的垂足 $\bar{p}_j$：

$$
\bar{p}_j=\left(\frac{b^2\hat{x}_j-ab\hat{y}_j-ac}{a^2+b^2},\frac{a^2\hat{y}_j-ab\hat{x}_j-bc}{a^2+b^2}\right)
$$

然后用 camera intrinsics/extrinsics 和 $\bar{p}_j$ 显式计算 depth $D^{i\to j}(p_i,\bar{p}_j)$。多个 target views 会得到多个 depth 候选。

Flow-Resilient Depth Blending 的核心是比较光流误差对 depth 的敏感度。作者定义 source camera 到 3D 点的 reference distance $dis_{ref}$，以及其在 target view 上的 projection distance $dis_{pro}$，推导梯度：

$$
dis'_{ref}(dis_{pro})=\frac{t\sin\beta\sin^2(\alpha+\theta)}{m\sin\theta\sin^2(\alpha+\beta)}
$$

对同一 source 像素，选择 $dis'_{ref}$ 最小的 target view 对应 depth：

$$
D_i(p_i)=D^{i\to k}(p_i),\quad k=\arg\min_j dis'_{ref}(dis_{pro}^{i\to j,p_i})
$$

Flow-Filtered Depth Pruning 中，计算 predicted matched point 到 epipolar line 的距离：

$$
g^{i\to j}(p_i)=\frac{|a\hat{x}_j+b\hat{y}_j+c|}{\sqrt{a^2+b^2}}
$$

若该距离大于阈值，则认为光流不可靠并过滤。最终用像素颜色作为 Gaussian 初始颜色，用 depth 投影得到 3D center $\mu$。训练 loss 只使用 3DGS 的 RGB loss：

$$
L=(1-\lambda_c)L_1+\lambda_cL_{D\text{-}SSIM}
$$

## 6. 实验设置

实验在 LLFF、Blender、DTU、Mip-NeRF360 上进行，采用与已有 sparse-view 方法相同的 split 和分辨率。DTU 评估时使用 mask 去除背景影响。相机参数被假定已知。

对比方法包括 NeRF-based 的 SparseNeRF、DS-NeRF、ViP-NeRF、SimpleNeRF，以及 3DGS-based 的 3DGS、DNGaussian、FSGS、CoR-GS。指标为 PSNR、SSIM、LPIPS 和 AVGE。

## 7. 主要结果

LLFF、DTU、Mip-NeRF360 上，论文报告 NexusGS 在 PSNR、SSIM、LPIPS、AVGE 上均达到 SOTA，尤其 LLFF 上相对第二名分别提升 0.62 PSNR、0.026 SSIM、0.019 LPIPS、0.009 AVGE。文本抽取未完整保留主表 1 的逐项数值，因此这里不补写缺失数值。

Blender 8-view 上，NexusGS 达到 24.37 PSNR、0.893 SSIM、0.087 LPIPS、0.047 AVGE，优于 DNGaussian 的 24.07 PSNR 和 CoR-GS 的 23.98 PSNR。

定性结果显示，NexusGS 在 LLFF 的 Bicycle/Stump、Mip-NeRF360 大场景和 DTU object-centric 场景中生成更完整点云和更准确 depth map。DNGaussian/FSGS 受 monocular depth 或稀疏点云影响会缺 Gaussian 或过平滑，CoR-GS 深度较完整但纹理细节偏平滑。

## 8. 消融与分析

LLFF 3-view 消融中，3DGS baseline 为 18.54 PSNR、0.588 SSIM、0.272 LPIPS。四种 depth blending 策略中，Average 为 20.39 PSNR，Nearest 为 20.62，Weighted Average 为 20.59，FRDB 为 20.90。加入 FFDP 后进一步提升，FRDB+FFDP 达到 21.07 PSNR、0.738 SSIM、0.177 LPIPS。

通用性实验显示，NexusGS depth/point cloud 可提升其他方法。SparseNeRF 从 19.86 PSNR 提升到 20.23；FSGS 加 Our PC 后从 20.43 提升到 20.85，并将 LPIPS 从 0.248 降到 0.166；CoR-GS 加 Our PC 后从 20.45 提升到 21.00。

DNGaussian 的多个组合也显示出提升：使用 NexusGS point cloud、depth 或二者都能改善结果，说明 NexusGS 提供的 dense point cloud 和 depth map 不只是服务本方法，也能作为可迁移 prior。

## 9. 与相关工作的关系

相对 DNGaussian、SparseNeRF 等 monocular depth prior 方法，NexusGS 的 depth 来自 epipolar geometry，尺度由相机几何和光流匹配决定，不需要依赖单目深度的相对尺度正则。

相对 FSGS 的 point densification，NexusGS 的点由真实像素和几何 depth 反投影得到，覆盖更均匀、更有 metric grounding。

相对 MVSplat/PixelSplat 等需要大规模训练的 MVS/generalizable 方法，NexusGS 是 per-scene、无需大规模预训练的 sparse-view 3DGS 初始化策略。

## 10. 优点

NexusGS 的优点是把 depth prior 直接嵌入初始点云，而不是在训练 loss 中再用复杂正则拉 geometry。这样 3DGS 从第一步就有更好的 dense geometry。

第二个优点是对光流误差有专门处理。FRDB 选择对匹配误差不敏感的深度，FFDP 过滤离 epipolar line 太远的 flow matches，避免简单 flow triangulation 的噪声。

第三个优点是 prior 可复用，能显著提升其他 sparse-view 方法。

## 11. 局限

方法需要准确相机位姿和内参。若 pose 有误，epipolar line 和 depth triangulation 都会出错。它也依赖 optical flow estimator，在低纹理、反光、遮挡或大视差区域可能仍会产生错误匹配。

另一个限制是它主要解决初始化和点云密度，不直接处理动态物体、光照变化或 pose-free 设置。

## 12. 可复现要点

复现时需要为每对输入视图计算 optical flow，并对每个 source 像素将 flow point 投影到 epipolar line 的垂足，再计算 depth 候选。

不要直接平均多视图 depth。应计算 $dis'_{ref}(dis_{pro})$ 并选择敏感度最小的 depth；随后用 $g^{i\to j}$ 做 flow-filtered pruning。最终点云由像素颜色和投影 3D 坐标组成，再按标准 3DGS RGB loss 训练。

## 13. 可能扩展

一个扩展是结合 learned flow uncertainty，让 FFDP 的阈值自适应，而不是固定距离阈值。另一个扩展是将 NexusGS 与 pose refinement 联合优化，使 epipolar depth prior 能在位姿轻微错误时仍然工作。

第三个方向是把 epipolar depth point cloud 与 Gaussian uncertainty/dropout 结合，对低置信 flow 区域降低 densification 或训练权重。

## 14. 个人理解

NexusGS 的核心启发是：sparse-view 3DGS 的很多问题来自起点太差。与其在训练中用深度 loss 不断纠偏，不如先用 epipolar 几何把点云做密、做准。

这篇文章也说明 optical flow 虽然不是 3D depth，但它的错误空间受图像分辨率约束；结合相机几何后，可以比单目深度给出更有尺度约束的 prior。关键在于不能盲信 flow，必须用 epipolar line 和敏感度分析过滤。
