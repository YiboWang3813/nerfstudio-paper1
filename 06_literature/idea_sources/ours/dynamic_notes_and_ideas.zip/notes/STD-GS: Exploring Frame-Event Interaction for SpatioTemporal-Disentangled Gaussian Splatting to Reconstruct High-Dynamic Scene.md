# STD-GS: Exploring Frame-Event Interaction for SpatioTemporal-Disentangled Gaussian Splatting to Reconstruct High-Dynamic Scene

## 0. Metadata

- Paper title: STD-GS: Exploring Frame-Event Interaction for SpatioTemporal-Disentangled Gaussian Splatting to Reconstruct High-Dynamic Scene
- Authors: Hanyu Zhou; Haonan Wang; Haoyue Liu; Yuxing Duan; Luxin Yan; Gim Hee Lee
- Venue / year: ICCV 2025
- Project / code: `https://github.com/Haonan-Wang-aurora/STD-GS`
- Zotero item key: `2EPHKPJK`
- Zotero PDF attachment key: `W3IRNWUE`
- Zotero PDF path: `/Users/wangyibo/Zotero/storage/W3IRNWUE/Zhou 等 - STD-GS Exploring Frame-Event Interaction for SpatioTemporal-Disentangled Gaussian Splatting to Reco.pdf`
- Local note path: `notes/STD-GS: Exploring Frame-Event Interaction for SpatioTemporal-Disentangled Gaussian Splatting to Reconstruct High-Dynamic Scene.md`

## 1. One-Sentence Technical Summary

STD-GS 用事件相机补偿普通帧相机在高速动态场景中的低帧率和曝光模糊限制，通过 appearance-motion clustering 将场景解耦为静态背景和动态物体，再用 event brightness/flow 约束物体 4D Gaussians 的颜色与形变，从而重建时间连续的高动态场景。

## 2. Problem Formulation

输入是像素对齐的 frame-event 数据：帧图像提供 dense spatial appearance，但在高速运动下会有 blur 和 temporal discontinuity；事件流提供 sparse spatial signal，但有高时间分辨率和连续 motion cue。目标是在动态场景中同时表示刚性静态背景和形变动态物体，并渲染 novel views。

论文批评统一 Gaussian 表示的核心问题是 feature mismatch：背景和物体在空间外观、时间运动上属于不同分布，但统一 3D/4D Gaussian representation 直接混合它们，容易把背景刚性特征和物体连续形变特征互相污染。STD-GS 的问题设定就是显式解耦这些 spatiotemporal features。

## 3. Method Overview

整体框架包含 Dynamic Scene Disentanglement (DSD) 和 Gaussian Representation Fusion (GRF)。DSD 使用帧图像的 superpixel appearance features 和事件流的 correlation-volume motion features，通过 K-Means 生成伪标签，再训练 ClusterFormer 做 learnable appearance-motion clustering，把 scene pixels/features 分成 background 和 objects。

GRF 将静态背景映射为 3D Gaussians，将动态物体映射为以连续 tracking points 为中心的 4D Gaussians。物体 tracking points 由事件 correlation volume 和 EKF 沿时间更新，解决帧相机造成的时间不连续。进一步，论文利用 Gaussian 与 event 的两类一致性：Gaussian color 对应 event brightness，Gaussian deformation 对应 event flow。最后用 shadow-based weights 融合背景和物体 Gaussians，完成渲染。

## 4. Method Details

### 4.1 Spatiotemporal Discrepancy and Clustering

作者先分析背景和物体的 feature distribution：在 frame spatial features 中，背景由于刚性更集中，动态物体因形变更发散；在 event temporal features 中，背景因为缺少连续动态响应更离散，动态物体则因连续运动更集中。这个观察构成 DSD 的先验。

具体地，frame image 被 superpixel 分割成局部 patch，作为 spatial appearance cue；event stream 在候选区域内通过 inner product 得到 correlation volumes，作为 temporal motion cue。K-Means 根据这些 spatiotemporal cues 产生背景/物体伪标签。

ClusterFormer 接收这些特征并递归更新 cluster centers，训练时使用 clustering consistency loss：

$$
L_{\mathrm{clu}} = \sum_{i,j} \left\lVert x_i - c_{y_i} \right\rVert + \left\lVert f(x_i)-f(x_j) \right\rVert \cdot S(y_i,y_j).
$$

其中 $x_i$ 是样本，$c_{y_i}$ 是 K-Means 标签 $y_i$ 对应的中心，$f(x)$ 是 ClusterFormer 输出特征，$S(\cdot)$ 描述两个标签间关系。该模块的作用不是直接渲染，而是提供 background/object mask 或 latent decomposition，降低后续 Gaussian 表示的混合歧义。

### 4.2 Object Gaussian Disentanglement

对动态物体，STD-GS 不只从帧图像提取关键点，而是用事件数据的 correlation volume 作为模板，使用 EKF 沿时间维度跟踪物体，生成连续 tracking points。随后，静态背景表示为 3D Gaussians $G_s$，动态物体表示为带 temporal scale 的 4D Gaussians $G_o$，物体 Gaussians 以这些连续 tracking points 为中心。

这一步的技术目的很明确：frame-only 动态方法在高动态场景中会遇到大位移和低时间采样，事件流提供更连续的轨迹提示，可以把物体 Gaussian 的时间形变从帧采样限制中释放出来。

### 4.3 Event-Gaussian Spatiotemporal Consistency

论文强调 Gaussian representation 与 event data 共享一致的 spatiotemporal characteristic。空间上，同一物体的 Gaussian color distribution 应与事件的 spatial brightness distribution 相似；时间上，Gaussian deformation trajectory 应与事件的 temporal flow 对齐。

因此 GRF 中有两类一致性约束。color-brightness consistency 让物体 Gaussian 的颜色统计接近事件亮度响应，从而缓解高速运动造成的颜色偏移和模糊。deformation-flow consistency 让 Gaussian 的时序形变与 event flow 对齐，从而减少物体位置漂移和时间突变。提取文本没有给出完整公式，但消融表明这类 $L_{\mathrm{consis}}$ 对最终指标有明显贡献。

### 4.4 Gaussian Fusion and Rendering

背景 Gaussians 与物体 Gaussians 不是简单拼接。论文使用 shadow-based weights 融合背景和物体 Gaussian 集合，再通过 Gaussian splatting 渲染 novel view。这个融合步骤对应图 2 中的 Gaussian Representation Fusion：背景贡献刚性 spatial structure，物体贡献连续 spatiotemporal structure。

从建模角度看，STD-GS 形成了“先 scene-level 解耦，再 object-level 解耦，最后 representation-level 融合”的流水线。scene-level 解耦解决背景/物体混合，object-level 事件一致性解决高速动态物体的连续性，fusion 则把两者合成一个可渲染场景。

## 5. Mathematical Objectives and Losses

论文主损失可以抽象为三类：渲染重建损失 $L_{\mathrm{recon}}$，appearance-motion clustering loss $L_{\mathrm{clu}}$，以及 event-Gaussian spatiotemporal consistency loss $L_{\mathrm{consis}}$。消融表 4 直接比较这些项，说明三者组合效果最好：

$$
L = L_{\mathrm{recon}} + L_{\mathrm{clu}} + L_{\mathrm{consis}}.
$$

$L_{\mathrm{recon}}$ 负责 novel-view image rendering，是基础项；$L_{\mathrm{clu}}$ 推开背景和物体的 spatiotemporal features，提升场景解耦；$L_{\mathrm{consis}}$ 则把物体 Gaussian 的颜色和形变约束到 event brightness/flow 上，提升高速动态连续性。

论文明确给出的 $L_{\mathrm{clu}}$ 为：

$$
L_{\mathrm{clu}} = \sum_{i,j} \left\lVert x_i - c_{y_i} \right\rVert + \left\lVert f(x_i)-f(x_j) \right\rVert \cdot S(y_i,y_j).
$$

由于全文抽取未包含 color-brightness consistency 与 deformation-flow consistency 的完整数学表达，具体实现需要查 PDF 图文细节或代码。

## 6. Training and Inference Procedure

训练前需要配对 frame-event 数据。对现有 frame-only 数据，作者使用 frame extraction、blur synthesis 和 v2e 生成 synthetic event data；对真实场景，作者构建了光学同轴设备采集像素对齐的 CoFED frame-event 数据。

训练流程大致为：先从 frame images 提取 superpixels，并从 event stream 构造 temporal correlation volumes；用 K-Means 得到 appearance-motion pseudo labels；训练 ClusterFormer 完成 background/object disentanglement；使用 SfM/sparse points 初始化背景 3D Gaussians；对物体用 event correlation 和 EKF 生成连续 tracking points 并初始化 4D Gaussians；加入 Gaussian-event consistency 和 reconstruction loss 联合优化；最后通过 alpha blending / shadow-based weights 融合渲染。

推理时，输入目标视角和时间，使用已学背景 3D Gaussians、物体 4D Gaussians 与融合权重进行渲染。事件数据主要在训练中提供高时间分辨率监督和解耦先验。

## 7. Experimental Setup and Results Summary

实验包含 synthetic Event-HyperNeRF、real HD-CED，以及作者自建的 CoFED。指标为 PSNR、SSIM、LPIPS。比较方法覆盖 static reconstruction、event-only/event-frame static methods，以及 dynamic reconstruction methods：3DGS、EventNeRF、E2NeRF、E2GS、TiNeuVox、4DGS、SpacetimeGS、E-D3DGS、Ex4DGS、GauFRe 等；部分 frame-based 方法还测试了先 deblur 再训练的策略。

在 Event-HyperNeRF 上，STD-GS 达到 23.57 PSNR、0.69 SSIM、0.38 LPIPS；在 HD-CED 上达到 27.12 PSNR、0.88 SSIM、0.25 LPIPS，显著高于 4DGS w/ Deblur 的 21.58 PSNR、0.69 SSIM、0.30 LPIPS。CoFED 上，低动态场景 STD-GS 为 31.42 PSNR、0.89 SSIM、0.24 LPIPS，高动态场景为 27.68 PSNR、0.87 SSIM、0.26 LPIPS，尤其在高动态场景比 Ex4DGS 和 4DGS 更强。

消融表明，逐步加入 scene disentanglement、object disentanglement、Gaussian fusion、color fusion 后，指标从 24.83/0.75/0.42 提升到 27.68/0.87/0.26。损失消融也显示 $L_{\mathrm{clu}}$ 和 $L_{\mathrm{consis}}$ 都有贡献。训练数据消融显示 frame-event 明显优于 frame-only 或 event-only；temporal tracking 优于 frame interpolation；ClusterFormer 在高动态场景优于 SAM。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是面向高动态场景的 frame-event spatiotemporal-disentangled Gaussian splatting。实际技术增量主要有三层。第一，利用事件流做 temporal motion cue，使背景/物体解耦不只依赖 RGB appearance。第二，把物体动态 Gaussian 的中心和形变绑定到 event-based continuous tracking，弱化帧相机的低时间采样问题。第三，用 event brightness/flow 作为 object Gaussian 的 spatiotemporal consistency prior。

相较 event-enhanced static GS，STD-GS 的重点不是把事件当作额外图像信号增强 reconstruction，而是把事件用于解耦和连续动态建模。相较 frame-only 4DGS，技术优势集中在高速运动物体：事件提供更高时间分辨率的运动观测，ClusterFormer 提供显式 scene/object split。

但该方法也更依赖硬件和数据：需要 pixel-aligned frame-event 数据，真实推广成本高于只用 RGB 视频的动态 GS。

## 9. Limitations / Assumptions

方法假设 frame-event 已经良好对齐。论文为此构建了光学同轴设备；如果普通数据没有严格对齐，color-brightness 和 deformation-flow consistency 可能会引入错误监督。

事件相机对沿 $x,y$ 方向的亮度变化敏感，但论文也指出，对沿相机 $z$ 轴径向运动的物体，frame 和 event 都难以区分其 spatiotemporal feature 与背景。这是该方法的明确限制，作者建议未来引入 LiDAR 建模 3D motion field。

DSD 依赖 superpixel、K-Means pseudo labels、ClusterFormer 和 event correlation volume，流水线较长。错误的初始 clustering 可能影响后续 Gaussian 分配；虽然 ClusterFormer 提供学习能力，但其泛化到复杂多物体、透明/反光、弱纹理场景仍需额外验证。

## 10. Matrix-Ready Summary

| Dimension | Entry |
|---|---|
| Input | Pixel-aligned frame-event data |
| Output | Novel-view rendering of high-dynamic scenes |
| Representation | Static background 3D Gaussians plus dynamic object 4D Gaussians |
| Core idea | Spatiotemporal disentanglement of background and objects using frame-event cues |
| Scene decomposition | Superpixel appearance + event correlation motion + ClusterFormer |
| Object modeling | EKF event tracking points as centers of object 4D Gaussians |
| Event prior | Color-brightness consistency and deformation-flow consistency |
| Fusion | Shadow-based weights / alpha blending of background and object Gaussians |
| Datasets | Event-HyperNeRF, HD-CED, CoFED |
| Main advantage | Stronger high-dynamic reconstruction than frame-only or simple frame-event baselines |
| Main limitation | Requires aligned frame-event sensing; weak for radial $z$-axis motion |

## 11. Reusable Components

- Appearance-motion clustering: combine frame superpixel appearance and event correlation motion to separate background and moving objects.
- Event-guided object tracking: use event correlation volumes plus EKF to produce continuous object tracking points for dynamic Gaussians.
- Event-Gaussian consistency: use event brightness and flow as priors for Gaussian color and deformation.
- Scene/object separated Gaussian banks: keep static background 3DGS and dynamic object 4DGS distinct until fusion.
- Coaxial frame-event dataset design: useful for future multimodal dynamic reconstruction benchmarks.

## 12. Gap / Idea Seeds

- Replace K-Means pseudo labels with differentiable contrastive clustering trained directly from reconstruction gradients and event consistency.
- Extend event-Gaussian consistency to radial motion by adding depth/LiDAR/structured-light cues, as the authors suggest.
- Study whether a learned frame-event alignment module can relax the strict coaxial hardware requirement.
- Use object-level identities and long-term tracks to support multiple independently moving objects with occlusion.
- Convert STD-GS into a monocular RGB-only distillation pipeline: use event data during training, then distill into an RGB-only dynamic prior.

## 13. Human Check List

- NEED_HUMAN_CHECK: Extracted text truncates the exact formulas for color-brightness and deformation-flow consistency; verify from PDF/code before implementation.
- NEED_HUMAN_CHECK: Confirm whether ICCV 2025 is the final venue metadata; extracted PDF contains ICCV open-access watermark.
- NEED_HUMAN_CHECK: Check the exact definition of shadow-based weights in the supplementary/code.

## 14. Evidence Anchors

- Abstract: frame-event interaction; spatiotemporal-disentangled Gaussian splatting; background/object discrepancy; Gaussian-event consistency.
- Figure 1-2: unified vs disentangled Gaussian representation; DSD and GRF framework.
- Section 3.2: frame superpixels, event correlation volumes, K-Means pseudo labels, ClusterFormer and $L_{\mathrm{clu}}$.
- Section 3.3: EKF tracking, background 3D Gaussians, object 4D Gaussians, color-brightness and deformation-flow consistency.
- Tables 1-2: Event-HyperNeRF, HD-CED, CoFED quantitative comparisons.
- Tables 3-7: disentanglement/fusion, loss, training data, temporal continuity and segmentation strategy ablations.
