# Generative Sparse-View Gaussian Splatting

## 0. 元数据

* Title: Generative Sparse-View Gaussian Splatting
* Authors: Hanyang Kong; Xingyi Yang; Xinchao Wang
* Year: 2025
* Venue: CVPR
* PDF source: `/Users/wangyibo/Zotero/storage/3M3WCTS5/Kong 等 - Generative Sparse-View Gaussian Splatting.pdf`
* Zotero item key: `KUUMSX26`
* Zotero PDF attachment key: `3M3WCTS5`
* Code: Not specified
* Project page: Not specified
* Dataset link: Not specified
* Main task: sparse-view 3D/4D Gaussian Splatting novel view synthesis
* Domain: 静态场景重建、动态场景重建、少视角视图合成
* Input: 少量带已知相机位姿的图像集合 $I=\{I_i\}_{i=1}^N$ 与相机位姿 $P=\{P_i\}_{i=1}^N$
* Output: 优化后的 3D/4D Gaussian Splatting 表示，以及从 novel views 渲染出的图像

## 1. 一句话技术摘要

GS-GS 把预训练 depth-conditioned diffusion model、LoRA 场景适配、伪视角图像生成和 3D/4DGS 优化放进一个交替循环中，用 diffusion hallucination 补少视角缺失信息，并用跨视角 diffusion feature 对齐与 DPT-depth MS-SSIM 正则约束生成图像和 Gaussian 几何的一致性。

## 2. 问题形式化

论文处理的是 sparse-view 下的 3D/4D Gaussian Splatting 重建：给定少量训练视角图像 $I=\{I_1,\ldots,I_N\}$ 和已知相机位姿 $P=\{P_1,\ldots,P_N\}$，在由原始位姿插值得到的伪视角集合 $\tilde{P}=\{\tilde{P}_1,\ldots,\tilde{P}_{\tilde{N}}\}$ 上生成伪图像 $\tilde{I}$，再把真实视角和伪视角一起用于优化 Gaussian 表示参数 $\theta$。

作者把核心目标写成双层/交替优化：上层优化 Gaussian 渲染误差，下层将 diffusion model 参数 $\Theta$ 适配到当前场景，并用适配后的 diffusion model 采样伪视角图像。这个形式化的关键假设是：伪视角图像虽然不是 GT，但只要通过几何约束生成，就能作为有效的额外监督。

## 3. 方法概览

方法由三个模块组成。

第一，先用稀疏训练视角初始化一个粗糙的 3DGS 或 4DGS。静态场景基于 official 3DGS，动态场景基于 SpacetimeGS。

第二，使用 depth T2I-adapter 和 LoRA 对预训练 Stable Diffusion 进行场景级适配。3D/4DGS 在真实视角和伪视角渲染当前图像，DPT 估计深度作为条件，LoRA 用这些图像更新，使 diffusion prior 逐步变成 scene-specific prior。

第三，在伪视角上用 fine-tuned diffusion model 生成新的 $\tilde{I}$，把这些 hallucinated images 加入 3D/4DGS 的训练集；同时在 Gaussian 优化中加入 DPT depth 与 rasterized depth 的 MS-SSIM 正则。整个过程反复进行，形成“GS 渲染数据更新 LoRA，LoRA 生成伪视角数据更新 GS”的闭环。

## 4. 方法细节

**伪视角生成。** 伪相机位姿 $\tilde{P}$ 由原始训练相机位姿插值得到。对于每个伪视角，当前 3D/4DGS 先渲染图像并估计深度，depth-conditioned diffusion model 再生成该视角的 hallucinated image。这个设计避免只依赖文本 prompt 或无几何条件的图像生成。

**LoRA 场景适配。** 论文不全量微调 diffusion model，而是在预训练 diffusion model 中插入 LoRA。LoRA 的训练数据不是固定的，而是随 3D/4DGS 的优化迭代更新：当前 GS 在真实视角和伪视角渲染出的图像会成为下一轮 LoRA fine-tuning 的数据。

**Geometry-aware diffusion fine-tuning。** 为了让伪视角生成跨视角一致，论文借鉴 DIFT 的观察：diffusion intermediate features 含有语义对应信息。具体做法是将伪视角渲染图 $\tilde{I}$ 通过已知相机外参 warping 到真实训练视角 $P$，得到 $\tilde{I}_{R,T}$；然后对真实图像 $I$ 和 warped 图像 $\tilde{I}_{R,T}$ 提取 diffusion features $f_{train}$ 与 $f'_{train}$，用二者的 feature distance 作为 LoRA fine-tuning 的几何正则。

**Gaussian depth regularization。** 由于 hallucinated images 仍可能与真实几何不完全对齐，作者在 GS 优化阶段增加深度正则。对真实训练视角和伪视角都渲染 rasterized depth $D_{\text{GS}}$，再用 DPT 对渲染图估计 monocular depth $D_{\text{DPT}}$。二者先标准化，再用 MS-SSIM 而不是 $L_1$ 或 $L_2$ 约束结构一致性。

## 5. 数学目标与损失

3D Gaussian 的基本形式沿用 3DGS：

$$
G(\boldsymbol{x}) = e^{-\frac{1}{2}(\boldsymbol{x}-\boldsymbol{\mu})^T\boldsymbol{\Sigma}^{-1}(\boldsymbol{x}-\boldsymbol{\mu})}
$$

协方差由尺度和旋转构成：

$$
\boldsymbol{\Sigma}=\boldsymbol{R}\boldsymbol{S}\boldsymbol{S}^T\boldsymbol{R}^T
$$

GS-GS 的概念性双层优化为：

$$
\boldsymbol{\theta}^*=\arg\min_{\boldsymbol{\theta}}\sum_{i=1}^{N}\mathcal{L}_{\text{GS}}(R(P_i;\boldsymbol{\theta}),I_i)+\sum_{j=1}^{\tilde{N}}\mathcal{L}_{\text{GS}}(R(\tilde{P}_j;\boldsymbol{\theta}),\tilde{I}_j)
$$

其中 $\boldsymbol{\Theta}^*$ 通过 $L_{\text{LDM}}$ 适配 diffusion model，并用 $\tilde{I}_j=\texttt{sample}[\boldsymbol{\epsilon}_{\boldsymbol{\Theta}^*}(\tilde{y}_j)]$ 生成伪视角图像。

LoRA fine-tuning 损失为：

$$
\mathcal{L}_{\boldsymbol{\Theta}}=\mathcal{L}_{\text{LDM}}(I,y;\boldsymbol{\Theta})+\mathcal{L}_{\text{LDM}}(\tilde{I}_{R,T},y;\boldsymbol{\Theta})+\lambda_{\text{geo}}\|f_{\text{train}},f'_{\text{train}}\|
$$

论文报告 $\lambda_{\text{geo}}=0.1$。注意 PDF 抽取中 feature distance 记作 $\|f_{\text{train}},f'_{\text{train}}\|$，具体范数形式未进一步明确，应标记为 `NEED_HUMAN_CHECK`。

Gaussian rasterized depth 为：

$$
D_{\text{GS}}=\sum_{i\in N}d_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_i)
$$

其中 $d_i$ 是 z-buffer，$\alpha_i$ 是 Gaussian density/opacity。PDF 公式中乘积项写作 $(1-\alpha_i)$，按体渲染常见形式可能应为 $(1-\alpha_j)$，这里不擅自修正，标记 `NEED_HUMAN_CHECK`。

深度标准化为：

$$
D_{\text{GS}}^{\text{norm}}=\frac{D_{\text{GS}}-\mu_{D_{\text{GS}}}}{\sigma_{D_{\text{GS}}}}
$$

$$
D_{\text{DPT}}^{\text{norm}}=\frac{D_{\text{DPT}}-\mu_{D_{\text{DPT}}}}{\sigma_{D_{\text{DPT}}}}
$$

深度正则为：

$$
\mathcal{L}_{\text{reg}}=-\text{MS-SSIM}(D_{\text{DPT}}^{\text{norm}},D_{\text{GS}}^{\text{norm}})
$$

最终 GS 优化损失为：

$$
\mathcal{L}_{\text{GS}}=\mathcal{L}_1(R(\mathcal{P};\boldsymbol{\theta}),\mathcal{I})+\mathcal{L}_1(R(\tilde{\mathcal{P}};\boldsymbol{\theta}),\tilde{\mathcal{I}})+\lambda\mathcal{L}_{\text{D-SSIM}}(R(\mathcal{P};\boldsymbol{\theta}),\mathcal{I})+\lambda\mathcal{L}_{\text{D-SSIM}}(R(\tilde{\mathcal{P}};\boldsymbol{\theta}),\tilde{\mathcal{I}})+\lambda_{\text{reg}}\mathcal{L}_{\text{reg}}
$$

## 6. 训练与推理流程

1. 用稀疏训练视角通过 SfM 初始化点云，并训练一个 coarse 3D/4DGS。
2. 从训练相机位姿插值得到伪视角 $\tilde{P}$。
3. 当前 3D/4DGS 在真实视角 $P$ 和伪视角 $\tilde{P}$ 渲染图像。
4. 用 DPT 为这些图像估计深度，作为 depth T2I-adapter 的条件。
5. 用真实图像、GS 渲染图、warped pseudo-view 图像，以及 geometry-aware feature loss 更新 diffusion model 中的 LoRA 参数。
6. 用 fine-tuned diffusion model 在伪视角生成新的 hallucinated images $\tilde{I}$。
7. 用真实图像 $I$ 和伪图像 $\tilde{I}$ 共同优化 3D/4DGS，并加入 normalized depth MS-SSIM 正则。
8. 重复 LoRA 更新与 GS 更新，直到完成 10,000 iterations。
9. 推理时只需使用优化后的 3D/4DGS 渲染目标 novel views；diffusion model 主要用于训练期数据生成。

## 7. 实验设置与结果摘要

数据集包括 Blender、LLFF、Mip-NeRF360 和 Neural 3D Video。静态 sparse-view 3D 重建中，Blender 使用 8 views 训练、25 views 测试；LLFF 使用 3 views 训练；Mip-NeRF360 使用 24 views 训练。动态场景实验在 Neural 3D Video 上进行，从除第一个评估相机外的相机中均匀采样 3、6、9 views。

静态 baselines 包括 Mip-NeRF、DietNeRF、RegNeRF、FreeNeRF、SparseNeRF、3DGS、DNGaussian 和 FSGS；动态 baseline 使用 SpacetimeGS。指标为 PSNR、SSIM 和 LPIPS。

主要结果：在 Blender、LLFF、Mip-NeRF360 三个静态数据集上，GS-GS 在表 1 中均取得最优 PSNR/SSIM/LPIPS。例如 LLFF 的 PSNR 为 24.82，显著高于 FSGS 的 20.31；Mip-NeRF360 的 PSNR 为 25.87，高于 FSGS 的 23.70。动态 Neural 3D Video 中，3 views 下 GS-GS 的 PSNR/SSIM/LPIPS 为 27.13/0.907/0.135，而 SpacetimeGS 为 14.98/0.774/0.327；9 views 下 GS-GS 达到 30.21/0.928/0.082。

Ablation 表 3 支持三个模块的必要性：去掉 diffusion hallucination 时 LLFF PSNR 为 17.43；有 diffusion 但无 geometry-aware fine-tuning 为 22.71；去掉 depth regularization 为 24.09；完整模型为 24.82。Mip-NeRF360 上也有类似趋势，从 20.89 提升到 25.87。

## 8. 声称贡献与实际技术增量

* 声称贡献 1: 一个适用于 3D 和 4D Gaussian Splatting 的 sparse-view generative pipeline。实际增量是把 diffusion pseudo-view hallucination 与 Gaussian optimization 做成闭环，而不是只做一次性数据扩增。
* 声称贡献 2: 通过 semantic correspondences 强化几何一致性。实际实现不是显式三维匹配，而是 warping 后的 diffusion intermediate feature 对齐。
* 声称贡献 3: sparse-view 下达到 SOTA。证据来自 Blender、LLFF、Mip-NeRF360 和 Neural 3D Video，但动态实验只和 SpacetimeGS baseline 比，缺少专门 sparse dynamic baselines。
* 实际可复用技术点: LoRA 场景适配、DPT depth-conditioned generation、pseudo-view iterative dataset update、MS-SSIM depth regularization。

## 9. 局限与隐含假设

* 需要已知相机位姿；无 pose sparse-view 场景不在本文主流程内。
* 依赖预训练 diffusion model、depth T2I-adapter 和 DPT，质量受这些 foundation models 的先验影响。
* 伪视角由相机插值得到，方法更偏向补足已观测轨迹附近的缺失视角；对外推视角或大 baseline 未充分讨论。
* Hallucinated images 可能引入不真实细节，论文用 geometry-aware feature loss 和 depth regularization 缓解，但没有从不确定性角度筛掉低可信伪标签。
* 训练成本高于普通 3DGS，因为需要反复 LoRA fine-tuning、DPT depth estimation 和 diffusion sampling。
* 动态场景实验的 baseline 较少，无法判断相对最新 sparse dynamic GS 方法的优势。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法类别 | Diffusion-assisted sparse-view 3D/4DGS |
| 核心模块 | LoRA scene adaptation; depth-conditioned pseudo-view generation; diffusion feature consistency; DPT-depth MS-SSIM regularization |
| 输入条件 | Sparse posed images |
| 额外先验 | Stable Diffusion; depth T2I-adapter; DPT; SfM initialization |
| 监督信号 | 真实视角 RGB、伪视角 hallucinated RGB、DPT depth consistency |
| 适用范围 | 静态 3DGS 与动态 4DGS |
| 主要收益 | 用生成模型补足欠采样区域，提高 sparse-view 下几何和外观质量 |
| 主要风险 | 伪标签 hallucination bias、训练成本、依赖 pretrained priors |

## 11. 对我研究可复用的组件

* **迭代伪视角数据集更新**: 可以移植到其他 sparse-view GS 方法中，把当前渲染结果作为 diffusion adaptation 的场景数据，再将生成图像反哺 GS。
* **Diffusion feature correspondence loss**: 可用于约束跨视角语义一致性，尤其适合缺少真实深度或多视角 GT 的场景。
* **Normalized depth MS-SSIM regularization**: 比直接 $L_1$/$L_2$ 深度回归更关注结构形状，适合 monocular depth scale 不可靠的情况。
* **训练期生成、推理期纯 GS**: 生成模型只用于优化阶段，最终推理仍保持 Gaussian Splatting 的高效渲染。

## 12. 缺口与想法种子

* **伪标签可信度建模**: 为每个 hallucinated pseudo-view 或每个区域估计 uncertainty，只让高可信伪监督参与 densification 或 loss。
* **主动选择伪视角**: 不均匀插值相机，而是根据当前 Gaussian coverage、depth uncertainty 或 view disagreement 选择最有价值的 pseudo views。
* **无位姿扩展**: 将 RegGS/pose-free GS 的相机优化与 GS-GS 的 diffusion pseudo-view loop 结合，减少对准确 pose 的依赖。
* **动态场景一致性**: 对 Neural 3D Video 引入时间一致的 video diffusion prior，而不是逐视角/逐帧图像 diffusion。
* **防 hallucination regularizer**: 用 multi-view reprojection 或 feature cycle consistency 检测 diffusion 生成的“看似合理但三维不一致”内容。

## 13. 人工检查清单

* `NEED_HUMAN_CHECK`: Eq. (6) 的 feature distance 具体范数形式，PDF 文本只显示为 $\|f_{\text{train}},f'_{\text{train}}\|$。
* `NEED_HUMAN_CHECK`: Eq. (7) 中 alpha product 是否应为 $\prod_{j=1}^{i-1}(1-\alpha_j)$；PDF 抽取显示为 $(1-\alpha_i)$。
* `NEED_HUMAN_CHECK`: supplementary 中是否给出 pseudo-view interpolation 数量、LoRA fine-tuning 迭代频率、learning rates 和 $\lambda_{\text{reg}}$。
* `NEED_HUMAN_CHECK`: code/project page 未在抽取文本中发现。

## 14. 证据锚点

* Abstract: GS-GS 使用预训练 image diffusion models 生成 unseen views，并在 sparse 3D/4DGS 下提升重建质量。
* Sec. 1 Introduction: 三个贡献是 joint optimization、geometry-aware diffusion fine-tuning 和 depth regularization。
* Fig. 2: 展示 GS 渲染、DPT 深度、depth T2I-adapter、LoRA fine-tuning、pseudo-view 更新的完整 pipeline。
* Sec. 4.1 / Eq. (5): 问题定义和 bi-level optimization。
* Algorithm 1: joint optimization 的训练循环。
* Sec. 4.3 / Eq. (6): geometry-aware diffusion fine-tuning 与 feature loss。
* Sec. 4.4 / Eq. (7)-(10): rasterized depth、DPT depth normalization 和 MS-SSIM depth regularization。
* Sec. 4.5 / Eq. (11): 最终 3D/4DGS photometric + depth regularization loss。
* Sec. 5.1-5.2: 数据集、baselines、指标和 10,000 iteration 设置。
* Table 1: Blender、LLFF、Mip-NeRF360 静态 sparse-view 定量对比。
* Table 2: Neural 3D Video 动态 sparse-view 对 SpacetimeGS 的对比。
* Table 3 / Fig. 6: diffusion hallucination、geometry-aware fine-tuning 和 depth regularization 的消融。
