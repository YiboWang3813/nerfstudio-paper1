# 3D Gaussian Rendering Can Be Sparser: Efficient Rendering via Learned Fragment Pruning

## 0. 元数据

* Title: 3D Gaussian Rendering Can Be Sparser: Efficient Rendering via Learned Fragment Pruning
* Authors: Zhifan Ye; Chenxi Wan; Chaojian Li; Jihoon Hong; Sixu Li; Leshu Li; Yongan Zhang; Yingyan Lin
* Year: 2024
* Venue: NeurIPS
* PDF source: `/Users/wangyibo/Zotero/storage/A6HI6EW2/Ye 等 - 3D Gaussian Rendering Can Be Sparser Efficient Rendering via Learned Fragment Pruning.pdf`
* Zotero item key: `GQTAUQ6Y`
* Zotero PDF attachment key: `A6HI6EW2`
* Code: `https://github.com/GATECH-EIC/Fragment-Pruning`
* Project page: Not specified
* Dataset link: Not specified
* Main task: efficient 3D/4D Gaussian rendering via fragment pruning
* Domain: 3DGS acceleration, edge rendering, primitive/fragment pruning
* Input: pre-trained 3DGS, Mini-Splatting, or 4DGS model
* Output: per-Gaussian learned truncation thresholds and faster renderer

## 1. 一句话技术摘要

该文指出 Gaussian primitive pruning 减少 primitives 后并不等比例减少 rasterization bottleneck，因为每个 Gaussian 覆盖的 fragments 反而增加；因此提出 per-Gaussian learned truncation threshold，对每个 Gaussian 的 2D projected fragments 做自适应裁剪，通过 sigmoid 近似 indicator 进行微调，推理时直接用硬阈值减少 fragment count。

## 2. 问题形式化

标准 3DGS 渲染可分为 Projection、Sorting、Rasterization 三段。Primitive pruning 主要降低 Gaussian 数量 $\#G$，因此对 Projection/Sorting 有帮助；但 Rasterization 的复杂度主要由 fragments 数量 $\#F$ 决定，即所有投影 2D Gaussians 覆盖的 pixels 总数。Profiling 显示 rasterization 占总渲染时间 71.66%-94.25%，且 Mini-Splatting 这类 primitive pruning 虽然大幅降低 $\#G$，但 $\#F$ 降低很小，甚至 $\#F/\#G$ 大幅升高。

本文目标是：在不删除整个 Gaussian primitive 的情况下，裁剪每个 Gaussian 投影到 image plane 上的 fragment extent，降低 rasterization 计算量，同时保持或提升图像质量。

## 3. 方法概览

方法是 post-training fine-tuning。

首先，从预训练 3DGS/Mini-Splatting/4DGS 模型出发。对每个 Gaussian 增加一个可学习 truncation threshold $T_i$。普通 3DGS 使用固定 opacity threshold $1/255$ 来决定一个 Gaussian 是否影响某个 pixel；本文改为每个 Gaussian 学习不同阈值，从而让不同大小/重要性的 Gaussians 有不同的 projection support。

其次，为了可微训练，将硬 indicator $\mathbb{I}\{E_i(p)>T_i\}$ 用 sigmoid 近似。Fine-tuning 期间只训练 $T_i$ 和 opacity $o_i$，冻结 rotation、scale 和 SH coefficients，避免全模型微调过拟合。

最后，推理时丢弃 sigmoid approximation，直接使用硬阈值 $T_i$ 做 fragment pruning，因此没有额外 sigmoid 计算开销。

## 4. 方法细节

**为什么 primitive pruning 不够。** 表 1 显示，Mini-Splatting 在 Mip-NeRF360 scenes 上把 Gaussian 数量从数百万降到几十万，但 fragment 数量下降有限。例如 Room 中 $\#G$ 从 1.54M 到 0.39M，而 $\#F$ 从 83.99M 只降到 76.51M，导致 $\#F/\#G$ 从 54.7 增到 194.2。Rasterization stage 因此仍然慢。

**Fragment pruning granularity。** 对第 $i$ 个 Gaussian，fragment count 是其投影 2D Gaussian 在所有 pixels 上超过 threshold 的像素数量。提高 threshold 会缩小该 Gaussian 的有效 projection support，从而减少 $\#F_i$。但全局 threshold 不适合不同大小、opacity、位置的 Gaussians，所以本文学习 per-Gaussian $T_i$。

**基于 exponent term 裁剪。** 为避免额外计算 exponentials，方法不直接用 $\alpha_i(p)$ 裁剪，而是用 Eq. (5) 中指数项 $E_i(p)$ 做阈值判断。作者指出这与基于 $\alpha_i$ threshold 数学等价，对应 effective alpha threshold 为 $o_ie^{T_i}$。

**Threshold initialization。** Fine-tuning 前根据 opacity 初始化：

$$
T_i=\log(\frac{1}{64\cdot o_i})
$$

使初始化后的 effective alpha threshold 为 $1/64$。

**Fine-tuning scope。** 只训练 $T_i$ 和 opacity $o_i$；冻结 $R$、$S$、SH coefficients 等其他参数。损失沿用 3DGS 的 $L_1+\text{SSIM}$。静态场景 fine-tune 5,000 epochs，batch size 1；动态场景 batch size 4。

## 5. 数学目标与损失

3D Gaussian 为：

$$
G(x)=e^{-\frac{1}{2}(x-\mu)^T\Sigma^{-1}(x-\mu)}
$$

2D covariance projection 为：

$$
\Sigma'=JW\Sigma W^TJ^T
$$

标准 alpha compositing：

$$
C(p)=\sum_{i=1}^{\#G}c_i\alpha_i(p)\prod_{j=1}^{i-1}(1-\alpha_j(p))
$$

原文 Eq. (4) 抽取显示为 $(1-\alpha_i(p))$，按 alpha compositing 应为 $(1-\alpha_j(p))$，标记 `NEED_HUMAN_CHECK`。

Opacity value：

$$
\alpha_i(p)=o_i e^{-\frac{1}{2}(p-\mu_i)^T\Sigma_i'^{-1}(p-\mu_i)}
$$

普通 3DGS 固定 threshold truncation：

$$
\alpha'_i(p)=\alpha_i(p)\mathbb{I}\{\alpha_i(p)>T\}
$$

Fragment count：

$$
\#F=\sum_{i=1}^{\#G}\sum_{p\in P}\mathbb{I}\{\alpha_i(p)>T\}
$$

本文的 per-Gaussian threshold：

$$
\alpha'_i(p)=\alpha_i(p)\mathbb{I}\{E_i(p)>T_i\}
$$

Sigmoid approximation：

$$
\mathbb{I}\{E_i(x)>T_i\}\approx\text{Sigmoid}(\frac{E_i(x)-T_i}{t})
$$

Fine-tuning objective 沿用 3DGS photometric reconstruction loss，训练变量为 $\{T_i,o_i\}$。

## 6. 训练与推理流程

1. 使用官方 3DGS、Mini-Splatting 或 4DGS 训练得到 pre-trained model。
2. 对每个 Gaussian 根据 opacity 初始化 truncation threshold $T_i$。
3. 将 indicator 替换为 sigmoid approximation，构成可微 renderer。
4. 冻结 geometry、scale、rotation、SH coefficients，仅微调 $T_i$ 和 opacity $o_i$。
5. 静态场景 fine-tune 5,000 epochs，batch size 1，Adam learning rate 0.01，$\beta_1=0.9$、$\beta_2=0.99$。
6. 动态场景使用同样超参，但 batch size 4。
7. 推理时移除 sigmoid，使用硬 threshold $T_i$ 做 fragment pruning。
8. 在 OpenGL-based renderer 上 benchmark Jetson Orin NX，渲染分辨率固定 1080P。

## 7. 实验设置与结果摘要

静态场景数据集包括 Mip-NeRF360 的 9 个 scenes、Tanks&Temples 的 Train/Truck、Deep Blending 的 DrJohnson/Playroom。动态场景使用 Plenoptic Video Dataset 的 6 个 real-world video sequences。速度在 Jetson Orin NX 上测量，分辨率 $1920\times1080$。

Profiling 表 1 显示 rasterization 是主要瓶颈。Primitive pruning 后 Projection 和 Sorting 获得明显加速，但 Rasterization 加速不足，因为 fragment count 未等比例下降。

静态结果表 2 中，Fragment Pruning 应用于 3DGS 可将 FPS 从 Mip-NeRF360/Tanks&Temples/Deep Blending 的 20/16/18 提升到 37/36/44，同时 PSNR 也略有提升。与 Mini-Splatting 结合后，FPS 达到 54/60/60，其中 Tanks&Temples 和 Deep Blending 达到 60 FPS cap。作者报告在 Tanks&Temples 上，3DGS+Fragment Pruning 相比 Mini-Splatting 还高 0.57 PSNR 和 1 FPS。

动态结果表 3 中，将 Fragment Pruning 加到 4DGS 后，PSNR 从 32.01 到 32.04，LPIPS 从 0.055 到 0.053，FPS 从 14 到 22，平均速度提升约 +8 FPS，且直接使用静态场景超参。

限制表 4 显示 fine-tuning 带来额外时间：在 A5000 GPU 上，3DGS 后处理 fine-tuning 约为 pre-training 时间的 16%-21%，例如 Mip-NeRF360 预训练 45.2 min、fine-tuning 7.7 min；Mini-Splatting 上 fine-tuning 为 2.2-3.4 min。

## 8. 声称贡献与实际技术增量

* 声称贡献 1: 发现 fragment count 是 3DGS 渲染瓶颈。实际证据来自 Jetson Orin NX profiling，primitive pruning 并未显著降低 rasterization fragment count。
* 声称贡献 2: Fragment pruning。实际增量是 per-Gaussian learned truncation threshold，裁剪 Gaussian 的 2D support。
* 声称贡献 3: 可微 threshold learning。实际实现是 sigmoid approximation fine-tuning，推理回到硬 threshold。
* 声称贡献 4: Orthogonal to primitive pruning。实验显示可叠加 Mini-Splatting 和 4DGS。
* 与 sparse-view 研究的关系: 这里的 sparse 指 fragments/rendering support 更 sparse，不解决 sparse input views 的欠约束。

## 9. 局限与隐含假设

* 需要 post-training fine-tuning，增加约 16%-21% 额外训练时间。
* 只微调 thresholds 和 opacity，若原模型几何/颜色已有严重错误，fragment pruning 不能修复根本重建问题。
* 方法依赖 renderer 支持 per-Gaussian truncation threshold，需改 OpenGL renderer。
* FPS 结果在 Jetson Orin NX 和 1080P 下测得，其他 GPU/分辨率收益可能不同。
* 过度裁剪可能丢失透明/边缘细节，虽然实验中平均质量不降反升，但需要场景级验证。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法类别 | Fragment-level 3DGS rendering acceleration |
| 核心模块 | Per-Gaussian truncation threshold; sigmoid fine-tuning; hard threshold inference |
| 输入 | Pre-trained 3DGS / Mini-Splatting / 4DGS |
| sparse 含义 | Sparse fragments, not sparse training views |
| 优化变量 | $T_i$ and opacity $o_i$ |
| 推理收益 | Reduced fragment count, faster rasterization |
| 主要优势 | Orthogonal to primitive pruning; edge GPU FPS gains |
| 主要代价 | Additional fine-tuning and renderer modification |

## 11. 对我研究可复用的组件

* **Fragment count profiling**: 评估 GS 方法时不要只看 Gaussian 数量，也要看 $\#F$ 和 $\#F/\#G$。
* **Per-Gaussian threshold**: 可用于 sparse-view 方法后处理，减少训练后浮动边缘和高 fragment 区域。
* **Threshold-only fine-tuning**: 只动 threshold/opacity，可降低过拟合和避免破坏几何。
* **Combine with pruning**: 与 Speedy-Splat/Mini-Splatting/DropGaussian 等方法可组合。
* **Edge-device metric**: 直接在 Jetson/移动 GPU 上测 FPS，比桌面 GPU 更能反映部署价值。

## 12. 缺口与想法种子

* **Sparse-view uncertainty thresholding**: 将 $T_i$ 与 Gaussian uncertainty/covisibility 关联，低可信 Gaussians 更强裁剪。
* **Joint train-time fragment regularization**: 不做 post-training，而是在 3DGS 训练中同时学习 thresholds，减少额外 fine-tuning。
* **View-adaptive threshold**: 当前 $T_i$ 是 Gaussian-level，可扩展为 view-dependent threshold，适应不同视角边缘/遮挡。
* **Fragment pruning + anti-floater**: 高 fragment density 边缘可能对应 floaters，可与 CoMapGS/CoherentGS 的几何正则结合。
* **Dynamic temporal threshold smoothness**: 在 4DGS 中对同一 Gaussian 的 thresholds 加时间平滑，避免动态闪烁。

## 13. 人工检查清单

* `NEED_HUMAN_CHECK`: 原文 Eq. (4) alpha compositing 下标疑似笔误。
* `NEED_HUMAN_CHECK`: $E_i(p)$ 的具体符号定义在主文中简略，应确认是 exponent term 还是其负值。
* `NEED_HUMAN_CHECK`: sigmoid temperature $t$ 的具体取值。
* `NEED_HUMAN_CHECK`: discussion 7.2 后续内容是否有更多限制，PDF 抽取主要给出 fine-tuning overhead。

## 14. 证据锚点

* Abstract: 提出 fragment pruning，并报告 Jetson Orin NX 上 up to $1.71\times$ speedup 和 Tanks&Temples +0.16 PSNR。
* Fig. 1: fragment density 与 FPS/PSNR tradeoff。
* Sec. 1: primitive pruning 不能等比例提升速度的原因是 fragment count 未下降。
* Sec. 3 / Eq. (1)-(6): 3DGS primitive、projection、sorting、rasterization 和 fixed truncation。
* Table 1 / Sec. 4: rasterization bottleneck、$\#G$ 与 $\#F$ profiling。
* Sec. 5.1 / Eq. (8)-(9): fragment count 和 per-Gaussian threshold。
* Sec. 5.2 / Eq. (10): sigmoid approximation。
* Sec. 6.1-6.2: datasets、Jetson Orin NX、1080P、fine-tuning setup。
* Table 2: Mip-NeRF360、Tanks&Temples、Deep Blending static results。
* Table 3: Plenoptic Video dynamic results。
* Fig. 3 / Appendix Fig. 4-5: qualitative comparisons and fragment density visualization。
* Table 4 / Sec. 7.1: fine-tuning overhead limitation。
