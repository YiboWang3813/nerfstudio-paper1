# LoopSparseGS: Loop-Based Sparse-View Friendly Gaussian Splatting

## 0. Metadata

* Title: LoopSparseGS: Loop-Based Sparse-View Friendly Gaussian Splatting
* Authors: Zhenyu Bao, Guibiao Liao, Kaichen Zhou, Kanglin Liu, Qing Li, Guoping Qiu
* Year: 2025
* Venue: IEEE Transactions on Image Processing, Vol. 34
* PDF source: Zotero local PDF
* Zotero item key: 4T2CPCEL
* Zotero PDF attachment key: YW5RP6KG
* PDF path: `/Users/wangyibo/Zotero/storage/YW5RP6KG/Bao 等 - 2025 - LoopSparseGS Loop-Based Sparse-View Friendly Gaussian Splatting.pdf`
* Note path: `notes/LoopSparseGS: Loop-Based Sparse-View Friendly Gaussian Splatting.md`
* Code: https://github.com/pcl3dv/LoopSparseGS
* Project page: Not specified
* Dataset link: Not specified
* Main task: sparse-input novel view synthesis with 3D Gaussian Splatting
* Domain: sparse-view 3DGS, geometry regularization, Gaussian densification
* Input: sparse posed images, SfM points/cameras, monocular depth from MiDaS
* Output: denser and better regularized 3DGS for novel view rendering

## 1. One-Sentence Technical Summary

LoopSparseGS 通过循环式 Progressive Gaussian Initialization 迭代生成伪视角并重新跑 SfM 增密初始点云，再用 scale-consistent PGI depth 与 scale-inconsistent monocular depth 做 sliding-window alignment，最后用 Sparse-friendly Sampling 拆分导致高误差像素的 oversized Gaussians。

## 2. Problem Formulation

稀疏输入下 vanilla 3DGS 有三个核心问题：SfM 初始点太少，只有 photometric supervision 时几何欠约束，部分 Gaussian ellipsoids 会因为邻域稀疏或训练视角过少而变得过大，造成 novel view 中的模糊和局部错误。已有 FSGS、DNGaussian、CoR-GS 等方法分别引入 proximity densification、monocular depth 或 auxiliary model，但仍存在初始点不可靠、深度尺度不一致或几何先验不足的问题。

本文的目标不是重写 3DGS renderer，而是在 sparse-view 场景下增强初始化、深度约束和 densification 选择，使 3DGS 更适合只有少量输入视角的 NVS。

## 3. Method Overview

方法由三个模块组成。PGI 在每轮 3DGS 训练后从训练视角附近生成 pseudo cameras，渲染 pseudo RGB images，与原始训练图像一起输入 SfM，获得更多初始化点。DAR 使用 PGI 产生的 scale-consistent sparse depth 与 MiDaS monocular depth 共同约束渲染深度，并用 sliding window Pearson loss 做局部尺度对齐。SFS 根据训练视图中的高 PSNR error pixels 找到贡献最大的 Gaussian 进行 split，同时对非最大权重 Gaussians 做 opacity regularization。

整体是一个 loop-based pipeline：每轮重建带来更密的初始化点和更可靠的 PGI depth，下一轮 3DGS 再在这些几何约束下优化。

## 4. Method Details

### 4.1 Progressive Gaussian Initialization

PGI 的观察是：即使 sparse-input 3DGS 的远距离 novel views 质量差，靠近训练视角的 rendered views 通常仍可用。因此，方法在每个 loop round 为每个训练视角生成 4 个 pseudo views，总数为 $P\times4$，其中 $P$ 是训练视图数。pseudo camera 位置由训练相机位置加 Gaussian noise 得到，并随 loop index $l$ 扩展采样半径：

$$
z_{i,j}^{g,l}=N(z_j^t,\epsilon+\delta l),\quad j\in[1,P], i\in[1,4]
$$

其中 $\epsilon=0.02$、$\delta=0.1$。早期伪相机靠近训练视角以保证渲染质量，后续逐步扩大覆盖范围。pseudo orientation 取相邻训练视角 orientation 的平均值。每轮新增的 pseudo images 会与训练图像一起输入 SfM，产生新的初始化点；先前 loop 的 pseudo images 也会累积使用。

### 4.2 Depth-Alignment Regularization

PGI 产生的点云可以投影成 sparse but scale-consistent depth，即 PGI depth；MiDaS 提供 dense but scale-inconsistent monocular depth。DAR 先对 PGI depth 做三类过滤：去除 SfM match error 大于阈值 2 的点；丢弃只由 pseudo views 匹配出来的点；只保留从当前视角可见的 3D points。过滤后的 PGI depth 用作绝对尺度锚点。

为避免整图 Pearson correlation 无法处理局部错位，DAR 在 rendered depth 和 monocular depth 上滑动窗口，计算 window-level Pearson distribution loss。最终深度对齐损失为：

$$
L_a=\lambda_dL_1(D_p,D_c)+\sum_{w=1}^{W}\lambda_pL_p[\chi_w(D_p),\chi_w(D_m)]
$$

其中 $D_p$ 是 rendered depth，$D_c$ 是 SfM-derived / PGI depth，$D_m$ 是 monocular depth，$\chi_w$ 表示第 $w$ 个窗口。这个损失把稀疏的绝对尺度深度与稠密的相对深度局部对齐。

### 4.3 Sparse-friendly Sampling

SFS 处理 sparse-view 下 oversized ellipsoids 导致的 blur。方法遍历训练视图所有 rendered pixels，收集 PSNR error 最大的像素；由于每个像素颜色由多个 Gaussians alpha blending 得到，SFS 找到沿该 ray 权重最大的 ellipsoid：

$$
\omega_i=\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j)
$$

然后对这些主导高误差像素的 oversized Gaussians 进行 split，实验中每个拆成 $m=2$ 个小 ellipsoids。与此同时，对同一 ray 上非最大权重 ellipsoids 加 opacity regularization，降低它们用错误颜色补偿主 Gaussian 的机会。

## 5. Mathematical Objectives and Losses

3DGS 基础渲染采用 front-to-back alpha blending：

$$
C=\sum_{i\in N}c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j)
$$

标准 color loss 为：

$$
L_{color}=(1-\lambda)L_1(\tilde{I},I)+\lambda L_{D-SSIM}(\tilde{I},I)
$$

完整优化目标为：

$$
L=\lambda_1L_1(C_p,C_{gt})+\lambda_2L_{D-SSIM}(C_p,C_{gt})+L_a+L_o
$$

其中 $L_a$ 是 depth-alignment loss。非最大权重 opacity 正则为：

$$
L_o=\frac{\lambda_o}{N}\sum_{n=1}^{N}|\alpha_n|
$$

$L_1$、$L_{D-SSIM}$ 和 $L_o$ 在训练视图上计算，$L_a$ 在训练视图和 pseudo views 上计算。

## 6. Training and Inference Procedure

实现使用 PyTorch、COLMAP 和 MiDaS。每个 dataset 默认运行 3 个 loop，每轮训练 10000 iterations；每个训练相机每轮生成 4 个 pseudo cameras。Gaussian densification 从 1000 iterations 后开始，频率为 200 iterations，2D gradient threshold 为 0.0005。sliding window 长度为 32，step size 为 4。损失权重 $\lambda_1=0.8$、$\lambda_2=0.2$、$\lambda_o=0.05$、$\lambda_d=0.005$、$\lambda_p=0.05$。

推理阶段是标准 3DGS rasterization，不需要继续跑 SfM、MiDaS 或 PGI loop。论文报告 LLFF、Mip-NeRF360、DTU、Blender 上平均渲染速度分别约 418、490、831、720 FPS，训练耗时约每 loop 10 分钟，总计 35-45 分钟，硬件为 NVIDIA 3090。

## 7. Experimental Setup and Results Summary

实验数据集包括 LLFF、Mip-NeRF360、DTU 和 Blender。LLFF 使用 3/6/9 sparse views，Mip-NeRF360 使用 24 views，DTU 使用 3 views，Blender 使用 8 views。指标为 PSNR、SSIM、LPIPS。对比方法包括 Mip-NeRF、FreeNeRF、SparseNeRF、FSGS、DNGaussian、RegSegField、CoR-GS、MVPGS 等。

主结果显示，LoopSparseGS 在四类场景上都取得强表现：LLFF 3-view 下达到最高 PSNR，6/9 views 下保持最好或接近最好；Mip-NeRF360 上相对 FSGS 在两个分辨率分别提升 0.39 和 1.02 PSNR，并相对 CoR-GS 有小幅 PSNR 优势；DTU 3-view 上相对 DNGaussian、RegSegField、CoR-GS、MVPGS 分别提升 1.77、1.71、1.47、0.03 PSNR；Blender 8-view 上相对第二名提升 0.92 PSNR。

消融表明，DAR、PGI、SFS 都有独立收益，其中 PGI 带来约 0.803 PSNR 增益，SFS 带来约 0.282 PSNR 增益，三者组合最好。深度对齐消融显示 SfM depth、monocular depth 和 window-level Pearson alignment 互补。loop 数过多会退化，因为后期 pseudo views 离训练视角太远，会引入不准初始化点；最终选择 3 loops。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 loop-based sparse-view friendly 3DGS、PGI、DAR、SFS。实际技术增量主要是把“渲染伪视角再跑 SfM”做成 3DGS 初始化循环，并用这个循环产生的 sparse absolute depth 作为 monocular depth 的尺度锚点。SFS 则把 densification 触发从 ellipsoid-level gradient / weight 改成 pixel-error-driven max-weight Gaussian split。

与 FSGS 相比，它不是只在已有 Gaussian 邻域做 unpooling，而是尝试通过伪视角 SfM 生成新的几何点。与 DNGaussian 相比，它没有只依赖 scale-inconsistent monocular depth，而是引入 PGI depth 做绝对尺度。与 CoR-GS 相比，它不需要 auxiliary 3DGS model，但代价是多轮 SfM 和训练。

## 9. Limitations and Hidden Assumptions

方法依赖 COLMAP / SfM 在 sparse views 和 pseudo views 上仍能稳定产生匹配。作者在结论中明确指出，多高光输入会让 COLMAP 难以准确重建，从而限制方法效果。PGI 还假设靠近训练视角的 early rendered pseudo images 足够可信；如果 baseline 3DGS 初期已经严重错误，伪视角可能污染后续 SfM。

另一个隐含成本是循环训练和多次 SfM。虽然推理仍很快，但训练时间和工程复杂度高于单阶段正则化方法。DAR 使用 MiDaS，monocular depth 的域外泛化也会影响最终几何。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| 核心任务 | Sparse-view 3DGS novel view synthesis |
| 输入 | Sparse posed images, SfM, MiDaS monocular depth |
| 关键模块 | PGI loop, DAR, SFS |
| 几何先验 | PGI / SfM sparse absolute depth + monocular relative depth |
| Densification 策略 | 按高误差像素找到 max-weight Gaussian 并 split |
| 训练代价 | 3 loops，每轮 10000 iterations，多次 SfM |
| 主要优势 | 增密初始化点、改善深度约束、减少 oversized Gaussian blur |
| 主要风险 | 依赖 SfM 和伪视角可靠性，高光/反射场景弱 |

## 11. Reusable Components for My Research

1. PGI 可以作为 general sparse-view bootstrap：先用保守 pseudo views 增密，再逐步扩大视角范围。
2. DAR 的 window-level depth alignment 适合任何同时使用 sparse metric depth 和 dense monocular depth 的 3DGS 方法。
3. SFS 的 pixel-error-driven max-weight split 可以与 uncertainty 或 view-consistency error 结合，替代单纯 gradient threshold densification。
4. PGI depth filter 的三条规则可复用到伪标签筛选：匹配误差、是否只来自伪视角、当前视角可见性。

## 12. Gap and Idea Seeds

1. 用 MASt3R / DUSt3R 替代 COLMAP 参与 PGI，减少高光和纹理弱场景下的 SfM 失败。
2. 将 PGI pseudo view selection 改成 uncertainty-aware active view generation，而不是固定每个训练视角 4 个局部噪声相机。
3. 把 DAR 中的 MiDaS depth 换成 foundation depth model ensemble，并用 depth uncertainty 调节 $\lambda_p$。
4. 将 SFS 与 DropoutGS / DropGaussian 结合：高误差 max-weight Gaussian split，低置信 non-max Gaussians dropout。
5. 把 loop 终止条件改成验证 novel-view consistency 或新增 SfM point 收益，而不是固定 3 loops。

## 13. Human Check List

* NEED_HUMAN_CHECK: 表格中的逐场景数值在 PDF 文本抽取中不完整，如需做精确横向矩阵，应回看原 PDF 表格图像。
* NEED_HUMAN_CHECK: Eq. 3 在文本抽取中符号略乱，note 中按作者描述重写为“训练相机位置加随 loop 扩大的 Gaussian noise”，需与 PDF 公式截图核对。
* NEED_HUMAN_CHECK: SFS Algorithm 1 的逐步伪代码没有完全抽取，复现时需看原论文算法框。
* 已确认：公式格式按仓库 inline / display dollar 规范书写。

## 14. Evidence Anchors

* Abstract: 概括三大问题和 PGI / DAR / SFS 三个模块，并给出代码链接。
* Section I, Introduction: 指出 sparse-view 3DGS 的 sparse SfM points、geometry under-constraint、oversized Gaussian ellipsoids 三个问题。
* Section III-B, PGI: 描述每个训练视角每轮生成 4 个 pseudo views，随 loop 扩大采样范围，并将 pseudo images 与 training images 一起输入 SfM。
* Section III-C, DAR: 给出三种 depth filter strategy、sliding-window Pearson alignment 和 Eq. 7。
* Section III-D/E, SFS and Optimization: 给出 high-error pixel traversal、max-weight Gaussian split、opacity regularization、Eq. 8 和 Eq. 9。
* Section IV-A: 数据集、指标、实现细节、loop 数、窗口大小、损失权重、训练/渲染速度。
* Section IV-B/C: LLFF、Mip-NeRF360、DTU、Blender 主结果，以及 DAR、PGI、SFS、loop 数、pseudo view 数和 threshold 消融。
* Section V, Conclusion: 明确指出高光场景中 COLMAP 难以重建是局限，并建议 learning-based pose estimation 和 vision foundation models。
