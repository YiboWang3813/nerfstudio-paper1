# Variational Multi-scale Representation for Estimating Uncertainty in 3D Gaussian Splatting

## 0. Metadata

* Title: Variational Multi-scale Representation for Estimating Uncertainty in 3D Gaussian Splatting
* Authors: Ruiqi Li; Yiu-ming Cheung
* Year: 2024
* Venue: NeurIPS
* PDF source: `/Users/wangyibo/Zotero/storage/RRL7TBNB/Li和Cheung - 2024 - Variational Multi-scale Representation for Estimating Uncertainty in 3D Gaussian Splatting.pdf`
* Zotero item key: `KHBM99IL`
* Zotero PDF attachment key: `RRL7TBNB`
* Code: Not specified
* Project page: Not specified
* Dataset link: LF, LLFF, Mip-NeRF 360
* Main task: uncertainty estimation for 3D Gaussian Splatting
* Domain: Bayesian 3DGS, variational inference, uncertainty maps, floater removal
* Input: calibrated multi-view images
* Output: 3DGS rendering with predictive uncertainty and posterior uncertainty per Gaussian
* Main representation: base 3DGS plus local multi-scale offset table around selected base Gaussians
* Supervision type: variational inference with reconstruction loss and KL regularization
* Core contribution in one sentence: 通过在重要大尺度 Gaussian 周围学习局部多尺度 offset table，用 variational inference 近似参数 posterior，从而在保持 3DGS 渲染质量的同时估计 predictive uncertainty。
* Note status: `complete`

## 1. 一句话技术摘要

This paper addresses uncertainty estimation in deterministic 3DGS by using a variational local multi-scale Gaussian representation to transform point-estimated Gaussian parameters into posterior samples, with the key technical novelty being an offset table that samples position/scale/opacity perturbations around base Gaussians.

## 2. 问题形式化

标准 3DGS 是 deterministic/MLE 训练，缺少 uncertainty quantification。论文希望在不训练多个 ensemble 3DGS 的情况下，估计 rendered color/depth 的 predictive uncertainty，并用 posterior uncertainty 删除 noisy floaters。

每个 Gaussian 参数为 $\theta=\{p,c,\alpha,S,R\}$。方法对重要 base Gaussians 生成 finer multi-scale alternatives，但不真正复制大量完整 Gaussian，而是用 offset table 存储 position、scale、opacity 的 offset distribution。

## 3. 方法概览

核心思想：

1. 选出 scale、opacity、gradient magnitude 较大的 base Gaussians。
2. 为每个 base Gaussian 创建 offset table $\phi$，表示 $K$ 个 finer Gaussians 的 offset distribution。
3. 颜色 $c$ 和 rotation $R$ 共享 base Gaussian，只对 position $p$、scale $S$、opacity $\alpha$ 学 offset。
4. 用 variational inference 学 offset posterior。
5. 推理时从 posterior 采样多次，渲染预测分布，计算 uncertainty。

## 4. 方法细节

### 4.1 Local multi-scale representation

选择 base Gaussians 的条件是 scale 和 opacity 超过阈值，同时 gradient magnitude 过滤掉远背景等 trivial Gaussians。对 base Gaussian 生成局部 finer Gaussians。新位置和尺度由 offset 得到：

$$
p^* = p + \chi_p,\quad S^* = S + \chi_S
$$

offset table 有 $K$ 个 entries，但每次随机等概率选择 $M$ 个 entries 并平均，得到最终 offset distribution parameters $\tilde{\phi}$。这样构造随机多尺度替代，提高参数空间样本多样性。

### 4.2 Offset posterior inference

目标是用变分分布 $q(\chi)$ 近似真实 posterior $p(\chi|D)$，最小化 KL：

$$
d_{KL}[q(\chi)\|p(\chi|D)] = -\mathbb{E}_{\chi \sim q(\chi)}[\log p(\chi,D)-\log q(\chi)] + \log p(D)
$$

position offset 和 scale offset 的 prior 分别设为 normal 和 uniform。scale offset prior 让新 scale 范围与 base scale 相关：

$$
q(\chi_S) \sim U(-(1/K)S_{base},0),\quad q(\chi_p) \sim N(0,\delta^2)
$$

主文排版中 scale prior 写法等价表达为新 scale 范围 $[(1-1/K)S_{base},S_{base}]$。position prior 零均值，鼓励 finer Gaussians 位于 base Gaussian 周围。

### 4.3 Training objective

训练时采样 offset $\chi$，渲染图像，计算原始 3DGS 的 image losses，并加 KL：

$$
\mathcal{L}_{total} = \mathcal{L}_1(\hat{c},c) + \mathcal{L}_{SSIM}(\hat{c},c) + d_{KL}[q(\chi)\|p(\chi)]
$$

推理时通过 marginalization 得到 predictive distribution：

$$
p(c|x,D) = \mathbb{E}_{\chi \sim p(\chi|D)}[p(c|x,\chi)]
$$

用多次采样渲染的方差作为 uncertainty。

## 5. 数学目标和损失

该方法是 Bayesian/variational extension，但只对 offset table 做 posterior approximation，不对所有 3DGS 参数做 full Bayesian inference。重建项仍是 3DGS 常规 L1 + SSIM，KL 项让 offset posterior 接近 multi-scale prior。

重要实现点：color 和 rotation 共享 base Gaussian，主要通过 position/scale/opacity 的随机 offset 建模 uncertainty，因此 computational cost 低于 ensemble。

## 6. 训练和推理流程

训练伪代码见 Algorithm 1：

1. 常规 3DGS 训练过程中每隔 $t$ steps 检查是否 spawn。
2. 选择 $G_{base}$：满足 gradient、scale、opacity 阈值。
3. 创建 offset table $\phi=\{\phi_S,\phi_p,\phi_\alpha\}$ 并分配 prior。
4. 每次训练采样 offset，渲染图像。
5. 计算 $\mathcal{L}_1$、$\mathcal{L}_{SSIM}$ 和 KL。
6. 优化 base parameters $\theta$ 和 offset table $\phi$。

实现使用 AdamW；$K=10$ finer Gaussians；offset table 学习率为对应 3DGS attribute 学习率的 0.1；实验在单张 A100 上。

## 7. 实验设置与结果摘要

数据集：

* LF dataset: 8 个 dense 360 scenes，使用 torch、basket、africa、statue。
* LLFF: 8 个 forward-facing scenes。
* Mip-NeRF 360: 6 个 outdoor scenes，用于 floater removal。

uncertainty 指标：

* AUSE with MAE: 衡量 uncertainty 与真实 error 的排序相关性。
* NLL: 衡量 predictive distribution 对 ground truth 的 likelihood。

结果：

* Table 1: depth uncertainty 在 LF 上平均 AUSE 0.19，优于 CF-NeRF、S-NeRF、Bayes' Ray，略优于 Ensemble GS 的 0.20。
* Table 2: rendered image uncertainty 在 LF 上 AUSE 0.26，优于 Ensemble GS 的 0.29；LLFF 上 NLL 0.23 最好。
* 渲染质量接近 ensemble，但不需要训练 10 个 3DGS。
* Fig. 5: 用 posterior uncertainty 删除高不确定 Gaussians，可自动去除 Mip-NeRF 360 背景 floaters，保留前景物体。

## 8. 声称贡献 vs 实际技术增量

论文声称提出 probabilistic framework for uncertainty estimation in 3DGS。实际增量是非常工程友好的局部 posterior 建模：只对重要 Gaussian 附近的 offset 做随机多尺度建模，不对整套 3DGS 参数做昂贵 Bayesian inference。

这种 uncertainty 比 PUP 的 Fisher sensitivity 更接近 posterior/predictive uncertainty；但它依赖 offset table 设计和 prior 选择，并非全模型 posterior。

## 9. 局限性和隐藏假设

* posterior 只覆盖 offset table，不覆盖颜色/rotation 等全部参数。
* base Gaussian 选择阈值会影响 uncertainty 质量。
* scale prior 和 position prior 是手工设计，可能对不同场景不最优。
* 多次采样推理比单次 3DGS 慢，尽管比 ensemble 便宜。
* 对动态场景未验证。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 任务 | 3DGS uncertainty estimation |
| 输入 | calibrated images |
| 输出 | predictive uncertainty maps, cleaned Gaussians |
| 表示 | base Gaussians + variational multi-scale offset table |
| 关键模块 | base Gaussian selection, offset posterior, Monte Carlo rendering |
| 关键损失 | L1, SSIM, KL divergence |
| 主要优点 | uncertainty calibration 好，成本低于 ensemble |
| 主要风险 | posterior 覆盖范围有限，依赖手工 prior/threshold |

## 11. 可复用组件

* offset table 可用于给 3DGS 引入轻量 stochasticity。
* posterior uncertainty 可用于 automatic floater removal。
* local multi-scale sampling 可作为 densification 的 probabilistic variant。

## 12. Gap 和 idea seeds

* 将 offset posterior 用于 active view selection 或 dynamic Gaussian densification。
* 把 uncertainty 与 PUP Fisher score 结合，区分“参数 posterior 大”和“训练误差不敏感”。
* 对 4DGS，可在 motion parameters 上建立 offset posterior，估计 temporal uncertainty。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: Appendix B 中 opacity offset prior 和完整实现细节需复核。
* `NEED_HUMAN_CHECK`: Algorithm 1 的 KL 写法与正文 $d_{KL}[q\|p]$ 方向在排版中需核对。

## 14. Evidence Anchors

* Sec. 3.1: uncertainty quantification preliminaries。
* Sec. 3.2: local multi-scale 3D Gaussian, Eq. (3)。
* Sec. 3.3: offset posterior inference, Eq. (4)-(7), Algorithm 1。
* Sec. 4.1: datasets, metrics, baselines, implementation。
* Table 1-2: uncertainty and rendering quality。
* Fig. 4: uncertainty map visualization。
* Fig. 5: noisy floater removal。
