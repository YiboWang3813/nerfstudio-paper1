# 3D Geometry-aware Deformable Gaussian Splatting for Dynamic View Synthesis

## 0. Metadata

* Title: 3D Geometry-aware Deformable Gaussian Splatting for Dynamic View Synthesis
* Authors: Zhicheng Lu; Xiang Guo; Le Hui; Tianrui Chen; Min Yang; Xiao Tang; Feng Zhu; Yuchao Dai
* Year: 2024
* Venue: CVPR 2024
* PDF source: `/Users/wangyibo/Zotero/storage/VD895MTX/Lu 等 - 2024 - 3D Geometry-aware Deformable Gaussian Splatting for Dynamic View Synthesis.pdf`
* Zotero item key: T2MFSFBL
* Zotero PDF attachment key: VD895MTX
* Local note path: `/Users/wangyibo/Documents/ZoteroLocalNotes/notes/3D Geometry-aware Deformable Gaussian Splatting for Dynamic View Synthesis.md`
* Code: `https://npucvr.github.io/GaGS/`
* Project page: `https://npucvr.github.io/GaGS/`
* Dataset link: Not specified
* Main task: dynamic view synthesis from monocular video / dynamic scene inputs
* Domain: dynamic Gaussian Splatting, deformation modeling, geometry-aware feature encoding
* Input: image sequence or monocular video of a dynamic scene with timestamps and known camera intrinsics/extrinsics
* Output: novel view rendering at arbitrary view and timestamp
* Main representation: canonical 3D Gaussians plus geometry-aware deformation field
* Supervision type: image reconstruction supervision with motion regularization
* Core contribution in one sentence: 将 3D Gaussians 当作点云体素化，用 sparse 3D U-Net 提取局部几何特征，再与逐 Gaussian identity feature 融合来预测每个 Gaussian 的位置、6D 旋转和尺度变形，从而让动态形变学习显式利用 3D 几何结构。
* Note status: `partial`

`partial` 的原因：核心方法、损失和主要实现超参已给出，但 sparse 3D U-Net 的层级结构、voxel size、density-control 阈值等复现细节需要代码确认。

## 1. One-Sentence Technical Summary

这篇论文处理 dynamic view synthesis 中形变场缺少 3D 几何约束的问题，通过把 canonical 3D Gaussians 视作点云并体素化，用 sparse 3D U-Net 提取局部几何特征，再由 MLP deformation decoder 预测每个 Gaussian 在时间 $t$ 的 $\Delta x_t,\Delta r_t,\Delta s_t$，关键技术增量是用真实 3D 空间中的 sparse convolution 代替纯 positional encoding 或 2D/plane interpolation 来建模局部一致形变。

Evidence: Abstract, Fig. 1-2, Sec. 3.2-3.3, PDF p.1-5.

## 2. Problem Formulation

### 2.1 Task Definition

* 任务：给定动态场景视频和相机参数，在任意目标时间与目标视角合成图像。
* 输入：动态图像序列、timestamp $t$、camera intrinsic $K$、extrinsic $[R|T]$。
* 输出：目标时间下变形后的 3D Gaussians 以及 rasterized image $\hat{C}_t$。
* 假设：动态场景可以由一个 canonical Gaussian field 加 deformation field 表示；局部几何结构对真实形变具有强约束。
* 优化目标：用 photometric loss 监督渲染图像，同时用 motion loss 抑制不必要的大位移，并用动态版 density control 维护 Gaussian 分布。

Evidence: Sec. 3, Sec. 3.5, PDF p.3-5.

### 2.2 Formal Notation

| Symbol | Meaning | Evidence |
| ------ | ------- | -------- |
| $G(x)$ | 3D Gaussian density | Eq. 1 |
| $\Sigma$ | Gaussian covariance | Eq. 1-2 |
| $S,R$ | scaling and rotation matrix | Eq. 2 |
| $x,c,r,s,o$ | canonical Gaussian position, color, rotation, scale, opacity | Sec. 3.1-3.2 |
| $[a_1,a_2]$ | 6D rotation vector before mapping to SO(3) | Sec. 3.2 |
| $f_{V2M}$ | mapping from 6D representation to rotation matrix | Eq. 5-6 |
| $P\in\mathbb{R}^{N\times 3}$ | Gaussian centers treated as point cloud | Sec. 3.2 |
| $V$ | voxelized point cloud coordinates | Eq. 7 |
| $F_v,F_p,F_{fuse}$ | voxel feature, point identity feature, fused geometry-aware feature | Sec. 3.2, Eq. 8 |
| $G_\Phi$ | deformation decoder MLP | Eq. 9 |
| $\Delta x_t,\Delta r_t,\Delta s_t$ | predicted position, rotation, scale deformation | Eq. 9 |
| $\gamma(\cdot)$ | NeRF positional encoding | Eq. 10 |

### 2.3 Why This Problem Is Hard

| Claimed difficulty | Technical reason | Evidence |
| ------------------ | ---------------- | -------- |
| Dynamic view synthesis needs complex 3D deformation | monocular observation has motion / shape ambiguity | Introduction |
| Point-level positional encoding lacks neighborhood structure | independent MLP features cannot capture local geometric consistency | Fig. 1, Introduction |
| Grid interpolation has limited geometry extraction | interpolation receptive field is limited and can introduce artifacts | Introduction, Related Work |
| Plane projection loses 3D information | 4D / plane decomposed representations compress 3D space to 2D planes | Sec. 2.2 |
| Static 3D-GS density control is not directly suitable | dynamic scene needs evaluate split/clone under transformed timestamp attributes | Sec. 3.5, Fig. 3 |

## 3. Method Overview

### 3.1 High-Level Pipeline

Step 1:
Input: images / monocular video with camera parameters and timestamps.
Operation: optimize canonical 3D Gaussians in a static canonical field.
Output: canonical Gaussian parameters $x,c,r,s,o$.
Purpose: provide an explicit point-like scene representation.
Evidence: Sec. 3, Fig. 2.

Step 2:
Input: Gaussian centers $P$.
Operation: voxelize centers by $V=\mathrm{floor}(P/s)$ and run sparse 3D U-Net over sparse voxels.
Output: voxel-level geometry feature $F_v$.
Purpose: aggregate local geometry across different receptive fields in true 3D space.
Evidence: Sec. 3.2, Eq. 7.

Step 3:
Input: Gaussian centers $P$.
Operation: use an identity MLP to map each point coordinate to point-level feature $F_p$.
Output: independent high-resolution point feature.
Purpose: preserve per-Gaussian identity and high-resolution point distinction.
Evidence: Sec. 3.2.

Step 4:
Input: voxel feature $F_v$ and point feature $F_p$.
Operation: de-voxelize / assign voxel features to points, concatenate $F'_p$ and $F_p$, then fuse by MLP.
Output: geometry-aware feature $F_{fuse}$.
Purpose: combine local structural context with point identity.
Evidence: Eq. 8.

Step 5:
Input: $F_{fuse}$, positional encoding $\gamma(x)$, timestamp encoding $\gamma(t)$.
Operation: deformation MLP $G_\Phi$ predicts $\Delta x_t,\Delta r_t,\Delta s_t$.
Output: transformed Gaussian parameters $x_t,s_t,r_t$.
Purpose: model dynamic motion and shape deformation for each Gaussian.
Evidence: Sec. 3.3, Eq. 9-11.

Step 6:
Input: transformed Gaussians and camera parameters.
Operation: differentiable tile rasterizer renders $\hat{C}_t$, optimized by photometric and motion losses; density control uses timestamp-transformed attributes.
Output: dynamic novel view image.
Purpose: render high-fidelity dynamic scene while maintaining adaptive Gaussian density.
Evidence: Sec. 3.4-3.5, Eq. 12-15, Fig. 3.

### 3.2 Core Idea

* Representation-level idea: use canonical 3D Gaussians as explicit dynamic scene primitives.
* Feature-level idea: extract true 3D local geometry via sparse 3D convolution, rather than relying only on positional encoding or 2D plane interpolation.
* Rotation-level idea: use continuous 6D rotation representation to make neural rotation prediction smoother than quaternion addition.
* Optimization-level idea: keep color and opacity constant over time, and predict only position, rotation, and scale deformation.
* Density-control idea: decide clone/split under transformed timestamp parameters, then inverse-transform new Gaussians back to canonical space.

Evidence: Introduction, Sec. 3.2-3.5.

### 3.3 Method Diagram Reconstruction

Figure 2 shows:
* input: dynamic images and canonical 3D Gaussian field.
* Gaussian canonical field: 3D Gaussians -> voxel point cloud; sparse 3D U-Net extracts geometric features; identity MLP extracts point features; concat + MLP creates fused features.
* deformation field: fused feature, position encoding and time encoding feed an MLP that predicts deformation.
* transform: canonical Gaussian parameters are moved/rotated/scaled to timestamp $t$.
* rasterization: 3D Gaussian rasterizer renders RGB image.

Evidence: Fig. 2, PDF p.3.

## 4. Method Details

### 4.1 Gaussian Canonical Field

* Module purpose: maintain canonical-space scene representation and provide geometry-aware features.
* Input: initial point cloud or random initialized points, training images.
* Output: canonical Gaussian parameters and fused point-level features.
* Internal operations: optimize Gaussian position/color/scale/opacity/rotation; use 6D rotation representation instead of quaternion.
* Architecture details: canonical field includes Gaussian parameters plus geometry feature learning network.
* Mathematical formulation: Eq. 1-8.
* Trainable parameters: Gaussian attributes, identity MLP, sparse 3D U-Net, fusion MLP.
* Hyperparameters: D-NeRF initializes 150000 random points; HyperNeRF uses provided point cloud.
* Why this module is needed: deformation needs local geometric structure, not isolated point features.
* What would happen without it: w/o geo. feat. PSNR drops from 38.0134 to 37.5757; PointNet / plane features are worse.
* Evidence anchor: Sec. 3.2, Table 4.

Implementation-level reconstruction:
* Treat Gaussian centers as point cloud $P$.
* Use grid size $s$ to voxelize, but exact $s$ is Not specified.
* Sparse 3D U-Net produces $M\times C$ voxel features.
* De-voxelize by assigning each point the feature of its containing voxel.
* Concatenate with identity point MLP features and fuse by another MLP.

Relation to prior work:
* Builds on 3D-GS explicit primitives, but adds sparse-conv 3D geometry feature extraction for dynamic deformation.

### 4.2 Continuous 6D Rotation Representation

* Module purpose: avoid discontinuity of quaternion representation in neural deformation learning.
* Input: two 3D vectors $a_1,a_2$.
* Output: SO(3) rotation matrix via normalized orthogonal basis $b_1,b_2,b_3$.
* Internal operations: normalize $a_1$, orthogonalize and normalize $a_2$, compute cross product.
* Architecture details: rotation is stored/predicted as 6D vector and mapped by $f_{V2M}$.
* Mathematical formulation: Eq. 5-6.
* Trainable parameters: 6D rotation vectors in canonical field and predicted $\Delta r_t$.
* Hyperparameters: none.
* Why this module is needed: smoother parameter space helps MLP learn time-varying rotation.
* What would happen without it: replacing 6D rotation with quaternion add degrades Table 4 metrics.
* Evidence anchor: Introduction, Sec. 3.2, Table 4.

Implementation-level reconstruction:
* Initialize $a_1=[1,0,0]^T$, $a_2=[0,1,0]^T$ for identity rotation.
* Compute $b_1=N(a_1)$.
* Compute $b_2=N(a_2-(b_1\cdot a_2)b_1)$.
* Compute $b_3=b_1\times b_2$ and stack as rotation matrix.

Relation to prior work:
* Directly adopts continuous rotation representation from Zhou et al. 2019 for neural networks.

### 4.3 Geometry-Aware Deformation Field

* Module purpose: predict per-Gaussian deformation at timestamp $t$.
* Input: $F_{fuse}$, $\gamma(x)$, $\gamma(t)$.
* Output: $\Delta x_t\in\mathbb{R}^3$, $\Delta r_t\in\mathbb{R}^6$, $\Delta s_t\in\mathbb{R}^3$.
* Internal operations: MLP decoder maps geometry-aware features and positional/time encodings to deformation parameters.
* Architecture details: 5-layer MLP with width 256 and skip connection.
* Mathematical formulation: Eq. 9-11.
* Trainable parameters: decoder MLP and Gaussian parameters.
* Hyperparameters: positional encoding $L=10$ for position and $L=6$ for timestamp.
* Why this module is needed: transforms canonical Gaussians into target-time Gaussians.
* What would happen without it: static 3D-GS cannot model dynamic deformation, producing poor results in Table 1.
* Evidence anchor: Sec. 3.3, Sec. 4.2.

Implementation-level reconstruction:
* Keep color $c$ and opacity $o$ constant over time.
* Update position by $x_t=x+\Delta x_t$.
* Update scale by $s_t=s+\Delta s_t$.
* Update rotation by $r_t=f_{V2M}(\Delta r_t)\times f_{V2M}(r)$.

Relation to prior work:
* Similar canonical field + deformation field pipeline as D-NeRF-like dynamic NeRF, but deformation is per Gaussian and geometry-aware.

### 4.4 Dynamic Density Control

* Module purpose: adapt 3D-GS clone/split strategy to dynamic transformed Gaussians.
* Input: transformed Gaussian attributes at timestamp $t$ and rendering gradients.
* Output: cloned / split Gaussians inserted back into canonical space.
* Internal operations: decide density control based on transformed current-time attributes, not canonical attributes; inverse-transform split/cloned Gaussians back to canonical space.
* Architecture details: modified optimization procedure.
* Mathematical formulation: Not specified beyond Fig. 3 and text.
* Trainable parameters: added Gaussian parameters.
* Hyperparameters: split scale factor $\phi=1.6$; clone/split thresholds Not specified.
* Why this module is needed: canonical-space Gaussians alone cannot reflect over/under reconstruction at all timestamps.
* What would happen without it: `canonical DC` ablation degrades Table 4 metrics.
* Evidence anchor: Sec. 3.5, Fig. 3, Table 4.

Implementation-level reconstruction:
* Render at current timestamp.
* Use current transformed scale / gradients to identify clone/split candidates.
* For split, replace large Gaussian by two new ones, divide scale by 1.6, sample positions from original Gaussian PDF.
* Apply inverse deformation transform to place new Gaussian parameters back into canonical field.

Relation to prior work:
* Inherits 3D-GS adaptive density control but changes the decision space from static canonical parameters to dynamic timestamp parameters.

## 5. Mathematical Objectives and Losses

| Loss / objective | Formula | Used for | Inputs | Weight | Evidence |
| ---------------- | ------- | -------- | ------ | ------ | -------- |
| 3D Gaussian | $G(x)=e^{-\frac{1}{2}(x-\mu)^\top\Sigma^{-1}(x-\mu)}$ | primitive density | mean and covariance | Not applicable | Eq. 1 |
| Covariance decomposition | $\Sigma=RSS^\top R^\top$ | stable PSD covariance | scale and rotation | Not applicable | Eq. 2 |
| Camera covariance | $\Sigma'=JW\Sigma W^\top J^\top$ | splatting projection | view transform and Jacobian | Not applicable | Eq. 3 |
| Alpha blending | $C=\sum_{i=1}^{N}T_i\alpha_i c_i$ | pixel rendering | sorted Gaussians | Not specified | Eq. 4 |
| 6D rotation mapping | $f_{V2M}([a_1,a_2])=[b_1,b_2,b_3]$ | rotation matrix construction | 6D vector | Not applicable | Eq. 5-6 |
| Voxelization | $V=\mathrm{floor}(P/s)$ | point cloud to sparse voxels | Gaussian centers and grid size | grid size $s$ Not specified | Eq. 7 |
| Feature fusion | $F_{fuse}=MLP(Concat(F'_p,F_p))$ | geometry-aware point features | voxel and identity features | Not specified | Eq. 8 |
| Deformation decoding | $\Delta x_t,\Delta r_t,\Delta s_t=G_\Phi(F_{fuse},\gamma(x),\gamma(t))$ | predict Gaussian deformation | features, position, time | Not specified | Eq. 9 |
| Positional encoding | $\gamma(p)=(\sin(2^0\pi p),\cos(2^0\pi p),...,\sin(2^{L-1}\pi p),\cos(2^{L-1}\pi p))$ | encode position/time | scalar coordinate | $L_x=10$, $L_t=6$ | Eq. 10, Sec. 4.2 |
| Gaussian transform | $x_t=x+\Delta x_t$, $s_t=s+\Delta s_t$, $r_t=f_{V2M}(\Delta r_t)\times f_{V2M}(r)$ | canonical to timestamp space | deformation outputs | Not applicable | Eq. 11 |
| Rasterization | $\hat{C}_t=Rasterizer(x_t,c,r_t,s_t,o,K,[R|T])$ | image rendering | transformed Gaussians and camera | Not applicable | Eq. 12 |
| Photometric loss | $L_{photo}=(1-\lambda)L_1+\lambda L_{D-SSIM}$ | image reconstruction | rendered and GT images | $\lambda$ Not specified | Eq. 13 |
| Motion loss | $L_{motion}=\|\Delta x_t\|_1$ | prefer static / small motion | position deformation | weighted by $\omega$ | Eq. 14 |
| Total loss | $L=L_{photo}+\omega L_{motion}$ | training objective | photo and motion losses | $\omega$ Not specified | Eq. 15 |

For each loss:
* $L_{photo}$ is the main rendering supervision.
* $L_{motion}$ encodes the prior that dynamic points are fewer than static points and motion magnitude should not be unnecessarily large.
* The paper does not ablate $\omega$ or $\lambda$ separately in the extracted text.

## 6. Training and Inference Procedure

### 6.1 Training Pipeline

| Item | Value | Evidence |
| ---- | ----- | -------- |
| Dataset | D-NeRF synthetic; HyperNeRF real dataset | Sec. 4.1 |
| Data split | D-NeRF 8 scenes; HyperNeRF selected scenes | Sec. 4.1 |
| Input resolution | synthetic ablation uses 800x800 | Sec. 4.5 |
| Preprocessing | D-NeRF random initializes 150000 points; HyperNeRF uses provided point cloud | Sec. 4.2 |
| Data augmentation | Not specified | Sec. 4 |
| Batch size | Not specified | Sec. 4.2 |
| Optimizer | Adam | Sec. 4.2 |
| Learning rate | exponential decay from $8e^{-4}$ to $1.6e^{-6}$ | Sec. 4.2 |
| LR schedule | exponential decay | Sec. 4.2 |
| Epochs / iterations | 40000 iterations; first 3000 optimize static scene only, then add deformation field | Sec. 4.2 |
| Loss weights | $\lambda$ and $\omega$ Not specified | Eq. 13, Eq. 15 |
| Initialization | random 150000 points for D-NeRF; provided point cloud for HyperNeRF | Sec. 4.2 |
| Hardware | single RTX 4090 GPU | Sec. 4.2 |
| Training time | around 2h average on D-NeRF | Sec. 4.3 |
| Code availability | project page provided | Abstract |

### 6.2 Inference Pipeline

| Item | Value | Evidence |
| ---- | ----- | -------- |
| Inference input | timestamp $t$, camera $K,[R|T]$, canonical Gaussians | Sec. 3.3-3.4 |
| Inference output | rendered image $\hat{C}_t$ | Eq. 12 |
| Test-time optimization | Not specified | Sec. 3-4 |
| Runtime | 12 FPS fixed viewpoint reported on D-NeRF | Sec. 4.3 |
| Memory / storage | 34MB point cloud + 14MB network | Sec. 4.3 |
| Postprocessing | Not specified | Sec. 3-4 |
| Failure cases | foreground/background motion segmentation is future work; real scenes with narrow camera range and pose ambiguity are challenging | Sec. 4.3, Conclusion |

### 6.3 Reproduction Checklist

Clearly specified:
* Use canonical 3D Gaussian field.
* Use 6D rotation representation.
* Voxelize Gaussian centers and use sparse 3D U-Net.
* Fuse voxel features and identity point features.
* Deformation decoder predicts position, rotation, and scale deformation.
* Keep color and opacity constant over time.
* Train 40000 iterations with 3000 static warm-up.

Not specified but inferable:
* Sparse convolution implementation likely follows sparse CNN library conventions.
* Density control follows 3D-GS clone/split with timestamp-space decision and canonical inverse transform.

Missing / need human check:
* Exact sparse 3D U-Net architecture and voxel grid size $s$.
* Exact density control thresholds and schedule.
* Exact $\lambda$ and $\omega$.
* Per-scene training settings and evaluation split details.

## 7. Experimental Setup and Results Summary

### 7.1 Datasets

| Dataset | Role | Size | Split | Modality | Preprocessing | Evidence |
| ------- | ---- | ---- | ----- | -------- | ------------- | -------- |
| D-NeRF | synthetic main benchmark | 8 scenes: Hell Warrior, Mutant, Hook, Bouncing Balls, Lego, T-Rex, Stand Up, Jumping Jacks | Not specified | synthetic monocular dynamic scenes | random 150000 points | Sec. 4.1-4.2 |
| HyperNeRF | real-scene benchmark | cut lemon, chicken, 3D printer, split cookie, broom, peel banana variants | Not specified | real dynamic scenes | uses provided point cloud | Sec. 4.1-4.3 |

### 7.2 Baselines

| Baseline | Category | Why compared | Fairness concern | Evidence |
| -------- | -------- | ------------ | ---------------- | -------- |
| 3D-GS | static Gaussian baseline | shows dynamic modeling necessity | not designed for dynamic scenes | Tab. 1-3 |
| D-NeRF | dynamic NeRF canonical/deformation baseline | classic canonical dynamic NeRF | slower / implicit representation | Tab. 1 |
| TiNeuVox-B, NDVG, FDNeRF | voxel / dynamic radiance field baselines | compare to geometry encoding alternatives | different rendering representations | Tab. 1-3 |
| 4D-GS | dynamic Gaussian baseline | closest Gaussian deformation baseline | uses HexPlane-style feature interpolation rather than sparse 3D geometry | Tab. 1, Tab. 3 |

### 7.3 Metrics

| Metric | Measures what | Used in which experiment | Higher/lower better | Evidence |
| ------ | ------------- | ------------------------ | ------------------- | -------- |
| PSNR | pixel fidelity | D-NeRF, HyperNeRF | higher better | Tab. 1-3 |
| SSIM / MS-SSIM | structural similarity | D-NeRF, HyperNeRF | higher better | Tab. 1-3 |
| LPIPS | perceptual error | D-NeRF, HyperNeRF | lower better | Tab. 1, Tab. 3 |
| FPS | rendering speed | D-NeRF computational cost | higher better | Sec. 4.3 |
| model size | storage | D-NeRF computational cost | lower better | Sec. 4.3 |

### 7.4 Results as Evidence Units

| Experiment | Purpose | Compared methods | Metrics | Main conclusion | Evidence strength | Evidence |
| ---------- | ------- | ---------------- | ------- | --------------- | ----------------- | -------- |
| D-NeRF quantitative | test synthetic dynamic view synthesis | 3D-GS, D-NeRF, TiNeuVox-B, NDVG, FDNeRF, 4D-GS | PSNR, SSIM, LPIPS | method is best across most scenes and notably improves over 4D-GS | strong | Tab. 1 |
| HyperNeRF quantitative | test real dynamic scenes | TiNeuVox, NDVG, FDNeRF, 3D-GS, 4D-GS | PSNR, MS-SSIM / SSIM, LPIPS | method competitive / best on averaged table; single-scene table mixed for some MS-SSIM | medium | Tab. 2-3 |
| visual comparisons | inspect artifacts and detail | D-NeRF / HyperNeRF baselines | qualitative | method recovers detailed images and dynamic object structures | medium | Fig. 4-5 |
| Gaussian visualization | assess geometry structure | 3D-GS, 4D-GS, Ours | qualitative point cloud | method produces clearer local geometric structure | medium | Fig. 7 |
| feature visualization | inspect learned geometry-aware features | internal visualization | qualitative | features separate moving / static parts and local structures | medium | Fig. 6 |
| ablation | isolate modules | w/o geo feature, w/o 6D rotation, canonical DC, vanilla, PointNet feat, Plane feat | PSNR, SSIM, LPIPS | geometry branch contributes most; 6D rotation and dynamic density control also help | strong | Tab. 4 |

## 8. Claimed Contribution vs Actual Technical Delta

| Claimed contribution | Actual technical change | Evidence | Is it novel? | Is it important? | Is it well supported? |
| -------------------- | ----------------------- | -------- | ------------ | ---------------- | --------------------- |
| geometry-aware feature extraction | voxelize Gaussian centers and run sparse 3D U-Net | Sec. 3.2, Fig. 1-2 | medium-high | high | yes, Table 4 |
| 6D rotation for dynamic Gaussian deformation | replace quaternion parameterization with continuous 6D vector | Sec. 3.2, Table 4 | medium | medium | yes |
| dynamic density control | clone/split based on transformed timestamp attributes | Sec. 3.5, Fig. 3 | medium | medium | yes, Table 4 |
| SOTA dynamic view synthesis | better D-NeRF and HyperNeRF results | Sec. 4, Table 1-3 | empirical claim | high | mostly yes |

实际技术边界：方法不是重新设计 rasterizer，而是在 3D-GS canonical/deformation pipeline 中加入更强的 3D 几何 feature encoder 和动态化 density control。

## 9. Limitations and Hidden Assumptions

### 9.1 Explicit Limitations

| Limitation | Evidence | Impact |
| ---------- | -------- | ------ |
| foreground/background motion segmentation remains future work | Conclusion | 当前 deformation field 可能把静态/动态区域耦合处理 |
| real scenes are challenging due to narrow camera view range and pose ambiguity | Sec. 4.3 | HyperNeRF 单场景表现并非所有指标都占优 |
| implementation details for sparse U-Net and density control are not fully specified | Sec. 3.2, 3.5 | exact reproduction requires code |

### 9.2 Inferred Limitations

| Inferred limitation | Why it may exist | Missing experiment | Possible consequence |
| ------------------- | ---------------- | ------------------ | -------------------- |
| depends on good canonical point distribution | geometry feature comes from Gaussian center point cloud | point initialization ablation | poor initial coverage may hurt deformation |
| sparse 3D U-Net adds memory / runtime overhead | true 3D sparse convolution over many Gaussians | runtime ablation by Gaussian count | slower than pure MLP / plane features |
| color and opacity are fixed over time | authors intentionally keep them constant | dynamic appearance ablation | lighting / topology changes may be underfit |
| motion regularizer assumes small motion | $L_{motion}=\|\Delta x_t\|_1$ | fast-motion benchmark | large real deformation may be over-regularized |

### 9.3 Hidden Assumptions

| Assumption | Where it appears | Risk if violated |
| ---------- | ---------------- | ---------------- |
| local 3D neighborhood correlates with deformation | Introduction, Sec. 3.2 | independent articulated parts close in space may be over-smoothed |
| canonical Gaussian geometry is meaningful before deformation | Sec. 3.2 | severe occlusion / sparse views reduce feature quality |
| 6D rotation improves neural smoothness enough to matter | Sec. 3.2, Table 4 | benefit may be dataset-dependent |
| dynamic points are fewer and motion is not too large | Sec. 3.5 | large dynamic scenes may be biased toward static solution |

## 10. Matrix-Ready Summary

| Field | Value |
| ----- | ----- |
| paper_id | lu3DGeometryawareDeformable2024 / T2MFSFBL |
| task | dynamic view synthesis |
| domain | dynamic Gaussian Splatting; geometry-aware deformation |
| input | monocular video / image sequence with camera parameters and timestamps |
| output | novel-view rendered image at target time |
| representation | canonical 3D Gaussians plus geometry-aware deformation field |
| backbone | 3D-GS rasterizer; sparse 3D U-Net; MLP deformation decoder |
| key_modules | Gaussian canonical field, 6D rotation, sparse 3D geometry feature learning, deformation field, dynamic density control |
| supervision | photometric loss plus L1 motion regularization |
| losses | $L=(1-\lambda)L_1+\lambda L_{D-SSIM}+\omega\|\Delta x_t\|_1$ |
| training_data | D-NeRF synthetic; HyperNeRF real |
| evaluation_data | D-NeRF scenes; HyperNeRF scenes |
| metrics | PSNR, SSIM, MS-SSIM, LPIPS, FPS, model size |
| baselines | 3D-GS, D-NeRF, TiNeuVox-B, NDVG, FDNeRF, 4D-GS |
| ablations | w/o geometry features, w/o 6D rotation, canonical density control, vanilla, PointNet feature, plane feature |
| main_claim | true 3D geometry features improve deformation modeling and dynamic view synthesis |
| actual_method_delta | sparse 3D U-Net over voxelized Gaussian centers plus 6D rotation and timestamp-aware density control |
| main_limitation | sparse U-Net / density control details not fully specified; future work needed for foreground/background motion segmentation |
| reusable_component | geometry-aware feature encoder for per-Gaussian deformation |
| possible_gap | combine geometry-aware features with explicit motion segmentation or uncertainty-aware graph propagation |

## 11. Reusable Components for My Research

| Component | What it does | How to reuse | Required changes | Risk |
| --------- | ------------ | ------------ | ---------------- | ---- |
| Sparse 3D U-Net geometry feature | aggregates local 3D structure from Gaussian centers | use as feature encoder before deformation MLP | tune voxel size and sparse conv architecture | expensive for large scenes |
| Identity point branch | preserves per-Gaussian high-resolution identity | concatenate with geometry feature | choose point MLP width/depth | may duplicate coordinate encoding |
| 6D rotation representation | provides continuous neural rotation parameterization | replace quaternion output in deformation heads | ensure SO(3) mapping and multiplication convention | implementation mismatch can break rotations |
| Dynamic density control | clone/split using timestamp-transformed Gaussian attributes | adapt 3D-GS densification to dynamic scenes | implement inverse transform to canonical space | wrong inverse transform creates inconsistent canonical field |
| Motion L1 regularizer | encourages small deformation | add to dynamic Gaussian deformation training | tune $\omega$ | suppresses large necessary motion |

## 12. Gap and Idea Seeds

| Gap / weakness | Evidence from this paper | Possible research direction | Minimal test |
| -------------- | ------------------------ | --------------------------- | ------------ |
| static/dynamic coupling unresolved | conclusion mentions foreground/background motion segmentation | add motion segmentation masks or static-background branch | compare on scenes with moving foreground and static background |
| geometry encoder uses only coordinates | Sec. 3.2 says only 3D coordinates are used | include color/opacity/scale in sparse features | ablate coordinate-only vs full Gaussian attributes |
| sparse U-Net design under-specified | missing voxel size / architecture | standardize a lightweight sparse encoder | reproduce with different voxel sizes |
| fixed color/opacity may fail with appearance changes | Sec. 3.3 keeps them constant | add controlled appearance deformation head | evaluate on dynamic lighting / topology changes |
| MLP deformation may still lack long-range motion grouping | local geometry only | combine with graph or skeleton-like motion priors | compare on articulated objects |

## 13. Human Check List

| Item | Why it matters | Location |
| ---- | -------------- | -------- |
| Sparse 3D U-Net architecture and voxel size $s$ | necessary for reproduction | Sec. 3.2 / code |
| Density control thresholds and schedule | clone/split behavior affects quality | Sec. 3.5 / code |
| Exact $\lambda$ and $\omega$ | loss balance matters | Eq. 13-15 / code |
| HyperNeRF per-scene split | real-scene comparison is mixed | Sec. 4.1-4.3 |
| Duplicate Zotero PDF attachment | later batch linking should choose VD895MTX or deduplicate | Zotero children |

## 14. Evidence Anchors

| Claim / detail | Evidence location |
| -------------- | ----------------- |
| motivation for geometry-aware deformation | Introduction, Fig. 1, PDF p.1-2 |
| pipeline overview | Fig. 2, PDF p.3 |
| 3D-GS preliminaries | Sec. 3.1, Eq. 1-4, PDF p.4 |
| 6D rotation representation | Sec. 3.2, Eq. 5-6, PDF p.4 |
| voxelization and sparse 3D U-Net | Sec. 3.2, Eq. 7, PDF p.4 |
| feature fusion | Sec. 3.2, Eq. 8, PDF p.5 |
| deformation field | Sec. 3.3, Eq. 9-11, PDF p.5 |
| rasterization | Sec. 3.4, Eq. 12, PDF p.5 |
| photometric and motion losses | Sec. 3.5, Eq. 13-15, PDF p.5 |
| dynamic density control | Sec. 3.5, Fig. 3, PDF p.5 |
| implementation details | Sec. 4.2, PDF p.6 |
| D-NeRF results | Table 1, PDF p.5-6 |
| HyperNeRF results | Table 2-3, PDF p.5-6 |
| visual comparisons | Fig. 4-7, PDF p.6-7 |
| ablation study | Table 4, PDF p.7 |
| future work on motion segmentation | Conclusion, PDF p.7 |

