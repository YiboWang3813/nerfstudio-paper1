---
title: "MVPGS: Excavating Multi-view Priors for Gaussian Splatting from Sparse Input Views"
authors: "Wangze Xu, Huachen Gao, Shihe Shen, Rui Peng, Jianbo Jiao, Ronggang Wang"
year: 2025
venue: "ECCV 2024 / extended version"
zotero_item_key: "5AG8I3NY"
pdf_attachment_key: "KTVTPQ52"
pdf_path: "/Users/wangyibo/Zotero/storage/KTVTPQ52/Xu 等 - 2025 - MVPGS Excavating Multi-view Priors for Gaussian Splatting from Sparse Input Views.pdf"
note_path: "notes/MVPGS: Excavating Multi-view Priors for Gaussian Splatting from Sparse Input Views.md"
tags: ["3D Gaussian Splatting", "sparse-view synthesis", "multi-view stereo", "forward warping", "depth regularization"]
---

## 0. 一句话总结

MVPGS 面向有位姿的 few-shot NVS，把 learning-based MVS 从“只做初始化”进一步挖成训练约束：用 MVSFormer 生成稠密一致深度初始化 3DGS，再基于该几何 forward warp 出未见视角外观作为额外监督，同时用 MVS 一致深度和单目深度正则约束 Gaussian 几何，缓解 sparse-view 3DGS 的过拟合。

## 1. 问题与动机

3DGS 在 dense-view NVS 中速度和质量都很好，但 sparse-view 下由于跨视角约束不足，容易过拟合训练视角，Gaussian 位置会漂移到不合理几何，novel view 中出现结构缺失、边缘错误和模糊。

相比 NeRF 的空白 MLP，3DGS 的初始点云已经包含部分几何和外观信息。作者认为，如果用 learning-based MVS 从少量输入图中挖出更丰富、更一致的几何，再把这些几何转成初始化、未见视角外观先验和几何约束，就能让 sparse-view 3DGS 更稳定。

## 2. 适用场景

MVPGS 适合相机位姿已知、输入视角很少的静态场景 novel view synthesis，包括 forward-facing LLFF、object-centric DTU、RGBD/in-the-wild NVS-RGBD，以及 Tanks and Temples 这类更大场景。

它依赖输入视角之间存在足够 overlap 以让 MVSFormer 估计可用深度。若场景非朗伯、强反光、光照变化明显，或输入视角太少导致 MVS 深度严重错误，forward warping 外观先验会受到影响。

## 3. 方法定位

MVPGS 是 per-scene optimization 的 3DGS sparse-view 方法，不是 feed-forward 泛化模型。它将 3DGS 与 learning-based MVS 深度估计结合，核心是把 MVS prior 用在三个层面：初始化、unseen-view appearance supervision、geometry regularization。

相对只用 MVS/COLMAP 点云初始化的 3DGS，MVPGS 更进一步：它发现单纯好初始化提升有限，真正解决 overfitting 还需要优化期间持续使用 MVS 几何生成约束。

## 4. 核心创新

第一，使用 MVSFormer 从 sparse posed views 中估计 dense view-consistent depths，经 geometric filtering 后合并为点云，作为 3D Gaussian centers 的初始化，比 COLMAP 稀疏点云更适合 few-shot。

第二，提出 forward warping appearance prior。基于已知训练视图的 MVS depth 和相机位姿，把训练视图的颜色 forward warp 到随机未见视角，生成符合场景几何的 pseudo appearance，用来监督 3DGS 在未见视角的渲染。

第三，提出 consistent structure regularization。将 3DGS 渲染出的深度与高置信 MVS depth 做 L1 约束，防止 Gaussian center 在优化中偏离初始可靠结构。

第四，使用 monocular depth prior 补偿 MVS 失效区域。对 textureless、低重叠等 MVS 不可靠区域，用 DPT 单目深度的相对顺序约束全局几何。

## 5. 方法细节

3DGS 部分沿用标准参数化，每个 Gaussian 为 $G=\{(X_i,S_i,R_i,\sigma_i,c_i)\}$。标准训练图像光度损失为：

$$
L_{photo}=\lambda_1 L_1(\hat{I},I)+(1-\lambda_1)(1-\operatorname{SSIM}(\hat{I},I))
$$

论文中 $\lambda_1=0.8$。

MVS 初始化阶段，给定训练视图 $\{V_i^{train}=(I_i,P_i)\}$，每个视图轮流作为 reference view，其他视图作为 source views。MVSFormer 构造 cost volume 并回归 $D_i^{mvs}$，再用 geometric filter 根据 depth reprojection error 得到高置信 mask $M_i$，最后把多视图深度融合成 3D 点云初始化 Gaussian centers。

forward warping 中，给定 source view 的图像 $I_{src}$、MVS 深度 $D_{src}^{mvs}$、source pose $P_{src}$ 和 target pose $P_{tgt}$，生成 target appearance：

$$
I_{tgt}=\operatorname{fwd}(I_{src},D_{src}^{mvs},P_{src},P_{tgt})
$$

像素投影关系为：

$$
p_{tgt}\sim K P_{tgt}^{-1}P_{src}D_{src}^{mvs}K^{-1}p_{src}
$$

由于投影位置通常是小数坐标，作者使用 reversed bilinear sampling，把源像素颜色分配给 target 中最近的 4 个像素。权重为 $w_t(i,j)=(1-|i-x_t|)(1-|j-y_t|)$。若多个点投到同一 target 像素，再用深度权重 $w_t^d=1/(1+d_t)^\gamma$ 处理遮挡，最终颜色是归一化加权和。

每隔若干 iteration 随机采样 unseen pose $P'$，用 forward warping 得到 $I'$，再渲染 $\hat{I}'$ 并计算：

$$
L_{fwd}=\lambda_2 L_1(\hat{I}',I')+(1-\lambda_2)(1-\operatorname{SSIM}(\hat{I}',I'))
$$

论文中 $\lambda_2=0.2$。

几何正则中，先通过 3DGS alpha blending 渲染深度：

$$
d=\sum_{i\in N}d_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j)
$$

consistent structure loss 在 MVS 高置信区域约束 rendered depth $D^r$ 与 $D^{mvs}$：

$$
L_{CS}=\sum |D^r-D^{mvs}|\odot M
$$

monocular depth loss 使用 DPT 预测 $D^{mono}$，随机采样两个不相交像素 batch $S_1,S_2$，用相对深度排序约束 rendered depth。总损失为：

$$
L_{total}=L_{photo}+L_{fwd}+\beta_1 L_{CS}+\beta_2 L_{mono}
$$

实验中 $\beta_1=0.1$，$\beta_2=0.005$，DTU 上 $\beta_2=0.01$。

## 6. 实验设置

实验覆盖 LLFF、DTU、NVS-RGBD 和 Tanks and Temples。LLFF 使用每 8 张留一测试，并从剩余视图中均匀采样 sparse views，报告 1/8 和 1/4 分辨率。DTU 使用 15 个场景和前人 split，报告 1/4 和 1/2 分辨率。NVS-RGBD 使用 Kinect 和 ZED2 两个分支；T&T 使用每个场景前 50 帧，并按 LLFF 风格划分。

实现基于 3DGS、PyTorch 和 CUDA。MVSFormer 预训练模型生成 depth，DPT 生成单目 depth。训练报告 10k iterations 的 Ours† 和 20k iterations 的 Ours；Gaussian densify/prune 每 100 iterations 执行一次，分别从 500 到 5k 和 10k。

## 7. 主要结果

LLFF 3-view 1/8 分辨率上，MVPGS Ours 达到 20.39 PSNR、0.715 SSIM、0.203 LPIPS、132 FPS；Ours† 为 20.54 PSNR、0.727 SSIM、0.194 LPIPS、209 FPS。相比 SparseNeRF 的 19.86 PSNR 和 FreeNeRF 的 19.63 PSNR，质量更高且渲染速度实时。

LLFF 1/4 分辨率上，Ours 达到 19.70 PSNR、0.681 SSIM、0.241 LPIPS、170 FPS，仍优于 NeRF-based baselines 且速度远高于它们。

DTU 3-view 1/4 分辨率上，Ours 达到 20.50 PSNR、0.871 SSIM、0.106 LPIPS、365 FPS；1/2 分辨率上达到 20.26 PSNR、0.851 SSIM、0.130 LPIPS、366 FPS。高分辨率下仍保持较好细节。

NVS-RGBD 上，ZED2 分支 Ours 为 26.62 PSNR、0.841 SSIM、0.185 LPIPS，Kinect 分支为 27.04 PSNR、0.887 SSIM、0.151 LPIPS。T&T 上 Ours 达到 25.57 PSNR、0.846 SSIM、0.139 LPIPS，明显优于 3DGS*、FreeNeRF、SparseNeRF。

不同输入视图数的 LLFF 实验中，2-view 时 Ours 为 18.53 PSNR，3-view 为 20.39，4-view 为 21.28，5-view 为 22.18，说明方法在极稀疏和稍多视图下都稳定。

## 8. 消融与分析

LLFF 3-view 1/8 分辨率消融显示，原始 3DGS baseline 为 14.87 PSNR、0.438 SSIM、0.383 LPIPS；仅换成 MVS point cloud 初始化提升到 16.16 PSNR、0.519 SSIM、0.331 LPIPS，说明好初始化有用但远远不够。

去掉 forward warping prior 后 Ours w/o $L_{fwd}$ 只有 17.32 PSNR、0.563 SSIM、0.306 LPIPS，性能大幅下降，说明未见视角外观监督是核心贡献。去掉 $L_{CS}$ 后为 20.06 PSNR，去掉 $L_{mono}$ 后为 20.17 PSNR，完整模型为 20.39 PSNR、0.715 SSIM、0.203 LPIPS。

不同 MVS 预训练数据的实验显示，用 DTU、BlendedMVS、DTU 再 finetune BlendedMVS 的 MVSFormer 都能得到接近结果，说明 MVPGS 对 MVS 预训练数据不太敏感。

## 9. 与相关工作的关系

相对 RegNeRF、FreeNeRF、SparseNeRF 等 NeRF-based few-shot 方法，MVPGS 使用显式 3DGS 表示，因此训练和渲染速度更快。

相对 DNGaussian/FSGS 等 sparse-view 3DGS 方法，MVPGS 更强调从 learning-based MVS 中挖掘 multi-view priors，不只是单目深度或 SfM 点补强。

相对 backward warping 方法，MVPGS 的 forward warping 从已知视图几何出发推断 target appearance，不依赖 target view rendered depth 去采样 source image，因此更适合训练早期和大 pose variation 的 sparse-view 场景。

## 10. 优点

MVPGS 的优点是每个模块都有明确几何含义：MVS 初始化提供初始结构，forward warping 扩展未见视角监督，$L_{CS}$ 维持高置信结构，$L_{mono}$ 覆盖 MVS 缺失区域。

另一个优点是效率高。它保持 3DGS 的实时渲染速度，同时在 sparse-view 下超过多个 NeRF-based 方法。对实际应用而言，质量和速度的平衡好。

## 11. 局限

论文明确指出，MVPGS 通过 view-consistent appearance priors 缓解过拟合，但不处理非朗伯表面的光照变化。forward warping 默认颜色跨视角基本一致，强反光、透明、曝光变化会破坏这个假设。

方法还依赖 MVS 深度质量。虽然用 monocular depth 补偿 MVS 失效区域，但如果 MVS 初始化大范围错误，forward-warped appearance 和 $L_{CS}$ 可能提供错误监督。

## 12. 可复现要点

复现时第一步是跑 MVSFormer：每个训练视图做 reference，其他训练视图做 source，输出 dense depth 和 consistency mask，再 merge 成初始点云。DTU 上使用 mask 只 warp 前景；LLFF、NVS-RGBD、T&T 上对 warp 图像边界区域用 LaMa inpainting。

优化时正常计算训练视图 $L_{photo}$，每隔 $E$ iterations 采样随机 unseen pose，只计算 $L_{fwd}$。同时对训练视图渲染 depth 计算 $L_{CS}$ 和 $L_{mono}$。训练中继续使用 3DGS adaptive pruning and densification。

## 13. 可能扩展

一个扩展是为 forward-warped appearance 加置信度或不确定性，避免 MVS 错误和遮挡区域被同等监督。可以根据 MVS matching confidence、depth consistency、warp hole 和 view angle 设权重。

第二个扩展是把 MVPGS 与匹配 prior 方法结合。MVS depth 提供稠密几何，feature matching 提供高置信稀疏对应，两者可以共同约束 Gaussian positions 和 rendered depth。

第三个扩展是处理非朗伯光照变化，例如引入 view-dependent appearance correction 或 reflectance/illumination 分解，让 forward warping 不再假设颜色完全一致。

## 14. 个人理解

MVPGS 的核心思想是把 MVS 的输出从“初始化材料”升级成“训练过程中持续可用的 multi-view prior”。这很关键，因为 sparse-view 3DGS 的问题不是没有初始点云，而是优化过程中会为了拟合少数训练图把几何拉坏。

这篇文章也说明，好几何 prior 应该以多种形式进入训练：点云初始化让模型从合理位置开始，forward warping 给未见视角增加外观约束，depth regularization 阻止几何漂移。三者组合起来才明显超过只换 MVS 初始化的 3DGS。
