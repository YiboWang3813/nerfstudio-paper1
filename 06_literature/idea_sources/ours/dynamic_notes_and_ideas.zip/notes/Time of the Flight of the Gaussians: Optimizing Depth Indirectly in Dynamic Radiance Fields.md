# Time of the Flight of the Gaussians: Optimizing Depth Indirectly in Dynamic Radiance Fields

## 0. Metadata

- Title: Time of the Flight of the Gaussians: Optimizing Depth Indirectly in Dynamic Radiance Fields
- Authors: Runfeng Li; Mikhail Okunev; Zixuan Guo; Anh Ha Duong; Christian Richardt; Matthew O'Toole; James Tompkin
- Venue/Year: CVPR 2025
- Project page: https://visual.cs.brown.edu/gftorf
- Zotero item key: `9S2ENIT4`
- Zotero PDF attachment key: `VBQ7WNC8`
- PDF path: `/Users/wangyibo/Zotero/storage/VBQ7WNC8/Li 等 - 2025 - Time of the Flight of the Gaussians Optimizing Depth Indirectly in Dynamic Radiance Fields.pdf`
- Local note path: `notes/Time of the Flight of the Gaussians: Optimizing Depth Indirectly in Dynamic Radiance Fields.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

GFTorF 将动态 3D Gaussian Splatting 适配到 monocular continuous-wave time-of-flight raw quad sensing，通过直接渲染 C-ToF raw samples、约束 quartet 内局部线性运动，并加入 occupancy bias 与 low-reflectivity bias，使 GS 在深度只被间接优化的欠约束设置下仍能稳定得到较准的动态几何，同时比 ToF NeRF 类方法快约 100 倍。

## 2. Problem Formulation

输入是单目 C-ToF camera 的动态 raw quartet 序列，可选同步 RGB。C-ToF camera 并不直接测得真实深度，而是测得不同 reference phase offset 下的 raw intensity samples；深度由这些 samples 的 phase 间接推导。动态场景中 quartet 的四张 raw frames 异步捕获，运动会使传统闭式 depth recovery 出错。

论文要解决两个耦合问题。第一，如何用比 neural volumetric ToF radiance fields 快得多的 GS 表示来重建动态 C-ToF radiance field。第二，GS 优化比 NeRF 更 brittle；在单目、动态、深度间接优化的设置中，即使 raw C-ToF samples 拟合得很好，Gaussian mean depth 仍可能严重错误。

## 3. Method Overview

方法把 3DGS 的 color rendering 改成 C-ToF phasor / raw quad rendering。每个 Gaussian 不再只携带 RGB radiance，而是携带 view-dependent infrared reflectivity。渲染时考虑 emitted light、inverse-square falloff、phasor phase shift 和 round-trip transmittance，得到 raw quartet predictions，并用真实 raw quads 监督。

动态部分沿用 monocular dynamic GS 的 canonical deformation 形式：MLP 输入 Gaussian position 和 time，输出 position offsets。为了适配 raw quartet 的异步捕获，模型只在 integer timesteps 预测 Gaussian positions，在 quartet 内 fractional timesteps 通过相邻 integer timesteps 线性插值。优化上加入 RAFT optical flow weak supervision，以及两个经验 bias：降低 reflectivity learning rate 的 occupancy bias，和低 reflectivity initialization。

## 4. Method Details

### 4.1 C-ToF Raw Measurement

C-ToF camera 用连续调制光照射场景，返回光与 reference sinusoid 相关，得到 $A\sin(\psi+\phi)+B$。通常使用四个 phase offsets $\phi\in\{0,\pi/2,\pi,3\pi/2\}$，产生 raw quartet $Q_\phi$。传统相机会由这些 raw samples 计算 phase $\psi$，再得到 depth：

$$
d_{\mathrm{ToF}}=\frac{c}{4\pi f}\psi,\quad \psi=\arctan\left(\frac{Q_0-Q_\pi}{Q_{\pi/2}-Q_{3\pi/2}}\right).
$$

该闭式模型假设四个 samples 同时捕获、光从单个 opaque Lambertian surface 反射回来。但真实动态场景中 quartet 异步、物体运动、multi-path transport 和 transmissive volume 都会破坏这个假设。

### 4.2 C-ToF Gaussian Splatting Formation

标准 3DGS 在像素 $x$ 上 alpha-composite color。C-ToF GS 改为渲染 phasor。对 Gaussian $k$，返回光由 source intensity $s$、reflectivity $r_k$、距离衰减 $1/d_k^2$、phasor $W(d_k)$、opacity 和 transmittance 组成。round-trip light transport 使 transmittance 项变成 $T_k^2$。

raw quad rendering 进一步将 phasor 替换为四个 phase samples $\phi(d_k)=\{\sin\psi_k,\cos\psi_k,-\sin\psi_k,-\cos\psi_k\}$，从而直接预测 raw quartet：

$$
q(x)=q_{\mathrm{bg}}T_N+\sum_{k=1}^{N}\frac{s r_k}{d_k^2}\phi(d_k)o_kG_k^{2D}(x)T_k^2.
$$

这样优化目标是 raw sensor measurements，而不是先由 noisy C-ToF depth 监督 3DGS。

### 4.3 Why Depth Is Indirect and Ill-Conditioned

感兴趣的 property 是 scene depth，但优化的是 raw C-ToF samples。mean Gaussian depth 可写为 $d(x)=\sum_k d_k o_kG_k^{2D}(x)T_k$。由于 raw quad 中 sine/cosine 随 depth 振荡，多个 depth peaks 可以组合出正确 raw signal，却产生错误 mean depth。也就是说，fitting C-ToF images 不等于 fitting depth。

NeRF-style volumetric models 在这种设置中相对稳健，可能来自 MLP 的低熵/平滑 bias；GS 则可以把 Gaussians 任意放在 ray 上，通过 reflectivity 和 opacity 调整来拟合 raw samples，容易形成高熵、多峰密度分布。

### 4.4 Optimization Biases

Heuristic 1 是 occupancy bias。作者认为在 reconstruction 参数中，occupancy，也就是 position、opacity 和 densification，应该比 reflectivity 更频繁变化。实现上把 reflectivity learning rate 降低 10 倍，让优化更倾向于移动/生成/删除 density，而不是通过快速改变 reflectivity 拟合 raw signal。

Heuristic 2 是 low-reflectivity bias。如果初始 reflectivity 过高，inverse-square falloff 会鼓励低反射区域的 Gaussians 被错误放远，之后被近处 splats 干扰，难以修正。将 reflectivity 初始化为低值，例如 0.01 到 0.1，可以让低反射区域从更合理的起点开始，高反射区域则逐步向相机靠近并优化 reflectivity。论文默认 reflectivity 初始化为 0.1。

### 4.5 Dynamic Deformation and Local Linearity

动态 GS 使用 MLP 输入 time $t$ 和 Gaussian 3D position $x_k$，输出 position offset $\delta x_k$。Gaussian 从 canonical space 变形到目标时刻。由于 raw quartet 是异步捕获，局部线性运动很重要。模型只在 integer timesteps 计算 positions，对 fractional timestep $j$ 用相邻 integer timesteps $i_1,i_2$ 线性插值：

$$
x_j=(i_2-j)x_{i_1}+(j-i_1)x_{i_2}.
$$

这与 F-ToRF 的 phase-aware reprojection loss 功能类似，用于处理 quartet 内运动。

### 4.6 Optical Flow Weak Supervision and Loss

为了帮助快速运动对应，方法用 RAFT 估计 optical flow，对 Gaussian 3D motion projected flow 施加弱 L2 supervision $L_f$。总 loss 为：

$$
L=\alpha L_q+L_c+\beta L_f.
$$

$L_q$ 是 raw quad reconstruction loss，$L_c$ 是可选 RGB reconstruction loss，两者都结合 L2 和 SSIM。默认 $\alpha=5$，synthetic scenes 为 1，$\beta=0.0008$。

## 5. Mathematical Objectives and Losses

这篇的数学核心是 C-ToF raw quad formation 和 depth indirectness。raw quads 是优化空间，scene depth 是由最终 Gaussian distribution 推导出的属性；二者不等价。论文没有用 depth distortion loss 强行压成 opaque surface，因为这会损害 C-ToF multi-path / transmissive modeling 能力，也会产生过平滑深度。

最终优化靠三类约束共同工作：raw C-ToF reconstruction 提供主要 sensor physics；optional RGB 提供外观/额外定位；optical flow weak supervision 帮助动态 correspondence。两个 optimization biases 则改变参数学习的相对速度和初始化，使 GS 更倾向于正确 occupancy。

## 6. Training and Inference Procedure

输入是 raw quartet C-ToF video 和可选 RGB。Gaussians 在 camera frustum 中随机初始化，near/far planes 限定范围，reflectivity 初始化为 0.1。前 2K iterations 是 warm-up，假设场景静态，把 Gaussians 放到有用位置。为了处理真实尺度下 large coordinates，仅对 MLP 输入按 unambiguous depth range 做 rescale，使多数值落在 $[0,1]$。

deformation MLP 有 8 层，每层 256 neurons，position/time positional encoding 频率 $L_x=10$、$L_t=10$。MLP learning rate 从 0.0008 指数衰减到 $1.6e^{-6}$，reflectivity learning rate 为 0.00016。每次迭代随机改变 background signal，均匀采样于 $[-1,1]$，避免低背景让低反射区域被错误解释。

实现基于 3DGS codebase，并加入 custom CUDA raw C-ToF forward/backward rasterization。每次训练会渲染 C-ToF view 计算 quad loss，也可渲染 RGB view 计算 color loss。

## 7. Experimental Setup and Results Summary

数据包括 ToRF real dynamic monocular sequences、F-ToRF real static-camera fast-motion sequences，以及 F-ToRF synthetic scenes。ToRF 有 moving camera 和慢运动；F-ToRF 更难，静态相机且包含 pillow、baseball、jumping jacks、target、fan 等快速运动。synthetic scenes 用 PBRT 生成 C-ToF emission，包含 sliding/occluded/axial/arcing cubes 和 chairs 等。

计算效率上，ToRF 约 60 小时，F-ToRF 约 72 小时；本文方法每个 4D scene reconstruction 约 40-60 分钟，rendering 100+ Hz。

synthetic depth MSE 表中，本文在 7 个场景中 5 个取得最佳或更优的 rendered scene depth $d$，raw-derived depth $d_{\mathrm{ToF}}$ 也常优于 F-ToRF。例如 Sliding Cube 的 Ours $d_{\mathrm{ToF}}$ 为 0.005、Ours $d$ 为 0.037；Axial Speed Test 的 Ours $d_{\mathrm{ToF}}$ 为 0.123、Ours $d$ 为 0.525。3 Chairs Speed Test 和 Arcing Cube 显示薄结构或强非线性运动仍较难。

定性结果显示，在 ToRF 较容易数据上，DeformableGS 若没有 C-ToF depth loss 会失败，加入 C-ToF depth 后改善但仍弱于本文 raw physics supervision。在 F-ToRF 快速运动数据上，本文与 F-ToRF 是少数能修正 motion artifacts 的方法；2D flow baseline 无法处理 axial motion，DeformableGS 往往丢失快速运动物体。Fan 场景中没有方法能准确重建旋转扇叶。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是一个动态 C-ToF GS 方法，优化和渲染都比 neural volumetric baselines 快约 100 倍，并系统分析 C-ToF radiance field 中 depth indirect optimization 的 bias。实际技术增量有两层：一是把 C-ToF phasor/raw quad image formation 写进 GS rasterization；二是在 GS 过于灵活导致 depth 不稳定时，用 reflectivity learning-rate 和 initialization biases 引导 occupancy 学习。

与 F-ToRF 相比，本文不是换一个 sensor model，而是把同类 raw C-ToF 物理建模迁移到 GS 并解决 GS 的脆弱性。与 DeformableGS+depth prior 相比，本文避免把 C-ToF 闭式 depth 当作真值，而是直接拟合 raw measurements。

## 9. Limitations / Assumptions

论文假设 emitter 与 camera co-located，近距离物体可能有 shadowing errors。运动被建模为 timesteps 之间 piecewise linear，高阶 motion 可能更适合旋转或复杂非线性运动。

方法使用 RAFT optical flow，flow 错误会传播到结果。depth wrapping 在 JumpingJacks、Target、Pillow 背景中出现，这是 C-ToF 的典型歧义，静态相机下本质上 ill-posed。

强非线性运动如 Fan 会失败或不如 F-ToRF，因为 canonical deformation field 难以跟踪这类几何。Gaussians 的空间平滑性也可能导致边缘不如 NeRF sharp。薄且快速运动物体难以稳定 densify，因为 loss 在 deformed space 中计算而 Gaussians 在 canonical space 中 densify。

两个 optimization heuristics 来自经验观察，没有通用保证。数据主要是室内 C-ToF 场景，户外或更复杂真实运动不一定适用。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Monocular C-ToF raw quartets; optional RGB |
| Output | Dynamic Gaussian scene with C-ToF-consistent depth and motion |
| Sensor model | Phasor / raw quad C-ToF Gaussian splatting |
| Dynamic model | Canonical GS + MLP position offsets + local linear interpolation |
| Main supervision | Raw quad loss, optional RGB loss, RAFT flow weak supervision |
| Key heuristics | Occupancy bias via low reflectivity LR; low-reflectivity initialization |
| Strength | 100x faster than ToF NeRFs, real-time rendering, good fast-motion reconstruction |
| Weakness | Strong nonlinear motion, thin structures, depth wrapping, heuristic dependence |

## 11. Reusable Components

- C-ToF raw quad rasterization for Gaussian splatting。
- reflectivity learning-rate reduction as occupancy bias。
- low reflectivity initialization for better depth placement。
- random C-ToF background signal during optimization。
- integer-time deformation with fractional-time linear interpolation for asynchronous raw frames。
- optical-flow weak supervision from rendered 3D Gaussian motion。

## 12. Gap / Idea Seeds

- Replace piecewise linear motion with spline or physics-aware trajectories for Fan-like nonlinear motion。
- Combine occupancy bias with uncertainty-aware depth distortion rather than hard opaque-surface regularization。
- Move densification into deformed/spacetime domain to handle thin fast-moving objects。
- Learn reflectivity priors from material/IR appearance instead of fixed low initialization。

## 13. Human Check List

- NEED_HUMAN_CHECK: Method nickname is not explicitly in title; project URL suggests `gftorf`, but this note uses the paper title as file name.
- NEED_HUMAN_CHECK: Quantitative table reports depth MSE x100 with both rendered depth $d$ and C-ToF-derived $d_{\mathrm{ToF}}$; note keeps this distinction.
- NEED_HUMAN_CHECK: The method is C-ToF-specific and not a general RGB-only dynamic 3DGS method.

## 14. Evidence Anchors

- Section 2: C-ToF imaging principles and raw quartet depth recovery。
- Section 3: C-ToF GS phasor/raw image formation model。
- Section 3.1: fitting C-ToF images vs fitting depth, depth distortion discussion, occupancy and low-reflectivity biases。
- Section 4: dynamic pipeline, local linear interpolation, optical-flow supervision, total loss and implementation details。
- Section 5 / Table 1: synthetic depth MSE and runtime comparison。
- Section 6: limitations on depth wrapping, nonlinear motion, sharpness, thin fast objects and heuristic guarantees。
