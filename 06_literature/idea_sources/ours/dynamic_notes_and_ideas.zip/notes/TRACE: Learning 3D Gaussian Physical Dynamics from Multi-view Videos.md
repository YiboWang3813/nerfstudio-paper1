# TRACE: Learning 3D Gaussian Physical Dynamics from Multi-view Videos

## 0. Metadata

- Title: TRACE: Learning 3D Gaussian Physical Dynamics from Multi-view Videos
- Authors: Jinxi Li; Ziyang Song; Bo Yang
- Venue/Year: ICCV 2025
- Code / data: https://github.com/vLAR-group/TRACE
- Zotero item key: `WGC6CHHX`
- Zotero PDF attachment key: `I4DRFH3T`
- PDF path: `/Users/wangyibo/Zotero/storage/I4DRFH3T/Li 等 - TRACE Learning 3D Gaussian Physical Dynamics from Multi-view Videos.pdf`
- Local note path: `notes/TRACE: Learning 3D Gaussian Physical Dynamics from Multi-view Videos.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

TRACE 将每个 3D Gaussian 视为带尺寸和朝向的刚性粒子，为每个粒子学习 translation-rotation dynamics system 的物理参数，并用 RK2 从这些参数推导未来状态，从而使动态 3DGS 不只插值观测时间内视角，还能进行物理一致的未来帧外推和基于动力学参数的无监督运动分割。

## 2. Problem Formulation

输入是带已知相机参数的 multi-view RGB dynamic videos。目标是在没有 object type、mask 或其他人工标注的情况下，学习 3D geometry、appearance 和 physical dynamics，并预测未来时间的 novel views。普通动态 NeRF / 3DGS deformation fields 主要拟合观测时间内的像素相关性，能做 interpolation，却缺少显式物理参数，往往无法 extrapolate future frames。

TRACE 的假设是：每个 3D Gaussian kernel 可以被看作一个 rigid particle。一个粒子在 3D 空间中的运动可以视为绕某个 rotation center 的旋转运动，而该 center 自身也在平移。因此只要学习每个粒子的平移-旋转动力学参数，就可以根据经典力学更新未来状态。

## 3. Method Overview

框架有三个部分。第一，canonical 3D scene representation：在 $t=0$ 使用 vanilla 3DGS 学习 canonical Gaussians，表示几何和外观。第二，auxiliary deformation field：用类似 Deformable 3DGS 的 MLP 在训练阶段预测 Gaussian 从 $0$ 到 $t$ 的 position、rotation、scale offsets，帮助核心物理模块稳定学习。第三，translation rotation dynamics system：对每个 Gaussian/rigid particle 预测等效中心速度、等效中心加速度、旋转向量和角加速度，并用 RK2 推导从 $t'$ 到 $t$ 的未来 motion。

论文的核心区别是：它不是给 deformation field 加 PINN soft losses，也不是直接拟合 velocity network，而是显式学习粒子级 physical parameters。这样学到的参数不仅用于未来帧外推，还能通过聚类得到物体/部件运动分割。

## 4. Method Details

### 4.1 Canonical 3D Gaussians

TRACE 在 canonical timestamp $t=0$ 训练一组 3D Gaussian kernels $G_0$。每个 Gaussian 包含 position $x_0$、由 quaternion $r_0$ 和 scale $s_0$ 得到的 covariance、opacity $\sigma$ 和 spherical harmonics color $c$。训练沿用 3DGS 的 project-render-optimize pipeline，用 $l_1$ 和 SSIM loss 拟合所有相机在 $t=0$ 的图像。

论文假设 opacity 和 color 随 Gaussian 被 transport over time，不随时间单独更新。动态主要由 position、rotation 和 scale 的变化表达。

### 4.2 Auxiliary Deformation Field

早期训练中 Gaussians 的位置和形状不稳定，直接学习物理参数困难。为此 TRACE 并行训练一个辅助 deformation network $f_{\mathrm{defo}}$。它输入 canonical position $x_0$ 和 timestamp $t$，输出 position displacement $\delta x$、quaternion change $\delta r$ 和 scale change $\delta s$：

$$
x_t=x_0+\delta x,\quad r_t=r_0\circ\delta r,\quad s_t=s_0\odot\delta s.
$$

该辅助场本身不能外推未来，只负责在训练观测时间内提供更可靠的 motion state，使物理模块能从 $t'$ 的 Gaussian 状态学习到可推导的动力学。

### 4.3 Translation-Rotation Dynamics System

对任意 rigid particle $P$，TRACE 学习两组参数。第一组是 rotation center 的参数：center position $P_c$、center velocity $v_c$ 和 acceleration $a_c$。第二组是粒子绕 center 的旋转参数：rotation vector $w_p$ 和 angular acceleration $\epsilon_p$。

粒子在时间 $t$ 的 composite velocity 可写为：

$$
v_p^t=w_p^t\times(P-P_c^t)+v_c^t.
$$

由于 $v_c^t$ 与 $P_c^t$ 在等式中耦合，作者不直接学习二者，而学习等效参数：

$$
\bar v_c^t=v_c^t-w_p^t\times P_c^t,\quad \bar a_c^t=a_c^t-\epsilon_p^t\times P_c^t.
$$

最终 dynamics MLP $f_{\mathrm{trd}}$ 输入 particle $P$ 和 time $t$，输出 $\{(\bar v_c^t,\bar a_c^t),(w_p^t,\epsilon_p^t)\}$。这些参数构成每个粒子的 translation-rotation dynamics system。

### 4.4 RK2 Physical Rollout

给定两个相近时间 $t'$ 和 $t$，其中 $\Delta t=t-t'$，训练时先用 $f_{\mathrm{defo}}$ 得到 $G_{t'}$，再用 $f_{\mathrm{trd}}$ 查询 $t'$ 的物理参数，并通过二阶 Runge-Kutta 更新到 $t$。RK2 先计算中点速度和旋转向量，例如 $\bar v_c^{mid}=\bar v_c^{t'}+\Delta t\bar a_c^{t'}/2$，$w_p^{mid}=w_p^{t'}+\Delta t\epsilon_p^{t'}/2$，再用中点量更新 position 和 orientation。

作者选择二阶动力学是工程折中：一阶只能表达常速或静止，过于简单；三阶或更高阶能表达更复杂突变，但优化更难。对于机器人操控等短期未来预测，二阶通常足够。

### 4.5 Physical Parameter Clustering

训练完成后，物理参数本身可以作为 motion grouping features。作者在 $t=0.7$ 用 auxiliary deformation field 得到 steady state Gaussians，再查询每个 Gaussian 的参数，并选择 $(\|\bar v_c^t\|,\bar v_c^t,\|w_p^t\|,w_p^t/\|w_p^t\|)$ 作为聚类特征。简单 K-means 就能把具有相似运动模式的物体或部件分出来。

## 5. Mathematical Objectives and Losses

TRACE 的核心不是加入 PINN PDE loss，而是用显式参数和 RK2 物理推导替代软物理约束。训练时，$f_{\mathrm{defo}}$ 给出 $t'$ 的状态，$f_{\mathrm{trd}}$ 从 $t'$ 推导到 $t$，再通过渲染 loss 拟合目标时间多视角 RGB。也就是说，物理参数只要无法正确驱动未来状态，就会在 rendered image loss 中被惩罚。

关键结构约束包括：每个 Gaussian 是独立 rigid particle；运动是 translation center 与 particle rotation 的组合；未来状态不是直接查询网络，而是由 learned parameters 通过 mechanics 更新得到；等效参数化缓解 center velocity 和 center position 的耦合。

## 6. Training and Inference Procedure

训练第一阶段只用 $t=0$ 的所有相机图像训练 canonical 3DGS。第二阶段使用其他 timestamps，联合优化 auxiliary deformation field 和 translation-rotation dynamics system。训练中 $\Delta t$ 设为训练集连续帧间隔 $\delta t$ 的两倍，论文认为太小会让 motion 太微弱，旋转可能被误学为平移；太大又会牺牲 appearance fitting。

未来帧外推时，auxiliary deformation field 的 query time 固定到训练最大时间附近，例如 $t'=0.7$，之后 future frames 通过 Algorithm 1 按相同 $\Delta t$ progressive rollout。这样模型不需要在未来时间直接查询 deformation field，而是依靠物理参数更新。

## 7. Experimental Setup and Results Summary

主任务是 future frame extrapolation。论文在三个已有动态数据集和一个新建 Dynamic Multipart dataset 上评估，并与 T-NeRF、D-NeRF、TiNeuVox、HexPlane、NVFi、DefGS、DefGS+NVFi、4DGS 等比较。作者强调普通动态 NVS 方法在观测时间内插值可行，但未来外推通常失败。

在表 1 中，TRACE 在 Dynamic Object、Dynamic Indoor Scene、Dynamic Multipart 等数据集上显著优于基线。摘要性结论是：相比 T-NeRF / D-NeRF / TiNeuVox / DefGS / 4DGS，TRACE 和 TRACE4dgs 在 future extrapolation 上通常高约 10 PSNR；相比最强 physics baseline NVFi / DefGSnvfi，在更复杂的 Dynamic Indoor Scene 和 Dynamic Multipart 上仍约高 3 PSNR。

物理参数聚类在 Dynamic Indoor Scene 上得到很强的 motion segmentation。Table 2 中 TRACE 的 AP 95.82、PQ 93.28、F1 97.90、Precision 96.21、Recall 99.86、mIoU 79.55，明显高于 NVFi 的 91.21 / 78.74 / 93.75 / 93.76 / 93.74 / 67.64，也超过完全监督 2D Mask2Former 的 mIoU 64.42。

continual learning 在 ParticleNeRF dataset 上测试。训练时间逐步从 0-0.15 扩展到 0-0.75，并外推后续 0.15 区间。平均 PSNR：DefGS 19.718，DefGSnvfi 26.181，TRACE 27.544，说明新观测加入后物理模块能继续适应变化动力学。

ablation 表明，移除 auxiliary deformation field 损害最大，在 Dynamic Multipart 上从 33.481 / 0.990 / 0.007 降到 19.206 / 0.907 / 0.120。去掉 physics derivation 降到 29.602 / 0.983 / 0.012，去掉 equivalence parameterization 降到 29.986 / 0.985 / 0.012。二阶动力学整体优于一阶和三阶的折中。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是从多视角 RGB 视频学习复杂 3D scene physics、为每个 rigid particle 学习 translation-rotation dynamics system，并在未来帧外推和运动分割上显著优于基线。实际技术增量在于把 dynamic 3DGS 的 per-Gaussian deformation 重新解释为 rigid particle mechanics，并强制未来状态通过物理参数 rollout 得到。

与 NVFi / PINN 类方法相比，TRACE 不把物理作为软 loss，而是把参数化和更新规则硬编码为 mechanics rollout。与 DefGS / 4DGS 相比，TRACE 不直接查询未来时间的 deformation，而是从训练末端状态按 RK2 推演未来。

## 9. Limitations / Assumptions

TRACE 需要 multi-view RGB videos 和已知相机，而不是单目 casual video。它的设置比许多 monocular dynamic 3DGS 更强。

每个 Gaussian 被视为独立 rigid particle，虽然组合起来能表达复杂形变，但没有显式对象级约束；物理参数聚类是后处理，不是训练中显式 object model。

二阶 dynamics 是主要选择，对突发破裂、碰撞后拓扑变化或高阶非平滑 motion 可能不足。作者也承认更高阶关系有趣但 non-trivial，留作未来探索。

模型仍依赖 auxiliary deformation field 稳定训练。消融显示去掉它性能大幅下降，说明核心物理模块单独从早期不稳定 Gaussians 学习仍很困难。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Multi-view RGB dynamic videos with known cameras |
| Output | Canonical 3DGS + per-particle physical dynamics for future rendering |
| Core representation | Each Gaussian as oriented rigid particle |
| Physics parameters | Equivalent center velocity/acceleration, rotation vector, angular acceleration |
| Future update | RK2 rollout from learned physical parameters |
| Auxiliary module | Deformation field for stable training states |
| Main application | Future frame extrapolation and motion-parameter segmentation |
| Weakness | Needs multi-view cameras; depends strongly on auxiliary deformation field |

## 11. Reusable Components

- Per-Gaussian translation-rotation dynamics system for future extrapolation。
- Equivalent velocity / acceleration parameterization to avoid center-position coupling。
- RK2 rollout layer inside dynamic Gaussian training。
- Auxiliary deformation field as curriculum / stabilizer for physics parameter learning。
- Motion segmentation by clustering learned physical parameters rather than scene flow.

## 12. Gap / Idea Seeds

- Combine TRACE-style physical rollout with monocular MoSca/ProDyG scaffolds to reduce multi-view requirement。
- Add object-level regularization during training so clustered physical parts become stable without post-hoc K-means。
- Learn adaptive order dynamics per particle: static/constant velocity/acceleration/higher order selected by model confidence。
- Use collision/contact priors to handle interactions where independent rigid-particle dynamics may diverge。

## 13. Human Check List

- NEED_HUMAN_CHECK: Table 1 text extraction was partially truncated; this note records the paper's stated comparative conclusions plus available values from later tables.
- NEED_HUMAN_CHECK: TRACE4dgs indicates the framework can use 4DGS-like auxiliary deformation; primary note describes TRACE with DefGS-style auxiliary field.
- NEED_HUMAN_CHECK: The method is multi-view, not monocular, despite being in the Dynamic collection with many monocular papers.

## 14. Evidence Anchors

- Section 3.1: canonical 3DGS initialization and auxiliary deformation field。
- Section 3.2: translation-rotation dynamics parameters and equivalent parameterization。
- Section 3.3 / Algorithm 1: RK2 physical rollout during training。
- Section 4.1: future frame extrapolation setup and comparative conclusions。
- Section 4.2 / Table 2: physical-parameter clustering and motion segmentation results。
- Section 4.3 / Table 3: continual learning results。
- Section 4.4 / Table 4: ablations on $\Delta t$, dynamics order, deformation field, physics derivation and equivalent parameterization。
