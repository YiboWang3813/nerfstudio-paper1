# BARD-GS: Blur-Aware Reconstruction of Dynamic Scenes via Gaussian Splatting

## 0. Metadata

- Title: BARD-GS: Blur-Aware Reconstruction of Dynamic Scenes via Gaussian Splatting
- Authors: Yiren Lu; Yunlai Zhou; Disheng Liu; Tuo Liang; Yu Yin
- Venue/Year: CVPR 2025
- Project page: https://vulab-ai.github.io/BARD-GS/
- Zotero item key: `N6FGH64Z`
- Zotero PDF attachment key: `N3QEUB4G`
- PDF path: `/Users/wangyibo/Zotero/storage/N3QEUB4G/Lu 等 - BARD-GS Blur-Aware Reconstruction of Dynamic Scenes via Gaussian Splatting.pdf`
- Local note path: `notes/BARD-GS: Blur-Aware Reconstruction of Dynamic Scenes via Gaussian Splatting.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

BARD-GS 将动态场景中的 motion blur 显式拆成 camera-induced blur 和 object-induced blur：第一阶段用 exposure 内 virtual camera trajectory 只在静态区域优化相机运动去模糊，第二阶段用 dynamic Gaussian deformation trajectory 渲染 exposure 内多个 virtual timestamps，从而在 blurry monocular inputs 和不准相机下重建清晰动态 3DGS。

## 2. Problem Formulation

现实手持单目拍摄动态场景时，相机和物体常在同一曝光时间内同时运动，造成 motion blur。静态区域主要受 camera motion blur 影响，动态区域同时受 camera motion blur 和 object motion blur 影响。普通 dynamic 3DGS 假设输入图像清晰且相机准确，因此在 motion-blurred inputs 下几何和外观都会退化。

已有 deblur-GS 方法多面向静态场景，只能处理 camera blur；把它们直接接到 dynamic GS 上，仍无法解决物体高速运动导致的 object blur。NeRF-based dynamic deblurring 方法会把相机和物体运动耦合在 latent rays 中，静态区域占主导时容易牺牲动态区域细节。BARD-GS 的目标是显式分离两种 blur source 并分阶段处理。

## 3. Method Overview

BARD-GS 有两个训练阶段。Stage 1 是 camera motion deblurring：用 COLMAP 得到不准的 blurry-image camera poses，然后为每个输入图像学习 exposure 开始和结束的 virtual camera poses，并在 SO(3) / translation 上插值得到多个 virtual cameras。用这些 virtual poses 渲染静态 Gaussians 的多个 sharp images，平均成 reconstructed blurry image，只在静态 mask 区域与输入 blur 对齐。

Stage 2 是 object motion deblurring：在 Stage 1 优化出的相机基础上，初始化 dynamic Gaussians，并用 deformation field 学习 dynamic Gaussians 在时间上的 trajectory。对于每个 blurry input，取 exposure 内多个 virtual timestamps，渲染对应 virtual camera 和 virtual Gaussians 的 sharp images，再平均成 blur，与整张输入图像对齐。为了让 deformation field 真正跟随物体运动，初期加入由 BootsTAPIR + Depth-Anything + optimized cameras 得到的 3D track loss。

## 4. Method Details

### 4.1 Motion Blur Formation

motion blur 被建模为曝光时间内瞬时 radiance 的积分。连续形式为 $B(u,v)=\phi\int_0^\tau S_t(u,v)dt$，其中 $S_t$ 是时间 $t$ 的瞬时清晰图像，$\tau$ 是曝光时间。实现中用离散平均近似：

$$
B(u,v)\approx \frac{1}{n}\sum_{i=0}^{n-1}S_i(u,v).
$$

因此无论是 camera blur 还是 object blur，都可以通过渲染 exposure 内多个 virtual sharp views / states 后平均来模拟。

### 4.2 Camera Trajectory Modeling

给定 blurry images $\{B_i\}_{i=1}^{T}$，先用 COLMAP 得到初始但不准确的 real camera poses $\tilde P_i$。对每张图像，学习 exposure 开始和结束的 pose offsets $\Delta P_i^0$ 和 $\Delta P_i^n$：

$$
P_i^0=\tilde P_i\cdot\Delta P_i^0,\quad P_i^n=\tilde P_i\cdot\Delta P_i^n.
$$

中间 virtual poses $P_i^j$ 由 $P_i^0$ 和 $P_i^n$ 插值得到。rotation 在 $SO(3)$ / $so(3)$ manifold 上通过 exp/log 插值，translation 线性插值。评估时取 midpoint pose $P_i^{mid}$ 作为优化后相机。

### 4.3 Camera Motion Deblurring

Stage 1 只优化 camera trajectory 和 static Gaussians。用 virtual cameras 渲染 $n+1$ 张静态 sharp images 并平均：

$$
\hat B_i=\frac{1}{n+1}\sum_{j=0}^{n}I_i^j(P_i^j,G_c^{static}).
$$

损失只在静态区域计算：$L_{\mathrm{render}}=\sum_{(x,y)\notin M_d}\|\hat B_i(x,y)-B_i(x,y)\|_1$。动态 mask $M_d$ 由 TrackAnything 获得。这样动态区域不会污染 camera blur estimation，Stage 1 可以专注恢复静态背景和相机 motion。

### 4.4 Object Motion Modeling

Stage 2 用 MLP deformation field 建模动态物体：

$$
(\delta x,\delta r,\delta s)=F_\theta(\gamma(x),\gamma(t)).
$$

输入 canonical Gaussian mean $x$ 和 timestamp $t$，输出 position、rotation 和 scale offsets。论文还给 static Gaussians 加了一个额外 static deformation field，用于处理移动物体造成的 reflection / shadow 等副产物，以及静态边缘区域初始 Gaussians 不足导致的质量问题。

### 4.5 Object Motion Deblurring

对 blurry image $B_i$，取 exposure 内 virtual timestamps $\{t_i^j\}_{j=0}^{n}$，在 $[t_i-\tau/2,t_i+\tau/2]$ 内均匀插值。用 deformation field 得到每个 virtual time 的 Gaussians $G_i^j=G_c+F_\theta(\gamma(X),\gamma(t_i^j))$。此时 blur synthesis 同时考虑 camera 和 object：

$$
\hat B_i=\frac{1}{n+1}\sum_{j=0}^{n}I_i^j(P_i^j,G_i^j).
$$

Stage 2 的 rendering loss 在整张图像上计算，优化 dynamic 和 static regions。

### 4.6 3D Track Loss

仅靠 rendering loss，deformation field 可能不会让同一组 Gaussians 跟随同一物体，而是在不同时间用不同 Gaussians 表示同一运动物体。为此，作者在训练初期加入 3D track loss：

$$
L_{\mathrm{track}}=\sum_{x_i\in dynamic}\|x_i^{gt}-x_i\|_1.
$$

参考轨迹 $x_i^{gt}$ 的构造是：先用 BootsTAPIR 在 dynamic mask 内得到 2D pixel trajectories，再用 Depth-Anything 估计深度，并使用 Stage 1 优化相机把 2D tracks back-project 到 3D。该 loss 强迫 dynamic Gaussians 跟随像素/物体轨迹，尤其有助于 fast object motion。

## 5. Mathematical Objectives and Losses

BARD-GS 的核心 loss 分阶段变化。Stage 1 只用静态区域的 blur reconstruction loss 优化 virtual cameras 和 static Gaussians，避免动态物体影响相机估计。Stage 2 用整图 blur reconstruction loss，同时优化 dynamic deformation 和 static refinement。训练早期额外加入 $L_{\mathrm{track}}$，防止 deformation field 学到不符合物体轨迹的 Gaussian reassignment。

整体上，本文不是先做 2D deblurring 再重建，而是在 3DGS 渲染过程中模拟 blur formation，把 deblurring 变成对 camera trajectory 和 Gaussian trajectory 的联合估计。

## 6. Training and Inference Procedure

总训练 80K iterations。前 10K 用 Stage 1 loss 优化 virtual cameras 和 static region reconstruction。10K 到 30K 引入 static deformation field，并使用 Stage 2 rendering loss 加 3D track loss；此阶段暂停 dynamic Gaussians 的 splitting、duplicating 和 culling，因为假设 dynamic Gaussians 与 3D track points 一一对应。30K 之后移除 track loss，仅使用 Stage 2 rendering loss，并恢复 dynamic Gaussians 的 densification / pruning。

推理或评估时，用 optimized midpoint camera pose 渲染目标视角。动态物体通过 deformation field 在目标 timestamp 变形，最终输出清晰 novel view。

## 7. Experimental Setup and Results Summary

论文构建了两个 blur 数据设置。synthetic blurry dataset 由 HyperNeRF 和 DyCheck sharp frames 通过 RIFE 插帧到高帧率后平均得到，用于 deblurring evaluation。real-world captured blurry dataset 包含 12 个动态场景，用两台同步 GoPro 采集：一台 1/24s exposure 拍 blurry training images，另一台 1/240s exposure 拍 sharp evaluation images，用于 NVS 评估。

synthetic deblurring 表中，Ours 为 PSNR 28.75、SSIM 0.8414、LPIPS 0.2343、LV 65.31、MUSIQ 57.03，高于 DyBluRF、D3DGS、D3DGS+MPRNet、4DGS、4DGS+MPRNet。real-world NVS 表中，Ours 的 SI-PSNR 25.13、SI-SSIM 0.8508、SI-LPIPS 0.1567、LV 96.42、MUSIQ 54.29，也明显优于所有 baseline 和 pre-deblur variants。

消融表显示，去掉 static deblurring 影响最大：deblurring PSNR 从 28.75 降到 26.00，NVS SI-PSNR 从 25.13 降到 22.22，LV 也大幅下降。去掉 track loss 或 dynamic deblurring 会降低动态区域质量；去掉 static deformation field 也会影响静态细节。virtual views 数量从 6 到 20 的消融显示，增加 virtual cameras 有助于 blur handling，但超过某个点后收益下降甚至反效果。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 blur-aware dynamic scene reconstruction、显式解耦 camera/object motion blur，以及新的 real-world blurry dynamic dataset。实际技术增量在于把静态 deblur-GS 的 exposure camera trajectory 思路扩展到动态场景，并明确用两阶段训练阻止静态区域主导 object blur learning。

与 DyBluRF 的 latent-ray blur modeling 相比，BARD-GS 通过显式 virtual cameras 和 virtual Gaussians 分别表达两类 motion，因此动态区域细节更可控。与 D3DGS / 4DGS + 2D pre-deblurring 相比，它直接在 3D reconstruction 中建模 blur formation，避免 2D deblurring 失败或破坏多视角一致性。

## 9. Limitations / Assumptions

dynamic masks 来自 TrackAnything，2D tracks 来自 BootsTAPIR，depth 来自 Depth-Anything；这些外部模型的错误会影响 camera/object blur 分离和 track loss。

object motion 在 exposure 内假设 constant speed，virtual timestamps 均匀插值。对强加速度、旋转或非线性快速运动，这个假设可能不足。

Stage 1 依赖静态区域占据足够比例并可由 COLMAP 初始化相机；若动态物体占满画面或 COLMAP 在 blurry images 上失败，相机 motion deblurring 会不稳定。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Blurry monocular dynamic video with imprecise camera poses |
| Output | Sharp dynamic 3DGS and optimized camera poses |
| Blur decomposition | Camera-induced blur + object-induced blur |
| Camera blur model | Virtual camera trajectory within exposure |
| Object blur model | Virtual Gaussian trajectory via deformation field |
| Main supervision | Blur reconstruction loss, static mask loss region, early 3D track loss |
| Dataset contribution | Real-world blurry dynamic scenes with paired sharp evaluation captures |
| Weakness | Depends on masks/tracks/depth priors; constant-speed exposure assumption |

## 11. Reusable Components

- exposure-time virtual camera interpolation on $SO(3)$ for camera blur。
- two-stage blur decomposition: static-region camera deblur before object deblur。
- virtual timestamp Gaussian rendering and averaging for object blur。
- early 3D track loss from 2D tracker + monocular depth + optimized cameras。
- paired blurry/sharp capture protocol with different GoPro exposure times。

## 12. Gap / Idea Seeds

- Replace constant-speed exposure interpolation with spline or acceleration-aware object trajectories。
- Jointly estimate dynamic masks instead of relying on TrackAnything。
- Use uncertainty-weighted track loss so unreliable BootsTAPIR / depth points contribute less。
- Model rolling shutter and exposure timing jointly with blur, since handheld videos often contain both.

## 13. Human Check List

- NEED_HUMAN_CHECK: The paper uses TrackAnything, BootsTAPIR and Depth-Anything as external priors; exact versions are not specified in the extracted text.
- NEED_HUMAN_CHECK: Real-world sharp evaluation images are captured by a second GoPro, so pose alignment motivates shift-invariant metrics in Table 2.
- NEED_HUMAN_CHECK: Some synthesized GT frames may themselves be blurry due to low frame rate, which the authors mention in qualitative analysis.

## 14. Evidence Anchors

- Section 3.2: physical motion blur formation and discrete averaging approximation。
- Section 3.3: virtual camera pose endpoints, SO(3) interpolation and static-region rendering loss。
- Section 3.4: deformation field, virtual timestamps, full-image object blur loss and 3D track loss。
- Section 4: synthesized and real-world blurry datasets。
- Section 5 / Tables 1-4: deblurring, NVS, component ablation and virtual-view-count ablation。
