# Template-free Articulated Gaussian Splatting for Real-time Reposable Dynamic View Synthesis

## 0. Metadata

* Title: Template-free Articulated Gaussian Splatting for Real-time Reposable Dynamic View Synthesis
* Authors: Diwen Wan; Yuxiang Wang; Ruijie Lu; Gang Zeng
* Venue/Year: NeurIPS 2024
* Project: `https://dnvtmf.github.io/SK_GS/`
* Code: `https://github.com/dnvtmf/SK_GS`
* Zotero item key: `9MR3K298`
* Zotero PDF attachment key: `Y56BL6YS`
* PDF path: `/Users/wangyibo/Zotero/storage/Y56BL6YS/Wan 等 - Template-free Articulated Gaussian Splatting for Real-time Reposable Dynamic View Synthesis.pdf`
* Local note path: `notes/Template-free Articulated Gaussian Splatting for Real-time Reposable Dynamic View Synthesis.md`
* Tags: Dynamic Gaussian Splatting; Articulated Object; Reposing; Skeleton Discovery; Superpoints

## 1. One-Sentence Technical Summary

这篇文章用 3D Gaussians 表示 canonical appearance，用 learnable superpoints 聚合相似运动的 Gaussians，再从 superpoint motion 中自动发现 skeleton tree 并切换到 kinematic model 优化，从而在不依赖类别模板或 pose annotation 的情况下得到可重摆姿态、可实时渲染的 articulated dynamic object。

## 2. Problem Formulation

### 2.1 输入

* 多视角动态物体视频。
* 已知 camera poses。
* 没有 object-specific template。
* 没有 skeleton/pose annotations。

### 2.2 输出

* canonical 3D Gaussian object。
* superpoints 作为近似 rigid parts。
* 自动发现的 skeleton model，包括 joints 和 tree structure。
* 可通过 skeleton / kinematic model re-pose 的 dynamic view synthesis 模型。

### 2.3 目标

* 保持 3DGS 的高质量和实时渲染速度。
* 学到可编辑、可 reposing 的 articulated representation，而不是只能 replay training video 的动态场景。
* 避免 WIM/AP-NeRF 的慢渲染或低质量问题。
* 不使用 SMPL、animal template、human-specific prior 等类别模板。

### 2.4 基本假设

* 目标主要是一个 articulated object。
* superpoints 可以近似表示 rigid parts。
* 输入视频中的运动足以暴露 skeleton structure。
* multi-view calibration 足够准确。

## 3. Method Overview

方法分三步。

### 3.1 Dynamic stage

在 canonical space 中训练 3D Gaussians，并学习 superpoints。每个 superpoint 通过 deformable field $\Phi$ 在时间 $t$ 预测 6-DoF transform。Gaussian 的动态位置和旋转由邻近 superpoints 的 LBS interpolation 得到。

### 3.2 Skeleton discovery stage

训练完 dynamic stage 后，把每个 superpoint 视为 rigid part。根据 superpoint 间的相对运动和潜在 joint 稳定性，估计两两 superpoint 之间是否应连接。然后用 minimum spanning tree 得到 skeleton tree，并选择 tree center 作为 root。

### 3.3 Kinematic stage

固定 skeleton structure 后，用 kinematic model 和新的 deformable field $\Psi$ 预测 joint rotations。再通过 forward kinematics 得到 superpoint transforms，用 LBS 驱动 Gaussians 渲染。这个阶段微调 joints、kinematic model 和 Gaussians。

### 3.4 Adaptive control

为了避免 superpoints 过多或分布不合理，训练过程中对 superpoints 做 prune、densify 和 merge，并用 motion regularization、smooth skinning 和 sparse skinning 正则控制其行为。

## 4. Method Details

### 4.1 Canonical Gaussian representation

每个 Gaussian $G_i$ 包含 position $\mu_i$、quaternion $q_i$、scale $s_i$、opacity $\sigma_i$ 和 SH coefficients $h_i$。covariance 为 $\Sigma_i=R_iS_iS_i^TR_i^T$。

渲染仍使用 3DGS 的 EWA splatting 和 alpha compositing。优化静态 3DGS 时使用 $L_{rgb}=(1-\lambda)L_1(I,I_{gt})+\lambda L_{SSIM}(I,I_{gt})$，其中 $\lambda=0.2$。

### 4.2 Superpoint-based deformation

superpoints $P=\{p_j\}_{j=1}^M$ 是 learnable 3D points，关联一组 Gaussians，并被解释为 object rigid parts。对时间 $t$，deformable field 预测 superpoint transform：

$$
\Phi:(p_j,t)\rightarrow (R_j^t,o_j^t).
$$

Gaussian $G_i$ 的动态 mean 和 rotation 由 $K$ 个最近 superpoints 进行 LBS：

$$
\mu_i^t=\sum_{j\in N_i} w_{ij}(R_j^t\mu_i+o_j^t),\quad q_i^t=(\sum_{j\in N_i}w_{ij}r_j^t)\otimes q_i.
$$

LBS weights $w_{ij}$ 来自 learnable matrix $W$ 的 softmax。scale、opacity、SH 在 dynamic stage 中保持 canonical attributes。

### 4.3 Skeleton discovery cues

论文复用 WIM 的直觉：

* 若两个 parts 之间有关节，它们在空间中通常较近。
* 当两个 parts 相对姿态变化时，关节位置相对稳定。
* 若两个连接 parts 在整段序列中保持相同相对姿态，它们可被合并。

对 superpoint pair $(a,b)$，估计潜在 joint $j_{ab}$，并用相对 transform 的一致性定义距离 $d_{ab}$。同时约束从 $a$ 到 $b$ 和从 $b$ 到 $a$ 推出的 joint 一致。距离用 momentum 平滑：

$$
\hat d_{ab}(\tau+1)=(1-\epsilon)\hat d_{ab}(\tau)+\epsilon d_{ab}(\tau),
$$

其中 $\epsilon=0.1$。之后只考虑 $K'$-nearest superpoint pairs，按 $\hat d_{ab}$ 从小到大加入边，若不形成 cycle 则加入 skeleton graph，最终得到 tree。

### 4.4 Kinematic model

Skeleton discovery 后，用 $\Psi$ 为每个 joint $j_k$ 和时间 $t$ 预测 rotation $\hat R_k^t$。沿 skeleton tree 做 forward kinematics，superpoint $p_j$ 的 transform 是 root transform 与 ancestor bone transforms 的连乘。再使用与 dynamic stage 相同的 LBS 把 superpoint transforms 传播到 Gaussians。

### 4.5 Adaptive control of superpoints

Prune:

* 计算 superpoint impact $W_j=\sum_{i\in \tilde N_j} w_{ij}$。
* 若 $W_j<\delta_{prune}$，说明它几乎不影响 Gaussians motion，删除。

Densify:

* 若 $W_j>\delta_{clone}$，说明太多 Gaussians 依赖该 superpoint，clone 以表达细节运动。
* 若 weighted Gaussian gradient norm $g_j$ 超过 $\delta_{grad}$，也 clone。

Merge:

* 对 superpoint pair $(a,b)$，计算整段训练时间上的平均相对 transform 距离 $D_{a,b}$。
* 若 $D_{a,b}<\delta_{merge}$ 且 $p_b$ 是 $p_a$ 的 $K'$ 近邻，则 merge。

这个控制策略的目标是减少冗余 superpoints，同时让剩余 superpoints 更集中在运动区域。

## 5. Mathematical Objectives and Losses

### 5.1 Dynamic stage loss

dynamic stage 使用重建损失、joint discovery 辅助项和 superpoint 正则。总损失为：

$$
L=\lambda_0L_{rgb}+\lambda_1L_{joint}+\lambda_2L_{arap}+\lambda_3L_{smooth}+\lambda_4L_{sparse}.
$$

实验中 $\lambda=\{1,1,10^{-3},0.1,0.1\}$。

### 5.2 Regularizers

* $L_{joint}$: 鼓励潜在 joint distance 可用于 skeleton discovery。
* $L_{arap}$: as-rigid-as-possible regularization，鼓励邻近 superpoints 有相似 motion pattern。
* $L_{smooth}$: 对 LBS weights 做 smoothness penalty。
* $L_{sparse}$: 用 entropy-like term 鼓励一个 Gaussian 主要绑定到少数 superpoints。

### 5.3 Skeleton discovery loss

skeleton discovery stage 固定 skeleton structure 后，缓存 dynamic stage 中 $\Phi$ 输出的 superpoint motions，并训练 $\Psi$ 与 kinematic model 去匹配这些 transforms。其 loss 同时约束 rotation/translation transform difference 和 superpoint position offset，权重 $\lambda_5=1$、$\lambda_6=0.1$。

### 5.4 Kinematic stage loss

kinematic stage 固定 Gaussian 数量、superpoint 数量和 skeleton structure，只使用 $L_{rgb}$ 优化 kinematic model、joints 和 Gaussians。

## 6. Training and Inference Procedure

### 6.1 Architecture and hyperparameters

* $\Phi$ 和 $\Psi$ 都使用 NeRF-style 8-layer MLP。
* 每层 hidden dimension 为 256，ReLU activation。
* 输入坐标与时间使用 positional encoding；坐标 $L=10$，时间 $L=6$。
* initial superpoints 数量为 512。
* $K=K'=5$。
* optimizer 为 Adam。
* 3D Gaussians learning rate follow 3DGS；其他组件从 $10^{-3}$ 到 $10^{-5}$ exponential decay。
* 单张 NVIDIA Tesla V100 32GB 上训练。

### 6.2 Dynamic stage schedule

总计 40k iterations：

* 0-2k: 固定 deformable field $\Phi$。
* 2k-10k: 训练 $\Phi$，此时输入用 Gaussian positions 而不是 superpoints；7.5k 用 farthest point sampling 采样 $M$ 个 Gaussians；10k 初始化 superpoints 并重置 canonical Gaussians。
* 10k-13k: 再次固定 $\Phi$。
* 13k-40k: 优化所有参数。
* 前 20k 不发现 joints，即 $\lambda_1=0$。
* 20k-40k 每 100 iterations 更新 skeleton structure。
* joint 与其他模块之间 stop-gradient，避免 joint learning 反向影响 Gaussians/superpoints/deformation field。

Gaussian adaptive control:

* iterations 1-7500 和 10k-35k，每 100 iterations densify/prune。
* densify gradient threshold 为 0.0002。
* opacity prune threshold 为 0.005。
* 每 3k steps reset Gaussian opacity。

Superpoint adaptive control:

* 20k-30k 每 1000 steps densify/prune superpoints。
* $\delta_{grad}=0.0002$，$\delta_{prune}=0.001$。
* 30k-40k 每 1000 steps merge superpoints。
* $\delta_{merge}=0.0005$。

### 6.3 Skeleton discovery stage

* 固定 skeleton structure $\Gamma$。
* 根据 $\Gamma$ 初始化 joints。
* 缓存 dynamic stage 中所有训练时间戳的 superpoint motions。
* 用 Adam 优化 $\Psi$ 和 joint positions。
* 训练 10k iterations，learning rate 为 $10^{-3}$。

### 6.4 Kinematic stage

* 固定 Gaussian 数量、superpoint 数量和 skeleton structure。
* 优化 kinematic model、joints 和 Gaussians。
* 训练 40k iterations。
* 只使用 $L_{rgb}$。

### 6.5 Inference / reposing

给定 skeleton pose 或插值得到的新 pose，通过 kinematic model 得到 superpoint transforms，再用 LBS warping canonical Gaussians，最后用 3DGS rasterizer 实时渲染 novel view。

## 7. Experimental Setup and Results Summary

### 7.1 Datasets

* D-NeRF: 使用 6 个 scene，排除 Lego 和 Bouncing Balls；每个 scene 50-200 frames。
* Robots: 7 个 topology 不同的 robot synthetic multi-view videos；18 views training，2 views evaluation。
* ZJU-MoCap: follow WIM/AP-NeRF，评估 5 sequences，每个 sequence 使用 6 training views。

Metrics: PSNR, SSIM, LPIPS, FPS。

### 7.2 D-NeRF results

| Method | Skeleton | PSNR | SSIM | LPIPS | FPS | Resolution | Opt. Time |
|---|---|---:|---:|---:|---:|---|---:|
| WIM | yes | 25.21 | 0.9383 | 0.0700 | 0.16 | 400x400 | 11 h |
| AP-NeRF | yes | 30.91 | 0.9700 | 0.0350 | 1.33 | 400x400 | 150 min |
| 4D-GS | no | 34.39 | 0.9830 | 0.0190 | 141.37 | 800x800 | 20 min |
| SP-GS | no | 37.55 | 0.9884 | 0.0137 | 234.83 | 800x800 | 52.3 min |
| D-3D-GS | no | 40.11 | 0.9918 | 0.0120 | 42.10 | 800x800 | 66 min |
| SC-GS | no | 42.98 | 0.9955 | 0.0028 | 123.04 | 400x400 | 53.3 min |
| Ours | yes | 38.80 | 0.9870 | 0.0095 | 103.98 | 800x800 | 90.6 min |
| Ours | yes | 39.23 | 0.9890 | 0.0070 | 110.90 | 400x400 | 92.5 min |

解读：它明显优于 template-free articulated baselines WIM/AP-NeRF，并且做到实时渲染。与非 skeleton 的 3DGS dynamic methods 相比，质量低于 SC-GS/D-3D-GS，但多了 skeleton discovery 和 reposing 能力。

### 7.3 Robots results

| Method | PSNR | SSIM | LPIPS | FPS |
|---|---:|---:|---:|---:|
| WIM | 29.11 | 0.9664 | 0.0350 | 0.11 |
| AP-NeRF | 32.45 | 0.9784 | 0.0202 | 0.89 |
| Ours | 34.34 | 0.9809 | 0.0187 | 137.76 |

Robots 上的优势更直接：质量高于 WIM/AP-NeRF，速度约 138 FPS。

### 7.4 ZJU-MoCap results

| Method | PSNR | SSIM | LPIPS | FPS |
|---|---:|---:|---:|---:|
| WIM | 31.08 | 0.963 | 0.053 | 0.12 |
| AP-NeRF | 29.60 | 0.958 | 0.063 | 1.31 |
| Ours | 29.11 | 0.961 | 0.063 | 198.23 |

论文承认 ZJU-MoCap 上因 camera calibration imperfections，视觉质量低于 WIM/AP-NeRF，但渲染速度远高。

### 7.5 Ablation / resource summary

* Without adaptive control: superpoints 分布不均，运动区域反而稀疏，motion modeling 变差。
* Without merge: superpoints 数量显著增加；示例中 full 为 97，without merge 为 608。
* Without $L_{arap}$: superpoint density control 变差。
* D-NeRF average training resource: 1.51 h, 2.83 GB VRAM, $1.28\times 10^5$ Gaussians, 118.5 superpoints。
* 初始 superpoint 数量 $M$ 在 hellwarrior 上有 ablation；$M=512$ 不是最高 PSNR，但作为默认兼顾数量和效果。

## 8. Claimed Contribution vs Actual Technical Delta

### 8.1 Claimed contributions

* 用 3D Gaussians 和 superpoints 从视频建模 articulated object appearance、skeleton 和 motion。
* 不依赖 category-specific template 或 pose annotations，自动发现 skeleton。
* 用 adaptive control 和正则学习、控制 superpoints。
* 在多数据集上达到较好 visual fidelity 和实时渲染。

### 8.2 Actual technical delta

真正的技术增量是把 template-free articulation recovery 和 3DGS rendering 结合起来：

* superpoints 从 SC-GS/SP-GS 风格的 motion control primitive 变成 skeleton discovery 的 part proxy。
* dynamic stage 先学习一个 flexible deformation model，再把它蒸馏/投影到 kinematic skeleton model。
* skeleton discovery 使用 WIM 式 joint stability 和 MST，但底层 appearance renderer 换成实时 3DGS。
* adaptive control 解决 superpoints 太多导致 skeleton 不可编辑的问题。

### 8.3 与动态重建方法的边界

这不是追求最高 PSNR 的 dynamic 3DGS replay 方法。它牺牲一部分与 SC-GS/D-3D-GS 相比的重建质量，换取显式 skeleton 和 reposing。评价时应与 WIM/AP-NeRF 这类 articulated template-free methods 对齐，而不是只和非可编辑 dynamic GS 比 PSNR。

## 9. Limitations / Assumptions

* 学到的 skeleton 受输入视频运动空间限制，可能与真实物理 skeleton 差异明显。
* 对 unseen poses 的 extrapolation 可能出错。
* 与其他 dynamic 3DGS 一样，camera pose 不准会导致 reconstruction failures。
* large motion 或 long-term sequences 可能失败。
* 主要处理一个 articulated object；多组件物体或复杂多物体场景仍是 future work。
* ZJU-MoCap 上质量受 calibration imperfection 影响，说明实际数据鲁棒性仍有限。
* skeleton discovery 是基于 motion cues 的 heuristic/MST，不保证语义部件正确。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| Task | template-free articulated dynamic view synthesis and reposing |
| Input | calibrated multi-view videos |
| Output | canonical 3DGS + superpoints + skeleton tree + kinematic model |
| Core primitive | 3D Gaussians and learnable superpoints |
| Motion model | dynamic stage: superpoint MLP transforms + LBS; kinematic stage: skeleton forward kinematics + LBS |
| Skeleton discovery | joint stability distance + MST |
| Editing | skeleton pose interpolation/reposing |
| Template-free | yes |
| Pose annotation-free | yes |
| Real-time | yes, roughly 100-200 FPS depending dataset |
| Main baselines | WIM, AP-NeRF, D-NeRF, 4D-GS, D-3D-GS, SP-GS, SC-GS |
| Best fit | single articulated object with enough observed motion |
| Main weakness | skeleton extrapolation and calibration/large-motion robustness |

## 11. Reusable Components

* **Superpoint-to-skeleton pipeline**: 先学习 flexible superpoint motion，再从 motion 中抽 skeleton。
* **MST-based articulation graph discovery**: 用两两 part distance 构图，再取 tree。
* **Dynamic-to-kinematic distillation**: 用 flexible deformation field 的 cached motions 初始化/监督 kinematic field。
* **Superpoint adaptive control**: prune/densify/merge 让 control primitives 数量可编辑。
* **Sparse/smooth LBS regularization**: 可复用于其他 control-point dynamic GS。

## 12. Gap / Idea Seeds

* 用 uncertainty 或 multi-hypothesis skeleton 表达 motion ambiguity，而不是单一 MST tree。
* 对 unseen pose 加 physical/joint-limit prior，减少 skeleton extrapolation error。
* 在 multi-object scene 中先做 object decomposition，再分别运行 skeleton discovery。
* 把 semantic part segmentation 或 foundation model correspondence 引入 superpoint merge，提升语义部件一致性。
* 用 differentiable calibration refinement 改善 ZJU-MoCap 这类 pose 不准场景。
* 将 kinematic stage 的 pose controls 暴露成可交互编辑器，记录重摆姿态下的 failure cases。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: 论文没有 DOI；如果 Zotero 后续补全 metadata，需要同步。
* `NEED_HUMAN_CHECK`: Code URL 来自 NeurIPS checklist，需确认仓库当前可访问且版本对应论文。
* `NEED_HUMAN_CHECK`: Eq. 13 的 $g_j$ 在 PDF 抽取中分母排版不清，需看原 PDF/源码确认 precise implementation。
* `NEED_HUMAN_CHECK`: $L_{joint}$ 中第二项基于 $\Gamma$ 的具体更新时序和 stop-gradient 细节需结合代码确认。
* `NEED_HUMAN_CHECK`: ZJU-MoCap calibration imperfection 的影响可能与具体 preprocessing 有关。
* `NEED_HUMAN_CHECK`: Reposing 结果主要是可视化展示，缺少定量 pose-control 指标。

## 14. Evidence Anchors

* Abstract: claims template-free skeleton model discovery from videos using 3DGS and superpoints.
* Fig. 1: two-stage dynamic/kinematic pipeline plus skeleton discovery and adaptive control.
* Sec. 3.2: superpoints predict time-varying 6-DoF transforms through $\Phi$ and drive Gaussians through LBS.
* Eq. 5-7: superpoint transform, Gaussian LBS deformation, and skinning weight softmax.
* Sec. 3.3: skeleton discovery observations and MST construction.
* Eq. 9-10: pairwise joint distance and momentum smoothing.
* Sec. 3.4: kinematic model with $\Psi$ and forward kinematics.
* Sec. 3.5: prune/densify/merge superpoints.
* Appendix A: dynamic stage loss, schedules, thresholds, and three-stage optimization.
* Table 1: D-NeRF comparison; ours 38.80/39.23 PSNR and about 104/111 FPS.
* Table 2: Robots comparison; ours 34.34 PSNR and 137.76 FPS.
* Table 3: ZJU-MoCap; ours lower PSNR but 198.23 FPS.
* Fig. 6: ablation on adaptive control, merge, and $L_{arap}$.
* Sec. 5.1: limitations on observed motion space, camera pose accuracy, large motion, long-term sequences, and multi-object scenes.
