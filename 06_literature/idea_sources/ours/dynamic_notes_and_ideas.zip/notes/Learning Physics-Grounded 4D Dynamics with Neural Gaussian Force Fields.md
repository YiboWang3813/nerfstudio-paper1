# Learning Physics-Grounded 4D Dynamics with Neural Gaussian Force Fields

## 0. Metadata

- Paper title: Learning Physics-Grounded 4D Dynamics with Neural Gaussian Force Fields
- Authors: Shiqian Li; Ruihong Shen; Junfeng Ni; Chang Pan; Chi Zhang; Yixin Zhu
- Venue / year: ICLR 2026
- Project / code: `https://neuralgaussianforcefield.github.io/`
- Zotero item key: `NRGNAYDY`
- Zotero PDF attachment key: `ILCQMKH9`
- Zotero PDF path: `/Users/wangyibo/Zotero/storage/ILCQMKH9/Li 等 - 2025 - Learning Physics-Grounded 4D Dynamics with Neural Gaussian Force Fields.pdf`
- Local note path: `notes/Learning Physics-Grounded 4D Dynamics with Neural Gaussian Force Fields.md`

## 1. One-Sentence Technical Summary

NGFF 将多视角 RGB 重建为 object-aware 3D Gaussians，再用 DeepONet/relational neural operator 预测 object-centric force fields，并通过 ODE solver 推进 Gaussian 状态，从而生成具备物理一致性的交互式 4D 视频。

## 2. Problem Formulation

输入是在初始时刻从多个未定姿视角采集的 RGB 图像 $I_0=\{I_0(p_k)\in\mathbb{R}^{H\times W\times 3}\mid k=1,\ldots,N\}$，目标是在任意未来时间 $t\in T$ 和任意相机位姿 $p\in\mathbb{R}^6$ 下生成未来观测 $I_t(p)$，同时满足视觉一致性和物理约束。

场景由初始 Gaussians $G_0=\{g_{0,i}\}_{i=1}^{M}$ 表示，编码几何、外观和语义属性。核心动态问题是学习 neural dynamics model $f_\theta$，使其预测物理合理的状态转移：

$$
G_{t+1}=f_\theta(G_t),
$$

并通过 Gaussian splatting 渲染：

$$
I_{t,k}=\operatorname{Render}(G_t,p_k).
$$

相比纯视频生成模型，NGFF 明确建模物体间力和 ODE 轨迹；相比传统 Gaussian+physics-engine 方法，它用神经力场替代昂贵模拟器，追求更快推理和更强泛化。

## 3. Method Overview

NGFF 分为 perception 和 dynamics 两部分。Perception 部分使用 feed-forward transformer 从 unposed multi-view RGB images 预测相机位姿、Gaussian centers 和 Gaussian attributes；再用 SAM2 生成 instance masks，并通过 majority voting 把 Gaussians 划分为 object groups；为补全遮挡或不可见部分，还使用 DiffSplat 和 Sim(3) pose refinement 增强对象拓扑完整性。

Dynamics 部分把每个 object group 编码成 object state $z_q(t)$，包括 semantic features、zeroth-order states 和 first-order states。DeepONet-style neural operator 在接触图上预测 global transformation force field，并通过局部网络预测 soft-body local stress field。二者组成 unified force field $F(z_q(t))$，再由 second-order ODE solver 积分得到未来 object trajectories。最后演化后的 Gaussians 被渲染成未来多视角视频。

## 4. Method Details

### 4.1 Feed-Forward 3D Reconstruction

输入图像先由 DINOv2 tokenization，再进入 $L$ 层 Alternating-Attention Transformer，建模多视角全局几何关系。三个 decoder heads 分别预测：camera poses $p$、Gaussian centers $\mu$、以及 Gaussian attributes $(\alpha,r,s,c)$。其中 pose 和 center 使用 pixel-shuffling decoder，attributes 使用 convolutional upsampling 和 RGB shortcuts 以保留外观细节。

重建模块初始化自 pretrained $\pi^3$ 参数。训练时 feature encoder、point head 和 camera head 冻结，splatter head 在 WildRGBD 上用 RGB 与 geometric consistency losses fine-tune，使 predicted/rendered depth maps 对齐。

### 4.2 Object-Centric Gaussian Reconstruction

物理模拟需要对象级状态，而不是未分组的 Gaussian cloud。NGFF 用 SAM2 生成 pixel-wise instance masks，并将 masks 回投到 Gaussians 上，通过 majority voting 给每个 Gaussian 分配 object label：

$$
G_k=\{g\in G\mid \operatorname{label}(g)=k\}.
$$

由于多视角 RGB 输入可能存在遮挡和不可见区域，作者使用 DiffSplat 结合 Sim(3) pose estimation refinement，对单视图输入进行对象补全和拓扑修复。论文说明 refinement 选择 single-view 而非 multi-view，因为最终 3D generation 效果更好。

### 4.3 Object State Definition

每个 query object $q$ 在时间 $t$ 的状态定义为：

$$
z_q(t)=\{h_q,s_q(t),\dot{s}_q(t)\}.
$$

其中 $h_q$ 是从 Gaussian centers 经 PointNet 提取的 object-level semantic features；$s_q(t)$ 是 zeroth-order states，包括 local point cloud $x(t)\in\mathbb{R}^{M\times 3}$、center of mass $c(t)\in\mathbb{R}^3$ 和 orientation Euler angles $\theta(t)\in\mathbb{R}^3$；$\dot{s}_q(t)$ 是 first-order states，包括 local point cloud velocity $\dot{x}(t)$、center velocity $\dot{c}(t)$ 和 angular velocity $\dot{\theta}(t)$。

该状态设计把 Gaussian 表示转成物理上可解释的对象状态，使 force prediction 能同时处理刚体平移/旋转和局部形变。

### 4.4 Global Force Field

对于包含 $K$ 个交互对象的场景，NGFF 在 relational graph $\mathcal{N}=(V,E)$ 上建模全局 transformation force field $F_{\mathrm{global}}\in\mathbb{R}^6$，其中 nodes 是对象状态，edges 表示 physical contacts。对 query object $q$：

$$
F_{\mathrm{global}}(z_q(t)),F_{\mathrm{latent}}(z_q(t))
=
\sum_{i\in\mathcal{N}(q)}
W\left(f_\eta(z_i(t))\odot f_\phi(z_q(t))\right)+b.
$$

这里 $\mathcal{N}(q)$ 是与 $q$ 接触的邻居对象，$f_\eta$ 和 $f_\phi$ 是 neural encoders，$\odot$ 是 element-wise product，$W$ 与 $b$ 把 hidden features 投影为 force vectors。该 relational formulation 用于捕捉 collision、sliding、gravity 等交互。

### 4.5 Local Stress Field and Unified Force

为了建模 soft bodies 的局部形变，NGFF 使用网络 $\Phi$ 预测 point-wise local stress fields $F_{\mathrm{local}}\in\mathbb{R}^{M\times 3}$。输入包括 latent force distribution、Contact Area Mask (CAM)、point positions 和 point velocities：

$$
F_{\mathrm{local}}(z_q(t))=
\Phi(F_{\mathrm{latent}}(z_q(t)),\operatorname{CAM},x_q(t),\dot{x}_q(t)).
$$

全局和局部力场合并为：

$$
F(z_q(t))=(F_{\mathrm{local}},F_{\mathrm{global}}).
$$

其中 global 部分负责对象级平移/旋转，local 部分负责软体接触区域和点级 deformation。

### 4.6 ODE Trajectory Integration

NGFF 通过 second-order ODE solver 把 learned force fields 积分为连续轨迹：

$$
z_q(t)=\operatorname{ODESolve}(z_q(0),F,0,t).
$$

状态积分写作：

$$
s(t)=s(0)+\int_0^t \dot{s}(t)\,dt,\qquad
\dot{s}(t)=\dot{s}(0)+\int_0^t F(z_q(t))\,dt.
$$

该 formulation 是 perception 和 physical dynamics 的接口：力场网络输出 acceleration/force-like quantities，ODE solver 产生未来 Gaussian object states，renderer 输出未来视频。

## 5. Mathematical Objectives and Losses

论文将整体目标写为最小化预测 Gaussian 状态 $\hat{G}_t$ 与 ground-truth Gaussian 状态 $G_t$ 的损失：

$$
\min_\theta L(\hat{G}_t,G_t).
$$

训练采用两阶段。重建模块用 RGB 和 geometry consistency loss fine-tune splatter head；dynamics simulator 在 synthetic MPM simulation data 上单独训练，优化预测 Gaussian configurations 和 motion trajectories 与 ground-truth simulations 之间的 MSE：

$$
L_{\mathrm{dyn}}=\operatorname{MSE}(\hat{G}_{1:T},G_{1:T})+\operatorname{MSE}(\hat{\tau}_{1:T},\tau_{1:T}).
$$

上式是根据文本对“predicted Gaussian configurations and motion trajectories”的描述整理的抽象形式；具体实现中 Gaussian state 和 trajectory loss 的权重需查代码或完整补充材料。

## 6. Training and Inference Procedure

训练数据来自 GSCollision。作者用 MPM simulators 生成包含刚体与软体、多物体交互的物理场景，并把动态过程渲染为 Gaussian/video 数据。训练时，重建模块从 multi-view RGB 得到 object-aware 3D Gaussians；dynamics module 用 ground-truth simulation trajectories 学习 force fields 和 ODE 预测。

推理时，输入真实或合成多视角 RGB 初始观测；feed-forward reconstruction 生成 object-aware Gaussians；PointNet 和 object state extraction 得到对象状态；DeepONet/relational force operator 预测接触力场；ODE solver 递推未来状态；Gaussian renderer 输出 novel-view 4D videos。系统支持 force-prompted interactive generation，即外部力作为控制信号改变后续动态。

## 7. Experimental Setup and Results Summary

GSCollision 包含 10 类 everyday objects，覆盖不同 density 和 Young’s modulus，从 cloth、rope、pillow 到 bowl、phone 等。数据集有 3,200 scenes、640k rendered physical videos，总量约 4.25 TB，动态包括 falling、collision、rotation、sliding、containment，并引入 WildRGBD 真实背景增强视觉复杂度。评估 splits 包括 training、longer temporal rollout、compositional、novel-view 和 novel-background。

评价任务包括 dynamic prediction、video generation、real-world transfer。动态准确性指标包括 MSE/RMSE、FPE、PCE、Pearson correlation；视频质量用 PhysR 和 PhotoR，并结合 Gemini-2.5-flash 与 61 名参与者的人类评估。真实数据由 10 台 DJI Pocket 3 相机在办公室桌面采集 40 段 50 FPS、3K 分辨率多视角交互序列。

论文声称 NGFF 优于 Pointformer、GCN、VLM-MPM、PhysGen3D、Cosmos、Veo3 等 baselines，尤其在 novel-background、novel-view、compositional 和 comprehensive split 上具有更强 physical realism。附录消融显示加入 deformation modeling 能显著降低 RMSE/FPE 并提高 PCC。速度上，作者称相比 prior Gaussian simulators 有两个数量级加速；附录表中 NGFF-V 推理约 37s/72s，去 refinement 版本约 12s/19s，PhysGen3D 为 400s/590s。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称 NGFF 是连接 Gaussian perception 与 physics-grounded dynamics 的 end-to-end neural framework，并发布 GSCollision 大规模数据集。实际技术增量主要在接口设计：把 feed-forward 3D Gaussian reconstruction 变成 object-aware Gaussian states，再让 neural force field 和 ODE solver 在对象图上演化这些 states。

与 PhysGaussian/MPM-Gaussian simulator 相比，NGFF 不依赖每个场景昂贵优化和传统物理求解器，而是学习 force field operator，因此速度和泛化更好。与大视频生成模型相比，它显式建模 object permanence、contact、gravity 和 deformation，物理可控性更强。

在 Dynamic GS 分类中，这篇属于“Gaussian representation for physical 4D prediction”，不是传统 NVS benchmark 上的动态重建方法。它的核心贡献是把 3DGS 从可渲染表示推进为物理状态表示。

## 9. Limitations / Assumptions

NGFF 的物理推理依赖 object decomposition、SAM2 masks、Gaussian reconstruction 和 DiffSplat refinement。如果对象分割或重建失败，后续 force field 的输入状态会不可靠。

训练 dynamics 主要依赖 MPM synthetic simulations 和 GSCollision 数据。虽然论文展示 sim-to-real transfer，但真实世界材料、摩擦、接触和非均匀密度的复杂度远超数据集。附录单独展示 uneven density object，如 fixed pot 的 shaking ficus，说明这是需要关注的边界场景。

框架较复杂，包含多个 foundation/pretrained modules、Gaussian refinement、neural operator、ODE solver 和 renderer。端到端部署时，错误可能在 perception 到 dynamics 多级传播。

## 10. Matrix-Ready Summary

| Dimension | Entry |
|---|---|
| Task | Physics-grounded 4D video prediction and generation |
| Input | Unposed multi-view RGB images at initial time |
| Representation | Object-aware 3D Gaussians |
| Perception | DINOv2 + Alternating-Attention Transformer + Gaussian decoder |
| Object split | SAM2 masks back-projected to Gaussians; DiffSplat refinement |
| Dynamics | Neural Gaussian Force Fields with relational neural operator |
| Force components | Global transformation force and local stress field |
| Integration | Second-order ODE solver |
| Dataset | GSCollision, 3,200 scenes, 640k videos, ~4.25 TB |
| Main advantage | Explicit physical reasoning with renderable Gaussian states |
| Main limitation | Depends on accurate object reconstruction/segmentation and synthetic physics coverage |

## 11. Reusable Components

- Object-aware Gaussian state extraction: turn visual 3DGS into object-centric physics states.
- Relational force field operator: predict contact-dependent forces over object interaction graphs.
- Local stress field head: model point-wise soft-body deformation with CAM and latent force distribution.
- ODE-integrated Gaussian dynamics: evolve renderable Gaussians through differentiable physics-like trajectories.
- GSCollision protocol: evaluate spatial, temporal, compositional, novel-view and novel-background generalization.

## 12. Gap / Idea Seeds

- Add uncertainty propagation from Gaussian reconstruction into force prediction, so bad geometry does not produce overconfident dynamics.
- Learn material parameters jointly with force fields rather than treating object features as implicit semantics.
- Incorporate energy/momentum conservation penalties to improve long-horizon physical consistency.
- Build online adaptation for real scenes where friction, mass and material are unknown.
- Use NGFF trajectories as physics priors for dynamic GS NVS methods in scenes with object interactions.

## 13. Human Check List

- NEED_HUMAN_CHECK: Zotero date is 2025/10/08, while full text says ICLR 2026; verify final metadata.
- NEED_HUMAN_CHECK: Exact loss weights and Gaussian-state loss decomposition are not fully visible in extracted text; inspect code/supplement before implementation.
- NEED_HUMAN_CHECK: Confirm public availability and license of GSCollision and pretrained modules.

## 14. Evidence Anchors

- Abstract and Introduction: NGFF, explicit force fields, two-orders speedup, GSCollision scale and capabilities.
- Figure 2: pipeline from RGB observations to object-centric reconstruction, force fields, ODE solver, simulation/rendering.
- Section 3.1: problem formulation with Gaussian state transition and rendering.
- Section 3.2.1: feed-forward reconstruction, SAM2 object grouping, DiffSplat refinement.
- Section 3.2.2: object state, global force field, local stress field, ODE integration.
- Section 4 and Appendix C/E: GSCollision dataset, metrics, real-world collection, ablations and inference timing.
