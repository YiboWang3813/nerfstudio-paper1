---
title: "S2Gaussian: Sparse-View Super-Resolution 3D Gaussian Splatting"
authors: "Yecong Wan, Mingwen Shao, Yuanshuo Cheng, Wangmeng Zuo"
year: 2025
venue: "CVPR 2025"
zotero_item_key: "PLTMGE6J"
pdf_attachment_key: "SL6SK8NI"
pdf_path: "/Users/wangyibo/Zotero/storage/SL6SK8NI/Wan 等 - S2Gaussian Sparse-View Super-Resolution 3D Gaussian Splatting.pdf"
note_path: "notes/S2Gaussian: Sparse-View Super-Resolution 3D Gaussian Splatting.md"
tags: ["3D Gaussian Splatting", "sparse-view synthesis", "super-resolution", "low-resolution inputs", "robust optimization"]
---

## 0. 一句话总结

S2Gaussian 处理“输入视角稀疏且分辨率低”的联合退化问题：先用低分辨率图像和深度正则优化 LR Gaussian 稳住几何，再通过 Gaussian Shuffle Split 把粗 Gaussian 拆成更紧凑的 HR Gaussians，最后用 2D 超分模型生成的真实视角和伪视角监督优化高分辨率 Gaussian，并用不一致建模和 3D 鲁棒梯度策略抵消超分伪监督的多视角不一致。

## 1. 问题与动机

现实采集中的 3D 重建常同时面临两个问题：视角数量少，以及每个视角分辨率低。已有 sparse-view NVS 方法主要处理视角缺失，但不负责恢复高分辨率细节；已有 super-resolution NVS 方法主要处理低分辨率观测，但通常假设有足够密集视角。

直接把 sparse-view 3DGS 和 2D/3D 超分方法拼起来并不理想。超分需要密集、一致的监督来恢复细节，而 sparse-view regularization 往往偏向平滑；2D 超分模型逐图处理会产生多视角不一致，伪视角本身也有未优化区域和伪影，直接监督 Gaussian 会导致错误结构和模糊。

## 2. 适用场景

S2Gaussian 适用于只有少量低分辨率输入图像，但希望重建高分辨率 3DGS 并进行高质量 novel view synthesis 的场景，例如低带宽采集、互联网图片、机器人或移动端采集。论文主实验是 $4\times$ sparse-view super-resolution NVS。

它依赖 SfM/COLMAP 初始化相机和点云，属于 per-scene optimization 方法，不是泛化前馈模型。若 SfM 失败、输入视角重叠过少或超分模型产生强 hallucination，后续 HR Gaussian 优化会受到影响。

## 3. 方法定位

S2Gaussian 不是单独的 sparse-view 方法，也不是单独的 3D super-resolution 方法，而是把二者组合成两阶段 3DGS 优化框架。Stage 1 在低分辨率空间优化可靠几何；Stage 2 在高分辨率空间引入超分监督和鲁棒策略恢复细节。

相比 FSGS+SRGS 这类顺序组合 baseline，S2Gaussian 的关键区别是它专门处理组合后的不兼容问题：Gaussian Shuffle Split 解决 HR 初始化不够细，blur-free inconsistency modeling 解决 2D SR 多视角不一致，3D robust optimization 解决伪监督带来的错误梯度。

## 4. 核心创新

第一，提出 sparse-view super-resolution 3DGS 任务设定，明确同时处理 deficient perspectives 和 deficient clarity，而不是只处理其中一个退化。

第二，提出 Gaussian Shuffle Split。它把 LR 阶段优化出的一个较大 Gaussian 沿三个主轴正负方向替换为六个小 Gaussian，既保持原始 3D 表示的局部覆盖，又提供更多可移动 primitives 来表达高分辨率细节。

第三，提出 blur-free inconsistency modeling。作者在预训练 2D SR 模型后加入可学习 inconsistency modeling module 模拟跨视角不一致，同时用 blur proposal module 对渲染图进行可学习模糊后再与修正 SR 图对齐，避免 IM 为追求一致性而牺牲锐利纹理。

第四，提出 3D robust optimization。每个 Gaussian 增加一个用于记录历史梯度趋势的 flag gradient，对当前梯度与历史趋势做 cosine similarity 判断，若方向冲突就缩小当前梯度，减少错误伪监督对 Gaussian 参数的破坏。

## 5. 方法细节

Stage 1 先使用预训练 DPT 估计低分辨率训练视图的单目深度，然后用 RGB 和深度正则共同优化 LR Gaussian。论文采用 Pearson correlation depth loss 作为基线深度正则，使低分辨率 3DGS 先学到可靠的场景布局。

Gaussian Shuffle Split 对每个 Gaussian $g=\{\mu,s,q,\sigma,c\}$ 生成六个 sub-Gaussians。设 $R$ 为由旋转 $q$ 得到的旋转矩阵，$s=[s_1,s_2,s_3]$，偏移系数 $\alpha=0.5$，六个中心沿主轴正负方向移动：

$$
\mu_{sub} \in \{\mu+R[\alpha s_1,0,0]^T,\mu+R[-\alpha s_1,0,0]^T,\mu+R[0,\alpha s_2,0]^T,\mu+R[0,-\alpha s_2,0]^T,\mu+R[0,0,\alpha s_3]^T,\mu+R[0,0,-\alpha s_3]^T\}
$$

每个 sub-Gaussian 在对应偏移轴上的 scale 缩小为原来的 $1/4$，从而把一个粗 ellipsoid 替换成六个更紧凑的局部 ellipsoids。

Stage 2 中，模型从两类视角生成 SR 监督：原始 sparse training views，以及 LR Gaussian 通过插值虚拟相机渲染出的 pseudo-views。预训练 2D SR backbone 采用 ResShift。

为处理 SR 多视角不一致，作者让 super-resolved image $I_{SR}$ 经过 inconsistency modeling module 得到 $I_{SR}^{IM}=I_{SR}+IM(I_{SR})$。但 IM 可能让细节变模糊，因此引入 blur proposal module，输入 detach 的 HR 渲染图 $R_{HR}^{detach}$，输出 per-pixel blur kernel $B_k$，得到模糊渲染图 $R_{HR}^{blur}=R_{HR}*B_k$。SR 监督损失为：

$$
L_{SR}=(1-\beta)L_1(R_{HR}^{blur},I_{SR}^{IM})+\beta L_{D\text{-}SSIM}(R_{HR}^{blur},I_{SR}^{IM})
$$

其中 $\beta=0.2$。

3D robust optimization 给 Gaussian 参数 $\{\mu,s,q,\sigma,c\}$ 额外维护 flag gradient $\nabla$。若当前属性梯度 $g_i^c$ 与历史梯度趋势 $\nabla(g_i)$ 的 cosine similarity 大于 0，则正常使用当前梯度并用平均值更新 flag；否则认为可能是扰动，将当前梯度乘以 $\epsilon=0.1$，同时缓慢更新 flag：

$$
g_i^c \leftarrow \epsilon g_i^c,\quad \nabla(g_i)\leftarrow (1-\epsilon)\nabla(g_i)+\epsilon g_i^c
$$

HR 优化还使用辅助损失 $L_{AUX}=L_{TV}(R_{HR})+L_1(R_{HR}\downarrow,I_{LR})$，最终损失为：

$$
L=L_{AUX}+L_{SR}
$$

## 6. 实验设置

论文主要评估 $4\times$ sparse-view super-resolution NVS。数据集包括 Blender、LLFF 和 Mip-NeRF360。Blender 从 100 张训练图中均匀采样 8 张，训练分辨率为 200 x 200；LLFF 采样 3 张 sparse views，低分辨率训练为 252 x 189，高分辨率渲染为 1008 x 756；Mip-NeRF360 采样 24 张训练图，目标约 1K 分辨率，训练输入再下采样 $4\times$。

实现基于原始 3DGS。LR GS 优化 10k iterations，HR GS 再优化 10k iterations。实验使用单张 RTX 3090。评价指标包括 PSNR、SSIM、LPIPS 和 FID。

## 7. 主要结果

Blender $4\times$ 8-view 上，S2Gaussian 达到 24.19 PSNR、0.879 SSIM、0.089 LPIPS、28.47 FID，优于 FSGS+SRGS 的 22.68 PSNR 和 SRGS 的 22.64 PSNR。

LLFF $4\times$ 3-view 上，S2Gaussian 达到 20.45 PSNR、0.654 SSIM、0.139 LPIPS、45.89 FID，显著优于 FSGS+SRGS 的 19.49 PSNR、0.590 SSIM、0.175 LPIPS。

Mip-NeRF360 $4\times$ 24-view 上，S2Gaussian 达到 22.05 PSNR、0.687 SSIM、0.296 LPIPS、43.51 FID，相比 FSGS+SRGS 的 19.83 PSNR 提升 2.22 dB，说明在大场景高分辨率重建中优势最明显。

定性结果显示，3DGS 和 Mip-Splatting 在极稀疏设置下结构不稳，FSGS 难以恢复高分辨率细节，FSGS+SRGS 虽有合理整体结构但有不一致、缺细节和模糊。S2Gaussian 的纹理更自然，细结构更连贯。

## 8. 消融与分析

Mip-NeRF360 $4\times$ 24-view 的组件消融显示，baseline 为 19.79 PSNR、0.520 SSIM、0.429 LPIPS、87.22 FID；加入 two-stage 后为 20.06 PSNR；加入 Gaussian Shuffle Split 后为 20.62；加入 blur-free inconsistency modeling 后为 21.12；最终加入 3D robust optimization 后达到 22.05 PSNR、0.687 SSIM、0.296 LPIPS、43.51 FID。

sub-Gaussian 数量消融显示，4、5、6、7、8、9 个 sub-Gaussians 的 PSNR 分别约为 21.76、21.95、22.05、22.03、22.09、22.08。虽然 8/9 个略高或接近，但显存和优化复杂度明显上升；6 个 sub-Gaussians 能沿三个主轴对称分布，是质量和成本的较好折中。

blur-free inconsistency modeling 的可视化显示，IM 能模拟超分图像的不一致，而 blur proposal 显式建模模糊，使最终重建避免为了跨视角一致而丢失锐利细节。3D robust optimization 在 corrupted training views 下能减少 Gaussian 被错误监督拉向坏结构。

## 9. 与相关工作的关系

相对 sparse-view 方法如 RegNeRF、SparseNeRF、DNGaussian、FSGS，S2Gaussian 额外处理低分辨率输入和高分辨率渲染，不只是解决视角少的问题。

相对 super-resolution NVS/3DGS 方法如 NeRF-SR、SRGS、GaussianSR、SuperGaussian，S2Gaussian 关注 sparse low-resolution views，而不是默认有充足视角来保证超分监督一致。

相对简单组合 FSGS+SRGS，S2Gaussian 不是先 sparse 重建再做 SR 的流水线，而是在 3DGS 优化中显式设计 HR 初始化、多视角不一致建模和鲁棒梯度更新。

## 10. 优点

S2Gaussian 的优点是任务设定更贴近真实采集：少视角和低清晰度经常同时出现。方法结构也比较完整，分别处理几何初始化、细节表达、SR 不一致和伪监督错误梯度。

Gaussian Shuffle Split 很实用，它不依赖训练网络，可以直接把已有 LR Gaussian 变成更适合 HR 细节优化的密集初始化。3D robust optimization 也有插件属性，可与 Adam 等梯度优化器结合，优化完成后 flag gradient 不影响渲染速度和存储。

## 11. 局限

方法依赖 2D super-resolution 模型的质量。若 SR backbone hallucination 严重，IM 和 3DRO 只能缓解，不能保证恢复真实细节。伪视角由 LR Gaussian 渲染，也会继承 LR 几何错误和未优化区域。

此外，该方法需要两阶段共 20k iterations，计算成本高于直接 3DGS 或简单 FSGS。Gaussian Shuffle Split 会显著增加 primitive 数量，sub-Gaussian 数量过多会带来显存和优化压力。

## 12. 可复现要点

复现时先用 SfM 得到相机和初始点云，再训练 LR Gaussian 10k iterations，并加入单目深度 Pearson correlation 正则。训练好 LR GS 后，对每个 Gaussian 执行六方向 Shuffle Split 初始化 HR Gaussian。

HR 阶段需要生成两类 SR 监督：原始 sparse views 的 SR 图，以及 LR Gaussian 渲染 pseudo-views 后的 SR 图。训练中要同时启用 IM、BP 和 3DRO；最终 loss 为 $L_{AUX}+L_{SR}$，其中 $L_{AUX}$ 保证 HR 渲染下采样后仍与原始 LR 输入一致。

## 13. 可能扩展

一个扩展是让 Gaussian Shuffle Split 自适应。不同 Gaussian 可根据 scale、opacity、view residual 或不确定性决定拆分数量和方向，而不是统一六个 sub-Gaussians。

第二个扩展是用多视角一致的 video/3D diffusion SR 模型替代逐图 2D SR，从源头降低跨视角不一致，减轻 IM/BP/3DRO 的压力。

第三个扩展是把 3D robust optimization 和 sparse-view uncertainty 结合，对伪视角、SR 图像、真实 LR 图像分别设置信任权重，让可靠监督更快更新，不可靠监督更保守。

## 14. 个人理解

S2Gaussian 的核心不是“用 SR 模型增强 3DGS”这么简单，而是承认 2D SR 监督进入 3D 优化后会制造新的多视角问题。它把问题拆成低分辨率几何稳定、高分辨率初始化、SR 不一致吸收、错误梯度抑制四步，因此比直接 FSGS+SRGS 更系统。

这篇文章对后续工作有启发：当外部强先验来自 2D 模型时，不能直接把生成结果当真值监督 3D 表示。必须显式建模生成先验的不一致、模糊和错误更新，否则 3DGS 会用错误几何去解释这些伪细节。
