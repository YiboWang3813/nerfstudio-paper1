# Foundation Model Gaussian Splatting Idea Report

本文综合 `notes/` 下标题包含 `foundation` 的 4 篇笔记，覆盖 visual foundation models、geometric foundation models、open-vocabulary 3D understanding 和 self-supervised occupancy。报告先逐篇回顾，再整理共同路线，并提出 7 个可以尝试的组合型 idea。

## 1. 逐篇回顾

| # | 论文 | 主要创新点 | 典型应用场景 |
|---:|---|---|---|
| 1 | GaussTR: Foundation Model-Aligned Gaussian Transformer for Self-Supervised 3D Spatial Understanding | 用 Transformer 直接预测 sparse 3D Gaussians，并把它们 splat 回 2D VFM feature/depth 空间对齐 CLIP/FeatUp/Talk2DINO/Metric3D，实现无需 3D semantic labels 的开放词表 occupancy。 | 自动驾驶 3D occupancy、开放词表空间理解、自监督 3D 表示学习。 |
| 2 | Feat2GS: Probing Visual Foundation Models with Gaussian Splatting | 用浅层 feature-to-Gaussian readout 和 Geometry/Texture/All probing modes，把 NVS 作为 VFM 3D awareness 的 dense multi-view proxy task。 | 评估 VFM 的几何/纹理信息含量，选择适合 3DGS 的 feature backbone。 |
| 3 | FMGS: Foundation Model Embedded 3D Gaussian Splatting for Holistic 3D Scene Understanding | 在普通 3DGS 几何/RGB 上叠加 multi-resolution hash semantic field，蒸馏 hybrid CLIP 与 DINO feature，用 text relevance 做开放词表 3D 查询。 | 开放词表 3D detection/segmentation、文本交互式 3D 场景理解。 |
| 4 | Deep Gaussian from Motion | 用 DUSt3R/Spann3R 类 3D geometric foundation model 预测 pointmaps 和 Gaussians，通过 progressive registration、PnP、point-to-ray refinement 和 3DGS photometric training 从无位姿图像重建 3DGS。 | pose-free 3DGS、unordered image reconstruction、COLMAP 失败场景。 |

## 2. 综合观察

这 4 篇工作使用 foundation model 的方式不同。

第一种是 feature distillation。GaussTR 和 FMGS 都把 2D foundation feature 渲染目标化，让 3DGS 或 Gaussian field 学会多视角一致的 CLIP/DINO/Talk2DINO 表示。关键问题是如何让 2D feature 的语义、边界和几何在 3D 中一致。

第二种是 feature probing。Feat2GS 不急着提出新重建系统，而是用 Gaussian readout 判断哪些 VFM feature 真的含有 geometry、texture 或 all-in-one 信息。它的价值在于帮助后续方法选 backbone。

第三种是 geometric prior / pose prior。Deep Gaussian from Motion 用 3D geometric foundation model 替代 classical SfM 中的 sparse matching 和 triangulation，再通过 3DGS rendering 做 scene-specific refinement。

共同瓶颈也很明确：foundation model 很强，但会带来 domain bias、feature resolution 不足、texture 信息丢失、geometry scale drift 和系统复杂度。未来更有价值的路线不是简单把 VFM feature 塞进 Gaussian，而是让 foundation model 负责“初始化、约束、分配容量、提供语义接口”，同时让 3DGS 保持显式、可渲染、可优化的优势。

## 3. 7 个可以尝试的组合型 Idea

### Idea 1: Foundation-selected Gaussian Query Allocation

组合来源：GaussTR 的 Gaussian queries，Feat2GS 的 VFM probing，FMGS 的 CLIP/DINO semantic feature。

要做的是不用固定每视角 300 queries 或每像素生成 Gaussian，而是让 foundation features 决定 Gaussian query 的位置和数量。DINO 边界、SAM mask、小物体检测、depth discontinuity 和 uncertainty map 共同决定哪里需要更多 Gaussians。大平面用少量大 Gaussians，小物体和边界用密集小 Gaussians。

### Idea 2: Probe-before-distill 3DGS Pipeline

组合来源：Feat2GS 的 GTA probing，FMGS/GaussTR 的 feature distillation。

要做的是每个场景或数据集先运行轻量 probe，判断当前 foundation model 的 geometry feature、texture feature、semantic feature 哪些可靠，再决定蒸馏策略。如果 geometry probe 弱，就更依赖 depth/MVS；如果 texture probe 弱，就不要让 VFM 控制 SH color；如果 semantic probe 强，就把它用于 feature field。这个 pipeline 可避免盲目相信单一 VFM。

### Idea 3: Pose-free Open-vocabulary Gaussian Splatting

组合来源：Deep Gaussian from Motion 的 progressive pose registration，FMGS 的 CLIP/DINO semantic field，GaussTR 的 feature/depth splatting。

要做的是从无位姿图像集合中同时恢复相机、Gaussians 和开放词表 semantic field。geometric foundation model 先给 2D-3D correspondences 和 coarse pointmaps，3DGS photometric loss refine geometry，CLIP/DINO feature splatting 同步训练 semantic field。最终输出既能 render RGB，也能做 text query。

### Idea 4: Dynamic Foundation Feature Field for 4DGS

组合来源：FMGS 的 semantic hash field，GaussTR 的 VFM-aligned splatting，dynamic 4DGS 的 deformation/motion nodes。

要做的是把 CLIP/DINO/Talk2DINO feature field 从静态 3D 扩展到 4D。Gaussian 的 semantic feature 应随 object identity 稳定，而不是随帧漂移；motion nodes 或 superpoints 负责把语义 feature 绑定到动态对象。训练时用跨帧 feature consistency、SAM2 masks 和 optical flow 约束语义随物体运动。

### Idea 5: Geometry Foundation Model as Sparse-view 3DGS Initializer

组合来源：Deep Gaussian from Motion 的 DUSt3R/Spann3R pointmaps，MVSplat/TranSplat 的 depth-to-Gaussian centers，sparse-view 3DGS 的 per-scene refinement。

要做的是把 geometric foundation model 输出的 pointmap、confidence、relative pose 和 dense correspondence 转成 3DGS 初始化，不只提供点云，还提供 Gaussian scale、opacity 和 uncertainty。后续 per-scene 3DGS 根据 confidence 分配学习率和 pruning 策略。目标是替代 fragile COLMAP，并提升 sparse/unposed 场景稳定性。

### Idea 6: Text-guided Gaussian Editing with Reliability Maps

组合来源：FMGS 的 text relevancy，GaussTR 的 open-vocabulary logits，uncertainty 3DGS 的可靠性估计。

要做的是开放词表 text query 不直接变成 hard selection，而是输出“语义相关性 + 几何可靠性 + 多视角一致性”三通道。编辑或删除对象时，只操作高语义相关且高几何可靠的 Gaussians；低可靠区域请求更多视角或使用 SAM refine。这样可以减少 text-guided 3D editing 中常见的误选背景或漏选薄结构。

### Idea 7: Foundation Feature Compression for Real-time Semantic GS

组合来源：FMGS 的 MHE semantic field，GaussTR 的 sparse Gaussian feature，Feat2GS 对不同 VFM feature 的分析。

要做的是训练高维 CLIP/DINO feature teacher，但部署时蒸馏到低维 Gaussian semantic codes。压缩目标不只是重建 feature cosine，还包括 text-query ranking、边界一致性和跨视角一致性。可以根据 Feat2GS probing 结果只保留对 3D useful 的 feature subspace，减少开放词表 3DGS 的显存和带宽。

## 4. 优先级建议

最快能做原型的是 Idea 5 和 Idea 6：前者可以接在现有 sparse 3DGS 初始化前，后者可以接在 FMGS/LERF 类语义场之后。

最适合作为方法论文的是 Idea 1、Idea 2 和 Idea 7。它们都不是简单“换一个 foundation model”，而是把 foundation model 的信息用于 query allocation、策略选择和部署压缩。

最有系统价值的是 Idea 3 和 Idea 4：一个解决 pose-free + open-vocabulary，另一个解决 dynamic 4D semantic consistency，工程更重但应用面更广。
