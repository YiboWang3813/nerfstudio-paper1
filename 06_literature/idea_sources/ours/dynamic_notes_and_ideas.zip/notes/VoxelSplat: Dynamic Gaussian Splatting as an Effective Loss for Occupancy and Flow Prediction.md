# VoxelSplat: Dynamic Gaussian Splatting as an Effective Loss for Occupancy and Flow Prediction

## 0. Metadata

- Paper title: VoxelSplat: Dynamic Gaussian Splatting as an Effective Loss for Occupancy and Flow Prediction
- Authors: Ziyue Zhu; Shenlong Wang; Jin Xie; Jiang-jiang Liu; Jingdong Wang; Jian Yang
- Venue / year: CVPR 2025
- Project / code: `https://zzy816.github.io/VoxelSplat-Demo/`
- Zotero item key: `RHUUIDRU`
- Zotero PDF attachment key: `H646MBUM`
- Zotero PDF path: `/Users/wangyibo/Zotero/storage/H646MBUM/Zhu 等 - VoxelSplat Dynamic Gaussian Splatting as an Effective Loss for Occupancy and Flow Prediction.pdf`
- Local note path: `notes/VoxelSplat: Dynamic Gaussian Splatting as an Effective Loss for Occupancy and Flow Prediction.md`

## 1. One-Sentence Technical Summary

VoxelSplat 把 dynamic semantic 3D Gaussians 作为训练期渲染头和辅助损失，利用 2D camera-view semantic/depth supervision 与相邻帧标签同时增强 camera-based 3D occupancy 和 scene flow prediction，推理时仍只保留原 voxel occupancy pipeline。

## 2. Problem Formulation

输入是多帧多相机图像，基础模型输出 voxel features $V$、3D semantic occupancy $S$ 和 scene flow $F$。传统 occupancy 监督直接作用在 3D voxel grid 上，但存在三个问题：大量标注区域在相机视野中被遮挡，强行监督不可见区域可能沿射线污染图像特征；voxel grid 更偏 Eulerian 表示，不擅长显式对象运动；自动驾驶数据中类别和速度分布极不平衡，高速小目标样本尤其少。

VoxelSplat 的目标不是改造推理表示，而是在训练阶段从 voxel representation 解码 sparse semantic Gaussians，把语义和 flow 通过 differentiable splatting 投影到 2D camera views，让可见空间的 2D label 和相邻帧 label 提供更直接的监督。

## 3. Method Overview

方法作为 plug-and-play training regularization 接到已有 occupancy networks 上。基础网络仍预测 voxel features、3D semantic logits 和 scene flow。VoxelSplat 额外从可见 occupied voxels 中采样 Gaussian centers，通过一个小 MLP 解码 Gaussian shape attributes，包括 opacity、rotation 和 scale；semantic logits 直接来自 voxel semantic head，flow 直接来自 scene-flow head。

训练时，当前帧 dynamic Gaussians 的中心用预测 flow 更新到未来帧，得到 future dynamic Gaussians。静态 Gaussians 与动态 Gaussians 被分开渲染到当前/相邻 camera views，生成 semantic maps 和 depth maps，并与在线生成的 2D semantic/depth labels 计算渲染损失。推理时删除 Gaussian decoder 和 renderer，只运行原 occupancy pipeline，因此没有额外 latency。

## 4. Method Details

### 4.1 Semantic Gaussian Splatting

VoxelSplat 使用 3D Gaussian 的几何形式，但把 RGB/SH color 替换为 semantic logits。一个 Gaussian 由中心 $\mu$ 和 covariance $\Sigma$ 定义：

$$
G(x)=\exp\left(-\frac{1}{2}(x-\mu)^T\Sigma^{-1}(x-\mu)\right).
$$

其中 $\Sigma=RS_cS_c^TR^T$，$S_c=\operatorname{diag}(s_x,s_y,s_z)$，$R \in SO(3)$。对于 occupancy/flow 任务，每个 Gaussian 不存颜色，而存 semantic logits $s_i$。渲染时按 alpha blending 累积语义和深度：

$$
S=\sum_{i=1}^{M}s_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j), \qquad
D=\sum_{i=1}^{M}d_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j).
$$

这样，3D occupancy prediction 可以获得来自 2D camera-visible space 的监督信号。

### 4.2 Weighted Point Sampling

从所有 occupied visible voxels 中直接均匀采样会强化静态大类，忽视高速动态小类。作者先用 ray casting 生成 camera-visible masks，再从可见 occupied grids 中采样 voxel centers 作为 Gaussian centers。每个 batch 中有 $P$ 个 semantic types，并按 speed 划分为 $Q$ 个速度等级，共 $PQ$ 个类别。

对类别 $(p,q)$，若包含 $N_{p,q}$ 个 voxels，采样概率为：

$$
p_{p,q} = \frac{P(N_{p,q})}{\sum_{i=1}^{PQ}P(N_i)}, \qquad P(x)=\frac{1}{x^t+1}.
$$

该函数提高少数类和高速类的采样概率。论文最终设置 $t=0.5$，每个 scene 采样 100000 points。

### 4.3 Decode Dynamic Gaussians

采样得到坐标 $\{\mu_n\}$ 后，通过 grid sampling 从 occupancy network 输出中查询 voxel embeddings $\{v_n\}$、scene flows $\{\Delta x_n\}$ 和 semantic logits $\{s_n\}$。这里 $\Delta x_n$ 是原始预测 scene flow 乘以两帧时间间隔后的运动向量。

Gaussian decoder $G(\cdot)$ 是两层 MLP，把 voxel embedding 加 learnable positional embedding $pe$ 映射为 opacity、rotation 和 scale：

$$
g_n:(\mu,\Delta x,s,\alpha,r,sc)=(\mu_n,\Delta x_n,s_n,G(v_n+pe)).
$$

根据 ground-truth center semantics，Gaussians 被分为 static $G_s$ 和 dynamic $G_d$。对 dynamic Gaussians，用预测 flow 更新中心 $\mu+\Delta x$，得到 future dynamic Gaussians $G_d^f$。这让 scene flow 的学习可通过未来帧 2D labels 进行间接约束。

### 4.4 Static/Dynamic Rendering

VoxelSplat 分别渲染静态和动态部分。静态 Gaussians $G_s$ 被 splat 到 camera plane 得到 static semantic/depth maps $(S_s,D_s)$。动态部分则将当前动态 Gaussians 与未来动态 Gaussians 组合渲染，得到 $(S_d,D_d)$，用于自监督或弱监督地学习 moving objects 的 scene flow。

此外，训练不只渲染当前帧 camera views，也选择相邻帧的 camera views 作为 virtual views，得到 $M$ 个 rendering views。这提供更多 multi-view cues，并让模型关注 future location perception。

### 4.5 Online 2D Label Generation

为了与渲染输出对齐，作者在线把 3D ground-truth voxels 分为 static 和 dynamic。dynamic voxels 按 scene flow 复制并移动到未来位置，再用 3DGS 工具投影到 camera views，生成 static semantic/depth labels $(\hat{S}_s,\hat{D}_s)$ 与 dynamic semantic/depth labels $(\hat{S}_d,\hat{D}_d)$。这样避免额外离线标注，同时保证 2D loss 的监督目标与 splatting 输出格式一致。

## 5. Mathematical Objectives and Losses

基础 3D loss 包含原 occupancy loss $L_{\mathrm{occ}}$ 和 scene flow 的 $L_1$ loss，并对 voxels 按速度 magnitude 加权。论文称其组合为 $L_{\mathrm{3D}}$。

2D rendering loss 对 static/dynamic 类别以及多个 views 求和，对 semantic maps 用 cross entropy，对 depth maps 用 $L_1$：

$$
L_{\mathrm{2D}} = \sum_{k=s,d}\sum_{m=1}^{M}\operatorname{CE}(S_m^k,\hat{S}_m^k) + \left\lVert D_m^k-\hat{D}_m^k \right\rVert_1.
$$

该损失只在有 rendered values 的区域计算。总损失为：

$$
L_{\mathrm{total}} = L_{\mathrm{3D}} + L_{\mathrm{2D}}.
$$

核心设计点是 $L_{\mathrm{2D}}$ 同时约束语义和由 flow 更新后的动态 Gaussian 位置，因此对 occupancy 与 scene flow 都有增益。

## 6. Training and Inference Procedure

训练阶段：输入连续多帧多视角图像；基础 occupancy network 预测 voxel feature、semantic occupancy 和 scene flow；VoxelSplat 从可见 occupied voxels 进行 weighted sampling；查询 voxel outputs 并解码 semantic Gaussians；按 static/dynamic 分解；用 predicted flow 更新 dynamic centers 到 future frame；把 static/dynamic Gaussians 渲染到当前和相邻虚拟视图；在线生成对应 2D labels；联合优化 $L_{\mathrm{3D}}$ 与 $L_{\mathrm{2D}}$。

推理阶段：Gaussian sampling、decoder、renderer 和 2D loss 全部移除，只使用原模型的 voxel-based upper branch 预测 occupancy 和 flow。论文明确强调没有额外 inference cost。

## 7. Experimental Setup and Results Summary

主数据集是 nuScenes，使用 OpenOcc、Occ3D 和 SurroundOcc 标注进行评估。occupancy 指标包括 RayIoU 和 mIoU，flow 指标是动态类 true positives 上的 absolute velocity error (mAVE)。作者把 VoxelSplat 接到 BEVDet-Occ、FB-Occ、SparseOcc 等模型上，并额外添加 scene-flow decoder。

在 nuScenes validation 上，FB-Occ-flow + VoxelSplat 的 RayIoU 达 36.9，比 FB-Occ-flow 的 33.5 提升 3.4；mAVE 从 0.505 降到 0.303，提升 0.202；mIoU 从 39.2 提升到 42.3。OpenOccupancy semantic occupancy 表中，FB-OCC + VoxelSplat 的 SC IoU 为 35.85，SSC mIoU 为 22.64，均明显高于 FB-OCC。

跨框架实验显示 BEVDet-Occ、FB-Occ、SparseOcc 分别提升 3.6、3.4、2.9 RayIoU。消融表明：Gaussian splatting 比 volume rendering 更有效；相邻帧 virtual views 能提升 RayIoU 并降低 mAVE；static/dynamic separate supervision 对 flow 学习帮助很大；weighted sampling 进一步改善类别和速度不平衡。

## 8. Claimed Contribution vs Actual Technical Delta

论文的主要贡献不是提出新的 dynamic NVS 表示，而是把 dynamic Gaussian splatting 改造成 perception training loss。它把 voxel occupancy model 的隐式 3D grid 输出转为可渲染的 sparse semantic Gaussians，使 camera-visible 2D supervision 能回传到 3D semantics 与 flow。

相比 RenderOcc/NeRF-style volume rendering，VoxelSplat 的实际优势是只从 occupied voxels 解码 Gaussians，监督更集中在 occupied space，而不是沿相机 ray 密集采样大量 empty space。相比已有 Gaussian occupancy 表示，它强调训练期插件：保留原模型推理结构，降低部署阻力。

对 Dynamic GS 分类来说，这篇的价值在于展示了 dynamic Gaussian 的“可微投影和显式运动点”可以作为任务损失，而不只是作为最终渲染表示。

## 9. Limitations / Assumptions

论文明确指出，虽然 2D rendering loss 有助于 self-supervised scene flow learning，但模型仍需要 ground-truth 3D scene flow。因此它不是完全自监督 flow 方法。

VoxelSplat 依赖 occupancy ground truth、flow labels、ray casting visible masks 和在线投影标签质量。若 3D labels 或 flow labels 噪声较大，2D rendering supervision 也会继承这些偏差。

该方法主要验证在 autonomous driving occupancy/flow prediction 上，尚未证明 Gaussian rendering loss 对 occupancy forecasting、planning-aware perception 或开放词表 occupancy 的通用性。

## 10. Matrix-Ready Summary

| Dimension | Entry |
|---|---|
| Input | Multi-frame multi-view camera images |
| Base model | Camera-based voxel occupancy network with semantic and flow heads |
| Gaussian role | Training-only semantic dynamic Gaussians |
| Gaussian attributes | Center, flow, semantic logits, opacity, rotation, scale |
| Motion model | Update dynamic Gaussian centers by predicted scene flow $\Delta x$ |
| Sampling | Visible occupied voxels with class/speed weighted sampling |
| Rendering outputs | 2D semantic maps and depth maps for static/dynamic parts |
| Loss | $L_{\mathrm{3D}} + L_{\mathrm{2D}}$ |
| Inference cost | None beyond base voxel pipeline |
| Main advantage | Improves occupancy and flow via camera-visible differentiable supervision |
| Main limitation | Still needs 3D scene-flow ground truth |

## 11. Reusable Components

- Training-only Gaussian head: decode sparse semantic Gaussians from voxel features for auxiliary 2D supervision.
- Class/speed weighted point sampling: balance rare semantic classes and high-speed objects during Gaussian decoding.
- Flow-as-Gaussian-motion: supervise scene flow by moving Gaussian centers and rendering future-frame labels.
- Static/dynamic split rendering: separate supervision makes dynamic flow learning more targeted.
- Online 2D label generation from 3D voxels: avoids storing extra rendered labels and keeps label generation consistent with current views.

## 12. Gap / Idea Seeds

- Remove dependency on 3D scene-flow ground truth by relying more heavily on adjacent-frame rendered semantic/depth consistency.
- Extend Gaussian rendering loss to occupancy forecasting, where future Gaussians are predicted beyond one frame.
- Use uncertainty-aware splatting to reduce negative supervision from occluded or weakly visible voxels.
- Replace hard static/dynamic split from GT semantics with learned motion probabilities for unlabeled domains.
- Add planning-weighted sampling so rare but safety-critical moving agents receive stronger Gaussian supervision.

## 13. Human Check List

- NEED_HUMAN_CHECK: Confirm final CVPR 2025 proceedings metadata and DOI if needed.
- NEED_HUMAN_CHECK: Check exact implementation of speed-weighted flow loss in code; extracted text only states speed-based voxel weighting.
- NEED_HUMAN_CHECK: Verify whether dynamic rendering uses $G_d \cup G_d^f$ exactly as written in the PDF extraction, since the phrase is slightly ambiguous.

## 14. Evidence Anchors

- Abstract: semantic 3D Gaussians projected to 2D views; scene flow moves Gaussians; plug-and-play no inference cost.
- Figure 1-2: current Gaussians, flow-updated future Gaussians, rendering losses for semantic and flow prediction.
- Section 3.1: semantic Gaussian splatting and semantic/depth alpha blending.
- Section 3.2: weighted point sampling, Gaussian decoder, static/dynamic decomposition, future Gaussian centers.
- Section 3.3: virtual view rendering, online label generation, $L_{\mathrm{2D}}$ and total loss.
- Tables 1-4: main nuScenes results, cross-framework gains, volume rendering comparison, decomposition and weighted sampling ablations.
