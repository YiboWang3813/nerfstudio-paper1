# Deep Gaussian from Motion: Exploring 3D Geometric Foundation Models for Gaussian Splatting

## 0. Metadata

* Title: Deep Gaussian from Motion: Exploring 3D Geometric Foundation Models for Gaussian Splatting
* Authors: Yu Chen; Rolandos Alexandros Potamias; Evangelos Ververas; Jifei Song; Jiankang Deng; Gim Hee Lee
* Year: 2025
* Venue: NeurIPS
* PDF source: `/Users/wangyibo/Zotero/storage/NNAJI995/Chen 等 - 2025 - Deep Gaussian from Motion Exploring 3D Geometric Foundation Models for Gaussian Splatting.pdf`
* Zotero item key: `3T5FE6DW`
* Zotero PDF attachment key: `NNAJI995`
* Code: Not specified
* Project page: Not specified
* Dataset link: LLFF, Mip-NeRF360, Tanks-and-Temples, Seq TnT, 7Scenes
* Main task: training 3DGS from unordered/unposed images
* Domain: pose-free 3D reconstruction, geometric foundation models, Gaussian Splatting
* Input: unordered image collection without known poses
* Output: camera poses, pointmaps, 3D Gaussian scene representation, novel views
* Main representation: scene regressor network based on Spann3R/DUSt3R predicting pointmaps and per-pixel 3D Gaussians
* Supervision type: self-supervised photometric rendering loss plus geometric pose refinement
* Core contribution in one sentence: 用预训练 3D geometric foundation model 作为 neural scene regressor，通过 progressive registration、point-to-ray pose refinement 和 3DGS photometric training，从无位姿图像训练 Gaussian scene。
* Note status: `complete`

## 1. 一句话技术摘要

This paper addresses pose-free Gaussian Splatting from unordered images by using a 3D geometric foundation model as a scene regressor to transform image pairs into global pointmaps and Gaussians, with the key technical novelty being progressive self-supervised registration and point-to-camera-ray pose refinement.

## 2. 问题形式化

标准 3DGS 依赖 COLMAP/SfM 提供相机位姿和初始点云。当图像 unordered、densely captured 或 SfM 失败时，3DGS 无法直接训练。论文目标是在未知相机位姿下同时估计 camera poses、pointmaps 和 3D Gaussians。

设输入图像集合为 $I = \{I_i\}$。scene regressor $f_{SCR}$ 接收图像对 $(I_i,I_j)$，输出全局坐标下的 pointmaps $X_i,X_j$ 和对应 per-pixel Gaussians $G_i,G_j$。再用 PnP、multi-view pose refinement 和 differentiable Gaussian rendering 做自监督训练。

## 3. 方法概览

方法类似 classical incremental SfM，但把 sparse feature matching/triangulation 替换为 learned 3D geometric foundation model：

1. seed initialization: 选一个与最多图像相似的 seed image，固定其 pose 为 identity。
2. scene regressor fine-tuning: 基于 seed 做 photometric self-supervision。
3. progressive registration: 用 regressor 预测 target image 的 2D-3D correspondences，通过 RANSAC+PnP 得到 coarse pose。
4. multi-view pose refinement: 用 point-to-camera ray consistency loss 优化新注册相机。
5. finalization: 全局 pose refinement，然后用显式 3DGS densification/pruning 提升细节。

## 4. 方法细节

### 4.1 Scene regressor

网络基于 DUSt3R 和 Spann3R。DUSt3R 对图像对预测局部坐标 pointmaps；Spann3R 用 spatial memory 融合成全局 pointmaps。本文把这个 scene regressor 扩展为同时预测 dense pointmaps 和 3D Gaussian primitives：

$$
(X_i, G_i; X_j, G_j) = f_{SCR}(I_i, I_j)
$$

每个 Gaussian 包含 opacity $o$、mean $u$、covariance $\Sigma$ 和 SH coefficients。covariance 用 $\Sigma = RSS^\mathsf{T}R^\mathsf{T}$ 参数化。mean 不直接预测，而是从 pointmap 加 offset：$u = X + \Delta X$。

渲染时使用 differentiable rasterizer：

$$
\hat{I} = R(T,K;\{G_i\})
$$

### 4.2 Seed initialization

用 NetVLAD 计算每张图像 global descriptor，构建 similarity graph，边权为图像相似度，低于阈值 $s_{sim}$ 的边删除。选 degree 最大的节点作为 seed image，因为它与最多图像有重叠。

seed pose 固定为 $T_{seed}=I$，seed image 同时作为 reference 和 target，自监督 photometric loss 为：

$$
\mathcal{L}_{photo} = \sum \|I - R(T_{seed},K,\{G_i\})\|_1
$$

### 4.3 Progressive registration

对未注册图像 $I_k$，用已注册 reference image $I_{ref}$ 与 $I_k$ 输入 scene regressor，得到 target 的全局 3D points $X_k$。像素坐标 $y_k$ 与 $X_k$ 自然形成 2D-3D correspondences，用 RANSAC+PnP 得到 coarse pose：

$$
T_k^{coarse}, S_k = \mathrm{PnP}(K,\{(y_k,X_k)\})
$$

只有 inliers 数超过阈值 $s_{inlier}$ 的图像才加入 training buffer。

### 4.4 Multi-view pose refinement

coarse poses 仍不准，论文用 point-to-camera ray consistency loss 优化当前 epoch 新注册相机：

$$
X_i, T_k^{refine} = \arg\min_{X_i,R_k,t_k}\sum_{i,k}\rho(\|d_{i,k}\nu_{i,k} - (X_i-t_k)\|_2)
$$

其中 $t_k$ 是相机中心，$\nu_{i,k}$ 是 ray direction，$d_{i,k}$ 是 3D point 到 camera center 的 scale。相比 reprojection loss，这个误差有界，更稳。优化时固定 seed pose 解决 gauge ambiguity，并固定 seed 与相邻图像的 scale 解决 scale ambiguity。

### 4.5 Finalization

当所有图像注册完或无法继续注册时，先用 Eq. (8) 优化所有 camera poses，减少增量注册的累积误差；再用显式 3DGS densification/pruning refine scene details，因为 scene regressor 训练时受 GPU 限制只用低分辨率图像，几何细节偏粗。

## 5. 数学目标和损失

主要目标包括：

* photometric loss: $\mathcal{L}_{photo} = \sum_k \|I - R(T_k^{refine},K,\{G_i\})\|_1$；
* PnP registration: 基于 regressor 输出的 2D-3D correspondence；
* point-to-ray consistency: 用于 multi-view camera refinement；
* final explicit 3DGS refinement: 采用 3DGS densification/pruning 策略，细节未在主文重新展开。

## 6. 训练和推理流程

训练流程：

1. 计算 NetVLAD similarity graph，选择 seed image。
2. 用 seed image 进行自监督 scene regressor fine-tuning。
3. 每个 epoch 尝试注册更多图像；对每张候选图像做 RANSAC+PnP。
4. 对当前 epoch 注册的图像做 point-to-ray refinement。
5. 用 refined poses 和 Gaussian rendering photometric loss 继续 fine-tune regressor。
6. 全部注册后做全局 pose refinement 和 explicit 3DGS refinement。

推理/输出是重建出的 camera poses、3D Gaussians 和 novel view rendering。

## 7. 实验设置与结果摘要

评估数据包括 LLFF、Mip-NeRF360、Tanks-and-Temples、Seq TnT 和 7Scenes。Table 2 报告 camera pose accuracy，Fig. 3 和 Fig. 4 可视化相机位姿误差。论文声称在 pose accuracy 和 NVS 上超过 pose-free NeRF/3DGS 方法，甚至在部分场景超过用 COLMAP poses 训练的 3DGS。

主文强调该方法能处理 unordered 或 densely captured images，而 DUSt3R 的全局对齐后处理耗时且内存大，Spann3R 虽然可输出全局点但受短序列和精度限制。

## 8. 声称贡献 vs 实际技术增量

论文声称探索 3D geometric foundation models for Gaussian Splatting。实际增量是把 DUSt3R/Spann3R 这类模型放进一个 incremental SfM-like loop：每轮注册更多图像，利用它们预测的 dense pointmap 做 PnP 和 pose refinement，再通过 3DGS rendering loss 反向优化。

关键技术点不是单个网络层，而是 pipeline 设计：foundation model 负责 initial geometry/correspondence，3DGS photometric loss 负责 scene-specific refinement，point-to-ray loss 负责多视角 pose consistency。

## 9. 局限性和隐藏假设

* 依赖预训练 3D geometric foundation model 的泛化能力。
* progressive registration 可能受 seed choice 和 early pose errors 影响。
* 需要图像之间有足够 overlap；极端 sparse 或重复纹理场景可能失败。
* final 细节仍依赖 explicit 3DGS refinement，说明 regressor 输出不足以直接达到最高质量。
* 主文 pipeline 较长，复现时要核对阈值 $s_{sim}$、$s_{inlier}$ 和训练 epoch 策略。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 任务 | pose-free 3DGS from unordered images |
| 输入 | unordered unposed images |
| 输出 | camera poses, pointmaps, 3D Gaussians |
| 表示 | scene regressor + explicit Gaussians |
| 关键模块 | seed selection, RANSAC+PnP, point-to-ray pose refinement, progressive buffer |
| 关键损失 | photometric rendering loss, point-to-camera ray consistency |
| 主要优点 | 绕过 COLMAP，适合无位姿图像集合 |
| 主要风险 | 对 foundation model、overlap 和增量注册稳定性依赖强 |

## 11. 可复用组件

* 用 geometric foundation model 生成 2D-3D correspondences，再做 PnP。
* point-to-camera ray consistency 可用于其他 pose-free GS/NeRF。
* progressive training buffer 可与 streaming/online 3DGS 结合。
* final teacher-student：先用 regressor 获得粗场景，再蒸馏/优化到 explicit compact 3DGS。

## 12. Gap 和 idea seeds

* 把该 progressive reconstruction 与 uncertainty 结合，注册低置信度图像时降低其 photometric 权重。
* 对 dynamic scenes，可将 point-to-ray consistency 扩展为 motion-aware ray consistency，避免动态物体破坏 pose。
* 可用 Feat2GS 的 VFM feature probe 选择最适合 pose-free 3DGS 的 foundation model。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: supplementary 中 detailed hyperparameters、thresholds 和 runtime 需要复核。
* `NEED_HUMAN_CHECK`: 论文标题日期为 2025/10/29，需确认最终 NeurIPS 版本和代码发布。

## 14. Evidence Anchors

* Fig. 2: full training pipeline。
* Sec. 3.1: DUSt3R/Spann3R preliminaries, Eq. (1)-(2)。
* Sec. 3.2: scene regressor and Gaussian representation, Eq. (3)-(5)。
* Sec. 3.3.1: seed initialization, Eq. (6)。
* Sec. 3.3.2: progressive registration, Eq. (7)-(9)。
* Sec. 3.3.3: final pose and explicit 3DGS refinement。
* Sec. 4: datasets and camera pose experiments。
