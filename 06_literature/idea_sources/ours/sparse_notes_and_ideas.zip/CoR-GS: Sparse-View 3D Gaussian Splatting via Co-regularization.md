# CoR-GS: Sparse-View 3D Gaussian Splatting via Co-regularization

## 0. Metadata

* Title: CoR-GS: Sparse-View 3D Gaussian Splatting via Co-regularization
* Authors: Jiawei Zhang, Jiahe Li, Xiaohan Yu, Lei Huang, Lin Gu, Jin Zheng, Xiao Bai
* Year: 2025
* Venue: ECCV 2024 / LNCS 15059, 2025 proceedings
* PDF source: Zotero local PDF
* Zotero item key: CNNY4IKD
* Zotero PDF attachment key: RH942A55
* PDF path: `/Users/wangyibo/Zotero/storage/RH942A55/Zhang - CoR-GS Sparse-View 3D Gaussian Splatting via Co-regularization.pdf`
* Note path: `notes/CoR-GS: Sparse-View 3D Gaussian Splatting via Co-regularization.md`
* Code: Not specified
* Project page: https://jiaw-z.github.io/CoR-GS
* Dataset link: Not specified
* Main task: sparse-view 3DGS novel view synthesis
* Domain: 3DGS regularization, co-training / co-regularization, disagreement-based pruning
* Input: sparse posed views, fused stereo point cloud initialization
* Output: compact and coherent 3DGS radiance field

## 1. One-Sentence Technical Summary

CoR-GS 同时训练两个随机 densification 行为不同的 3DGS，通过 point disagreement 找到位置不可靠的 Gaussians 并 co-prune，通过 pseudo-view rendering disagreement 约束两套 radiance fields 在未见视角上保持一致，从而在不使用外部 depth prior 的情况下正则化 sparse-view 3DGS。

## 2. Problem Formulation

Sparse-view 3DGS 的根本问题是训练视角约束不足，densification 创建的新 Gaussians 会受随机采样影响，被放到不正确位置后很难被 sparse photometric supervision 修正。已有 FSGS / depth-supervised 方法用外部 depth estimator 纠正几何，但 depth noise 会引入额外错误。

CoR-GS 的观察是：即使用同样 sparse views 训练两个 3DGS，它们也会因为 densification randomness 在 Gaussian positions 和 rendered pixels 上出现不一致；这些 disagreement 与真实重建误差负相关。因此可以不用 ground truth novel views 或 depth GT，仅比较两个模型的分歧来定位不可靠重建。

## 3. Method Overview

方法分三步。第一，经验性定义并验证两个 disagreement：point disagreement 表示两套 Gaussian point clouds 的位置不一致，rendering disagreement 表示两套模型在 unseen views 上渲染颜色和深度不一致。第二，同时训练两个 3D Gaussian radiance fields $\Theta^1$ 和 $\Theta^2$。第三，在训练中用两种机制压制 disagreement：co-pruning 删除没有互相匹配点的 Gaussians；pseudo-view co-regularization 在插值 pseudo views 上最小化两套模型的渲染差异。

训练结束后只保留其中一个 3DGS 用于推理，因此推理成本不会翻倍；由于 co-pruning 得到更 compact Gaussians，推理甚至比 vanilla 3DGS 更快。

## 4. Method Details

### 4.1 Disagreement definition

每个 3D Gaussian primitive 写作 $\theta_i=\{\mu_i,s_i,q_i,\alpha_i,f_i\}$，其中 $\mu_i$ 是中心，$s_i$ 是 scale，$q_i$ 是 rotation，$\alpha_i$ 是 opacity，$f_i$ 是 color feature。Gaussian influence 为：

$$
G_i(x)=e^{-\frac{1}{2}(x-\mu_i)^T\Sigma_i^{-1}(x-\mu_i)}
$$

point disagreement 把两套 Gaussians 当作 point clouds，使用 point cloud registration 的 Fitness 和 RMSE 衡量位置分歧，最大 correspondence 距离 $\tau=5$。rendering disagreement 同时比较两套模型渲染图像和深度图；图像差异用 PSNR，深度差异用 relative absolute error。

### 4.2 Co-pruning

CoR-GS 同时训练两套 radiance fields：

$$
\Theta^1=\{\theta_i^1|i=1,2,\ldots,N^1\},\quad \Theta^2=\{\theta_i^2|i=1,2,\ldots,N^2\}
$$

对 $\Theta^1$ 中的每个 Gaussian，在 $\Theta^2$ 中找最近邻匹配：

$$
f(\theta_i^1)=KNN(\theta_i^1,\Theta^2)
$$

若对应位置距离超过阈值 $\tau=5$，则视作 non-matching：

$$
M_i=
\begin{cases}
1,&\|\mu_i^1-\mu_{f(i)}^2\|^2>\tau\\
0,&\mathrm{otherwise}
\end{cases}
$$

两套 Gaussian sets 都计算 non-matching mask，并剪掉所有 non-matching Gaussians。co-pruning 每 5 次 optimization / density control interleaves 执行一次，目标是剪掉优化无法修正的错误新生 Gaussians。

### 4.3 Pseudo-view co-regularization

pseudo view 在线采样自欧氏距离最近的两个训练视图，遵循 FSGS 式采样：

$$
P'=(t+\epsilon,q)
$$

其中 $t$ 来自训练相机位置，$\epsilon$ 是 normal distribution noise，$q$ 是两个训练相机 rotation 的平均 quaternion。在 pseudo view $P'$ 上，分别用 $\Theta^1$ 和 $\Theta^2$ 渲染 $I'^1$ 与 $I'^2$，计算 co-regularization：

$$
R_{color}^{p}=(1-\lambda)L_1(I'^1,I'^2)+\lambda L_{D-SSIM}(I'^1,I'^2)
$$

其中 $\lambda=0.2$。该项把 high rendering disagreement 的 pixels 视为不可靠区域，通过压低分歧约束未见视角几何。

## 5. Mathematical Objectives and Losses

训练视图上，模型仍使用标准 3DGS photometric supervision。对 $\Theta^1$ 渲染训练视图图像 $I^1$，真值为 $I^*$：

$$
L_{color}=(1-\lambda)L_1(I^1,I^*)+\lambda L_{D-SSIM}(I^1,I^*)
$$

最终损失为：

$$
L=L_{color}+\lambda_pR_{color}^{p}
$$

论文设置 $\lambda_p=1.0$。$\Theta^2$ 也以相同方式训练。方法没有引入外部 depth loss；几何正则来自两套 3DGS 的 mutual disagreement。

## 6. Training and Inference Procedure

实验使用 LLFF、Mip-NeRF360、DTU 和 Blender。数据划分和下采样遵循 prior works，LLFF / Mip-NeRF360 / DTU / Blender 下采样率分别为 8 / 4 / 4 / 2。DTU 使用 object masks 去除背景影响。相机位姿假设已知。对比方法包括 Mip-NeRF、DietNeRF、RegNeRF、FreeNeRF、SparseNeRF、FSGS 和 vanilla 3DGS。

LLFF、DTU、Blender 训练 10000 iterations，Mip-NeRF360 训练 30000 iterations。与 FSGS 一样，3DGS 和 CoR-GS 使用 sparse views fused stereo point cloud 初始化。训练时同时维护两套 3DGS 并渲染 pseudo views；推理时保留一套模型。

## 7. Experimental Setup and Results Summary

LLFF 上，CoR-GS 在 3/6/9 training views 下均在 PSNR、SSIM、LPIPS、AVGE 上取得最好表现。论文强调，当 9 views 时 vanilla 3DGS 已能较好重建结构，外部 depth supervision 的收益下降，而 CoR-GS 仍通过压制错误几何带来提升。

Mip-NeRF360 上，CoR-GS 在 12 和 24 training views 下获得最佳 PSNR、SSIM、AVGE；12 views 下 LPIPS 由 vanilla 3DGS 最好，作者认为未见区域与训练视角共可见性低，pseudo-view co-regularization 可能倾向 blur，但 24 views 时 CoR-GS 的 LPIPS 也最好。DTU 上，CoR-GS 在 3/6/9 views 的 SSIM、LPIPS、AVGE 最好；3 views 时 NeRF-based methods 的 PSNR 可能更高，因为 3DGS 对不可见区域常渲染黑背景。

效率对比在 LLFF 3-view、RTX 3090 Ti 上进行。FreeNeRF 约 0.09 FPS、2.3h、4x48GB；SparseNeRF 约 0.09 FPS、1.5h、32GB；3DGS 318 FPS、19.22 PSNR、2.5min、2GB；CoR-GS 349 FPS、20.45 PSNR、6min、3GB。CoR-GS 训练比 3DGS 慢，但点数减少约 33%，推理速度更快。

消融 Table 6 显示，在 LLFF 3-view 中，baseline 3DGS 为 19.22 / 0.649 / 0.229；只用 co-pruning 为 19.62 / 0.673 / 0.217；只用 pseudo-view co-reg 为 20.26 / 0.706 / 0.198；两者结合为 20.45 / 0.712 / 0.196。DTU 3-view 中，两者结合达到 19.21 / 0.853 / 0.119，也优于单独模块。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 point / rendering disagreement 的发现、co-pruning、pseudo-view co-regularization，以及 SOTA sparse-view 结果。实际技术增量在于把 co-training / disagreement 思想移植到 unstructured 3DGS：两个随机初始化和 densification 轨迹不同的 Gaussian fields 互为无监督质量检测器。

与 depth-regularized sparse 3DGS 相比，CoR-GS 不依赖外部 depth estimator，因此避免 depth prior 噪声。与 DropGaussian / pruning 类方法相比，它不是盲目结构正则，而是通过两套模型之间的 nearest-neighbor mismatch 和 pseudo-view rendering mismatch 定位具体不可靠区域。

## 9. Limitations and Hidden Assumptions

方法需要同时训练两套 3DGS，并渲染 pseudo views，因此训练成本高于 vanilla 3DGS。co-pruning 依赖两个模型的 disagreement 能反映错误几何；如果两个模型在同一错误区域达成一致，方法可能无法识别。pseudo-view co-regularization 也可能在低共可见区域产生过平滑，Mip-NeRF360 12-view LPIPS 现象说明了这一风险。

方法仍假设输入相机位姿已知，并沿用 FSGS 的 fused stereo point cloud 初始化。对于 pose-free、极少视角、动态场景或强反射场景，disagreement 与真实误差的相关性需要重新验证。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| 核心任务 | Sparse-view 3DGS NVS |
| 输入 | sparse posed views, fused stereo point cloud |
| 核心思想 | two 3DGS disagreement predicts reconstruction error |
| 模块 | co-pruning, pseudo-view co-regularization |
| 外部先验 | no external depth prior |
| 训练成本 | two fields + pseudo-view rendering, about 6min on LLFF 3-view |
| 推理成本 | keep one field, 349 FPS, fewer Gaussians |
| 主要优势 | compact geometry, no depth noise, broad dataset performance |
| 主要风险 | shared wrong consensus, pseudo-view blur, doubled training fields |

## 11. Reusable Components for My Research

1. 训练两个 3DGS 并用 disagreement 做 uncertainty / error map，是一种无需 GT novel views 的质量估计方式。
2. co-pruning 可与 DropGaussian / DropoutGS 合并：先用 disagreement 定位 outlier，再做结构正则。
3. pseudo-view co-regularization 可作为 external depth-free 的 sparse-view regularizer。
4. point disagreement 的 Fitness / RMSE 可用于评估不同 initialization 或 densification 策略的稳定性。
5. disagreement map 可作为 active view selection 或 diffusion-guided pseudo-view generation 的采样权重。

## 12. Gap and Idea Seeds

1. 三模型或 ensemble disagreement：降低两个模型同时犯错导致的 false agreement。
2. uncertainty-weighted pseudo-view co-reg：只在中等 disagreement 区域约束，高 disagreement 区域先标记为不可信而非强行对齐。
3. 与 MVSplat / TranSplat 初始化结合：用 feed-forward Gaussians 启动两套 fields，再用 CoR-GS 去除错误中心。
4. 将 co-pruning 扩展到 opacity、scale、rotation disagreement，而不只比较 Gaussian centers。
5. 在动态 3DGS 中使用 temporal disagreement，识别 static jittering 或错误 deformation。

## 13. Human Check List

* NEED_HUMAN_CHECK: LLFF / Mip-NeRF360 / DTU / Blender 主表完整逐项数值在文本抽取中被截断，如需矩阵精确数值应回看 PDF 表格。
* NEED_HUMAN_CHECK: pseudo-view sampling 的 normal noise 方差、co-pruning 具体 schedule 和 KNN 实现细节需查 supplement / code。
* NEED_HUMAN_CHECK: project page 是否提供代码 release 需要浏览网页确认。
* 已确认：公式格式按仓库 inline / display dollar 规范书写。

## 14. Evidence Anchors

* Abstract: 提出 co-regularization perspective、point disagreement、rendering disagreement、co-pruning 和 pseudo-view co-regularization。
* Section 1, Introduction: 说明 densification randomness 导致两个 3DGS 在 sparse views 下差异累积。
* Section 3.1: 3DGS primitive 定义、point disagreement 和 rendering disagreement 的度量。
* Section 3.2 and Figures 3-5: 经验验证 disagreement 与 reconstruction quality 的负相关。
* Section 4.1: co-pruning 的 KNN matching、non-matching mask 和 $\tau=5$。
* Section 4.2: pseudo-view sampling、pseudo-view color co-regularization 和最终 loss。
* Section 5.1: LLFF、Mip-NeRF360、DTU、Blender 设置、metrics、训练 iterations、fused stereo point cloud initialization。
* Section 5.2: LLFF、Mip-NeRF360、DTU、Blender 主结果与定性 geometry compactness 分析。
* Table 5: LLFF 3-view 效率对比，CoR-GS 349 FPS、6min、3GB。
* Table 6 and Figure 10: co-pruning 与 pseudo-view co-regularization 的消融和互补性。
