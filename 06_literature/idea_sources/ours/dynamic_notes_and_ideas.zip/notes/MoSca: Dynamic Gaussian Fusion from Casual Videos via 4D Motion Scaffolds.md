# MoSca: Dynamic Gaussian Fusion from Casual Videos via 4D Motion Scaffolds

## 0. Metadata

- Title: MoSca: Dynamic Gaussian Fusion from Casual Videos via 4D Motion Scaffolds
- Authors: Jiahui Lei; Yijia Weng; Adam W. Harley; Leonidas Guibas; Kostas Daniilidis
- Venue/Year: CVPR Open Access version; Zotero date 2024. NEED_HUMAN_CHECK: confirm final venue year from the camera-ready record.
- Project / code: https://www.cis.upenn.edu/~leijh/projects/mosca
- Zotero item key: `Z39GHTKS`
- Zotero PDF attachment key: `624EM729`
- PDF path: `/Users/wangyibo/Zotero/storage/624EM729/Lei 等 - MoSca Dynamic Gaussian Fusion from Casual Videos via 4D Motion Scaffolds.pdf`
- Local note path: `notes/MoSca: Dynamic Gaussian Fusion from Casual Videos via 4D Motion Scaffolds.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

MoSca 用一个由稀疏 6-DoF 运动轨迹节点构成的 4D Motion Scaffold，把单目 casual video 中由深度、长程点轨迹和光流提供的 2D/3D 先验转成可变形场，再把动态前景 Gaussians 锚定到该 scaffold 上做全时刻融合，从而在无需模板和人工相机的条件下重建、渲染和编辑动态场景。

## 2. Problem Formulation

输入是一段单目 casual video，目标是在相机位姿、焦距、深度、动态前景和静态背景都不完全可靠的情况下，恢复一个可实时渲染的 4D 表示。论文将问题拆成三层：先从 foundation-model priors 估计相机与粗几何，再用 4D Motion Scaffold 表达动态物体的稀疏运动骨架，最后把动态 3D Gaussians 和静态背景 3DGS 放到统一渲染管线里联合优化。

核心约束来自三类观测：逐帧单目深度 $D_t$，长程 2D tracklets，和由 dense optical flow / epipolar error 得到的动态前景线索。作者不是直接为每一帧训练独立 Gaussians，而是学习一个跨时间共享的动态 Gaussian 集合 $G$，每个 Gaussian 通过 scaffold deformation 从参考时刻变换到目标时刻。

## 3. Method Overview

MoSca 的 pipeline 分为四步。第一步用 tracklet-based bundle adjustment 从置信静态背景 tracklets 初始化焦距、相机位姿和深度尺度修正。第二步把动态前景 tracklets 反投影到 3D，初始化为 motion scaffold nodes，并通过 ARAP 与时序平滑约束优化稀疏运动图。第三步初始化动态前景 Gaussians 和静态背景 Gaussians，用 scaffold deformation 将所有前景 Gaussians 融合到任意时刻渲染。第四步在 RGB、depth、tracking、ARAP 和时序项上联合优化，并周期性执行 node control，使 Gaussians 与 scaffold 节点的覆盖更稳定。

方法的关键选择是用稀疏节点而不是逐 Gaussian 自由形变来承载运动。这样可以把 2D tracker 的长程一致性转化为低维 4D 几何约束，同时仍保留 3DGS 的高效 rasterization。

## 4. Method Details

### 4.1 Motion Scaffold Representation

Motion Scaffold 是一个动态图 $S=(V,E)$。每个节点 $v^{(m)}$ 是一条 6-DoF 轨迹和一个全局控制半径：

$$
v^{(m)}=([Q_1^{(m)},\ldots,Q_T^{(m)}], r^{(m)}), \quad Q_t^{(m)}=[R_t^{(m)},t_t^{(m)}]\in SE(3).
$$

边 $E$ 通过 curve distance 的 KNN 周期性更新，距离定义为 $D_{\mathrm{curve}}(m,n)=\max_t\|t_t^{(m)}-t_t^{(n)}\|$。这比固定空间邻接更适合有接触、遮挡和拓扑变化的动态物体。

### 4.2 Dense Deformation by DQB

给定查询点 $x$、源时刻 $t_{\mathrm{src}}$ 和目标时刻 $t_{\mathrm{dst}}$，方法先找到最近节点 $m^\*$，再取其邻居节点的相对运动 $\Delta Q^{(i)}=Q_{t_{\mathrm{dst}}}^{(i)}(Q_{t_{\mathrm{src}}}^{(i)})^{-1}$。权重用 RBF 形式 $w_i(x,t_{\mathrm{src}})=\exp(-\|x-t_{t_{\mathrm{src}}}^{(i)}\|_2^2/(2r_i^2))$。最终 deformation $W(x,w;t_{\mathrm{src}},t_{\mathrm{dst}})$ 由 Dual Quaternion Blending 计算，而不是普通 LBS，以减轻旋转插值导致的伪影。

### 4.3 Camera and Depth Initialization

相机初始化使用静态背景 tracklets。论文先根据每条 tracklet 的最大 epipolar error 筛出静态点，再优化焦距、相机外参和深度修正。目标包括 reprojection loss $L_{\mathrm{proj}}$ 与 scale-invariant depth alignment $L_z$，组合为 $L_{\mathrm{BA}}=\lambda_{\mathrm{proj}}L_{\mathrm{proj}}+\lambda_zL_z$。后续 photometric optimization 仍会继续 refine camera poses。

### 4.4 Geometric Scaffold Optimization

动态前景 tracklets 通过当前相机与深度被提升到 3D：可见点由 $h_t=W_t\pi_K^{-1}(p_t,D_t[p_t])$ 得到，不可见位置在邻近可见帧之间做线性插值。节点初始化为 $Q_t^{(i)}=[I,h_t^{(i)}]$，半径设为固定初值 $r_{\mathrm{init}}$。

几何优化使用多层 subsampled topology pyramid 上的 ARAP loss，加上速度和加速度平滑项。一个重要实现细节是：优化阶段只更新节点旋转和不可见时刻的平移，可见的 3D track positions 保持不变，避免把 tracker/depth 给出的强观测拖偏。

### 4.5 Dynamic Gaussian Fusion

动态前景 Gaussian 集合写作 $G=\{(\mu_j,R_j,s_j,o_j,c_j;t_{\mathrm{ref},j},\Delta w_j)\}$。其中 $t_{\mathrm{ref},j}$ 是初始化时反投影深度所在的参考帧，$\Delta w_j$ 是可学习 skinning correction。查询时刻 $t$ 的前景 Gaussian 由

$$
T_j(t)=W(\mu_j, w(\mu_j,t_{\mathrm{ref},j})+\Delta w_j; t_{\mathrm{ref},j},t)
$$

变换得到，然后渲染 $(T_j(t)\mu_j,T_j(t)R_j,s_j,o_j,c_j)$。静态背景使用标准 3DGS 集合 $H$，每帧渲染的是 $G(t)\cup H$。

### 4.6 Tracking-Supervised Rendering and Node Control

除 RGB 和 depth 外，方法还 rasterize 3D 坐标来生成 flow / track maps，并用 inferred 2D flows / tracklets 监督 $L_{\mathrm{track}}$。这使渲染优化不只拟合颜色，也保持跨帧对应关系。

Node control 有三类操作：周期性把随机时刻的动态前景 Gaussians 复制到静态背景并重置前景 opacity，用后续 pruning 去掉错误转移；删除对所有 Gaussians 都低权重的 scaffold nodes；从 tracking loss 诱导的大梯度 Gaussians 中采样并生成新节点，以补足运动图覆盖不足的位置。

## 5. Mathematical Objectives and Losses

完整 photometric stage 的目标函数为：

$$
L=\lambda_{\mathrm{rgb}}L_{\mathrm{rgb}}+\lambda_{\mathrm{dep}}L_{\mathrm{dep}}+\lambda_{\mathrm{track}}L_{\mathrm{track}}+\lambda_{\mathrm{arap}}L_{\mathrm{arap}}+\lambda_{\mathrm{acc}}L_{\mathrm{acc}}+\lambda_{\mathrm{vel}}L_{\mathrm{vel}}.
$$

其中 $L_{\mathrm{rgb}}$ 约束渲染图像，$L_{\mathrm{dep}}$ 对齐深度，$L_{\mathrm{track}}$ 约束长程或 dense correspondence，$L_{\mathrm{arap}}$ 维持 scaffold 局部刚性，$L_{\mathrm{acc}}$ 和 $L_{\mathrm{vel}}$ 做时序平滑。论文的 loss 设计体现出两个优先级：几何对应关系先于纯颜色拟合，低维 scaffold 先于逐点任意变形。

## 6. Training and Inference Procedure

训练先运行 foundation priors：单目深度估计、长程 2D tracking、光流与 epipolar dynamic likelihood。然后执行静态背景 BA，得到相机和深度修正。随后将前景 tracklets 提升为 3D 轨迹节点，构建并优化 Motion Scaffold。最后初始化动态前景 Gaussians 和静态背景 Gaussians，进入联合 photometric optimization。

推理时给定目标时刻和相机，动态前景 Gaussians 通过 scaffold deformation 从各自参考时刻变换到目标时刻，静态背景保持不变，两者一起送入 3DGS rasterizer。因此推理复杂度主要来自 Gaussian 数量和 deformation 查询，而不是重新运行视频级优化。

## 7. Experimental Setup and Results Summary

论文在 DyCheck、SOM-5-1x、NVIDIA dynamic scenes、Sintel / TUM-dynamics camera pose、以及 DyCheck correspondence 上评估。DyCheck 上，MoSca 在已知 pose 条件下报告 mPSNR 19.32、mSSIM 0.706、mLPIPS 0.264；无 pose 条件下为 18.84 / 0.676 / 0.289，带焦距优化时为 19.02 / 0.683 / 0.279。SOM-5-1x 上 MoSca 为 PSNR 18.40、SSIM 0.67、LPIPS 0.42，高于 Shape-of-Motion 的 16.72 / 0.63 / 0.45。

NVIDIA 平均结果中，MoSca 报告 PSNR 26.72、LPIPS 0.070；无 pose 版本为 26.54、0.073。它与 RoDynRF、CTNeRF、DynPoint 等强基线接近或略高，但优势更集中在 casual-video setting 与动态对应能力上。

相机位姿表中，MoSca 在 Sintel 上 ATE 0.090、RPE trans 0.034、RPE rot 0.312；TUM-dynamics 上 ATE 0.031、RPE trans 0.011、RPE rot 0.426。DyCheck correspondence 的 PCK-T @0.05% 为 0.824，高于 CoTracker 0.803、Gaussian Marbles 0.806 和 BootsTAPIR 0.779。

Ablation 显示 photometric stage 最关键：去掉它后 DyCheck 从 19.32 / 0.706 / 0.264 降到 13.71 / 0.480 / 0.763。去掉 geometric optimization stage 降到 18.85 / 0.693 / 0.287；去掉 DQB、多层拓扑或 learnable skinning correction 也有小幅下降。论文还报告去掉 $L_{\mathrm{track}}$ 时 PCK-T 从 0.824 降到 0.737。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称的主要贡献是 4D Motion Scaffold、基于 scaffold 的 dynamic Gaussian fusion、以及无需人工相机的 casual-video 动态重建流程。实际技术增量可以概括为：把 tracker/depth/flow foundation priors 整合到一个稀疏 SE(3) 运动图里，并让 dynamic 3DGS 只通过这个运动图进行跨时刻融合。

与直接学习 deformation MLP 或每帧独立 Gaussian 的工作相比，MoSca 的新意不在 rasterizer，而在运动参数化和监督组织方式。它把对应关系监督显式引入渲染优化，又通过 DQB、ARAP、node control 让稀疏节点足以控制大量 Gaussians。实际差异更像一个鲁棒系统设计，而不是单个新 loss 或新渲染公式。

## 9. Limitations / Assumptions

方法依赖较准确的单目深度和长程 2D tracks。如果 tracker 在遮挡、快速运动、低纹理或反光区域失败，Motion Scaffold 的初始化和 $L_{\mathrm{track}}$ 都会受影响。

重建范围限于视频中至少某个时刻可见的区域。对从未可见的背面、内部结构或长期遮挡区域，当前方法没有真正的生成式补全能力。

变形场主要解释几何运动。阴影、反射、液体、曝光变化和非 Lambertian 效应不能被简单 deformation 完整解释，可能被错误吸收到背景 Gaussians 或产生伪影。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | 单目 casual video；估计深度、2D tracklets、dense flow / epipolar maps |
| Output | 静态背景 3DGS + 由 4D Motion Scaffold 驱动的动态前景 Gaussians |
| Core representation | 稀疏 SE(3) trajectory graph with radius；dynamic Gaussians anchored to scaffold |
| Motion model | RBF skinning + Dual Quaternion Blending |
| Main supervision | RGB、depth、track / flow、ARAP、velocity、acceleration |
| Camera requirement | 可从静态背景 tracklets 自动初始化并联合优化 |
| Strength | casual video setting 下同时做相机、动态几何、渲染和对应关系 |
| Weakness | 强依赖 foundation priors；对不可见区域和非几何光照效应有限 |

## 11. Reusable Components

- 用 curve-distance KNN 构图的 4D motion graph，可复用于其他动态场景表示。
- RBF skinning + DQB 的 sparse-node deformation，可以替代 LBS 或 MLP deformation。
- Tracklet-based static-background BA，适合没有 SfM / SLAM 可靠初始化的 monocular dynamic videos。
- Rasterized track / flow supervision，把 2D correspondence 转成 differentiable Gaussian rendering loss。
- Node control 机制：根据 Gaussian 权重、tracking gradients 和前背景转移动态调整 scaffold。

## 12. Gap / Idea Seeds

- MoSca 的 motion scaffold 仍然由外部 trackers 和 depth priors 强驱动，可以研究把 tracker uncertainty 显式建模进节点半径、边权和 loss weighting。
- 当前 node control 偏启发式；可以把节点增删改写成可学习的 graph refinement 或 Bayesian birth-death process。
- 对阴影、反射、液体这类非几何变化，可加入分离的 appearance residual field，避免把它们误解释成形变。
- 对从未可见区域，可结合 video diffusion 或 object priors，但需要保持 4D consistency 和可编辑性。

## 13. Human Check List

- NEED_HUMAN_CHECK: 确认最终正式发表年份和 venue 条目，Zotero metadata 仅给出 2024。
- NEED_HUMAN_CHECK: 项目 URL 在 PDF 提取文本中存在空格/tilde artifact，笔记中按常见项目页格式写为 `https://www.cis.upenn.edu/~leijh/projects/mosca`。
- NEED_HUMAN_CHECK: DyCheck Table 1 部分 baseline 行在文本抽取中断裂，本笔记只保留了较确定的 MoSca 与关键对比数字。

## 14. Evidence Anchors

- Section 3.1: 4D Motion Scaffold 的节点、边和 DQB deformation 定义。
- Section 3.2: depth、long-term tracks、epipolar dynamic maps 等 foundation priors。
- Section 3.3: camera / depth initialization via static tracklet BA。
- Section 3.4: geometric scaffold optimization，包含 ARAP、velocity、acceleration 和不可见点处理。
- Section 3.5: dynamic Gaussian fusion、tracking-supervised rendering、node control 和总目标函数。
- Tables 1-7: DyCheck、SOM-5-1x、NVIDIA、camera pose、correspondence、ablation、prior choices 和 model statistics。
