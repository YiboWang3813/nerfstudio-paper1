---
title: "UniGS: Modeling Unitary 3D Gaussians for Novel View Synthesis from Sparse-view Images"
authors: "Jiamin Wu, Kenkun Liu, Xiaoke Jiang, Yuan Yao, Lei Zhang"
year: 2025
venue: "ICCV 2025"
zotero_item_key: "6XI4E98I"
pdf_attachment_key: "U8EPMGMY"
pdf_path: "/Users/wangyibo/Zotero/storage/U8EPMGMY/Wu 等 - UniGS Modeling Unitary 3D Gaussians for Novel View Synthesis from Sparse-view Images.pdf"
note_path: "notes/UniGS: Modeling Unitary 3D Gaussians for Novel View Synthesis from Sparse-view Images.md"
tags: ["3D Gaussian Splatting", "generalizable reconstruction", "sparse-view synthesis", "DETR", "multi-view attention"]
---

## 0. 一句话总结

UniGS 针对多视图前馈 3DGS 中“每个视图逐像素预测 Gaussian 再拼接”造成的 ghosting、Gaussian 均匀浪费和输入视图数固定问题，提出在世界坐标系中维护固定数量的 unitary 3D Gaussians，把 Gaussian 当作 DETR-like queries，通过 multi-view deformable attention 从多张 posed sparse images 中逐层更新同一组 Gaussian。

## 1. 问题与动机

许多 generalizable 3DGS 方法采用 local prediction and fusion：每个输入视图的每个像素都预测一个或多个 Gaussian，再通过相机位姿变换到世界坐标系并 concat。这个设计带来两个问题。

第一，不同视图独立预测的 Gaussian 位置可能不对齐，concat 后会出现 ghosting，即多个视图对同一结构生成互相错位的 Gaussian。第二，Gaussian 数量随输入视图线性增长，且由像素网格均匀产生，简单区域和复杂区域得到类似密度，不能把更多 primitives 分配给细节区域。第三，训练和推理通常要求相同输入视图数，实际使用不灵活。

## 2. 适用场景

UniGS 适合有相机参数的 sparse-view object reconstruction 和 novel view synthesis，尤其是少量 posed views 输入、希望一次前馈得到高质量 3D Gaussian 表示的场景。

它支持任意数量输入视图的推理：因为 Gaussian query 数量固定且独立于输入视图数，更多视图只是提供更多 cross-attention 信息源，而不是生成更多 per-view Gaussian。

## 3. 方法定位

UniGS 是 generalizable feed-forward 3DGS 方法，不是 per-scene optimization。它也不是 pose-free 方法，仍需要用户提供相机内外参用于把 unitary Gaussian centers 投影到各输入视图并采样图像特征。

相对 LGM、Splatter Image、GS-LRM 等 per-view local Gaussian prediction 方法，UniGS 的核心变化是“先有一组全局 Gaussian queries，再从多视图信息中更新它们”，而不是“每个视图先预测一堆 Gaussian，再拼成全局表示”。

## 4. 核心创新

第一，提出 unitary 3D Gaussians。模型在世界坐标系中定义固定数量的 Gaussian queries，每个 query 和一个 Gaussian primitive 一一对应，所有输入视图共同更新这同一组 Gaussian。

第二，提出 Multi-View Deformable Attention（MVDFA）。每个 Gaussian center 被投影到每个输入视图，在投影参考点附近做 deformable sampling，从各视图图像特征中取相关信息更新 query。

第三，用 camera modulation 生成 view-specific queries。由于 Gaussian queries 是全局的，而各视图图像平面不同，作者用相机参数通过 adaLN/MLP 调制 query，使同一个全局 Gaussian 在不同视图中有不同查询形式。

第四，提出 Spatial Efficient Self-Attention（SESA）。为降低大量 Gaussian query 之间 self-attention 的显存成本，SESA 保持 query 数不变，但用 FPS 选出的子集作为 key/value，从而保留跨 Gaussian 信息交换并降低开销。

## 5. 方法细节

模型由 feature extractor encoder 和 query refinement decoder 组成。多视图输入先经过 U-Net 提取图像特征，视图数大于 1 时在 U-Net block 后加入 cross-view attention，用 shifted-window attention 降低内存。

decoder 中定义固定数量 queries $Q\in\mathbb{R}^{N\times C}$，$N$ 是 Gaussian 数，$C$ 是 hidden dimension。每个 query 对应一个 3D Gaussian，参数包括 center $\mu$、opacity $\sigma$、rotation $R$、scale $S$ 和 spherical harmonics $SH$。

每个 decoder layer 包括 MVDFA、SESA 和 FFN：

$$
Q_{l+1}=\operatorname{FFN}(\operatorname{SESA}(\operatorname{MVDFA}(Q_l,P_l,F)))
$$

query 通过 MLP 预测 Gaussian 参数增量 $\Delta G=\operatorname{MLP}(Q)$，再更新 $G'=G+\Delta G$。rotation 用乘法更新，其余参数用加法更新。

MVDFA 中，给定 Gaussian center $\mu$、第 $i$ 个视图的 pose $\pi_i$ 和 intrinsics $K_i$，先用 pinhole projection 得到该 Gaussian 在该视图上的参考点：

$$
P_i=K_i\pi_i\mu
$$

然后线性层预测采样 offset $\Delta s_i$，得到采样点 $s_i=P_i+\Delta s_i$。模型在这些采样点附近用 bilinear grid sampling 取图像特征作为 values，再预测 attention scores 做加权聚合，得到每个视图的 updated query。

view-specific queries 通过加权求和融合回 unitary query：

$$
Q'=\sum_i w_i q'_i,\quad w_i=\operatorname{MLP}(q'_i)
$$

SESA 用 FPS 从 Gaussian centers 中选出空间上分散的 query 子集作为 self-attention 的 key/value，避免全量 $N\times N$ 注意力开销。训练目标是渲染 4 个输入视图和 8 个额外视图，共 12 个视图，用 MSE 和 LPIPS 监督：

$$
L=L_{MSE}(I_{pd},I_{gt})+\lambda L_{LPIPS}(I_{pd},I_{gt})
$$

## 6. 实验设置

训练使用 Objaverse LVIS 的 refined subset。输入渲染图来自固定视角 front、back、left、right，监督视角为 32 个随机视角，elevation 在 -30 到 30 度之间。图像分辨率下采样到 128 x 128。

评估在 Google Scanned Objects（GSO）benchmark 上进行。固定视角输入为 front、left、back、right，测试 32 个随机视角，elevation 从 0 到 30 度。指标包括 PSNR、SSIM、LPIPS，并可视化 Gaussian centers 作为点云。

## 7. 主要结果

GSO 4-view、128 分辨率上，UniGS 达到 30.4245 PSNR、0.9614 SSIM、0.0422 LPIPS。相比 Splatter Image 的 25.6241 PSNR、LGM Large 的 26.2487 PSNR、InstantMesh 的 23.0177 PSNR、GS-LRM 的 29.5900 PSNR，UniGS 取得最好结果。

论文强调相比某些近期方法，UniGS 在 Objaverse 训练、GSO 测试时 PSNR 提升约 4.2 dB。定性结果显示，LGM 有明显 ghosting，InstantMesh 缺少细节，而 UniGS 的几何和纹理更稳定。

速度方面，UniGS forward time 为 0.6939s，rendering time 为 0.0019s，一次 forward 加 32 次 rendering 的 inference time 为 0.7538s；LGM 为 1.9143s，InstantMesh 为 20.4641s，DreamGaussian 为 118.4461s。

任意输入视图数实验显示，UniGS 训练时使用固定 4 views，但推理时输入 2 到 8 views 都能工作，并且视图数增加时性能提升；而依赖 per-view Gaussian concat 的方法在视图数偏离训练设定时性能下降或无法处理。

## 8. 消融与分析

初始化消融显示，完全随机初始化 Gaussian 性能极差，PSNR 只有 12.1213；随机初始化在 cone of vision 内提升到 22.6740；最终用从图像特征逐像素回归的初始化效果最好。原因是 MVDFA 需要把 Gaussian center 投影到图像上采样特征，若初始投影在图像外，会采到零特征并导致训练困难。

模型设计消融中，去掉 cross-view attention 后 PSNR 为 25.3923，UNet only 为 25.6033，去掉 camera modulation 为 26.1328，使用 3D sampling points 为 25.8392，完整模型为 26.5334、0.9344 SSIM、0.0667 LPIPS。说明 view-specific camera modulation 和 MVDFA 的 2D sampling 设计都重要。

SESA 消融显示，随着 self-attention key/value 下采样率增加，显存线性下降，而 PSNR 下降较慢；作者选择 0.01 作为质量和显存的平衡点。Gaussian 数量消融显示，当数量超过 19600 后收益趋于平缓，因此默认使用 19600 个 3D Gaussians。

## 9. 与相关工作的关系

相比 LGM、Splatter Image、GS-LRM，UniGS 不做 per-view per-pixel Gaussian prediction and concatenation，因此更少 ghosting，也不会让 Gaussian 数量随输入视图线性增加。

相比 MVSplat、pixelSplat 这类面向场景的 generalizable Gaussian 方法，UniGS 更偏 object-level reconstruction，并且把 Gaussian 当作 DETR-style queries，而不是从深度图或 cost volume 中 unproject 每像素 primitive。

相比 Deformable DETR/BEVFormer 等 2D-3D attention 思路，UniGS 的 reference points 是当前预测 Gaussian centers 投影到各视图，且通过 camera modulation 区分不同视图对同一全局 Gaussian 的查询方式。

## 10. 优点

UniGS 的优点是全局表示一致：所有视图共同更新同一组 Gaussian，天然避免多视图局部预测拼接造成的对不齐。固定 query 数也让模型更容易控制显存和 Gaussian 分布。

另一个优点是能把更多 Gaussian 分配给复杂区域。因为 Gaussian queries 通过全局优化和图像特征更新，不受像素网格均匀分布约束，复杂局部可以聚集更多 primitives。

第三个优点是输入视图数灵活。训练固定 4 views，但推理可用更多或更少视图，不需要重训。

## 11. 局限

论文明确指出 UniGS 需要用户提供相机参数，这对实际 3D reconstruction 是限制。所有 MVDFA projection 和 camera modulation 都依赖准确 pose/intrinsics；若相机错误，reference points 会错，特征采样和 Gaussian 更新都会受影响。

此外，方法主要在 object-level GSO/Objaverse 设置中验证，场景级、无界场景和强遮挡复杂环境的泛化仍需要更多实验。固定数量 Gaussian 虽然稳定，但对不同复杂度对象可能不是最优。

## 12. 可复现要点

复现时要先实现 unitary Gaussian query 初始化，不能直接随机全空间初始化。推荐先从图像特征逐像素回归得到较合理的 Gaussian 初始化，保证投影参考点落在视野附近。

MVDFA 需要对每个 Gaussian center 在每个输入视图做 projection，并在投影点附近预测 offset 采样多点图像特征。camera modulation 必须保留，否则不同视图下的 query 表达不足。SESA 对显存很重要，默认可用 FPS 采样 1% query 作为 self-attention key/value。

## 13. 可能扩展

一个直接扩展是与 pose-free 模型结合：先用 FreeSplatter/DUSt3R 估计相机，再用 UniGS 的 unitary Gaussian query 机制更新全局表示，减少 per-view concat ghosting。

第二个扩展是动态 Gaussian query 数量。可从固定 19600 扩展为按对象复杂度增减 query，或用 birth/death 机制在 decoder 中逐步增加复杂区域 Gaussian。

第三个扩展是场景级 UniGS。把 unitary queries 扩展到更大空间时，需要空间分块、层级 query 或稀疏 attention，否则复杂场景中的 fixed query set 可能难以覆盖全部区域。

## 14. 个人理解

UniGS 的核心贡献是把 generalizable 3DGS 从“像素生成 primitive”转向“primitive 主动查询图像”。这个方向更像 DETR：先定义对象查询，再从图像中取证据来更新对象，而不是让每个像素独立吐出一个结果。

这篇文章对 sparse-view 3DGS 很有启发：ghosting 的根源常常不是渲染器，而是多视图表示在融合前就不一致。只要每个视图独立预测一批 Gaussian，再 concat，就很容易产生错位冗余；统一 query set 是更干净的解决方式。
