# No Pose at All: Self-Supervised Pose-Free 3D Gaussian Splatting from Sparse Views

## 0. 元数据

* Title: No Pose at All: Self-Supervised Pose-Free 3D Gaussian Splatting from Sparse Views
* Authors: Ranran Huang; Krystian Mikolajczyk
* Year: 2025
* Venue: ICCV
* PDF source: `/Users/wangyibo/Zotero/storage/746R8CN7/Huang和Mikolajczyk - No Pose at All Self-Supervised Pose-Free 3D Gaussian Splatting from Sparse Views.pdf`
* Zotero item key: `PS9M2PEA`
* Zotero PDF attachment key: `746R8CN7`
* Code: `https://ranrhuang.github.io/spfsplat/`
* Project page: `https://ranrhuang.github.io/spfsplat/`
* Dataset link: Not specified
* Main task: self-supervised pose-free sparse-view 3D Gaussian Splatting and novel view synthesis
* Domain: pose-free NVS, feed-forward 3DGS, relative pose estimation
* Input: sparse unposed multi-view RGB images; camera intrinsics assumed available
* Output: pixel-aligned 3D Gaussians in a canonical frame, estimated camera poses, rendered target views

## 1. 一句话技术摘要

SPFSplat 用共享 ViT backbone 从 unposed sparse views 中一次性预测 canonical-space 3D Gaussians 和相机相对位姿，训练时用模型估计的 target pose 渲染目标图像，并用 pixel-wise reprojection loss 显式约束 Gaussian centers 与输入像素/预测 pose 对齐，从而在无 GT pose 训练和推理下实现 pose-free sparse-view NVS。

## 2. 问题形式化

目标是学习一个 feed-forward network：输入 $N$ 张未给定相机位姿的图像 $\{I_v\}_{v=1}^{N}$，输出每个视角相对第一个视角 canonical coordinate frame 的 3D Gaussians，以及每个视角到 reference view 的相对 pose。第一张输入图像 $I_1$ 被定义为全局参考坐标系。

Gaussian reconstruction 被写为：

$$
f_{\theta}:\{I_v\}_{v=1}^{N}\mapsto \{G_{v\rightarrow1}\}_{v=1,\ldots,N}
$$

其中 $G_{v\rightarrow1}$ 是 view $v$ 的 pixel-aligned Gaussians，但坐标表达在 view $1$ 的 canonical frame 中。Pose network 估计 $P_{v\rightarrow1}=[R_{v\rightarrow1}|T_{v\rightarrow1}]$。训练时 target view $t$ 的 pose 也由网络估计，而不是使用 GT pose。

## 3. 方法概览

SPFSplat 的核心是把 3DGS reconstruction 和 pose estimation 放进同一个共享特征体系中，而不是使用独立 pose 模块和独立 reconstruction 模块。

模型包含四部分：ViT encoder、multi-view ViT decoder、Gaussian prediction heads 和 pose head。输入 context views 经过共享 encoder 和 cross-attention decoder 后，一支 DPT-style head 预测每个像素的 Gaussian center，另一支预测 rotation、scale、opacity 和 spherical harmonics。pose head 使用同一 decoder 的 token 表示，经 global average pooling 和轻量 3-layer MLP 输出 10D pose representation。

训练时有两条 branch。context-only branch 用 context views 预测 Gaussians 和 context poses；context-with-target branch 把 context 和 target views 一起输入，只用于估计 target pose 和另一组 context poses。关键防泄漏设计是：Gaussians 只由 context views 预测，target image 不参与 Gaussian reconstruction；target image 只通过 estimated target pose 进入 rendering loss。

## 4. 方法细节

**Canonical-space Gaussians。** 方法继承 Splatt3R/NoPoSplat 的思路，把所有 Gaussians 表达在第一个输入视角的局部相机坐标中。这样不需要先得到全局 SfM 坐标，也能让网络在固定 canonical frame 中学习 pixel-aligned 3D points。

**共享 backbone。** 每个 view 的 RGB 图像先 patchify 成 tokens；可选地，把 camera intrinsics 通过线性层编码成额外 token 拼入图像 tokens，以缓解尺度歧义。每个 view tokens 先经 weight-sharing ViT encoder，再由 multi-view ViT decoder 用 cross-attention 聚合多视角信息。相比 pairwise DUSt3R/MASt3R 类架构，这种设计更容易扩展到多输入视角。

**Gaussian heads。** 第一 DPT-based head 预测每个像素对应的 3D center $\mu$，第二 head 预测 rotation quaternion $r$、scale $s$、opacity $\alpha$ 和 SH coefficients $c$。论文采用 high-resolution skip connections，把原始输入图像喂给 prediction heads 来保留细节。

**Pose head。** pose head 使用 encoder 和 decoder tokens 拼接后的特征，unpatchify 后 global average pooling 得到每个 view 的几何 embedding，再由 3-layer MLP 输出 10D pose。translation 用 4D homogeneous coordinates 表示，rotation 用连续 6D representation 表示，两条未归一化坐标轴经归一化和 cross product 构成 rotation matrix。第一个 view 被固定为 canonical pose $[I|0]$。

**为什么不能只加 context rendering loss。** 如果把 context views 也用 image rendering loss 监督，会导致训练不稳定：由于 Gaussian 空间定义在第一个 context view 坐标中，第一个 view 的重建不依赖 learnable pose，网络会优先优化它，并通过移动其他 view 的 Gaussian centers 和调整 poses 抑制其他 context views，最终 collapse。因此作者改用 reprojection loss 而不是 context rendering loss 来提供几何约束。

## 5. 数学目标与损失

每个 pixel-aligned Gaussian 可写为：

$$
G_{v\rightarrow1}=\{(\mu^{v\rightarrow1}_j,r^{v\rightarrow1}_j,c^{v\rightarrow1}_j,\alpha^v_j,s^v_j)\}_{j=1,\ldots,H\times W}
$$

Pose estimation 为：

$$
P_{v\rightarrow1}=f(I_v,I_1)
$$

训练时使用估计的 target pose 渲染：

$$
\hat{I}_t=R(P_{t\rightarrow1},\{G_{v\rightarrow1}\}_{v=1,\ldots,N})
$$

Rendering loss 是 $L_2$ 和 LPIPS 的组合：

$$
L_{\text{render}}=\|I_t-\hat{I}_t\|_2+\lambda_{\text{LPIPS}}\text{LPIPS}(I_t,\hat{I}_t)
$$

论文实现中 $\lambda_{\text{LPIPS}}=0.05$。

Reprojection loss 将 view $v$ 的第 $j$ 个像素 $p^v_j$ 与对应 Gaussian center $\mu^{v\rightarrow1}_j$ 在估计 pose 下的投影对齐：

$$
L_{\text{reproj}}=\sum_{v=1}^{N}\sum_{j=1}^{H\times W}\|p^v_j-\pi(K^v,P_{v\rightarrow1},\mu^{v\rightarrow1}_j)\|
$$

其中 $P_{v\rightarrow1}$ 来自 context-only branch 的 $P^c_{v\rightarrow1}$ 或 context-with-target branch 的 $P^{c+t}_{v\rightarrow1}$，两者都被施加 reprojection loss。最终损失可理解为：

$$
L=L_{\text{render}}+\lambda_{\text{reproj}}L_{\text{reproj}}
$$

论文实现中 $\lambda_{\text{reproj}}=0.001$。抽取文本中 Eq. (4) 的 LPIPS 权重符号缺失，按实现描述补为 $\lambda_{\text{LPIPS}}$。

## 6. 训练与推理流程

1. 训练采样 context views 和 target view；输入都不使用 GT camera poses。
2. context-only branch 从 context views 预测 canonical Gaussians 和 context poses。
3. context-with-target branch 输入 context + target views，只预测 target pose 和另一组 context poses；target tokens 不影响 Gaussian prediction。
4. 使用 estimated target pose $P_{t\rightarrow1}$ 渲染 $\hat{I}_t$，与 target RGB 做 rendering loss。
5. 对 context-only 与 context-with-target 两组 context poses，都将 Gaussian centers 投影回对应 context pixels，计算 reprojection loss。
6. 反向传播同时优化共享 backbone、Gaussian heads 和 pose head。
7. 推理时只使用 context-only branch：输入 unposed sparse views，一次 feed-forward 得到 Gaussians 和相机 poses，再渲染目标 views。

实现细节：PyTorch，CUDA 3DGS renderer 支持 camera pose gradients；encoder 为 ViT-Large patch size 16，decoder 为 ViT-Base；encoder、decoder 和 Gaussian center head 用 MASt3R 预训练权重初始化；pose head 初始化为接近 identity rotation；所有实验分辨率为 $256\times256$。

## 7. 实验设置与结果摘要

数据集包括 RE10K 和 ACID；训练/测试遵循 prior works，并按 image overlap ratio 分成 small、medium、large：small 为 0.05%-0.3%，medium 为 0.3%-0.55%，large 为 0.55%-0.8%。跨数据集泛化中，在 RE10K 训练后 zero-shot 测 ACID 和 DTU。NVS 指标为 PSNR、SSIM、LPIPS；pose estimation 指标为 5/10/20 度阈值下 cumulative pose error curve 的 AUC。

NVS baselines 包括 pose-required 的 pixelSplat、MVSplat，supervised pose-free 的 CoPoNeRF、Splatt3R、NoPoSplat，以及 self-supervised pose-free 的 SelfSplat、PF3plat。Pose estimation baselines 包括 SuperPoint+SuperGlue、DUSt3R、MASt3R、NoPoSplat、SelfSplat 和 PF3plat。

RE10K 表 1 显示 SPFSplat 在 small/medium/large overlap 下均优于先前 self-supervised pose-free 方法，并接近或超过 pose-required/supervised pose-free 方法。ACID 表 2 中，SPFSplat 平均 PSNR/SSIM/LPIPS 为 26.070/0.781/0.186；使用 EPA 时为 26.796/0.807/0.176。它明显优于 SelfSplat 和 PF3plat，并与/超过 NoPoSplat 的 EPA 结果。

效率方面，从两个 $256\times256$ 输入图像重建 3D Gaussians 只需 0.044 秒，约为 pixelSplat 的 $3.5\times$ 和 PF3plat 的 $27\times$ 速度提升。

Pose estimation 表 3 显示 SPFSplat 直接 pose head 和 PnP+RANSAC 两种策略都很强，RE10K 上 5/10/20 AUC 为 0.617/0.755/0.845，ACID zero-shot 为 0.364/0.520/0.662，优于 MASt3R、NoPoSplat、SelfSplat 和 PF3plat。

Ablation 表 5 说明 reprojection loss 是关键：完整模型 RE10K NVS EPA PSNR 为 25.845，pose 5/10/20 AUC 为 0.617/0.755/0.845；去掉 reprojection loss 后 PSNR 降到 21.914，pose AUC 降到 0.028/0.102/0.263。加入 GT pose loss 只小幅提升 NVS，说明无 pose supervision 下的 geometry learning 已经较强。

## 8. 声称贡献与实际技术增量

* 声称贡献 1: 首个在训练和推理都不需要 GT pose 的 self-supervised pose-free 3DGS sparse-view framework。实际增量是用 estimated target pose 替代 GT pose 做 rendering supervision。
* 声称贡献 2: 共享 backbone 同时预测 Gaussians 和 poses。实际增量是避免 pose/reconstruction 分离造成的 feature inconsistency，并提高 feed-forward 效率。
* 声称贡献 3: reprojection loss 稳定训练。实际增量是用 pixel-level 2D reprojection 显式约束 canonical Gaussian centers 与 estimated poses，而不是对 context views 做 rendering loss。
* 声称贡献 4: pose-free 下达到 SOTA NVS 和 relative pose estimation。证据来自 RE10K、ACID、DTU、ablation 和 pose AUC。

## 9. 局限与隐含假设

* 仍假设 camera intrinsics 可从 sensor metadata 获得；虽然 intrinsic embedding 可选，但 projection loss 需要 $K^v$。
* 训练使用 target RGB 图像作为监督，只是不使用 target GT pose；并非无监督图像生成。
* 依赖 MASt3R 预训练初始化，虽然作者说训练不需要 geometry priors，但 backbone initialization 仍带有强几何先验。
* 输出分辨率为 $256\times256$，高分辨率/大场景部署成本未充分展开。
* 极端遮挡、texture-less regions 和 extreme viewpoint changes 仍可能需要 generative ability 或显式 3D supervision。
* EPA 结果与 estimated-pose 渲染结果代表不同评估语义，比较时需区分 pose alignment 能力和 Gaussian reconstruction 能力。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法类别 | Self-supervised pose-free feed-forward 3DGS |
| 输入条件 | Sparse unposed RGB images; intrinsics available |
| 核心表示 | Pixel-aligned 3D Gaussians in first-view canonical frame |
| 核心模块 | Shared ViT encoder/decoder; DPT Gaussian heads; lightweight pose head; reprojection loss |
| 训练监督 | Target RGB rendering loss; context reprojection loss; no GT pose |
| 推理 | One-step feed-forward reconstruction and pose estimation |
| 主要优势 | 不需要 GT poses，速度快，pose 与 Gaussian 对齐好 |
| 主要风险 | 依赖 intrinsics/MASt3R init，低纹理/遮挡/极端视角仍困难 |

## 11. 对我研究可复用的组件

* **Context-with-target pose branch**: 训练时只让 target view 参与 pose estimation，不参与 Gaussian prediction，避免信息泄漏。
* **Canonical Gaussians + estimated pose rendering**: 可用于把 pose-free 方法从 supervised pose-free 推到 self-supervised pose-free。
* **Reprojection loss 替代 context rendering loss**: 对防 collapse 很关键，适合其他 canonical-space sparse-view GS。
* **共享 backbone 多任务学习**: pose estimation 和 Gaussian prediction 共用几何特征，比外接 SfM/feature matching 更高效。
* **Direct pose vs PnP 双路径评估**: 可用于检查 predicted Gaussians 与 predicted poses 是否真的几何一致。

## 12. 缺口与想法种子

* **Uncertainty-weighted reprojection**: 对低纹理、遮挡、重复纹理区域降低 reprojection loss 权重，避免错误 pixel-Gaussian 对齐。
* **Diffusion-assisted target supervision**: 在低 overlap 时结合 GS-GS 的伪视角生成，但用 SPFSplat 的 pose-free reprojection 保持几何一致。
* **Bundle-adjusted feed-forward refinement**: 推理后对 predicted poses 和 Gaussians 做少量 differentiable BA-style refinement，提高极端视角质量。
* **Intrinsics-free variant**: 同时估计 intrinsics 或使用 normalized camera model，减少对 sensor metadata 的依赖。
* **High-resolution cascade**: 先在 $256\times256$ 预测 pose 和 coarse Gaussians，再用局部高分辨率 Gaussian heads refine appearance。

## 13. 人工检查清单

* `NEED_HUMAN_CHECK`: appendix 中 10D pose representation 到 homogeneous transform 的完整转换细节。
* `NEED_HUMAN_CHECK`: RE10K 表 1 的完整数值在 PDF 抽取中部分错位，应以原 PDF 表格为准。
* `NEED_HUMAN_CHECK`: pose loss ablation 的 GT pose loss 具体形式。
* `NEED_HUMAN_CHECK`: EPA 的优化步数、学习率和是否会掩盖 pose prediction errors。

## 14. 证据锚点

* Abstract: SPFSplat 不需要训练或推理 GT poses，同时预测 3D Gaussians 和 camera poses。
* Fig. 1: 区分 pose-required、supervised pose-free 和 self-supervised pose-free training pipelines。
* Fig. 2: context-only 与 context-with-target branches、shared ViT、Gaussian heads、pose head、rendering/reprojection losses。
* Sec. 3.1 / Eq. (1)-(3): canonical Gaussian prediction、relative pose estimation 和 estimated-pose rendering。
* Sec. 3.2: ViT encoder/decoder、intrinsic token、DPT heads 和 10D pose head。
* Sec. 3.3 / Eq. (4)-(5): rendering loss 与 reprojection loss；解释 context rendering loss 导致 collapse。
* Sec. 4.1-4.2: RE10K、ACID、DL3DV、DTU、baselines、metrics、implementation details。
* Table 1: RE10K NVS 对比和 runtime。
* Table 2: ACID NVS 对比。
* Table 3: RE10K/ACID relative pose estimation AUC。
* Table 4: RE10K 到 ACID/DTU 的 zero-shot generalization。
* Fig. 5: Gaussian/depth geometry comparison。
* Table 5: intrinsic embedding、reprojection loss、GT pose loss ablation。
* Table 6: RE10K + DL3DV 训练数据规模提升 pose AUC。
* Table 7: context views 从 2 增至 10 时 NVS 提升。
