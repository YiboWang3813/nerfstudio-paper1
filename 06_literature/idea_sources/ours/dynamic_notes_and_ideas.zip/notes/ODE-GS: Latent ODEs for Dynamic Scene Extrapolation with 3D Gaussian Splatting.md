# ODE-GS: Latent ODEs for Dynamic Scene Extrapolation with 3D Gaussian Splatting

## 0. Metadata

- Title: ODE-GS: Latent ODEs for Dynamic Scene Extrapolation with 3D Gaussian Splatting
- Authors: Daniel Wang; Patrick Rim; Tian Tian; Alex Wong; Ganesh Sundaramoorthi
- Venue/Year: ICLR 2026
- Zotero item key: `R4T8W8J4`
- Zotero PDF attachment key: `EVJBG4RR`
- PDF path: `/Users/wangyibo/Zotero/storage/EVJBG4RR/Wang 等 - 2026 - ODE-GS LATENT ODES FOR DYNAMIC SCENE EXTRAPOLATION WITH 3D GAUSSIAN SPLATTING.pdf`
- Local note path: `notes/ODE-GS: Latent ODEs for Dynamic Scene Extrapolation with 3D Gaussian Splatting.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

ODE-GS 将动态 3DGS 从时间条件插值问题改写为 Gaussian parameter trajectory 的 sequence-to-sequence forecasting：先训练并冻结 canonical deformation 3DGS 作为轨迹生成器，再用 Transformer encoder + latent neural ODE 预测未来 Gaussian trajectories，实现动态场景的连续时间 extrapolation。

## 2. Problem Formulation

多数动态 3DGS 方法学习 $G+D_\omega(t,G)$，即 canonical Gaussians 加 timestamp-conditioned deformation network。这类模型擅长在训练时间窗口内 interpolation，但当 $t>t_{\max}$ 时，timestamp 已经超出训练分布，容易发生 out-of-distribution failure。

ODE-GS 关注 dynamic scene extrapolation：给定 observed window 内的多视角/单目动态场景观测，预测未来时间的 3D Gaussian states，并从任意新视角渲染。该任务比 reconstruction 更欠约束，因为同一段过去轨迹可能对应无穷多种未来。论文用连续时间 ODE smoothness 作为物理先验，偏向平滑、稳定、可积分的 latent dynamics。

形式上，数据为 calibrated images、camera poses 和 timestamps：$D=\{(I_i,V_i,t_i)\}_{i=1}^N$。目标是学习 continuous-time rendering operator $F(t,V)$，对 observed window 内使用 interpolation model，对未来时间使用 extrapolation model。

## 3. Method Overview

ODE-GS 是两阶段方法。第一阶段训练一个标准 dynamic 3DGS interpolation model：canonical Gaussian set $G$ 和 time-conditioned deformation MLP $D_\omega$，在 observed window 内重建训练图像。训练完成后冻结该模型。

第二阶段把 frozen interpolation model 当作 Gaussian trajectory generator。对每个 Gaussian $G_k$，在 observed window 内采样其 time-dependent position、rotation、scale 轨迹，构造 context prefix 和 target suffix。Transformer encoder 读取 context trajectory $\gamma_k$，输出 latent initial state $z(t_0)$；latent state 通过 neural ODE $\dot z=f_\theta(z(t))$ 连续演化；decoder $\delta_\psi$ 把未来 latent states 映射回 Gaussian parameters。

训练时，target suffix 仍位于 observed window 内，由 frozen interpolation model 生成 supervision。推理时，模型读取最后一段 observed context，向 $t_{\max}$ 之后积分，并解码出 future Gaussians $\hat G(t)$，再用 3DGS rasterizer 渲染。

## 4. Method Details

### 4.1 Rendering Operator and Gaussian State

ODE-GS 将 rendering operator 写作：

$$
F(t,V)=R(G(t),V).
$$

其中 $R$ 是 differentiable 3DGS rasterizer。对 observed window 内的时间，$G(t)$ 由 canonical Gaussians 和 interpolation deformation 给出；对未来时间，$G(t)$ 由 extrapolation model $E_\phi$ 给出：

$$
G(t)=G+D_\omega(t,G),\quad t_{\min}\le t\le t_{\max}.
$$

$$
G(t)=E_\phi(\gamma,t),\quad t>t_{\max}.
$$

每个 canonical Gaussian $G_k=(\mu_k,q_k,s_k,c_k,\alpha_k)$ 包括 position、quaternion、scale、SH coefficients 和 opacity。ODE-GS 只预测 time-dependent $\mu_k,q_k,s_k$，保持 opacity 和 color across time constant。协方差仍由 quaternion-derived rotation $R_k$ 和 scale matrix $S_k$ 给出：$\Sigma_k=R_kS_kS_k^\top R_k^\top$。

### 4.2 Interpolation Model for Trajectory Generation

第一阶段采用 Deformable GS / 4DGS 常见的 canonical-plus-deformation 策略。Deformation MLP $D_\omega$ 输入 timestamp 和 canonical Gaussian，输出 position、rotation、scale offsets。渲染图像为 $\hat I_i=R(G+D_\omega(t_i,G),V_i)$。

训练 loss 是 photometric reconstruction objective：

$$
L_{\mathrm{render}}=(1-\lambda)\|\hat I_i-I_i\|_1+\lambda(1-\mathrm{SSIM}(\hat I_i,I_i)).
$$

训练后冻结 $G$ 和 $D_\omega$。这样可以在 observed time window 内任意采样每个 Gaussian 的 pseudo-ground-truth trajectory，避免 extrapolation model 直接从图像端学习，并将 reconstruction 与 forecasting 解耦。

### 4.3 Transformer Latent ODE Extrapolator

对 Gaussian $k$，context trajectory 记为：

$$
\gamma_k=\{G_k(t_j)\}_{j=1}^{N_c}.
$$

每个时间步的 Gaussian state 向量包含 $\mu,q,s$，维度为 10。序列加 sinusoidal positional encoding 后输入 Transformer encoder：

$$
F_\phi:\mathbb{R}^{N_c\times 10}\rightarrow\mathbb{R}^{d}.
$$

Transformer 输出 latent initial state $z(t_0)$。Latent ODE 用 MLP 参数化 velocity field：

$$
\dot z(t)=\frac{dz}{dt}=f_\theta(z(t)).
$$

数值积分得到任意未来时间的 latent state $z(t)$，再由 decoder 映射回 Gaussian parameters：

$$
\hat G_k(t)=\delta_\psi(z(t)).
$$

这个设计不直接把未来 timestamp 喂给 deformation MLP，而是把 forecasting 变成 latent trajectory evolution。理论上它能处理任意未来 query time，也能适配 irregular timestamps。

### 4.4 Dynamic Trajectory Sampling

为了让 extrapolator 见到不同 forecasting horizons，ODE-GS 不使用固定时间跨度的 prefix-suffix 切分。给定 starting time $t_0$、context length $N_c$ 和 context span $T_c$，context 以固定间隔采样：

$$
\Delta_c=\frac{T_c}{N_c-1},\quad \gamma_c^{(i)}=\{G_k(t_0+i\Delta_c)\}_{i=1}^{N_c}.
$$

Target suffix 从 context 结束处开始，覆盖剩余 observed horizon，固定 target step 数 $N_e$ 但可变 target span：

$$
T_e=t_{\max}-t_c^{\mathrm{end}},\quad \Delta_e=\frac{T_e}{N_e},\quad \gamma_e^{(i)}=\{G_k(t_c^{\mathrm{end}}+i\Delta_e)\}_{i=1}^{N_e}.
$$

训练数据是所有 Gaussian indices 和 valid starting times 上这些 pairs 的 union。这样一个模型同时学习短期和长期预测。

### 4.5 Smoothness Regularization and Adaptive Weighting

Extrapolation loss 用 L1 监督 predicted target Gaussian parameters：

$$
L_e=\frac{1}{N_e}\sum_{j=1}^{N_e}\|\hat G_k(t_j)-G_k(t_j)\|_1.
$$

Latent regularization 惩罚 ODE velocity field 的高频振荡，用有限差分近似 latent acceleration：

$$
R_{\mathrm{latent}}=\frac{1}{N_e-1}\sum_{j=1}^{N_e-1}\left\|\frac{f_\theta(z(t_{j+1}))-f_\theta(z(t_j))}{\Delta t_j}\right\|_2^2.
$$

Trajectory regularization 直接惩罚 3D Gaussian positions 的 acceleration。速度为：

$$
v_k(t_j)=\frac{\mu_k(t_{j+1})-\mu_k(t_j)}{\Delta t_j}.
$$

位置轨迹正则为：

$$
R_{\mathrm{traj}}=\frac{1}{MN_e}\sum_{k=1}^{M}\sum_{j=1}^{N_e-2}\left\|\frac{v_k(t_{j+1})-v_k(t_j)}{\Delta t_j}\right\|_2^2.
$$

最终 loss 是：

$$
L=L_e+s_t(\lambda_{\mathrm{latent}}R_{\mathrm{latent}}+\lambda_{\mathrm{traj}}R_{\mathrm{traj}}).
$$

$s_t$ 是 adaptive regularization weight。训练早期 extrapolation loss 较大时，正则较弱，避免阻碍学习；随着 EMA loss 下降，正则增强，把预测推向更平滑的轨迹。

## 5. Mathematical Objectives and Losses

ODE-GS 的 objective 分为 reconstruction stage 和 extrapolation stage。Reconstruction stage 只训练 interpolation model，用 $L_1+\mathrm{SSIM}$ image loss。Extrapolation stage 不直接用 image supervision，而是在 Gaussian parameter space 监督 $\mu,q,s$ trajectories。

Adaptive weight 使用 extrapolation loss 的 EMA：

$$
L_{\mathrm{EMA}}(t)=\alpha L_{\mathrm{EMA}}(t-1)+(1-\alpha)L_e(t).
$$

Scaling factor 为：

$$
s_t=\exp\left(-\frac{1}{\tau}\cdot\mathrm{clip}\left(\frac{L_{\mathrm{EMA}}(t)-L_{\mathrm{end}}}{L_{\mathrm{init}}-L_{\mathrm{end}}},0,1\right)\right).
$$

附录还讨论 variational latent ODE variant。Transformer encoder 输出 posterior $q_\phi(z_k(t_0)\mid\gamma_k)=\mathcal{N}(\mu_{z_k},\mathrm{diag}(\sigma^2_{z_k}))$，用 reparameterization trick 采样并最小化 NLL + KL 的 ELBO。但实验显示 deterministic version 在 NVFi 全场景显著优于 variational version，原因是 posterior sampling 和 KL 使有限数据下的 sharp deterministic motion 更难拟合。

## 6. Training and Inference Procedure

Interpolation stage 训练 40k iterations，学习率 $8\times10^{-4}$，cosine annealing 到 $1.6\times10^{-6}$，实现基于 Deformable GS。Extrapolation stage 用 PyTorch 和 torchode，latent ODE solver 为 adaptive DOPRI5，rtol 为 $10^{-3}$，atol 为 $10^{-4}$。batch size 512，训练 40 epochs，初始学习率 $10^{-3}$，cosine annealing 到 $10^{-6}$。

架构参数：Transformer encoder 的 $d_{\mathrm{model}}=128$，8 attention heads，5 encoder layers；latent ODE dimension 64，ODE MLP 4 layers、hidden 64、Tanh activation；decoder 5 layers、hidden 128。训练时 context length $N_c=30$，target length $N_e=10$。

数据 split：D-NeRF 用前 80% 时间训练、后 20% extrapolation evaluation；HyperNeRF 用前 90%；NVFi 按原 split 前 75% 训练、后 25% 测试。Context span $T_c$ 在 D-NeRF 为 0.6，在 NVFi 和 HyperNeRF 为 0.5。

推理时，从 observed window 最后一段取 $N_c$ 个 Gaussian states，Transformer 编码成 latent initial state，ODE 向未来积分，decoder 输出未来 $\hat G(t)$，然后 rasterize。

## 7. Experimental Setup and Results Summary

论文在 D-NeRF、NVFi 和 HyperNeRF 上做 extrapolation evaluation。D-NeRF 包括 Lego、Mutant、Standup、Trex、Jumpingjacks、Bouncingballs、Hellwarrior、Hook。NVFi 包括 fan、whale、shark、bat、telescope、chessboard、darkroom、dining、factory、fallingball。HyperNeRF 使用 split-cookie、slice-banan、cut-lemon、keyboard、3dprinter、chickchicken。

摘要和贡献部分报告，ODE-GS 相对最强现有 extrapolation baseline 平均提升约 21.4% PSNR、7.4% SSIM、30.5% LPIPS；摘要另称整体 metrics 改善 19.8%。具体主表在抽取文本中被截断，但附录给出 NVFi 和 D-NeRF 的详细 ablation / multi-scene 表。

NVFi 附录表中，Ours deterministic 平均 PSNR 33.43、SSIM 0.9471、LPIPS 0.0603，优于 TiNeuVox 26.54 / 0.8826 / 0.1005、Deformable-GS 24.14 / 0.8787 / 0.1127、4D-GS 22.25 / 0.8926 / 0.1638、GaussianPredict 23.09 / 0.8584 / 0.1660、NVFi 28.45 / 0.9336 / 0.1024。

消融表 7 显示，去掉 ODE 后 NVFi 平均为 23.71 / 0.879 / 0.113；去掉 dynamic trajectory sampling 后为 31.35 / 0.935 / 0.069；完整 ODE-GS 为 33.43 / 0.947 / 0.060。说明 continuous latent ODE 和动态轨迹采样都重要。

表 8 显示，去掉 regularizers 平均为 32.90 / 0.943 / 0.066，去掉 adaptive regularizer scaling 为 32.19 / 0.938 / 0.068，完整模型为 33.43 / 0.947 / 0.060。正则不是简单越强越好，adaptive scaling 能改善稳定性。

D-NeRF joint training 表显示 per-scene Ours 平均 PSNR 27.31、SSIM 0.9497、LPIPS 0.0467；joint training 降到 21.79 / 0.9122 / 0.0984，支持冻结 interpolation model、单独训练 extrapolator 的设计。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是把 3DGS 与 Transformer Latent ODE 结合，用连续 latent dynamics 实现未来 extrapolation，并通过 smoothness regularizers 提高稳定性。实际技术增量在于把 dynamic scene forecasting 从 timestamp-conditioned deformation 改成 Gaussian trajectory forecasting。

与 Deformable GS / 4DGS 相比，ODE-GS 不直接查询未来 timestamp 的 deformation MLP，而是根据过去 Gaussian trajectories 预测未来。与 GaussianPrediction 相比，ODE-GS 使用 continuous-time latent ODE，可在任意未来 timestamp query，而不是离散 step extrapolation。与 NVFi 这类 NeRF extrapolation 方法相比，ODE-GS 继承了 explicit 3DGS 的高效渲染和 per-Gaussian trajectory representation。

一个重要工程选择是两阶段解耦：interpolation model 只负责在 observed window 内生成准确 trajectories，forecasting model 只学习这些 trajectories 的未来演化。这避免端到端训练中 reconstruction 和 extrapolation objectives 相互干扰。

## 9. Limitations / Assumptions

ODE-GS 的 supervision 来自 frozen interpolation model，而不是未来真实 Gaussian states。如果 interpolation model 在 observed window 内漏掉对象或学错运动，extrapolator 会学习错误 trajectories。附录的 fallingball case 就指出 interpolation model 未捕捉 falling ball object，导致后续预测受限。

Latent ODE 主要注入 smoothness prior，适合连续运动；对碰撞、突变、拓扑变化、外力驱动或多模态未来，deterministic ODE 可能过于单一。论文尝试 variational variant 但结果明显变差，说明不确定性建模仍未解决。

模型按 Gaussian trajectory 单位训练，依赖 interpolation model 产生稳定的 Gaussian identity。若 Gaussian densification/pruning 导致跨时间 identity 不稳定，trajectory forecasting 会更困难。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Task | Dynamic scene extrapolation beyond observed time window |
| Stage 1 | Train and freeze canonical dynamic 3DGS interpolation model |
| Stage 2 | Train Transformer encoder + latent ODE on generated Gaussian trajectories |
| Predicted attributes | Gaussian position $\mu$, quaternion $q$, scale $s$ |
| Fixed attributes | Opacity $\alpha$ and SH color $c$ across time |
| Core prior | Smooth continuous latent dynamics via neural ODE |
| Sampling | Dynamic prefix-suffix trajectory sampling with varied horizons |
| Loss | L1 trajectory loss + latent smoothness + 3D trajectory smoothness |
| Main strength | Arbitrary future timestamp extrapolation, not just interpolation |
| Main weakness | Depends on frozen interpolation quality and deterministic smooth-motion assumption |

## 11. Reusable Components

- Frozen dynamic 3DGS as a trajectory generator for downstream sequence learning.
- Per-Gaussian trajectory forecasting in $\mu,q,s$ space.
- Transformer encoder to aggregate context trajectory into latent initial state.
- Latent neural ODE for continuous-time extrapolation.
- Dynamic trajectory sampling that varies target horizon while keeping fixed sequence length.
- EMA-based adaptive regularization scaling.
- Separate latent-space and 3D-position smoothness regularizers.
- Deterministic latent ODE baseline compared against variational ODE for Gaussian trajectories.

## 12. Gap / Idea Seeds

- Add interaction-aware coupling between neighboring Gaussian trajectories instead of predicting each Gaussian independently.
- Combine latent ODE with physics priors for contact, gravity or articulated constraints.
- Use probabilistic forecasting without the underfitting observed in the variational variant, perhaps via mixture ODEs or diffusion over latent initial states.
- Detect low-quality interpolation trajectories and downweight them during extrapolator training.
- Extend identity tracking across densification/pruning so trajectory generation is more robust.

## 13. Human Check List

- NEED_HUMAN_CHECK: Main experiment tables for D-NeRF/HyperNeRF are truncated in extracted text; this note uses visible claims and appendix tables for quantitative detail.
- NEED_HUMAN_CHECK: Exact definition of $G(t)=E_\phi(\gamma,t)$ in Eq. 2 points to supplementary Sec. B; note summarizes from visible main and appendix text.
- NEED_HUMAN_CHECK: The method keeps color and opacity time-constant according to the visible formulation; verify if any implementation variant updates them.
- NEED_HUMAN_CHECK: ICLR 2026 status is taken from the PDF header and Zotero metadata; confirm final citation fields if needed.

## 14. Evidence Anchors

- Abstract and Introduction: extrapolation motivation and timestamp OOD failure.
- Section 3 notation: rendering operator, interpolation/extrapolation split and Gaussian state definition.
- Section 3.1: interpolation model and render loss.
- Section 3.2: Transformer latent ODE architecture.
- Section 3.3 / Appendix B: dynamic trajectory sampling.
- Section 3.4 / Appendix A.0.1: extrapolation loss, smoothness regularizers and adaptive weighting.
- Appendix Table 6: deterministic versus variational ODE comparison.
- Appendix Tables 7-8: ODE, dynamic sampling and regularizer ablations.
- Appendix Tables 9-11: NVFi baselines, multi-scene training and D-NeRF split analysis.
