# CoherentGS: Sparse Novel View Synthesis with Coherent 3D Gaussians

## 0. 元数据

* Title: CoherentGS: Sparse Novel View Synthesis with Coherent 3D Gaussians
* Authors: Avinash Paliwal; Wei Ye; Jinhui Xiong; Dmytro Kotovenko; Rakesh Ranjan; Vikas Chandra; Nima Khademi Kalantari
* Year: 2024
* Venue: ECCV 2024 / Computer Vision - ECCV 2024
* PDF source: `/Users/wangyibo/Zotero/storage/SH8FDLM9/Paliwal 等 - 2024 - CoherentGS Sparse Novel View Synthesis with Coherent 3D Gaussians.pdf`
* Zotero item key: `UQCZEYV4`
* Zotero PDF attachment key: `SH8FDLM9`
* Code: Not specified
* Project page: Not specified
* Dataset link: Not specified
* Main task: extremely sparse input novel view synthesis with 3D Gaussian Splatting
* Domain: sparse-view 3DGS, depth initialization, coherent Gaussian optimization
* Input: 2-4 posed sparse images, monocular depth, dense optical flow correspondences
* Output: coherent 3D Gaussian representation and rendered novel views

## 1. 一句话技术摘要

CoherentGS 为每个输入图像像素分配一个 Gaussian，并把其位置限制在对应 camera ray 上，用 implicit convolutional decoder 预测 residual depth/opacity 来保证单视图内相邻 Gaussians coherent，再用 rendered depth TV loss 和跨视图 flow correspondence loss 约束多视图一致性，从极少视图下避免普通 3DGS 的“needle/floater”过拟合。

## 2. 问题形式化

标准 3DGS 在极少视图，例如 2-4 张输入图像下，会把 unstructured anisotropic Gaussians 自由移动到能拟合训练图像的位置，导致 novel view 中出现随机针状 blobs、floaters 和不连贯几何。CoherentGS 的目标是：在保持 3DGS 实时渲染优势的同时，给 Gaussians 引入 2D image-space 可控结构，使每个像素对应的 Gaussian 只能沿该像素 ray 通过 depth residual 更新。

给定初始单目深度 $D_{\text{init}}^n$ 和输入 view $n$ 的像素 $p$，Gaussian 位置被定义为：

$$
x=g(D_{\text{init}}^n[p]+\Delta D_n[p],p)
$$

其中 $g(d,p)$ 是根据深度 $d$ 将像素 $p$ 反投影到 3D 的函数。优化不直接自由更新每个 $x$，而是更新 residual depth generator 的参数。

## 3. 方法概览

方法由两阶段组成。

第一阶段是 depth-based initialization。对每个输入图像估计 monocular depth；由于单目深度跨视角尺度不一致，作者用 optical flow correspondences 做 coarse alignment，使不同视图初始化出来的 per-pixel Gaussians 在世界坐标中大致对齐。

第二阶段是 regularized coherent optimization。每个像素一个 Gaussian，位置沿 ray 由 residual depth 控制；implicit convolutional decoder 输入 normalized view index，输出整张图的 residual depth 和 residual opacity。为处理深度 discontinuity，使用基于单目深度分段得到的 $C$-channel binary segmentation mask，让 decoder 输出 $C$ 个通道并按 mask 合成最终 residual。

在此基础上，方法加入 rendered inverse-depth TV loss 约束多视图表面平滑，并用 dense flow correspondences 让两张图中对应像素的 Gaussian 3D positions 接近。最后用 multisampling 解决每像素中心采样导致的 novel view 半透明问题。

## 4. 方法细节

**Per-pixel Gaussian representation。** CoherentGS 不从 sparse COLMAP 点云开始，而是为每个 input image 的每个 pixel 分配一个 Gaussian。这样 Gaussian 集合天然有 2D grid structure，可以在图像空间施加卷积/TV/flow regularization。

**Ray-constrained motion。** 每个 Gaussian 的位置只允许沿该 pixel 的 camera ray 移动，因此 3D position 由 depth scalar 决定。这减少了 3DGS 中 primitive 任意漂移的自由度，也让 occluded-in-all-input regions 不会被错误填满。

**Implicit convolutional decoder。** 单视图约束由 decoder $f_{\phi}$ 实现：输入 normalized view index $n$，输出 residual depth map $\Delta D_n=f_{\phi}(n)$。优化 decoder 参数而非每像素 residual depth，迫使 residual depth 具有空间平滑性和 coherent deformation。

**Depth segmentation mask。** 纯平滑 decoder 难以处理物体边界的 sharp depth discontinuities。作者根据 Depth Anything 的单目深度把每张图分成 $C=5$ 个相似深度区域，得到 binary segmentation mask $S$。Decoder 输出 $C$-channel residual depth，最终 residual 用 $S$ 按通道求和。Opacity residual 也使用类似机制。

**Multiview depth TV。** 为使所有视图的 Gaussians 形成平滑 3D surface，作者将 Eq. (1) 中 color 替换为 depth，渲染 depth image，再对 inverse depth/disparity 加 TV loss。先优化整体 $L_{\text{TV}}$ 得到全局连通几何，再逐步增加 mask-aware $L_{\text{MTV}}$ 的权重以恢复结构细节。

**Flow-based regularization。** 对输入图像对 $(i,j)$，用 FlowFormer++ 估计 dense correspondences，并通过 forward-backward consistency 得到可靠 mask。若像素 $p$ 和 $q$ 对应同一 3D 点，则对应 Gaussians 的 3D positions 应接近。

**Multisampling。** 普通 3DGS 每个 pixel 只采 center，在 sparse per-pixel Gaussian 设置中会造成 Gaussian 只覆盖 pixel center、novel view 看起来半透明。CoherentGS 在每个 pixel 内采多个 samples 并平均颜色，使 Gaussians 更好覆盖像素面积。

## 5. 数学目标与损失

标准 3DGS image formation 写为：

$$
R_{\Sigma,\alpha,x,c}(p)=\sum_{i\in N(p)}c_i\gamma_i\prod_{j=1}^{i-1}(1-\gamma_j)
$$

其中 $\gamma_k=f(\Sigma_k,\alpha_k,x_k,p)$ 是 Gaussian 在像素 $p$ 的 effective opacity。

常规 3DGS 优化为：

$$
\Sigma^*,\alpha^*,x^*,c^*=\arg\min_{\Sigma,\alpha,x,c}\sum_{p\in P}L(R_{\Sigma,\alpha,x,c}(p),R(p))
$$

CoherentGS 的 ray-constrained position 为：

$$
x=g(D_{\text{init}}^n[p]+\Delta D_n[p],p)
$$

Masked residual 合成为：

$$
\Delta D_n=\text{chsum}(S f_{\phi}(n))
$$

Rendered inverse-depth TV loss 为：

$$
L_{\text{TV}}=\|\nabla(\frac{1}{1+R_{\Sigma,\alpha,x,d}})\|_1
$$

Mask-aware TV loss 为：

$$
L_{\text{MTV}}=\|\nabla(S(\frac{1}{1+R_{\Sigma,\alpha,x,d}}))\|_1
$$

多视图平滑 loss 为：

$$
L_{\text{multi}}=(1-\lambda_s)L_{\text{TV}}+\lambda_sL_{\text{MTV}}
$$

其中 $\lambda_s$ 从 0 逐渐增至 1。

Flow regularization 为：

$$
L_{\text{flow}}=\sum_{(i,j)}\sum_p\|M_{i\rightarrow j}(g(D_i[p],p)-g(D_j[q],q))\|_1
$$

其中 $D_i[p]=D_{\text{init}}^i[p]+\Delta D_i[p]$，$p$ 和 $q$ 是 flow 对应像素，$M_{i\rightarrow j}$ 是可靠 correspondence mask。

最终目标为：

$$
\Sigma^*,\phi^*,c^*=\arg\min_{\Sigma,\phi,c}\sum_{p\in P}L(R_{\Sigma,\alpha,x,c}(p),R(p))+\beta_mL_{\text{multi}}+\beta_fL_{\text{flow}}
$$

论文设置 $\beta_m=5$、$\beta_f=0.1$。位置 $x$ 和 opacity $\alpha$ 通过 decoder 参数 $\phi$ 间接优化。

## 6. 训练与推理流程

1. 对每张 sparse input image 用 Depth Anything 估计 monocular depth。
2. 对所有图像对用 FlowFormer++ 估计 dense flow correspondences，并通过 forward-backward consistency 过滤可靠匹配。
3. 根据 monocular depth 对每张图分成 $C=5$ 个 depth regions，生成 binary segmentation masks。
4. 使用 flow correspondences 对不同视角的 monocular-depth point clouds 做 coarse alignment，初始化 per-pixel Gaussians。
5. 初始化阶段优化 1,000 iterations。
6. Regularized optimization 13,000 iterations；前 8,000 iterations 保持 rotation matrix 为 identity，并按公式指定 scale；后 5,000 iterations 自由优化 rotation 和 scale。
7. 优化时用 implicit decoder 预测 residual depth/opacity，并加入 photometric loss、$L_{\text{multi}}$ 和 $L_{\text{flow}}$。
8. 使用 multisampling 计算每个 pixel color，改善 novel view 覆盖。
9. 推理时按普通 3DGS rasterization 渲染，速度远高于 NeRF-based sparse methods。

## 7. 实验设置与结果摘要

实验数据集为 LLFF 和 NVS-RGBD。LLFF 使用 2、3、4 views；NVS-RGBD 使用 ZED 2 和 iPhone 两类数据，各用 2、3 views。Baselines 包括 FreeNeRF、FlipNeRF、SparseNeRF、RegNeRF 和 vanilla 3DGS。指标为 PSNR、SSIM、LPIPS。

LLFF 表 1 中，CoherentGS 在 2 views 下 PSNR/SSIM/LPIPS 为 18.32/0.644/0.220，显著优于 3DGS 的 12.83/0.311/0.470 和 SparseNeRF 的 17.74/0.513/0.386。3 views 下 CoherentGS 与 SparseNeRF PSNR 同为 20.33，但 SSIM 和 LPIPS 明显更好；4 views 下 PSNR 略低于 SparseNeRF，但 SSIM/LPIPS 仍最好。

NVS-RGBD 表 2 中，CoherentGS 在 ZED 2 的 2 views 下达到 23.05 PSNR、0.774 SSIM、0.164 LPIPS；在 iPhone 的 2 views 下达到 18.07/0.615/0.292，整体在 SSIM/LPIPS 上优势明显。作者报告 LLFF 3 inputs 的平均 inference speed 为 278 FPS，而 NeRF-based alternatives 约 0.08 FPS。

Ablation 表 3 显示 implicit decoder 是最关键组件：去掉后 LLFF 3-view PSNR 从 20.33 降到 16.68，SSIM 从 0.725 降到 0.477。去掉 coarse alignment、TV regularization、flow regularization 或 multisampling 都会降低质量，其中 alignment 对复杂场景跨视图对齐很重要，TV 抑制 novel view 中孤立点云，flow 帮助 unconstrained 区域纹理细节，multisampling 改善半透明表面。

## 8. 声称贡献与实际技术增量

* 声称贡献 1: 极少输入视图下的 3DGS reconstruction。实际增量是将自由 3D Gaussians 改成 per-pixel ray-constrained Gaussians。
* 声称贡献 2: structured Gaussian representation 和 coherency regularization。实际实现是 implicit convolutional decoder、depth segmentation mask、TV loss 和 flow loss。
* 声称贡献 3: depth-based initialization。实际实现是 monocular depth + flow-based cross-view coarse alignment。
* 独特 tradeoff: 不自由填充所有 occluded regions，反而能识别未重建区域并可用 diffusion inpainting 做后处理；这避免了其他方法在不可见区域生成模糊重复结构。

## 9. 局限与隐含假设

* 每个 pixel 只分配一个 Gaussian，难以处理透明/反射物体中同一 ray 上多个 surfaces，例如玻璃和后方栏杆。
* 依赖 monocular depth；若单目深度严重错误，初始化和后续 ray-constrained optimization 都会受影响。
* 依赖 dense optical flow correspondences；低纹理、遮挡或大视角变化会影响 coarse alignment 和 flow loss。
* 由于 Gaussians 不能自由移动到所有 3D 位置，完全被输入视图遮挡的区域不会自动重建，需要单独 inpainting。
* 该方法面向静态场景；动态 sparse-view 未处理。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 方法类别 | Coherent per-pixel 3DGS for extremely sparse NVS |
| 核心表示 | One Gaussian per input pixel, constrained along camera ray |
| 初始化 | Monocular depth + optical-flow-based cross-view alignment |
| 核心正则 | Implicit decoder residual depth/opacity; rendered depth TV; flow position consistency; multisampling |
| 输入条件 | 2-4 posed images; monocular depth; dense optical flow |
| 输出 | Static 3D Gaussian representation |
| 主要优势 | 极少视图下几何更平滑、LPIPS/SSIM 好、推理快 |
| 主要风险 | 透明/多层结构、错误深度/flow、不可见区域需要外部 inpainting |

## 11. 对我研究可复用的组件

* **Per-pixel Gaussian with ray constraint**: 可显著减少 sparse-view 下 Gaussian 自由漂移。
* **Implicit decoder residual maps**: 用 view-conditioned decoder 控制 residual depth/opacity，比逐点优化更 coherent。
* **Depth segmentation masked residual**: 在平滑 prior 和 sharp discontinuity 之间折中。
* **Flow-based 3D consistency loss**: 用 2D correspondence 直接约束跨视图 per-pixel Gaussian 3D positions。
* **Occlusion-aware no-fill policy**: 对全输入不可见区域不强行重建，可与 diffusion inpainting 后处理结合。

## 12. 缺口与想法种子

* **Multi-layer per-pixel Gaussians**: 为透明/反射/细结构场景给每个 pixel 多个 depth hypotheses，而不是单 Gaussian。
* **Uncertainty-weighted flow loss**: 使用 flow confidence 和 depth uncertainty 调整 $L_{\text{flow}}$，减少错误 correspondences 的影响。
* **CoMapGS + CoherentGS**: 用 covisibility map 区分 mono-view、multi-view、occluded regions，对不同区域选择 ray constraint 或自由 Gaussian。
* **Dynamic CoherentGS**: 将 per-pixel ray residual decoder 扩展为 time-conditioned decoder，处理 sparse dynamic scenes。
* **Generative inpainting loop**: 对 opacity 识别出的 occluded holes 使用 diffusion inpainting，然后再投影成 Gaussians 并用 consistency check 筛选。

## 13. 人工检查清单

* `NEED_HUMAN_CHECK`: coarse alignment 的 Eq. (8) 和 scale Eq. (9) 在 Zotero 文本中被截断，应查 PDF 原文。
* `NEED_HUMAN_CHECK`: multisampling 的采样数量和分布。
* `NEED_HUMAN_CHECK`: diffusion inpainting proof-of-concept 的具体 pipeline 在 supplementary。
* `NEED_HUMAN_CHECK`: code/project page 未在抽取文本中发现。

## 14. 证据锚点

* Abstract: 提出 regularized optimization、depth-based initialization、implicit decoder、TV loss、flow-based loss。
* Fig. 1: 3DGS sparse-view needle artifacts，以及 occluded-region inpainting proof-of-concept。
* Sec. 1: sparse 3DGS overfitting 和引入 coherency 的动机。
* Sec. 3 / Eq. (1)-(2): 3DGS rendering 和 optimization background。
* Fig. 2: monocular depth、dense flow、initialization、regularized optimization pipeline。
* Sec. 4.1 / Fig. 3 / Eq. (3): per-pixel Gaussian、ray-constrained residual depth、implicit decoder。
* Sec. 4.1 / Eq. (4)-(5): rendered inverse-depth TV 和 mask-aware TV。
* Sec. 4.2 / Fig. 4 / Eq. (6)-(7): flow-based regularization 和总目标。
* Sec. 4.3 / Fig. 5: monocular depth initialization 和 flow-based coarse alignment。
* Sec. 5: training schedule，1,000 iterations alignment + 13,000 iterations regularized optimization。
* Table 1: LLFF 2/3/4-view quantitative results。
* Table 2: NVS-RGBD ZED 2/iPhone results。
* Table 3 / Fig. 9: component ablations。
* Fig. 10 / Sec. 6: transparent objects limitation。
