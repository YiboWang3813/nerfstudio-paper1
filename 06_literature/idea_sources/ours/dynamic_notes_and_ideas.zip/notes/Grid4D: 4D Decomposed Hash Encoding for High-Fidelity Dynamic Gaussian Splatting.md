# Grid4D: 4D Decomposed Hash Encoding for High-Fidelity Dynamic Gaussian Splatting

## 0. Metadata

- Title: Grid4D: 4D Decomposed Hash Encoding for High-Fidelity Dynamic Gaussian Splatting
- Authors: Jiawei Xu; Zexin Fan; Jian Yang; Jin Xie
- Venue/Year: NeurIPS 2024
- Project page: https://jiaweixu8.github.io/Grid4D-web/
- Zotero item key: `Z8Z9SNND`
- Zotero PDF attachment key: `DDET4WFY`
- PDF path: `/Users/wangyibo/Zotero/storage/DDET4WFY/Xu 等 - Grid4D 4D Decomposed Hash Encoding for High-Fidelity Dynamic Gaussian Splatting.pdf`
- Local note path: `notes/Grid4D: 4D Decomposed Hash Encoding for High-Fidelity Dynamic Gaussian Splatting.md`
- Note status: method-centric conversion completed; Zotero backlink intentionally deferred to batch workflow.

## 1. One-Sentence Technical Summary

Grid4D 用一个 spatial 3D hash $(x,y,z)$ 和三个 temporal 3D hash $(x,y,t),(x,z,t),(y,z,t)$ 替代 4D-GS 的六个 2D plane encoding，并用 spatial feature 生成 $(-1,1)$ directional attention 调制 temporal features，从而更高保真地预测 dynamic Gaussian deformation。

## 2. Problem Formulation

动态 Gaussian Splatting 通常需要根据 4D coordinate $(x,y,z,t)$ 预测 canonical Gaussians 的 deformation。纯 MLP deformation field 有 over-smooth 问题，训练慢且细节不足。显式 plane-based encoding 速度快，但常把 4D input 过度分解成六个 2D planes：$(x,y),(y,z),(x,z),(x,t),(y,t),(z,t)$。

Grid4D 认为这种 plane decomposition 隐含不合适的 low-rank assumption。当两个 Gaussians 共享多个坐标时，它们在多个 2D planes 上得到相同 features，feature overlap ratio 高，导致 deformation feature discriminability 不足，难以给不同 scene components 预测不同运动。

直接使用 4D hyper-grid hash 可以减少 overlap，但空间复杂度为 $O(n^4)$，hash collision 率和存储都会过高。Grid4D 的目标是在避免 2D plane low-rank 过分解的同时，把复杂度控制在 $O(n^3)$。

## 3. Method Overview

Grid4D 先维护一组 canonical 3D Gaussians。对每个 Gaussian 和 timestamp $t$，将 4D input 分解成四个 3D encodings：一个 spatial encoding $(x,y,z)$ 表示跨时间共享的静态信息，三个 temporal encodings $(x,y,t)$、$(x,z,t)$、$(y,z,t)$ 表示动态时空信息。

Spatial encoding 经过 tiny spatial MLP 生成 directional attention score $a\in(-1,1)$。Temporal hash features 经过 tiny temporal MLP 得到 deformation feature，再与 $a$ 逐元素相乘。最后 multi-head decoder 输出 position rotation/translation、scale residual 和 rotation residual，用于 deform canonical Gaussian 并 rasterize。

由于 hash encoding 容易缺乏 smoothness，Grid4D 在 hash feature space 加 smooth regularization：对输入加小扰动，约束相邻 4D coordinates 的 hash features 相近，避免 chaotic deformation prediction。

## 4. Method Details

### 4.1 4D Decomposed Hash Encoding

Grid4D 将 $(x,y,z,t)$ 分解为：

$$
(x,y,z),\quad (x,y,t),\quad (x,z,t),\quad (y,z,t).
$$

相比 plane-based 六个 2D encodings，这种 tri-axial 3D decomposition 将一些坐标重合情况下的 feature overlap ratio 从约 $1/2$ 降到约 $1/4$。相比完整 4D hyper-grid，它又把复杂度从 $O(n^4)$ 降到 $O(n^3)$。

每个 3D hash encoder 使用 multi-resolution hash encoding。第 $l$ 层 resolution 按几何级数设置：

$$
N_l=\lfloor N_{\min}\cdot b^l\rfloor,\quad
b=\exp\left(\frac{\ln N_{\max}-\ln N_{\min}}{L-1}\right).
$$

对输入坐标，hash table index 使用大质数和 bit-wise XOR：

$$
h_l(x_l)=\left(\bigoplus_{i=1}^{d}x_i\pi_i\right)\bmod T_l.
$$

Temporal 3D encodings 在 $t$ 维使用不同 resolution，以适配时间采样相比空间更稀疏的特点。

### 4.2 Spatial and Temporal Features

四个 hash encoders 生成两类 features。$G_{xyz}$ 产生 spatial feature，表示 across timeline 的 common/static information。$G_{xyt}$、$G_{xzt}$、$G_{yzt}$ 产生 temporal features，负责 timestamp-dependent dynamic information。

这种分离使 spatial feature 可以作为 scene component cue，帮助模型判断不同位置/组件应如何聚合 temporal deformation。

### 4.3 Directional Attention

Directional attention 从 spatial grid hash encoder 输出生成。Spatial MLP $f_s$ 处理 $G_{xyz}(x,y,z)$ 后，经 sigmoid 映射到 $(-1,1)$：

$$
a=2\cdot\Phi(h_{xyz})-1,\quad h_{xyz}=f_s\circ G_{xyz}(x,y,z).
$$

使用 $(-1,1)$ 而不是常见的 $(0,1)$ 是因为一些相邻 scene components 可能有相反方向 deformation，例如 shadows 与 objects 的运动关系。Directional score 可以表达反向调制。

Temporal features 经 tiny temporal MLP $f_t$ 处理后，与 $a$ 点乘：

$$
h=a\odot f_t(G_{xyt}(x,y,t),G_{yzt}(y,z,t),G_{xzt}(x,z,t)).
$$

$h$ 是最终 deformation feature。

### 4.4 Multi-Head Deformation Decoder

Decoder $D$ 是 tiny multi-head MLP，输出 position deformation 的 rotation matrix / quaternion 和 translation，以及 scale、rotation residuals：

$$
D(h)=\{R_x,T_x,\Delta r,\Delta s\}.
$$

动态 Gaussian 参数更新为：

$$
\mu'=R_x\mu+T_x,\quad S'=S+\Delta s,\quad R'=R+\Delta r.
$$

更新后的 Gaussians 用标准 differentiable rasterization 渲染。论文指出 $R_x$ 用 quaternion 表示，以获得更稳定的优化和插值。

### 4.5 Smooth Regularization

显式 hash encoding 灵活但缺少 smoothness，容易产生局部 chaotic deformation。Grid4D 不对 MLP decoder 输出做正则，而是在 hash feature space 做相邻输入一致性：

$$
L_r=\|G_{xyzt}(x,y,z,t)-G_{xyzt}(x+\epsilon_x,y+\epsilon_y,z+\epsilon_z,t+\epsilon_t)\|_2^2.
$$

其中 $G_{xyzt}$ 是四个 grid hash encoders 的 concat，$\epsilon$ 是小随机扰动。附录中还尝试对 decoder outputs $R_x,T_x$ 加 smooth loss，但 PSNR 从 42.00 降到 41.92，说明 MLP 本身已有 smoothness，正则应主要作用在 explicit hash features。

## 5. Mathematical Objectives and Losses

Grid4D 的总体训练目标是 rendering reconstruction loss 加 smooth regularization。Rendering 使用 3DGS alpha compositing：

$$
C(p)=\sum_{i=1}^{N}c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j).
$$

其中：

$$
\alpha_i=\sigma_i\exp\left(-\frac{1}{2}(p-\mu_i^p)^\top\Sigma_i'^{-1}(p-\mu_i^p)\right).
$$

Smooth regularization $L_r$ 约束相邻 4D inputs 的 encoded features，而不是直接约束 rendered images 或 decoder outputs。这个选择降低计算成本，也避免对已经平滑的 MLP 再加无效约束。

## 6. Training and Inference Procedure

训练时从 canonical Gaussians 出发，对每个 Gaussian 的 position 和 timestamp 查询 4D decomposed hash encoders，经过 directional attention 和 decoder 输出 deformation，然后 rasterize 与 GT image 监督。Adaptive density control 沿用 3DGS 思路。

附录训练成本表显示，D-NeRF 上单 RTX 3090：Grid4D 训练 55 min、GPU memory 4.0 GB、PSNR 42.00；4D-GS 20 min / 1 GB / 35.41；DeformGS 33 min / 4.5 GB / 40.16；SC-GS 75 min / 3.1 GB / 41.65。Grid4D 质量最高，但训练速度不是优势。

模型深度消融显示 $L=32,d=0$ 的配置 PSNR 42.00 最好；更深的 decoder 没有提升，可能因为 deep MLP 更难训练。去掉 $R_x,T_x$ 的 rigid transform design 后 PSNR 为 41.80。

## 7. Experimental Setup and Results Summary

论文在 synthetic D-NeRF、real-world HyperNeRF 等动态数据集上比较 4D-GS、DeformGS、TiNeuVox 等方法。主实验表在抽取文本中部分截断，但摘要和可见附录明确显示 Grid4D 在 visual quality 和 rendering speed 上显著优于多个 SOTA。

D-NeRF 附录消融中，Grid4D 的平均 PSNR 为 42.00。训练成本表中同一 D-NeRF 设置下，Grid4D 比 SC-GS 的 41.65、DeformGS 的 40.16、4D-GS 的 35.41 更高。

Additional model architecture ablation：$L=8,d=0$ 为 41.34，$L=16,d=0$ 为 41.69，$L=32,d=0$ 为 42.00；$L=32,d=1$ 为 41.96，$L=32,d=2$ 为 41.75，说明适当扩大 hash/decoder capacity 有收益，但深度过大反而下降。

Qualitative figures 显示 Grid4D 在 D-NeRF 和 HyperNeRF 上比 4D-GS / DeformGS 有更清晰的 details 和更少 artifacts，但 supplementary limitation 也承认在 large and complex motions 下仍会出现 artifact。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 4D decomposed hash encoding、directional attention 和 smooth training strategy。实际技术增量主要是把 4D deformation feature 的显式表示从 plane-based low-rank decomposition 改成四个 3D hash，减少 feature overlap，同时避免完整 4D grid 的复杂度。

Directional attention 的实际作用是让 spatial feature 控制 temporal deformation feature 的方向和强度，使不同 scene components 可以拟合不同 deformation consistency。Smooth regularization 则是显式表示必需的稳定器，防止 hash lookup 导致局部跳变。

相对 4D-GS，Grid4D 替换了 plane-based encoder；相对 DeformGS，Grid4D 用 explicit hash 提升复杂 deformation capacity；相对 Swift4D，Grid4D 没有先做 static/dynamic decomposition，而是对全体 Gaussians 用 4D decomposed hash。

## 9. Limitations / Assumptions

Grid4D 没有显著提升训练速度。附录明确指出训练效率不是优势，D-NeRF 上训练时间 55 min，比 4D-GS 和 DeformGS 更长。

Large and complex motions 下仍可能有 artifacts。Supplementary Figure 9 展示 Grid4D 和其他 SOTA 在复杂运动场景中都可能失败。

方法仍依赖 canonical Gaussian + deformation prediction 范式；如果 canonical correspondence 本身困难，hash encoder 的 discriminability 不能完全解决问题。

主文结果部分在抽取文本中不完整，精确 per-scene 指标需回看 PDF 表格。

## 10. Matrix-Ready Summary

| Dimension | Summary |
| --- | --- |
| Input | Dynamic scene images with camera poses and timestamps |
| Output | Deformed 3D Gaussians for arbitrary time/view rendering |
| Encoding | $(x,y,z)$, $(x,y,t)$, $(x,z,t)$, $(y,z,t)$ 3D hash encoders |
| Motivation | Reduce plane-feature overlap without full 4D grid cost |
| Aggregation | Spatial-feature-generated directional attention in $(-1,1)$ |
| Decoder | Tiny multi-head MLP predicting $R_x,T_x,\Delta r,\Delta s$ |
| Regularization | Feature-space smooth loss under random 4D perturbations |
| Strength | High fidelity deformation features and clear rendering |
| Weakness | Training speed not improved; complex motion artifacts remain |

## 11. Reusable Components

- Four-branch 3D hash decomposition for 4D spacetime inputs.
- Spatial/temporal feature separation for dynamic Gaussian deformation.
- Directional attention score scaled to $(-1,1)$.
- Feature-space perturbation smooth regularization for hash encoders.
- Quaternion-based rigid transform head for Gaussian position deformation.
- Feature visualization by splatting L2 norms of hash features.
- Decoder regularization ablation showing smoothness belongs in hash feature space.

## 12. Gap / Idea Seeds

- Combine Grid4D with Swift4D-style static/dynamic decomposition to avoid hashing static background.
- Add motion segmentation or node-guided priors for large complex motion cases.
- Make temporal hash resolution adaptive by local motion speed.
- Use learned uncertainty to identify regions where hash features are unstable under perturbation.
- Apply frequency-aware kernels or Fourier embeddings on top of Grid4D for high-frequency motion.

## 13. Human Check List

- NEED_HUMAN_CHECK: Main experiment tables are partially truncated in extracted text; note uses visible appendix numbers and qualitative claims.
- NEED_HUMAN_CHECK: Smooth regularization section after Eq. 8 is truncated; exact separate spatial/temporal weighting should be checked from PDF if implementing.
- NEED_HUMAN_CHECK: Venue/year inferred from NeurIPS 2024 header and Zotero metadata.

## 14. Evidence Anchors

- Abstract and Introduction: low-rank plane limitation and 4D decomposed hash motivation.
- Figure 2: feature overlap comparison between plane encoding and Grid4D.
- Section 3.2: tri-axial 4D decomposed hash encoding.
- Section 3.3: directional attention and multi-head deformation decoder.
- Section 3.4: smooth regularization in hash feature space.
- Appendix Tables 7-9: architecture depth, training cost and decoder regularization ablations.
- Supplementary limitation: training speed and large-motion artifacts.
