# FMGS: Foundation Model Embedded 3D Gaussian Splatting for Holistic 3D Scene Understanding

## 0. Metadata

* Title: FMGS: Foundation Model Embedded 3D Gaussian Splatting for Holistic 3D Scene Understanding
* Authors: Xingxing Zuo; Pouya Samangouei; Yunwen Zhou; Yan Di; Mingyang Li
* Year: 2025
* Venue: International Journal of Computer Vision
* PDF source: `/Users/wangyibo/Zotero/storage/ECSIUDHC/Zuo 等 - 2025 - FMGS Foundation Model Embedded 3D Gaussian Splatting for Holistic 3D Scene Understanding.pdf`
* Zotero item key: `5AX3JQ7U`
* Zotero PDF attachment key: `ECSIUDHC`
* DOI: `10.1007/s11263-024-02183-8`
* Code: planned on project page
* Project page: `https://xingxingzuo.github.io/fmgs/`
* Dataset link: LERF dataset, 3D-OVS dataset
* Main task: open-vocabulary 3D scene understanding with Gaussian Splatting
* Domain: vision-language 3D scene representation, open-vocabulary detection/segmentation
* Input: calibrated images, COLMAP poses/sparse points, CLIP/DINO features
* Output: RGB-renderable 3DGS plus multi-view consistent rendered CLIP/DINO feature maps and relevancy maps
* Main representation: 3D Gaussians for geometry/appearance + multi-resolution hash encoding for semantic feature field
* Supervision type: self-supervised feature distillation from CLIP and DINO
* Core contribution in one sentence: 在 3DGS 中嵌入 foundation model 语义特征，用 GS 表示几何/RGB，用 MHE 表示 CLIP/DINO semantic field，从而实现快速开放词表 3D 查询。
* Note status: `complete`

## 1. 一句话技术摘要

This paper addresses open-vocabulary 3D scene understanding by using Gaussian Splatting plus multi-resolution hash encoding to transform calibrated images and foundation model features into a 3D vision-language feature field, with the key technical novelty being hybrid CLIP supervision and DINO-guided pixel-alignment for multi-view consistent semantic rendering.

## 2. 问题形式化

目标是在真实 3D 场景中实现开放词表对象定位和语义分割。输入是已标定图像，先训练普通 3DGS 获得几何和 RGB 表示；然后冻结高斯几何/RGB 属性，训练一个 semantic feature field，使任意视角渲染出的 CLIP/DINO feature map 与 2D foundation model 特征一致。

给定 3D point $x$，multi-resolution hash encoding 输出 $q$，两个 MLP 分别输出 CLIP feature $\hat{f}$ 和 DINO feature $\hat{d}$。渲染时用 alpha blending 聚合 feature。查询时将文本 prompt 的 CLIP embedding 与渲染 feature map 计算相关性。

## 3. 方法概览

FMGS 混合两种表示：

* 3DGS: 负责高效几何和 RGB 渲染。
* MHE: 负责轻量、连续的语义特征场，避免给每个 Gaussian 存高维 feature 导致内存爆炸。

训练分两阶段：

1. 先用普通 3DGS 训练 30K iterations，得到场景几何和外观。
2. 冻结几何和 SH，只选择约 40% 高 opacity/足够投影半径的 Gaussians 参与 semantic rendering，训练 CLIP/DINO feature field。

## 4. 方法细节

### 4.1 Hybrid CLIP supervision

给定视角，FMGS 渲染 CLIP feature map $\hat{F}$。每个像素 feature 通过 point-based alpha blending 得到：

$$
\hat{f}_{i,j} = \sum_{k \in N} \hat{f}_k \alpha_k \prod_{l=1}^{i-1}(1-\alpha_l)
$$

目标 CLIP feature map $F$ 不是单尺度 CLIP，而是 image pyramid 多尺度 patch 输入 CLIP 后，把小尺度 embedding 上采样到最大尺度并平均，得到 hybrid CLIP feature。CLIP loss 使用 Huber loss，阈值 $\delta=1.25$。

### 4.2 DINO regularization 与 pixel-alignment

CLIP feature 有语义但边界粗，DINO feature 边界更锐。FMGS 训练一个共享 hash grid、独立 MLP 的 DINO feature field，DINO loss 为：

$$
\mathcal{L}_{DINO} = |\hat{D} - D|^2
$$

pixel-alignment loss 让 rendered CLIP feature 的局部相似度结构跟 rendered DINO feature 对齐：

$$
\mathcal{L}_{pixel} = \frac{1}{K^2-1}\sum_{i \in P}\sum_{j \in N(i), j \ne i} |\hat{d}_i^\mathsf{T}\hat{d}_j - \hat{f}_i^\mathsf{T}\hat{f}_j|
$$

这里对 rendered DINO feature stop gradient，使 DINO field 不被该损失反向改变。

总损失：

$$
\mathcal{L}_{total} = \lambda \mathcal{L}_{CLIP} + (1-\lambda)\mathcal{L}_{DINO} + \gamma \mathcal{L}_{pixel}
$$

主文实现中 $\lambda=0.2$，$\gamma=0.01$。

### 4.3 Relevancy score

查询时先渲染 CLIP feature map $\hat{F}$，再把文本 prompt 编码为 $f_{query}$。为了避免普通 cosine similarity 的尺度/背景问题，论文沿用 LERF 的 canonical phrases，例如 “object”、“stuff”、“things”、“texture”。每个像素的 relevancy score 为 query 相对 canonical embeddings 的 softmax 最小值：

$$
r_{i,j} = \min_n \frac{\exp(\hat{f}_{i,j}^\mathsf{T}f_{query})}{\exp(\hat{f}_{i,j}^\mathsf{T}f_{query})+\exp(\hat{f}_{i,j}^\mathsf{T}f_{can}^n)}
$$

## 5. 数学目标和损失

核心损失是 CLIP Huber feature distillation、DINO L2 feature distillation 和 DINO-to-CLIP dot-product similarity alignment。FMGS 不使用语义标签训练 feature field；open-vocabulary 能力来自 CLIP embedding，边界细化来自 DINO similarity structure。

## 6. 训练和推理流程

训练：

1. COLMAP 求 pose 和 sparse visual points。
2. 训练 vanilla 3DGS 30K iterations，room-scale scene 约 10 分钟。
3. 冻结 Gaussian geometry 和 SH。
4. 用 OpenCLIP ViT-B/16 构建 7-scale CLIP feature pyramid，平均得到 hybrid CLIP feature。
5. 用 DINO 提取 dense feature。
6. 训练 MHE semantic field 4.2K steps，前 2.5K steps 不启用 pixel-alignment。

推理：

1. 从任意 query view 渲染 RGB、CLIP feature 和 DINO feature。
2. 对文本 prompt 计算 relevancy map。
3. 对 segmentation，可把各类文本 relevancy 当作 logits，再 softmax 得到每像素类别；也可用 SAM 后处理 refine。

## 7. 实验设置与结果摘要

开放词表检测使用 LERF dataset，包含 5 个带 text-query bounding boxes 的 scenes。FMGS 平均准确率 93.2%，显著优于 LERF 及 ablations。渲染 480 x 270 CLIP/DINO/RGB feature map 的速度为 103.4 FPS；LERF 为 0.1214 FPS，因此 FMGS 报告约 851x 更快。

语义分割使用 3D-OVS dataset 的 6 个 scenes。FMGS 原始 segmentation 在多场景上优于 LERF；SAM refine 后结果进一步提升，并接近或超过部分监督方法。需要注意 3D-OVS 是弱监督/任务专用，FMGS 和 LERF 是无 segmentation annotation 的开放词表方法。

消融：

* W/O hybrid CLIP 从 93.2% 降到 30.8%，说明 hybrid CLIP 是关键。
* W/ LERF CLIP 为 78.8%，低于单一 hybrid feature，且推理慢。
* W/O MHE 为 84.4%，说明 per-Gaussian semantic embedding 内存和质量都不如 hash field。
* W/O dotpsim 为 90.4%，说明 pixel-alignment 有增益但不是最大贡献。

## 8. 声称贡献 vs 实际技术增量

论文声称把 foundation model embedding 融入 3DGS，实现 holistic scene understanding。实际技术增量主要有三点：用 MHE 而非 per-Gaussian 高维 feature 表示语义场；用 hybrid CLIP feature 取代 LERF 的多尺度搜索；用 DINO similarity 约束 CLIP feature 的像素边界。

它更像是 LERF 思路在 3DGS/MHE 上的高效化和边界增强版本，而不是新的开放词表语义理论。

## 9. 局限性和隐藏假设

* 依赖高质量标定图像和 COLMAP/3DGS 训练结果。
* 语义质量受 CLIP/DINO 基础模型限制。
* segmentation 不是端到端任务目标，很多提升来自 SAM post-refinement。
* 只训练 feature field，不改变底层几何；几何错误会直接影响语义渲染。
* 背景语义和 close view context limited 情况仍有挑战。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 任务 | open-vocabulary 3D detection/segmentation |
| 输入 | calibrated images + CLIP/DINO features |
| 输出 | rendered semantic feature maps, relevancy maps |
| 表示 | 3DGS + MHE semantic field |
| 关键模块 | hybrid CLIP, DINO feature field, dot-product pixel alignment |
| 关键损失 | Huber CLIP, L2 DINO, local similarity alignment |
| 主要优点 | 语义渲染快，多视角一致，开放词表 |
| 主要风险 | 依赖 COLMAP/CLIP/DINO，segmentation 需后处理 |

## 11. 可复用组件

* 用 MHE 存 semantic feature field，而不是给每个 Gaussian 存高维向量。
* hybrid CLIP feature 可替代 LERF 的 per-query scale search。
* DINO-to-CLIP local similarity alignment 可用于其他 3D semantic distillation。
* 渲染 feature map 后做 text relevancy，可直接用于 3DGS 编辑/选择。

## 12. Gap 和 idea seeds

* 对 dynamic 4DGS，可训练时间一致的 CLIP/DINO feature field，使动态物体可跨时间文本查询。
* 可把 uncertainty 引入 semantic feature rendering，对几何不可靠区域降低语义置信度。
* 可把 SAM 或 segmentation foundation model 直接蒸馏到 3D，而不仅用于 2D 后处理。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: 代码发布状态需检查 project page。
* `NEED_HUMAN_CHECK`: Table 1 检测协议和 exact query list 需从 supplementary/数据集确认。

## 14. Evidence Anchors

* Sec. 4: FMGS method overview。
* Fig. 3: CLIP/DINO feature maps and hybrid CLIP pyramid。
* Fig. 4: query pipeline。
* Eq. (5): feature alpha blending。
* Eq. (6): CLIP Huber loss。
* Eq. (7)-(9): DINO loss, pixel-alignment loss, total loss。
* Eq. (10): relevancy score。
* Sec. 4.4: implementation details。
* Table 1-3: object detection, segmentation, ablation。
