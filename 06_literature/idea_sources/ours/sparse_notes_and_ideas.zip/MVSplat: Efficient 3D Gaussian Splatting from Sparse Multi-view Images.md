# MVSplat: Efficient 3D Gaussian Splatting from Sparse Multi-view Images

## 0. Metadata

* Title: MVSplat: Efficient 3D Gaussian Splatting from Sparse Multi-view Images
* Authors: Yuedong Chen, Haofei Xu, Chuanxia Zheng, Bohan Zhuang, Marc Pollefeys, Andreas Geiger, Tat-Jen Cham, Jianfei Cai
* Year: 2025
* Venue: ECCV 2024 / LNCS 15079, 2025 proceedings
* PDF source: Zotero local PDF
* Zotero item key: A9XJ8AEP
* Zotero PDF attachment key: WUTS64TN
* PDF path: `/Users/wangyibo/Zotero/storage/WUTS64TN/Chen 等 - 2025 - MVSplat Efficient 3D Gaussian Splatting from Sparse Multi-view Images.pdf`
* Note path: `notes/MVSplat: Efficient 3D Gaussian Splatting from Sparse Multi-view Images.md`
* Code: https://github.com/donydchen/mvsplat
* Project page: https://donydchen.github.io/mvsplat
* Dataset link: Not specified
* Main task: feed-forward sparse multi-view 3D reconstruction and novel view synthesis
* Domain: generalizable 3DGS, multi-view stereo, cost volume, sparse-view NVS
* Input: $K$ posed sparse-view images and camera projection matrices
* Output: feed-forward predicted 3D Gaussian parameters and novel-view renderings

## 1. One-Sentence Technical Summary

MVSplat 用 plane-sweep cost volume 显式编码多视图特征匹配信息，通过 2D U-Net 与 cross-view attention 预测每个输入视图的深度，再把深度反投影成 Gaussian centers，并与 opacity、covariance、SH color 一起用 photometric rendering loss 端到端训练。

## 2. Problem Formulation

论文处理的问题是：给定极少量 posed images，通常是 2 views，如何在一次 feed-forward inference 中预测可直接渲染的 3D Gaussian scene representation。传统 per-scene NeRF / 3DGS 优化太慢；已有 feed-forward 3DGS 如 pixelSplat 从 image features 直接预测 probabilistic depth distribution，几何质量不稳定，容易出现 floating Gaussians，并且需要额外 depth fine-tuning 才能改善结构。

MVSplat 的核心判断是：Gaussian center 的定位是 feed-forward 3DGS 的关键瓶颈，而 center 本质上应由多视图匹配确定。因此它把 sparse-view Gaussian prediction 重新表述为 feature matching / cost volume depth estimation，而不是纯数据驱动的 feature-to-depth regression。

## 3. Method Overview

MVSplat 的输入是 $K$ 个图像和对应投影矩阵。网络先用浅层 ResNet-like CNN 提取 4 倍下采样特征，再用 multi-view Transformer 的 self-attention 和 cross-attention 交换视图信息。随后对每个 reference view 构建 plane-sweep cost volume：在 inverse depth domain 采样 $D=128$ 个深度候选，把其他视图特征按候选深度 warp 到 reference view，并计算特征相关性。

初始 cost volume 与 Transformer feature 拼接后进入轻量 2D U-Net 做 refinement，U-Net 低分辨率层插入 cross-view attention。refined cost volume 经 softmax 和 depth candidates 加权平均得到每视图 depth map。depth map 反投影到世界坐标并取 union，得到 3D Gaussian centers。其他 Gaussian 参数从 image features、refined cost volume 和原图共同预测。最终使用 3DGS rasterizer 渲染目标视角，并只用 RGB photometric loss 训练。

## 4. Method Details

### 4.1 Feed-forward Gaussian mapping

论文把模型写成从 sparse posed images 到 Gaussian parameters 的映射：

$$
f_\theta:\{(I^i,P^i)\}_{i=1}^{K}\mapsto\{(\mu_j,\alpha_j,\Sigma_j,c_j)\}_{j=1}^{H\times W\times K}
$$

每个输入像素对应一个 Gaussian，因此 Gaussian 数量为 $H\times W\times K$。参数包括 center $\mu_j$、opacity $\alpha_j$、covariance $\Sigma_j$ 和 color $c_j$。与 pixelSplat 每像素预测多个 Gaussians 不同，MVSplat 默认每像素一个 Gaussian，因此参数量和渲染量更小。

### 4.2 Cost volume construction

对 reference view $i$，给定近远深度范围，在 inverse depth domain 采样 $D$ 个候选 $\{d_m\}_{m=1}^D$。将 source view $j$ 的特征 $F^j$ 按相机矩阵和候选深度 warp 到 view $i$：

$$
F_{d_m}^{j\rightarrow i}=W(F^j,P^i,P^j,d_m)
$$

然后与 reference feature 做 dot-product correlation：

$$
C_{d_m}^{i}=\frac{F^i\cdot F_{d_m}^{j\rightarrow i}}{\sqrt{C}}
$$

当输入超过两个视图时，对所有其他 source views 做同样 warp 和 correlation，并在 pixel 维度上平均，从而支持任意数量输入视图。最终 cost volume 为：

$$
C^i=[C_{d_1}^{i},C_{d_2}^{i},\ldots,C_{d_D}^{i}]
$$

### 4.3 Cost volume refinement and depth prediction

初始 cost volume 在无纹理或遮挡区域可能模糊，因此论文用 2D U-Net 输出 residual $\Delta C^i$：

$$
\tilde{C}^i=C^i+\Delta C^i
$$

U-Net 的最低分辨率层加入 3 个 cross-view attention layers，进一步跨视图交换信息。上采样到全分辨率后，沿 depth dimension softmax，并对 depth candidates $G=[d_1,\ldots,d_D]$ 做加权平均：

$$
V^i=\mathrm{softmax}(\hat{C}^i)G
$$

额外的 depth refinement U-Net 接收多视图图像、特征和当前深度，预测 residual depth 并加到当前 depth prediction 上。

### 4.4 Gaussian parameter prediction

Gaussian centers 由每视图深度 $V^i$ 反投影得到，并转到统一世界坐标后做 deterministic union。opacity 从 softmax matching distribution 的最大值，即 matching confidence，经两层卷积预测，因为高匹配置信度更可能对应真实表面。covariance 和 color 由两层卷积从 image features、refined cost volume 和原图预测；covariance 写作 $\Sigma=R(\theta)^T\mathrm{diag}(s)R(\theta)$，rotation 用 quaternion 表示，color 用 spherical harmonics 系数表示。

## 5. Mathematical Objectives and Losses

MVSplat 不需要 ground-truth depth 或 point cloud supervision。预测的 Gaussians 被输入 differentiable 3DGS rasterizer 渲染目标视角，训练损失是 RGB target image 上的 $\ell_2$ loss 和 LPIPS loss：

$$
L=L_2(I_{render},I_{gt})+0.05L_{LPIPS}(I_{render},I_{gt})
$$

注意这里没有显式 depth loss。几何质量来自 cost volume 中的 feature matching inductive bias，以及 photometric loss 经 renderer 回传到 depth / Gaussian centers。

## 6. Training and Inference Procedure

实现使用 PyTorch 和 CUDA 3DGS renderer。multi-view Transformer 包含 6 层 self- and cross-attention。cost volume 使用 128 个 depth candidates。所有模型在单张 A100 上训练 300000 iterations，优化器为 Adam。

推理阶段输入 sparse posed views，网络一次前向得到 Gaussian parameters，然后 rasterize novel views。论文报告整体 inference time 为 0.044 s，encoder 约 0.043 s，render 约 0.0015 s；相对 pixelSplat 的 0.104 s 总时间和 0.102 s encoder 更快。MVSplat 参数量为 12.0M，而 pixelSplat 为 125.4M。

## 7. Experimental Setup and Results Summary

主要训练和评估在 RealEstate10K 与 ACID 上进行，每个测试场景输入 2 views，渲染 3 个 novel views。指标为 PSNR、SSIM、LPIPS。对比包括 pixelNeRF、GPNR、AttnRend、MuRF 和 pixelSplat。

Table 1 中，MVSplat 在 RealEstate10K 上达到 26.39 PSNR / 0.869 SSIM / 0.128 LPIPS，优于 pixelSplat 的 25.89 / 0.858 / 0.142；在 ACID 上达到 28.25 / 0.843 / 0.144，略优于 pixelSplat 的 28.14 / 0.839 / 0.150，同时速度更快、参数更少。几何可视化显示 pixelSplat 虽能渲染可接受 2D 图像，但底层 3D 结构有大量 floating Gaussians；MVSplat 的深度和 Gaussian geometry 更干净，且不需要 pixelSplat 额外的 50000 steps depth fine-tuning。

跨数据集泛化实验中，模型只在 RealEstate10K 训练，直接测试 ACID 和 DTU。MVSplat 在 ACID 上为 28.15 / 0.841 / 0.147，pixelSplat 为 27.64 / 0.830 / 0.160；在 DTU 上为 13.94 / 0.473 / 0.385，pixelSplat 为 12.89 / 0.382 / 0.560。使用 3 context views 测 DTU 时，MVSplat 提升到 14.30 / 0.508 / 0.371，而 pixelSplat 为 12.52 / 0.367 / 0.585。

消融表明 cost volume 是核心：base 模型 26.12 PSNR，去掉 cost volume 降到 22.83，LPIPS 从 0.133 变为 0.197。去掉 cross-view attention 得到 25.19 PSNR，去掉 U-Net refinement 得到 25.45 PSNR；加入 depth refinement 的最终模型达到 26.39 PSNR。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是一个高效 feed-forward 3DGS 模型，并证明 cost volume 对 Gaussian center localization 的重要性。实际技术增量是把 classic MVS plane-sweep cost volume 嵌入到 3DGS 参数预测器中，用 matching-based depth 代替 pixelSplat 的 feature-to-probabilistic-depth regression。

相对 pixelSplat，MVSplat 的差别不是 renderer，而是 encoder inductive bias：pixelSplat 依赖 epipolar Transformer 特征和 learned depth distribution，MVSplat 显式枚举深度候选并计算跨视图相关性。这个变化同时带来更强几何、较小参数量和更好的 OOD 泛化。

## 9. Limitations and Hidden Assumptions

方法需要已知相机位姿，并依赖输入视图之间存在足够 overlap 来构建可靠 cost volume。对于反射表面，如 glass 和 window，作者承认模型可能产生不可靠结果。由于当前主要在 RealEstate10K 训练，数据多样性仍不足以保证 in-the-wild 泛化，作者建议未来混合更大更丰富的 scene-level datasets。

另一个隐含约束是 depth candidate range 的设置。若近远平面不合适、相机姿态误差大或 baseline 太小，plane-sweep cost volume 的 matching peak 会变弱。模型虽支持任意数量视图，但训练主要是 2-view，更多视图下的鲁棒性仍需要更系统验证。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| 核心任务 | Feed-forward sparse multi-view 3DGS |
| 输入 | $K$ posed images and projection matrices |
| 输出 | $H\times W\times K$ Gaussians |
| 核心模块 | multi-view Transformer, plane-sweep cost volume, 2D U-Net refinement, depth unprojection |
| 监督 | RGB rendering loss: $L_2+0.05L_{LPIPS}$ |
| 几何来源 | cost volume feature matching, not depth GT |
| 主要优势 | 12.0M 参数、0.044s inference、geometry cleaner than pixelSplat |
| 主要风险 | pose / overlap / reflective surfaces / depth range sensitivity |

## 11. Reusable Components for My Research

1. Cost-volume-to-Gaussian-center 是 sparse-view 3DGS 的强 baseline，可作为 per-scene optimization 的初始化器。
2. Matching confidence to opacity 的设计可迁移到不确定性建模：softmax peak 越低，Gaussian opacity 或训练权重越低。
3. 2D U-Net refinement over cost volume 比 3D CNN 更轻，适合实时或大规模 feed-forward 3DGS。
4. Deterministic union of per-view unprojected depths 是简单有效的 multi-view Gaussian center fusion，后续可加入 duplicate merging 或 uncertainty pruning。

## 12. Gap and Idea Seeds

1. 将 MVSplat 的 cost volume 初始化与 per-scene 3DGS refinement 结合：先 feed-forward 生成干净 Gaussians，再少量 iterations 优化外观。
2. 引入 pose uncertainty：把 camera pose noise 传播到 cost volume confidence，用于 opacity / covariance 预测。
3. 在反射区域加入语义或 material-aware mask，降低错误匹配对 Gaussian center 的影响。
4. 将 cost volume matching confidence 用作 DropoutGS / pruning 的先验，训练时随机弱化低置信 Gaussians。
5. 把 fixed inverse-depth candidates 改成 adaptive candidates，由 coarse depth network 或 scene bounds 预测更密的局部采样。

## 13. Human Check List

* NEED_HUMAN_CHECK: supplementary Appendix C 中可能包含网络结构细节、depth range 设置和 training schedule 细节，主文未完全展开。
* NEED_HUMAN_CHECK: Appendix A 有更多反射表面、pixelSplat 增强、Transformer 类型和多 Gaussian primitives 消融，本文 note 只记录主文摘要。
* NEED_HUMAN_CHECK: RealEstate10K / ACID 数据划分应与 pixelSplat 代码设置核对后再用于复现实验。
* 已确认：公式格式按仓库 inline / display dollar 规范书写。

## 14. Evidence Anchors

* Abstract: 提出 sparse multi-view feed-forward 3D Gaussians、cost volume、photometric supervision、22 fps、10x fewer parameters。
* Section 1, Introduction: 对比 pixelSplat 的 probabilistic depth distribution，说明 cost volume 降低 depth learning 难度。
* Section 3, Method: 给出 mapping $f_\theta$、cost volume construction Eq. 2-4、U-Net residual Eq. 5、softmax depth Eq. 6、Gaussian parameter prediction。
* Section 3.3, Training Loss: 说明只用 $\ell_2$ 和 LPIPS RGB rendering loss，不用 depth GT。
* Section 4.1, Implementation: 6 层 Transformer、128 depth candidates、A100、300000 iterations、Adam。
* Table 1: RealEstate10K / ACID 主结果、时间和参数量。
* Table 2: RealEstate10K 训练后 zero-shot 到 ACID / DTU 的跨数据集泛化。
* Table 3 and Section 4.3: cost volume、cross-view attention、U-Net refinement、depth refinement 的消融。
* Section 5, Limitations: 反射表面和训练数据多样性不足。
