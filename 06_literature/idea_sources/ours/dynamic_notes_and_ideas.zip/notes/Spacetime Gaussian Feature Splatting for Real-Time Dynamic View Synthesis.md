# Spacetime Gaussian Feature Splatting for Real-Time Dynamic View Synthesis

## Methods 总结

### 目标与整体流程

输入为**多视角视频**，输出为可在**任意视角与时间**渲染的 6-DoF 动态场景表示。方法包含三部分：**(1) Spacetime Gaussian (STG)**：在 3D 高斯上增加时间不透明度与参数化运动/旋转，统一表示静态、动态与瞬时（出现/消失）内容；(2) **Splatted Feature Rendering**：用神经特征替代球谐 (SH)，经光栅化 + 小 MLP 得到视角与时间相关外观，兼顾表达力与模型体积；(3) **Guided Sampling**：在训练误差大、初始高斯稀疏的区域（尤其远景）沿射线采样新高斯，提升收敛与渲染质量。

---

### 3. Preliminary: 3D Gaussian Splatting

3DGS 用各向异性 3D 高斯表示静态场景，经可微光栅化优化。第 \(i\) 个高斯有不透明度（在空间点 \(x\) 处）：
\[
\alpha_i = \sigma_i \exp\left( -\frac{1}{2}(x - \mu_i)^\top \Sigma_i^{-1}(x - \mu_i) \right)
\]
协方差分解为旋转与缩放：
\[
\Sigma_i = R_i S_i S_i^\top R_i^\top
\]
其中 \(S_i\) 为对角阵（3D 向量 \(s_i\)），\(R_i\) 由四元数 \(q\) 参数化。给定视角变换 \(W\) 与投影矩阵 \(K\)，投影到 2D 的中心与协方差为：
\[
\mu_i^{2D} = \left( K \frac{W\mu_i}{(W\mu_i)_z} \right)_{1:2}, \qquad
\Sigma_i^{2D} = (J W \Sigma_i W^\top J^\top)_{1:2,1:2}
\]
其中 \(J\) 为投影的 Jacobian。按深度排序后体渲染得到像素颜色（\(c_i\) 由 SH 与视角方向得到）：
\[
I = \sum_{i \in N} c_i \alpha_i^{2D} \prod_{j=1}^{i-1}(1 - \alpha_j^{2D})
\]

---

### 4.1 Spacetime Gaussians (STG)

将 3D 高斯扩展到 **4D 时空**：引入**时间不透明度**与**时间依赖的位置/协方差**，用于建模出现/消失与运动/形变。在时空点 \((x, t)\) 处，第 \(i\) 个 STG 的不透明度为：
\[
\alpha_i(t) = \sigma_i(t) \exp\left( -\frac{1}{2}(x - \mu_i(t))^\top \Sigma_i(t)^{-1}(x - \mu_i(t)) \right)
\]
其中 \(\sigma_i(t)\) 为时间不透明度，\(\mu_i(t)\)、\(\Sigma_i(t)\) 为随时间变化的位置与协方差。各分量如下。

**时间径向基函数 (Temporal RBF)**：用 1D 高斯表示时间不透明度，使 STG 在某一时间段内显著可见、其余时间衰减，从而建模出现/消失：
\[
\sigma_i(t) = \sigma_i^s \exp\left( -s_i^\tau |t - \mu_i^\tau|^2 \right)
\]
其中 \(\mu_i^\tau\) 为时间中心（该 STG 最可见的时刻），\(s_i^\tau\) 为时间尺度（有效持续时间），\(\sigma_i^s\) 为与时间无关的空间不透明度。

**多项式运动轨迹**：位置随时间用多项式表示（以 \(\mu_i^\tau\) 为参考）：
\[
\mu_i(t) = \sum_{k=0}^{n_p} b_{i,k}(t - \mu_i^\tau)^k
\]
\(b_{i,k} \in \mathbb{R}^3\) 为多项式系数并参与优化。实现中取 \(n_p = 3\)，在表达力与参数量间折中。结合式 (7)，长而复杂的运动可由多段较短、较简单的运动组成。

**多项式旋转**：旋转矩阵 \(R_i\) 仍由四元数表示，四元数随时间也采用多项式（以 \(\mu_i^\tau\) 为中心）：
\[
q_i(t) = \sum_{k=0}^{n_q} c_{i,k}(t - \mu_i^\tau)^k
\]
\(c_{i,k} \in \mathbb{R}^4\) 为系数；得到 \(q_i(t)\) 后转为 \(R_i(t)\)，再通过式 (2) 得到 \(\Sigma_i(t)\)。实验中取 \(n_q = 1\)。**缩放矩阵 \(S_i\) 保持与时间无关**，实验中发现对缩放做时间建模未带来明显提升。

---

### 4.2 Splatted Feature Rendering

为在**小体积**下表达**视角与时间相关**的外观，每个 STG 不存 SH 系数，而存 **9 维特征** \(f_i(t)\)，由三部分拼接：
\[
f_i(t) = \left[ f_i^{\mathrm{base}},\; f_i^{\mathrm{dir}},\; (t - \mu_i^\tau) f_i^{\mathrm{time}} \right]^\top \in \mathbb{R}^9
\]
其中 \(f_i^{\mathrm{base}} \in \mathbb{R}^3\) 为基底 RGB，\(f_i^{\mathrm{dir}}, f_i^{\mathrm{time}} \in \mathbb{R}^3\) 编码与视角、时间相关的信息。渲染流程与 3DGS 类似，但式 (5) 中的 RGB \(c_i\) 改为特征 \(f_i(t)\)：先对特征做 **splatting** 到像平面，在每个像素得到混合后的特征，再按式 (10) 的对应通道拆成 \(F_{\mathrm{base}}, F_{\mathrm{dir}}, F_{\mathrm{time}}\)，最后经 2 层 MLP \(\Phi\) 与视角方向 \(r\) 得到最终颜色：
\[
I = F_{\mathrm{base}} + \Phi(F_{\mathrm{dir}}, F_{\mathrm{time}}, r)
\]
相比 3 阶 SH（48 维），每 STG 仅 9 维特征，MLP 浅而窄，在保持速度的同时减小模型并更好建模时变外观。**Lite 版本**：可省略 \(\Phi\)，仅用 \(F_{\mathrm{base}}\)，进一步提速（如 8K 约 60+ FPS）。

---

### 4.3 Optimization

优化对象包括 MLP \(\Phi\) 与各 STG 参数：\(\sigma_i^s, s_i^\tau, \mu_i^\tau, \{b_{i,k}\}, \{c_{i,k}\}, s_i, f_i^{\mathrm{base}}, f_i^{\mathrm{dir}}, f_i^{\mathrm{time}}\)。通过可微 splatting 与梯度反传优化，并与**稠密度控制**（分裂/剪枝）交替进行。渲染损失为 **L1 + D-SSIM**，与真值图像比较。

---

### 4.4 Guided Sampling of Gaussians

**动机**：初始化时高斯稀疏的区域（尤其远离相机处）难以收敛到高渲染质量。因此在**训练误差大**的位置，结合**粗糙深度**沿射线**采样新的 STG**。

**流程**：(1) 在训练损失趋于稳定后进行采样；(2) 对训练误差做**块级聚合**，优先选误差较大的区域而非单点噪声；(3) 对每个被选中的块，从其中心像素发射射线；(4) 利用当前高斯中心 splatting 得到的**粗糙深度图**确定该射线上的有效深度范围，避免在过大范围内采样；(5) 在该深度范围内**均匀采样**若干新高斯中心，并加小噪声；(6) 训练若干步后，不必要的高斯不透明度会变低并被剪枝。实验中上述采样**最多进行 3 次**。该策略与 3DGS 的稠密度控制（在已有高斯附近分裂）互补，可覆盖**原本无或极少高斯**的远距离区域。

---

### 小结

| 模块 | 作用 |
|------|------|
| 预备 (Sec. 3) | 3DGS：α、Σ 分解、2D 投影、体渲染 (1)–(5) |
| STG (4.1) | 时间不透明度 (7)、多项式运动 (8)、多项式旋转 (9)；\(\mu_i(t),\Sigma_i(t)\)，\(S_i\) 与时间无关 |
| Feature Splatting (4.2) | 9 维特征 (10)，splat 后 \(F_{\mathrm{base}}+Φ(F_{\mathrm{dir}},F_{\mathrm{time}},r)\) (11)；lite 版仅 \(F_{\mathrm{base}}\) |
| Optimization (4.3) | L1 + D-SSIM，与稠密度控制交替 |
| Guided Sampling (4.4) | 误差图块聚合 → 射线 + 粗糙深度定范围 → 均匀采样 + 噪声 → 剪枝；最多 3 次 |

整体上，**Spacetime Gaussian** 用时间 RBF + 多项式运动/旋转统一表示静态/动态/瞬时内容，**Splatted Feature** 用少量特征 + MLP 替代 SH 以兼顾质量与体积，**Guided Sampling** 在误差大且稀疏区域补点，共同实现高分辨率、实时渲染与紧凑存储的动态视角合成。
