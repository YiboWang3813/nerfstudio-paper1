# TranSplat: Generalizable 3D Gaussian Splatting from Sparse Multi-View Images with Transformers

## 0. Metadata

* Title: TranSplat: Generalizable 3D Gaussian Splatting from Sparse Multi-View Images with Transformers
* Authors: Chuanrui Zhang, Yingshuang Zou, Zhuoling Li, Minmin Yi, Haoqian Wang
* Year: 2025
* Venue: AAAI 2025
* PDF source: Zotero local PDF
* Zotero item key: NEJ4T7BI
* Zotero PDF attachment key: C3HD89MY
* PDF path: `/Users/wangyibo/Zotero/storage/C3HD89MY/Zhang 等 - TranSplat Generalizable 3D Gaussian Splatting from Sparse Multi-View Images with Transformers.pdf`
* Note path: `notes/TranSplat: Generalizable 3D Gaussian Splatting from Sparse Multi-View Images with Transformers.md`
* Code: Not specified
* Project page: https://xingyoujun.github.io/transplat/
* Dataset link: Not specified
* Main task: generalizable sparse multi-view 3D Gaussian Splatting
* Domain: G-3DGS, sparse-view reconstruction, transformer matching, monocular depth prior
* Input: $K$ sparse posed images and camera parameters
* Output: one-forward-pass 3D Gaussian representation and novel view renderings

## 1. One-Sentence Technical Summary

TranSplat 在 MVSplat 式 feed-forward 3DGS 框架上加入 Depth-aware Deformable Matching Transformer，用 coarse depth confidence 引导局部 deformable feature matching，并用 DepthAnythingV2 monocular depth prior 通过 Depth Refine U-Net 修正非重叠区域的深度，从而提升 sparse multi-view Gaussian centers 的准确性。

## 2. Problem Formulation

Generalizable 3DGS 目标是在没有 per-scene optimization 的情况下，从 sparse multi-view images 一次前向预测 3D Gaussians。PixelSplat 和 MVSplat 都依赖从多视图匹配得到的 depth map，再反投影成 Gaussian centers。但稀疏视角中经常存在遮挡、低纹理、重复纹理和 non-overlapping regions，这些区域的 pixel-level matching 不可靠，导致 depth prediction 和 Gaussian centers 错误。

本文针对两个匹配瓶颈提出改进：对可匹配区域，用 depth confidence 引导 Transformer 更关注正确 depth candidates；对不可匹配或非重叠区域，用 monocular depth prior 补充 cross-view matching 缺失的信息。

## 3. Method Overview

TranSplat 输入 $K$ 个 sparse-view images 和相机参数，输出每像素一个 3D Gaussian。流程包括：feature extraction、coarse matching、coarse-to-fine matching、Depth Refine U-Net、Gaussian prediction。

特征提取使用 CNN + Swin Transformer，并用 squeeze-excitation layer 将 camera parameters 注入 CNN features。DepthAnythingV2 提供 relative depth 和 depth features。Coarse Matching 先得到初始 depth distribution；DDMT 利用 coarse depth、depth feature 和相机参数构造 depth-aware feature，再通过 deformable sampling 和 attention 预测 depth residual；Depth Refine U-Net 将 fine depth、input image 和 monocular relative depth 结合，输出最终 refined depth。最后 refined depth 反投影为 Gaussian centers，其他参数并行预测。

## 4. Method Details

### 4.1 Feature extraction and coarse matching

TranSplat 使用 CNN + Transformer 提取多视图图像特征 $F^i$，并从 DepthAnythingV2 提取 depth features $D^i$ 和 relative depths $d_{rel}^i$。camera parameters 通过 SE layer 注入 CNN features，提供全局空间信息。

Coarse Matching 在 depth candidates 上采样 cross-view features。对 reference view $i$ 和 source view $j$，根据候选深度 $d_{cand}$ 和相机矩阵采样 source feature：

$$
F_{sample}^{ij}=\mathrm{Sample}(F^j,P^i,P^j,d_{cand})
$$

然后与 reference feature 做点积相关，得到 coarse depth distribution：

$$
d_{coarse}^{i}=\frac{F^i\otimes F_{sample}^{ij}}{\sqrt{C}}
$$

当输入超过两个视图时，对其他 views 执行同样过程，并在像素层面平均。

### 4.2 Depth-aware Deformable Matching Transformer

Coarse Matching 是 pixel-aligned matching，低纹理和重复纹理区域容易失败。TranSplat 先融合 coarse depth、DepthAnythingV2 feature 和 camera parameters，构造 depth-aware feature：

$$
F_{d.a.}^{i}=f_\theta(d_{coarse}^{i})+f_\phi(D^i,P^i)
$$

其中 $f_\theta$ 是 MLP，$f_\phi$ 是带 camera parameter injection 的 SE module。随后用 deformable sampling 采样 source view 局部空间特征：

$$
F_{d.s.}^{ij}=D.S.(F^j,P^i,P^j,d_{cand},\Delta p^i)
$$

采样 offsets 和 attention weights 分别由 depth-aware feature 预测：

$$
\Delta p^i=f_p(F_{d.a.}^{i})
$$

$$
W^i=f_w(F_{d.a.}^{i})
$$

DDMT 通过 self-attention 和 cross-attention 聚合 depth 信息，并预测 residual：

$$
\Delta d^i=\frac{F^i\otimes \sum_P(W^i\otimes F_{d.s.}^{ij})}{\sqrt{C}}
$$

fine depth 为：

$$
d_{fine}^{i}=d_{coarse}^{i}+\Delta d^i
$$

### 4.3 Depth Refine U-Net

在 non-overlapping regions 中，cross-view matching 无法提供可靠监督。TranSplat 使用 Depth Refine U-Net 融合 fine depth、RGB image 和 monocular relative depth：

$$
d_{refine}^{i}=d_{fine}^{i}+f_r(d_{fine}^{i},I^i,d_{rel}^{i})
$$

这个模块将 matching depth 的几何一致性与 monocular depth 的相对结构 prior 结合，尤其用于改善不可匹配区域的 Gaussian center。

### 4.4 Gaussian prediction

TranSplat 按 PixelSplat / MVSplat 的 pixel-aligned 方式预测 $M=H\times W\times K$ 个 Gaussians。最终 refined depth $d_{refine}^i$ 被反投影成 global 3D points，直接作为 Gaussian centers $\mu$。opacity 被解释为 depth confidence，因此用 refined depth prediction 通过简单 MLP 预测。covariance 由 scaling matrix $s$ 和 rotation matrix $R(\theta)$ 表示，color 用 spherical harmonics coefficients 表示。

## 5. Mathematical Objectives and Losses

论文主文强调 TranSplat 端到端训练只用 ground-truth images 监督。虽然主文未展开完整 loss 公式，但从 G-3DGS 设置和实验描述可知，预测 Gaussians 经 3DGS rasterizer 渲染 novel views，再与 target RGB images 计算 photometric / perceptual reconstruction losses。未报告使用 ground-truth depth。

关键可复现数学模块是 depth pipeline：coarse correlation、depth-aware feature、deformable sampling residual、Depth Refine U-Net residual，以及 refined depth 到 Gaussian centers 的反投影。

## 6. Training and Inference Procedure

训练和评估使用 RealEstate10K 与 ACID，均提供 SfM camera poses。RealEstate10K 有 67477 training scenes 和 7289 testing scenes；ACID 有 11075 training scenes 和 1972 testing scenes。与 MVSplat 一致，训练使用 2 context views，每个测试场景评估 3 个 novel target viewpoints。跨数据集泛化在 DTU 的 16 个 validation scenes 上测试，每个场景 4 个 novel views。

输入图像 resize 到 $256\times256$，depth candidates 数量为 128。DDMT 主结果中 deformable points $P=4$。DepthAnythingV2 使用 base size。模型在 7 张 RTX 3090 上以 batch size 14 训练 300000 iterations，优化器为 Adam。推理时在单张 RTX 3090 上测速度和显存。

## 7. Experimental Setup and Results Summary

Table 1 中，TranSplat 在 RealEstate10K 上达到 26.69 PSNR / 0.875 SSIM / 0.125 LPIPS，优于 MVSplat 的 26.39 / 0.869 / 0.128 和 pixelSplat 的 25.89 / 0.858 / 0.142。在 ACID 上，TranSplat 达到 28.35 / 0.845 / 0.143，也略优于 MVSplat 的 28.25 / 0.843 / 0.144。显存为 2228 MB，低于 MVSplat 的 2906 MB；推理时间 0.0872 s，慢于 MVSplat 的 0.0667 s，但仍比 pixelSplat 的 0.1553 s 快。

跨数据集实验中，RealEstate10K 训练后 zero-shot 到 DTU，TranSplat 300k 达到 14.93 / 0.531 / 0.326，显著优于 MVSplat 的 13.94 / 0.473 / 0.385；100k 训练也有 14.72 / 0.517 / 0.344。zero-shot 到 ACID 时，TranSplat 300k 为 28.17 / 0.842 / 0.146，与 MVSplat 28.15 / 0.841 / 0.147 接近。

消融 Table 3 在 RealEstate10K 100k 设置下显示：只用 coarse matching 为 25.020 PSNR；加入 DDMT 后为 25.231；加入 Depth Refine U-Net 后为 25.516；完整模型加 Camera Parameter Encoding 达到 25.615 / 0.855 / 0.142。多输入视图消融显示，RealEstate10K 2-view 训练模型在 DTU 上直接用 3 views 可达 15.14 / 0.561 / 0.330，用 4 views 达到 15.22 / 0.570 / 0.340。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 depth confidence guided matching、monocular depth prior for non-overlap regions，以及 TranSplat 框架。实际技术增量是在 MVSplat 的 cost-volume / feed-forward 3DGS 思路上加入更强的 depth matching refinement：DDMT 用 depth-aware feature 指导局部 deformable attention，而 Depth Refine U-Net 用 DepthAnythingV2 处理无匹配区域。

相对 MVSplat，TranSplat 的主要收益不在 Gaussian renderer，而在 depth-to-center 的前端。它承认 sparse-view G-3DGS 的中心瓶颈是 accurate multi-view matching，因此把工作集中在 depth confidence、deformable sampling、camera parameter encoding 和 monocular prior 融合。

## 9. Limitations and Hidden Assumptions

TranSplat 仍需要准确相机参数，并且主干仍依赖 depth candidates 和跨视图匹配。DepthAnythingV2 先验能帮助 non-overlap 区域，但 monocular depth 的 scale 和 domain bias 仍可能影响 Gaussian centers。DDMT 增强了 matching，但带来额外计算，推理速度比 MVSplat 慢。

论文主文未详细给出完整 training loss、网络层数和所有超参数，许多实现细节在 supplements。方法主要在 $256\times256$ resolution 和 large-scale video datasets 上验证，高分辨率、强反射、动态对象或 pose noise 下的表现仍需进一步测试。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| 核心任务 | Generalizable sparse multi-view 3DGS |
| 输入 | sparse posed images, camera parameters |
| 输出 | per-pixel 3D Gaussians |
| 核心模块 | Coarse Matching, DDMT, Depth Refine U-Net, Camera Parameter Encoding |
| 外部先验 | DepthAnythingV2 depth features and relative depth |
| Gaussian center | refined depth unprojection |
| 主要优势 | better low-texture / repetitive / non-overlap reconstruction than MVSplat |
| 主要代价 | slower than MVSplat, depends on monocular depth prior and pose quality |

## 11. Reusable Components for My Research

1. DDMT 可作为 MVSplat cost volume 的替换模块，用 depth confidence 引导 deformable local matching。
2. Depth Refine U-Net 可用于任何 feed-forward 3DGS，在 non-overlap areas 中注入 monocular depth prior。
3. Camera Parameter Encoding 通过 SE layer 注入全局空间信息，可迁移到 sparse-view feature extraction。
4. opacity-from-depth-confidence 的思想可与 uncertainty / pruning 结合，降低低置信 Gaussian 的影响。
5. 多视图数量直接提升性能，说明训练 2-view 但测试多 view 的 generalizable model 可以作为可扩展方向。

## 12. Gap and Idea Seeds

1. 将 TranSplat 的 refined depth confidence 输出为 Gaussian uncertainty，并在 per-scene optimization 中用作自适应学习率或 pruning 权重。
2. 结合 MVSplat 的 lightweight cost volume 与 TranSplat 的 DDMT，只对低置信区域启用昂贵 deformable matching。
3. 用多个 monocular depth foundation models 做 ensemble，为 Depth Refine U-Net 提供 uncertainty-aware relative depth prior。
4. 在 pose-noisy setting 下加入 camera parameter uncertainty，让 DDMT 不把错误相机参数硬编码进特征。
5. 将 TranSplat 作为 initialization，后接 3DGS few-shot refinement 或 DropoutGS regularization，探索 feed-forward + per-scene hybrid。

## 13. Human Check List

* NEED_HUMAN_CHECK: 完整 training loss 和更多网络结构细节在 supplements，主文未充分展开。
* NEED_HUMAN_CHECK: Project page 有无代码 release 需要浏览网页确认，PDF 只给出 project page。
* NEED_HUMAN_CHECK: Table 3 第一行 random depth / coarse matching 的勾选列在文本抽取中略混乱，已按段落解释记录模块作用。
* 已确认：公式格式按仓库 inline / display dollar 规范书写。

## 14. Evidence Anchors

* Abstract: 提出 depth confidence map guided local matching 和 monocular depth prior for non-overlapping areas。
* Figure 1: 对比 MVSplat 在低纹理、重复纹理、非重叠区域的 artifacts 和 Gaussian construction。
* Figure 2: TranSplat pipeline：feature extraction、coarse matching、DDMT、Depth Refine U-Net、Gaussian prediction。
* Method, Coarse Matching: Sample operation Eq. 1 和 coarse depth Eq. 2。
* Method, DDMT: depth-aware feature Eq. 3、deformable sampling Eq. 4、residual Eq. 5-7。
* Method, Depth Refine U-Net: refined depth Eq. 8。
* Experiments: RealEstate10K / ACID 数据量、2 context views、3 target views、DTU cross-dataset setup。
* Table 1: RealEstate10K / ACID 主结果、速度和显存。
* Table 2: Re10K to DTU / ACID zero-shot 泛化结果。
* Table 3: Coarse Matching、DDMT、Depth Refine U-Net、Camera Parameter Encoding 消融。
* Conclusion: 总结 DDMT 解决 similar areas incorrect matching，Depth Refine U-Net 改善 non-overlap Gaussian centers。
