# Binocular-Guided 3D Gaussian Splatting with View Consistency for Sparse View Synthesis

## 0. Metadata

* Title: Binocular-Guided 3D Gaussian Splatting with View Consistency for Sparse View Synthesis
* Authors: Liang Han; Junsheng Zhou; Yu-Shen Liu; Zhizhong Han
* Year: 2024
* Venue: NeurIPS
* PDF source: `/Users/wangyibo/Zotero/storage/T3WM3DUS/Han 等 - Binocular-Guided 3D Gaussian Splatting with View Consistency for Sparse View Synthesis.pdf`
* Zotero item key: `EGBQ3D7Z`
* Zotero PDF attachment key: `T3WM3DUS`
* Code: Not specified
* Project page: `https://hanl2010.github.io/Binocular3DGS/`
* Dataset link: LLFF, DTU, Blender
* Main task: sparse-view novel view synthesis
* Domain: 3D Gaussian Splatting, self-supervised view consistency, sparse views
* Input: sparse posed images; dense initialization points from keypoint matching for LLFF/DTU
* Output: optimized 3D Gaussians for novel view synthesis
* Main representation: 3DGS with binocular stereo consistency and opacity decay
* Supervision type: photometric reconstruction plus self-supervised binocular consistency; no external depth prior during training
* Core contribution in one sentence: 通过轻微平移训练相机构造 binocular stereo pair，用渲染深度生成 disparity 并 warp 新视角图像回输入视角，从而不用外部深度先验就约束 sparse-view 3DGS 的几何。
* Note status: `complete`

## 1. 一句话技术摘要

This paper addresses sparse-view Gaussian Splatting by using self-supervised binocular stereo consistency to transform a rendered translated view into the input view via disparity from rendered depth, with the key technical novelty being prior-free view consistency plus opacity decay for cleaner surface-aligned Gaussians.

## 2. 问题形式化

sparse-view 3DGS 中，高斯缺少多视角约束，容易漂到真实表面之外或出现冗余。许多方法使用单目深度先验，但预训练 2D depth model 的输出常常 noisy/blurry，不能精确指导 radiance field。

本文希望不使用外部 depth prior 作为训练监督，而只从已有输入视图和模型自身渲染结果构造 self-supervision。核心约束来自 binocular stereo consistency：同一训练相机的轻微平移视图与原视图形成左右目，渲染深度决定 disparity，如果几何正确，右图 warp 回左图应与输入图一致。

## 3. 方法概览

方法有三部分：

1. Binocular stereo consistency: 轻微平移输入相机，渲染右目图像和左目深度，用 disparity warp 回输入图像，计算一致性 loss。
2. Opacity decay: 每步衰减 Gaussian opacity，让远离表面、梯度支撑弱的冗余高斯逐渐低 opacity 并被 prune。
3. Dense initialization: 对 LLFF/DTU 等 forward-facing sparse views，用 PDC-Net+ 生成密集 keypoint matches，三角化成 dense point cloud 初始化高斯。

## 4. 方法细节

### 4.1 Binocular stereo consistency

给定输入视图 $I_l$ 和相机中心 $C_l$，将相机向左或向右平移，得到 translational camera $O_r$，从该视角渲染右图 $I_r$。同时从原输入相机 $O_l$ 渲染 depth $D_l$。

根据双目几何，disparity 与 depth 的关系为 $d=f\cdot d_{cam}/D_l$，其中 $f$ 是 focal length，$d_{cam}$ 是相机平移距离。用 disparity 将右图 warp 到左图：

$$
I^{shifted}[i,j]=I_r[i-d_i,j-d_j]
$$

实际实现用 bilinear sampler 保持可微。consistency loss 为：

$$
\mathcal{L}_{consis}=\frac{1}{N}\sum_{i,j}|I_{ij}^l-I_{ij}^{shifted}|
$$

训练中不固定平移，而是在 $[-d_{max},d_{max}]$ 内随机左右平移。论文认为小平移、无旋转、低遮挡变化能让 warp error 主要来自 depth error，因此比使用远邻视角或任意 unseen view 做 warping 更稳定。

### 4.2 Opacity decay

rendered depth 不只由高斯位置决定，也受 scale 和 opacity 影响；因此单独 view consistency 仍可能得到错误几何。论文对 opacity 施加衰减：

$$
\hat{\alpha}=\lambda\alpha,\quad 0<\lambda<1
$$

直觉是：真实表面附近的高斯受到多视角一致性和 photometric loss 支撑，opacity gradient 足够大，能抵消 decay；远离表面的高斯 gradient 小，opacity 会逐渐下降并被 pruning。这样可减少表面附近冗余和远处噪声高斯。

### 4.3 Dense point cloud initialization

稀疏输入下 SfM 点太少，原始 3DGS 初始化不足。对 LLFF/DTU，作者用 PDC-Net+ 在输入图像对之间生成 matching points，再用相机参数三角化到 3D，形成 dense initialization point cloud。该匹配网络只用于初始化，不作为训练监督。Blender 是 360-degree 且 8 views，约束更强，使用原始 3DGS random initialization。

## 5. 数学目标和损失

总损失由 binocular consistency 和原 3DGS color reconstruction 组成：

$$
\mathcal{L}=\mathcal{L}_{consis}+\mathcal{L}_{color}
$$

其中：

$$
\mathcal{L}_{color}=(1-\beta)\mathcal{L}_1+\beta\mathcal{L}_{D\text{-}SSIM}
$$

实现中 $\beta=0.2$，opacity decay coefficient $\lambda=0.995$，maximum camera shift $d_{max}=0.4$。

## 6. 训练和推理流程

训练：

1. 对 LLFF/DTU 用 PDC-Net+ 匹配输入图像并三角化 dense point cloud；Blender 使用 random initialization。
2. 初始化 3DGS 并先用 photometric loss 训练到较高质量。
3. LLFF/DTU 训练 30,000 iterations，20,000 iterations 后加入 view consistency；Blender 训练 7,000 iterations，4,000 iterations 后加入 view consistency。
4. 每轮随机平移训练相机，渲染右图和左目 depth，计算 warp consistency。
5. 同时使用 opacity decay 逐步过滤冗余/远离表面的高斯。

推理时使用优化后的标准 3D Gaussians 渲染，不需要双目 warp。

## 7. 实验设置与结果摘要

数据集：

* LLFF: 3/6/9 views，8x downsample。
* DTU: 3/6/9 views，4x downsample。
* Blender: 8 views，2x downsample。

LLFF Table 1：3-view 下本文达到 21.44 PSNR、0.751 SSIM、0.168 LPIPS，优于 FSGS 20.31/0.652/0.288 和 DNGaussian 19.12/0.591/0.294。9-view 下达到 26.17 PSNR。

DTU Table 2：3-view 下本文 20.71 PSNR、0.862 SSIM、0.111 LPIPS，整体强于多数 NeRF/3DGS baselines；9-view 达到 26.70 PSNR。

Blender Table 3：8-view 下本文 24.71 PSNR，SSIM/LPIPS 与 SOTA 接近。

消融 Table 4/5：

* dense init、$\mathcal{L}_{consis}$、opacity decay 每个都有效；
* LLFF 3-view 从原始 3DGS 的 15.52 PSNR 提升到 full model 的 21.44；
* DTU 3-view 从 10.99 提升到 20.71；
* Blender 中 $\mathcal{L}_{consis}$ + opacity decay 从 22.23 提升到 24.71。

## 8. 声称贡献 vs 实际技术增量

论文声称是不依赖外部训练先验的 sparse-view 3DGS。实际技术增量是把双目几何中的小基线 disparity consistency 嵌入 3DGS 训练：模型自己渲染右目和左目 depth，然后用 warping loss 反向约束 depth/geometry。

需要注意 dense initialization 仍使用预训练 keypoint matching network，但它只用于初始化，不作为训练 supervision；因此“no external prior as supervision”基本成立，但不是完全无外部模型。

## 9. 局限性和隐藏假设

* 对 LLFF/DTU 依赖 PDC-Net+ dense initialization；匹配失败会影响初始几何。
* binocular consistency 假设小平移下遮挡变化可忽略；复杂遮挡或薄结构处仍可能产生错误 warp。
* view consistency 需要模型已能较好渲染训练视图后再加入，早期直接使用可能不稳定。
* opacity decay 超参数过强可能误删低纹理/弱贡献但真实存在的高斯。
* 主要面向静态场景。

## 10. 矩阵化摘要

| 维度 | 内容 |
|---|---|
| 任务 | sparse-view NVS |
| 输入 | sparse posed images |
| 输出 | optimized 3D Gaussians |
| 表示 | 3DGS + binocular consistency |
| 关键模块 | disparity-guided warping, opacity decay, dense keypoint initialization |
| 关键损失 | color L1/D-SSIM, binocular consistency |
| 主要优点 | 不用外部 depth prior 训练，几何更稳定 |
| 主要风险 | 依赖匹配初始化，小基线 warp 仍受遮挡影响 |

## 11. 可复用组件

* small-baseline synthetic stereo consistency 可用于其他 sparse-view 3DGS。
* opacity decay 是简单有效的 redundancy pruning regularizer。
* keypoint matcher dense initialization 可替代 sparse COLMAP 点云。

## 12. Gap 和 idea seeds

* 将 binocular consistency 与 FSGS pseudo-view depth correlation 结合：小基线 warp 约束局部几何，pseudo views 约束中远视角。
* 用 uncertainty/occlusion mask 过滤 warp loss 中不可见或遮挡区域。
* 动态场景中可用时间相邻帧构造 motion-aware binocular consistency。

## 13. Human Check List

* `NEED_HUMAN_CHECK`: Appendix 中不同 source view warping 的比较和更多可视化需要复核。
* `NEED_HUMAN_CHECK`: PDC-Net+ matching 和 triangulation 的具体 pair selection 策略需看代码。

## 14. Evidence Anchors

* Abstract: no external prior as supervision, binocular consistency, opacity constraint。
* Sec. 3.2: binocular stereo consistency, Eq. (3)-(4)。
* Sec. 3.3: opacity decay, Eq. (5)。
* Sec. 3.4: dense point cloud initialization。
* Sec. 3.5: total loss, Eq. (6)-(7)。
* Table 1-3: LLFF, DTU, Blender comparisons。
* Table 4-5: ablations。
* Fig. 6-7: depth/point cloud visual ablations。
