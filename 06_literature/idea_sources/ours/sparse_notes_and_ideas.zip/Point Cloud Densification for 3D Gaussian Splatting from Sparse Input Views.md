# Point Cloud Densification for 3D Gaussian Splatting from Sparse Input Views

## 0. Metadata

* Title: Point Cloud Densification for 3D Gaussian Splatting from Sparse Input Views
* Authors: Kin-Chung Chan, Jun Xiao, Hana Lebeta Goshu, Kin-Man Lam
* Year: 2024
* Venue: ACM MM 2024
* PDF source: Zotero local PDF
* Zotero item key: CQCW68TH
* Zotero PDF attachment key: YTL4SD4W
* PDF path: `/Users/wangyibo/Zotero/storage/YTL4SD4W/Chan 等 - 2024 - Point Cloud Densification for 3D Gaussian Splatting from Sparse Input Views.pdf`
* Note path: `notes/Point Cloud Densification for 3D Gaussian Splatting from Sparse Input Views.md`
* Code: Not specified
* Project page: https://doi.org/10.1145/3664647.3681454
* Dataset link: Not specified
* Main task: sparse-input novel view synthesis with 3DGS
* Domain: sparse-view 3DGS initialization, semantic side-view regularization
* Input: sparse posed images, COLMAP SfM points, DPT monocular depth
* Output: 3DGS initialized by densified point cloud and optimized with side-view semantic priors

## 1. One-Sentence Technical Summary

本文不把 monocular depth map 直接作为 depth loss，而是先用 DPT depth 反投影并与 SfM 点云对齐，随机采样得到 densified point cloud 作为 3DGS 初始化，同时用 SAOVS 采样训练视角附近的 side views，通过 DINO semantic consistency 和 adversarial loss 约束稀疏视角优化。

## 2. Problem Formulation

Sparse input views 下，COLMAP 输出点云稀疏，3DGS 的 Gaussian centers 初始化差，后续优化容易产生 floaters、细节缺失和 novel-view distortion。很多方法用 depth regularization 解决几何欠约束，但 monocular depth 往往只有相对深度且有尺度歧义，错误 depth map 会把噪声直接注入 loss。

本文把问题转为两个更局部的工程问题：第一，如何把不可靠但稠密的 monocular depth prior 转成相对稳健的初始化点云，而不是逐像素监督渲染深度；第二，如何在真实训练视角之外采样合理 side views，让 semantic prior 能正则化不可见区域，同时不因为随机视角过远而破坏优化。

## 3. Method Overview

方法包含 Point Cloud Densification 和 semantic prior supervision 两部分。PCD 对训练图像运行 DPT 得到 dense depth maps，将像素沿相机 ray lift 到 3D world space，再通过与 SfM points 对齐解决相对深度尺度问题。为避免 depth estimation 错误污染初始化，只从 dense lifted points 中随机采样一小部分，与原 SfM points 合并后初始化 3D Gaussians。

训练阶段仍使用标准 3DGS RGB supervision，但额外用 SAOVS 在相邻训练相机之间采样 side views。SAOVS 用 linear interpolation 采样相机位置，用 SLERP 采样相机方向，并逐步增大采样范围。渲染 side views 后，使用 DINO-ViT semantic consistency loss 和 GAN adversarial loss 约束 3DGS 在未观测视角上的结构和纹理。

## 4. Method Details

### 4.1 Point Cloud Densification

3DGS 默认用 COLMAP 点云作为初始 Gaussian centers。稀疏视角下 COLMAP 只能在纹理明显区域产生少量点，导致很多区域没有合理初始化。PCD 首先用 DPT 对每个训练图像预测 dense depth map，然后对每个像素构造 ray：

$$
r(t)=o+t\cdot d
$$

其中 $o$ 是相机中心，$d$ 是 ray direction，$t$ 来自 depth map。这样可把每个 depth pixel lift 成 3D point。

### 4.2 Point set alignment and sampling

DPT depth 是相对深度，不能直接当绝对尺度点云。作者先 lift 与 SfM points 对应的 pixels，并删除超出 SfM depth min/max 范围的点；随后估计 lifted points 与 SfM points 之间的 3D affine transformation，并把该变换应用到所有 lifted dense points。

由于 monocular depth 仍有错误，作者不把所有 lifted points 都用于初始化，而是随机采样一部分 dense points，与原始 SfM point cloud 合并作为 Gaussian initialization。实验中 point cloud sampling rate 过高会退化，说明 depth 错误会随采样率增加污染初始化；0.1% sampling rate 的效果最好。

### 4.3 SAOVS side-view sampling

DietNeRF / SinNeRF 证明 unseen views 的 semantic consistency 有助于全局结构，但随机 side-view sampling 在真实场景中容易采到内容差异太大的视角。SAOVS 在相邻训练相机 $i$ 与 $i+1$ 之间采样 side-view position：

$$
p(p_i,p_{i+1};t)=tp_i+(1-t)p_{i+1}
$$

方向使用 spherical linear interpolation：

$$
d(d_i,d_{i+1};r)=\frac{\sin[(1-r)\Omega]}{\sin\Omega}d_i+\frac{\sin[r\Omega]}{\sin\Omega}d_{i+1}
$$

其中 $\cos\Omega=d_0\cdot d_1$。参数 $t$ 和 $r$ 被建模为正态分布随机变量，$t\sim N(0,\sigma_t)$、$r\sim N(0,\sigma_r)$。训练早期 $\sigma_t$ 和 $\sigma_r$ 很小，随后逐步增加，使 side views 从保守邻域逐渐扩展。

## 5. Mathematical Objectives and Losses

semantic consistency loss 使用 DINO-ViT 提取训练视图 patch 和 side-view rendered patch 的语义 embedding：

$$
L_{cls}=\|f_{vit}(I_{gt})-f_{vit}(I_{r'})\|_2
$$

adversarial loss 将 3DGS rendering process 视作 generator $G$，判别器 $D$ 使用 hinge loss，并对输入做 differentiable augmentation $T$：

$$
L_D=\mathbb{E}_{x\sim p_{data}(x)}[f_D(-D(T(x)))]+\mathbb{E}_{z\sim p(z)}[f_D(D(T(G(z))))]
$$

$$
L_G=\mathbb{E}_{z\sim p(z)}[f_G(-D(T(G(z))))]
$$

$$
L_{adv}=L_D+L_G
$$

其中 $f_D(x)=\max(0,1+x)$，$f_G(x)=x$。总损失为：

$$
L_{total}=(1-\lambda_1)L_1+\lambda_1L_{D-SSIM}+\lambda_2L_{adv}+\lambda_3L_{cls}
$$

其中 $L_1$ 和 $L_{D-SSIM}$ 是标准 3DGS photometric terms。注意 PCD 不进入 loss，只影响初始化。

## 6. Training and Inference Procedure

ScanNet 使用约 18 个输入视图，LLFF 使用 4 个输入视图。总训练迭代数为 30000，硬件为单张 NVIDIA RTX 4090。$\sigma_t$ 和 $\sigma_r$ 初始值为 0.09，每 100 iterations 增大一次。损失权重 $\lambda_1=0.2$、$\lambda_2=1.59$、$\lambda_3=0.75$。

推理阶段不需要 DPT、DINO、side-view sampling 或 discriminator，只渲染训练好的 3DGS。PCD 是训练前初始化模块，SAOVS / semantic / adversarial losses 是训练时正则化模块。

## 7. Experimental Setup and Results Summary

实验在 ScanNet room-scale scenes 和 LLFF indoor scenes 上评估，指标为 PSNR、SSIM、LPIPS。ScanNet 对比 Roessle et al. 和 vanilla 3DGS；LLFF 对比 NeRF、DS-NeRF、ViP-NeRF、3DGS 及多个消融版本。

ScanNet Table 1 中，Roessle et al. 平均 12.48 PSNR / 0.47 SSIM / 0.74 LPIPS，3DGS 为 18.77 / 0.66 / 0.43，本文为 20.48 / 0.73 / 0.37。相对 3DGS，提升 1.71 dB PSNR 和 0.07 SSIM。

LLFF Table 2 中，本文 full model 平均 20.55 PSNR / 0.73 SSIM / 0.16 LPIPS，3DGS 为 19.24 / 0.68 / 0.21，因此相对 3DGS 提升 1.31 dB PSNR 和 0.05 SSIM。ViP-NeRF 在 room 场景 PSNR 更高，但本文在整体平均和纹理质量上更好。

消融显示：去掉 PCD 后平均 PSNR 为 19.88，去掉 semantic consistency 后为 19.63，去掉 adversarial loss 后为 19.88，使用 random position and direction sampling 为 19.73。SAOVS 对比 RPDS / LRDS 的 Table 3 中，SAOVS 达到 20.55 / 0.73 / 0.16，优于 LRDS 的 20.34 / 0.72 / 0.17 和 RPDS 的 19.73 / 0.71 / 0.19。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献包括 PCD、SAOVS 以及结合两者的 sparse-view 3DGS。实际技术增量可以拆成：把 monocular depth 从 “training loss regularizer” 改成 “initialization point generator”；把 side-view semantic regularization 从随机方向采样改成相邻相机间的 trajectory-like interpolation；再用 DINO semantic loss 和 GAN loss 分别约束全局语义与局部纹理。

相对 FSGS / SparseGS 的 depth regularization 路线，本文避免在优化中直接拟合可能错误的 dense depth。相对 SinNeRF，本文的 SAOVS 更适合真实 room-scale scenes，因为它控制 side views 与训练视图内容相似，同时增加覆盖区域。

## 9. Limitations and Hidden Assumptions

PCD 仍然依赖 DPT depth 的基本正确性。虽然随机采样降低了错误 depth 的影响，但采样率过高会明显退化，说明该模块并不能完全过滤深度错误。point set alignment 依赖 SfM points 能提供足够可靠的尺度锚点；如果 COLMAP 在极稀疏或弱纹理场景中几乎失败，对齐也会不稳定。

SAOVS 假设相邻训练相机之间存在合理的连续视角路径，适合 LLFF / ScanNet 这类连续采集数据；如果输入视角分布离散、无序或跨大 baseline，linear interpolation 与 SLERP 生成的 side views 可能落在不可见或无意义区域。semantic consistency loss 也依赖 DINO patch embedding 能表达场景结构，而不是被纹理或遮挡误导。

## 10. Matrix-Ready Summary

| 维度 | 内容 |
|---|---|
| 核心任务 | Sparse input 3DGS NVS |
| 输入 | Sparse posed images, COLMAP points, DPT depth |
| 核心模块 | PCD initialization, SAOVS side-view sampling, DINO semantic loss, GAN loss |
| Depth 使用方式 | depth lift + point sampling for initialization, not depth loss |
| Side-view 策略 | position linear interpolation + direction SLERP |
| 训练损失 | 3DGS photometric + adversarial + semantic consistency |
| 主要优势 | 改善初始点云，降低直接 depth regularization 噪声 |
| 主要风险 | DPT depth error、SfM alignment、side-view path assumption |

## 11. Reusable Components for My Research

1. 将 depth prior 用作 initialization 而非 loss，可以减少错误 depth 在后期优化中的持续影响。
2. point sampling rate 是控制 prior noise 的简单旋钮，可与 depth uncertainty map 结合做非均匀采样。
3. SAOVS 的 position interpolation + direction SLERP 可复用到 sparse-view pseudo-view generation。
4. DINO semantic consistency 可作为生成视图或 side views 的 weak supervision，尤其适合 occluded objects 的全局结构保持。
5. GAN loss 可以只施加在 side-view renderings 上，用来补充 photometric loss 无法约束的局部纹理。

## 12. Gap and Idea Seeds

1. 用 depth confidence 或 multi-model depth ensemble 替代随机采样 PCD points，保留高置信区域并降低错误点。
2. 将 PCD 与 MVSplat / DUSt3R depth 融合，用 multi-view consistent depth 替代单目 DPT。
3. 把 SAOVS 的 side-view sampling 改成 visibility-aware sampling，避开大面积不可见区域或空洞。
4. 用 CLIP / DINOv2 / SAM features 做 region-level semantic consistency，减少随机 crop 不稳定性。
5. 将 PCD 初始化后接 DropGaussian / DropoutGS，先增密再用结构正则剪掉不可靠 Gaussians。

## 13. Human Check List

* NEED_HUMAN_CHECK: 论文主文未给出 PCD affine transformation 的具体求解细节，复现时需查看代码或补充材料。
* NEED_HUMAN_CHECK: DPT depth 的归一化、ray construction 的坐标约定和 point sampling rate 搜索范围需要核对实现。
* NEED_HUMAN_CHECK: discriminator 结构和 differentiable augmentation 配置未在主文充分展开。
* 已确认：公式格式按仓库 inline / display dollar 规范书写。

## 14. Evidence Anchors

* Abstract: 提出 PCD、SAOVS，并报告 ScanNet / LLFF 上优于 3DGS。
* Introduction: 说明 depth regularization 对 depth accuracy 敏感，并提出把 depth prior 用于 point cloud initialization。
* Figure 1 and Section 3.2: 总体 pipeline，先 PCD 初始化，再用 side-view semantic prior training。
* Section 3.3: 3D points lifting、point set alignment、point sampling，以及 DPT / SfM 对齐动机。
* Section 3.4: SAOVS 的 camera position linear interpolation、direction SLERP 和 progressive training。
* Section 3.5: DINO semantic consistency loss、GAN loss、total loss Eq. 12。
* Table 1: ScanNet 主结果，本文平均 20.48 PSNR / 0.73 SSIM / 0.37 LPIPS。
* Table 2: LLFF 主结果和 PCD / semantic / adversarial 消融。
* Table 3: RPDS、LRDS、SAOVS side-view sampling 对比。
* Section 4.4 and Figure 8: PCD sampling rate 过高会因 inaccurate depth degradation。
