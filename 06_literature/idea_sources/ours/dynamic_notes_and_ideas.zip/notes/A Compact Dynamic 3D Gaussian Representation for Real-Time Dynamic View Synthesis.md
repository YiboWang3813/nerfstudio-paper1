# A Compact Dynamic 3D Gaussian Representation for Real-Time Dynamic View Synthesis

## 0. Metadata

- Paper title: A Compact Dynamic 3D Gaussian Representation for Real-Time Dynamic View Synthesis
- Authors: Kai Katsumata; Duc Minh Vo; Hideki Nakayama
- Venue / year: ECCV 2024 / Springer LNCS 2025
- DOI: `10.1007/978-3-031-73016-0_23`
- Zotero item key: `ZCZEX7R7`
- Zotero PDF attachment key: `LLVIB2IW`
- Zotero PDF path: `/Users/wangyibo/Zotero/storage/LLVIB2IW/Katsumata 等 - 2025 - A Compact Dynamic 3D Gaussian Representation for Real-Time Dynamic View Synthesis.pdf`
- Local note path: `notes/A Compact Dynamic 3D Gaussian Representation for Real-Time Dynamic View Synthesis.md`

## 1. One-Sentence Technical Summary

本文用少量时间函数参数表示每个 Gaussian 的中心和旋转：位置用 Fourier approximation、旋转用线性 quaternion approximation，scale/color/opacity 保持时间不变，并加入 optical-flow supervision，从而以紧凑内存实现 monocular/few-view 动态场景的实时 3DGS 渲染。

## 2. Problem Formulation

标准 3DGS 面向静态场景；若动态扩展为每个 timestep 都存 Gaussian position 和 rotation，则内存随视频长度 $T$ 线性增长，复杂度为 $O(TN)$，其中 $N$ 是 Gaussian 数量。这也要求每个 timestep 有足够多视角观测，否则 monocular/few-view 场景下每帧参数容易欠约束。

本文目标是在不引入 MLP deformation field 的情况下，用 explicit 3D Gaussian representation 表示动态场景，既保持 3DGS 的高速 rasterization 和编辑能力，又避免 per-timestep 参数存储。

## 3. Method Overview

每个 Gaussian 被分成 time-varying 和 time-invariant parameters。Time-varying 只包括 center position $\mu(t)$ 和 rotation $R(t)$；time-invariant 包括 scale $s$、SH color coefficients $h$ 和 opacity $o$。位置用 Fourier series 近似，旋转 quaternion 用线性函数近似后归一化。

优化上，先进行 static stage：把所有帧当作静态多视角观测，只优化时间不变属性和 position/rotation 的 intercepts，学习一个稳定 Gaussian prior。随后进入 dynamic stage：优化所有 Fourier/linear coefficients 来拟合动态变化。为缓解 monocular/few-view 的时间歧义，作者用 RAFT 估计相邻帧 optical flow，并把 Gaussian-induced 2D flow 与 ground-truth flow 对齐。

## 4. Method Details

### 4.1 Dynamic Gaussian Parameters

每个 dynamic Gaussian 包含：

- 3D center at time $t$: $\mu(t)=[x(t),y(t),z(t)]^T$。
- Quaternion rotation at time $t$: $q(t)=[q_x(t),q_y(t),q_z(t),q_w(t)]^T$。
- Time-invariant scale $[s_x,s_y,s_z]^T$。
- SH coefficients $h\in\mathbb{R}^{3\times(k+1)^2}$。
- Opacity $o\in\mathbb{R}$。

Gaussian density 为：

$$
G_t(x)=\exp\left(-\frac{1}{2}(x-\mu(t))^T\Sigma(t)^{-1}(x-\mu(t))\right).
$$

covariance 分解为：

$$
\Sigma(t)=R(t)SS^TR(t)^T,\qquad S=\operatorname{diag}(s_x,s_y,s_z).
$$

Scale 被固定为时间不变，因为多数动态场景中的实体不会显著膨胀或收缩；这减少模型大小，也保留较高渲染速度。

### 4.2 Fourier Position Approximation

位置用 $L$ 个 harmonic terms 的 Fourier approximation 表示：

$$
x(t)=w_{x,0}+\sum_{i=1}^{L}w_{x,2i-1}\sin(2i\pi t)+w_{x,2i}\cos(2i\pi t),
$$

$$
y(t)=w_{y,0}+\sum_{i=1}^{L}w_{y,2i-1}\sin(2i\pi t)+w_{y,2i}\cos(2i\pi t),
$$

$$
z(t)=w_{z,0}+\sum_{i=1}^{L}w_{z,2i-1}\sin(2i\pi t)+w_{z,2i}\cos(2i\pi t).
$$

作者比较了 polynomial、spline 和 Fourier。Polynomial 在低阶时欠拟合，高阶时过拟合；spline 有时略有提升但渲染更慢。实验中 $L=2$ 的平均效果最好，但某些复杂运动场景更高 $L$ 可提升质量。

### 4.3 Linear Quaternion Approximation

旋转 quaternion 用线性函数近似：

$$
q_x(t)=w_{q_x,0}+w_{q_x,1}t,\qquad
q_y(t)=w_{q_y,0}+w_{q_y,1}t,
$$

$$
q_z(t)=w_{q_z,0}+w_{q_z,1}t,\qquad
q_w(t)=w_{q_w,0}+w_{q_w,1}t.
$$

然后做单位化：

$$
q(t)\leftarrow \frac{q(t)}{\lVert q(t)\rVert}.
$$

作者也考虑过 slerp，但没有带来性能收益，且对静态 Gaussians 会造成数值不稳定，因此采用线性近似。

### 4.4 Rendering

给定 viewing transform $W$，3D covariance 投影为 2D covariance：

$$
\Sigma'(t)=JW\Sigma(t)W^TJ^T.
$$

Jacobian 为：

$$
J=
\begin{bmatrix}
\frac{1}{v_z} & 0 & -\frac{v_x}{v_z^2}\\
0 & \frac{1}{v_z} & -\frac{v_y}{v_z^2}\\
0 & 0 & 0
\end{bmatrix},
$$

其中 $[v_x,v_y,v_z]^T=W\mu(t)$。像素颜色通过 depth-ordered alpha blending 计算：

$$
C=\sum_{i=1}^{N}c_i\alpha_i\prod_{j=1}^{i-1}(1-\alpha_j).
$$

该渲染仍是标准 3DGS rasterization，因此保持高 FPS。

### 4.5 Image Reconstruction and Densification

图像重建损失为：

$$
L_{\mathrm{recon}}=(1-\lambda)\lVert \hat{I}-I\rVert_1+\lambda L_{\mathrm{D\text{-}SSIM}}.
$$

论文沿用 3DGS 的 densify/prune：大梯度大 scale 的 Gaussians 被 split，大梯度小 scale 的 Gaussians 被 clone；opacity 小于 0.005 的透明 Gaussians 被移除。真实场景用 SfM sparse points 初始化，synthetic scenes 因没有 prior 使用 uniform random initialization。

### 4.6 Flow Supervision

为了缓解每个 timestep 观测少导致的歧义，作者用 RAFT 从输入相邻帧估计 forward/backward optical flow，并监督 Gaussian motion 的投影 2D flow。提取文本在具体公式处截断，但方法描述明确：$L_{\mathrm{flow}}$ 是 Gaussian-induced flows 与 ground-truth flows 之间的 $L_1$ loss。

总训练目标可概括为：

$$
L=L_{\mathrm{recon}}+\lambda_{\mathrm{flow}}L_{\mathrm{flow}}.
$$

实现中 $\lambda=0.2$，$\lambda_{\mathrm{flow}}=1000$，RAFT 使用 Sintel pretrained model。

## 5. Mathematical Objectives and Losses

核心数学目标是用少量参数函数拟合 $\mu(t)$ 和 $q(t)$，并通过图像与光流联合监督：

$$
\min_{\{w,s,h,o\}}\sum_{t,c}L_{\mathrm{recon}}(\hat{I}_{t,c},I_{t,c})+\lambda_{\mathrm{flow}}L_{\mathrm{flow}}.
$$

该式中 $w$ 包含 Fourier position coefficients 和 linear quaternion coefficients，$s,h,o$ 是时间不变 scale、SH color 和 opacity。空间复杂度由 $O(TN)$ 降到 $O(LN)$，其中 $L$ 是近似函数参数数量，通常 $L<T$。

## 6. Training and Inference Procedure

训练采用两阶段，整个优化 30,000 iterations。Static stage 前 3,000 iterations：把捕获 frames 当作静态场景，只优化 scale、SH、opacity，以及 center/rotation 的 intercepts。Dynamic stage 后 27,000 iterations：优化所有 Gaussian parameters，包括 Fourier 和 linear coefficients。

推理时，对任意时间 $t$ 计算每个 Gaussian 的 $\mu(t)$ 和 $q(t)$，构造 $\Sigma(t)$，再用 3DGS rasterizer 渲染目标视角。由于不需要 per-timestep parameter lookup 或 MLP deformation query，渲染速度接近静态 3DGS。

## 7. Experimental Setup and Results Summary

实验覆盖 D-NeRF、DyNeRF 和 HyperNeRF。比较方法包括 TiNeuVox、K-Planes、V4D、HyperNeRF、3DGS、Dynamic3DGaussians 和 D-3DGS baseline。指标包括 PSNR、SSIM、LPIPS、FPS、training time 和 parameter memory。

在 HyperNeRF 上，本文平均 PSNR/SSIM 为 25.6/0.890，高于 HyperNeRF 22.2/0.811、TiNeuVox-B 24.3/0.837、V4D 24.7/0.827；FPS 为 188，训练约 1 小时，memory 约 720 MB。论文摘要报告在 1352 x 1014 分辨率单 GPU 上达到 118 FPS。

D-NeRF 上，本文质量与 TiNeuVox/K-Planes 竞争，同时渲染速度显著更快；DyNeRF 多视角场景中 D-3DGS 的质量较强，但本文 FPS 优势明显。Flow loss 消融显示它能缓解 ghost artifacts 并改善颜色重建。设计消融显示 $L=2$ 的 Fourier position approximation 平均表现最好，Spline 和 time-varying scale 只带来有限收益且增加速度或内存成本。

## 8. Claimed Contribution vs Actual Technical Delta

论文声称贡献是 compact dynamic 3D Gaussian representation，用 time-varying functions 表示 Gaussian center/rotation，而非每帧存一套 Gaussian parameters。实际增量非常清晰：把动态性限制在 position 和 rotation 的低维时间函数中，保留 scale/color/opacity 的静态性，从而在 monocular/few-view 下获得更强正则和更低内存。

与 deformation MLP 方法相比，它更显式、更快，但表达能力较受限。与 Dynamic 3D Gaussians per-timestep 存储相比，它牺牲部分灵活性换取内存和 sparse-view robustness。Flow loss 是对单目动态歧义的实用补充。

## 9. Limitations / Assumptions

表示假设所有 Gaussians 在整个时间范围内都存在，因此难以建模 topology changes、物体出现/消失或流体破碎。论文也明确指出 Gaussian lifetime，如 start/end time，是未来方向。

Color 和 opacity 时间不变，难以表达 illumination、反射或材质颜色随时间变化。若视频很长或 motion 很复杂，固定小 $L$ 的 Fourier approximation 会欠拟合；增加 $L$ 又会提高内存并可能过拟合。

离散 Gaussian primitives 有时会导致 smooth boundary 表现不如连续 neural field；论文建议未来可借鉴 PlenOctree-style distillation 来结合 NeRF 质量与 Gaussian 速度。

## 10. Matrix-Ready Summary

| Dimension | Entry |
|---|---|
| Task | Real-time dynamic view synthesis |
| Input | Monocular or multi-view dynamic videos with camera poses |
| Representation | Dynamic 3D Gaussians with time functions |
| Time-varying parameters | Position and rotation |
| Time-invariant parameters | Scale, SH color, opacity |
| Position model | Fourier approximation |
| Rotation model | Linear quaternion approximation + normalization |
| Extra supervision | RAFT optical flow loss |
| Training | Static stage then dynamic stage |
| Main advantage | Compact memory and high FPS without MLP deformation |
| Main limitation | Hard topology/color/lifetime changes |

## 11. Reusable Components

- Fourier trajectory parameterization for Gaussian centers.
- Linear quaternion approximation for lightweight dynamic rotation.
- Static-then-dynamic training schedule for few-view dynamic 3DGS.
- Flow-supervised Gaussian motion for monocular temporal consistency.
- Design-space comparison of Fourier, polynomial, spline and time-varying scale.

## 12. Gap / Idea Seeds

- Add learnable Gaussian lifetime parameters to handle appearance/disappearance.
- Use adaptive $L$ per Gaussian: static regions $L=0$, simple motion $L=1/2$, complex motion higher.
- Add low-rank time-varying color/opacity for illumination changes without full per-frame storage.
- Combine compact trajectories with local deformation residuals for complex non-rigid motion.
- Use scene/object segmentation to assign different trajectory bases to different motion classes.

## 13. Human Check List

- NEED_HUMAN_CHECK: Zotero authors include LNCS editors before actual paper authors; final citation should use Kai Katsumata, Duc Minh Vo, Hideki Nakayama.
- NEED_HUMAN_CHECK: Extracted text truncates exact $L_{\mathrm{flow}}$ formula; verify from PDF if implementing.
- NEED_HUMAN_CHECK: Confirm whether reporting venue should be ECCV 2024 or Springer book date 2025 in downstream bibliography.

## 14. Evidence Anchors

- Abstract and Introduction: compact time-function representation, monocular/few-view motivation, 118 FPS claim.
- Section 3.1: dynamic Gaussian parameters, Fourier position approximation, linear quaternion approximation.
- Section 3.2: 2D covariance projection and alpha blending rendering.
- Section 3.3: reconstruction loss, densify/prune, two-stage training, RAFT flow loss.
- Tables 1-4: D-NeRF/DyNeRF/HyperNeRF comparisons, design ablations for $L$, spline and scale.
- Discussion: topology, color, long sequence and smoothness limitations.
